function getRowstblanimation(){
	var tblanimationdata = [];
	tblanimationrows = $("#tblanimation tbody tr");
tblanimationrows.each(function (index) {
    var tblanimationrow = $(this);
 	var tblanimationobj = {};
	var vProperty = tblanimationrow.find("[name=Property]").text();
			tblanimationobj['Property'] = vProperty;
			tblanimationobj['index'] = index;
var vType = tblanimationrow.find("[name=Type]").text();
			tblanimationobj['Type'] = vType;
			tblanimationobj['index'] = index;
var vDefaultValue = tblanimationrow.find("[name=DefaultValue]").text();
			tblanimationobj['DefaultValue'] = vDefaultValue;
			tblanimationobj['index'] = index;
var vDescription = tblanimationrow.find("[name=Description]").text();
			tblanimationobj['Description'] = vDescription;
			tblanimationobj['index'] = index;

	tblanimationdata.push(tblanimationobj);
});
return tblanimationdata;
	}
function getRowsmethodanimation(){
	var methodanimationdata = [];
	methodanimationrows = $("#methodanimation tbody tr");
methodanimationrows.each(function (index) {
    var methodanimationrow = $(this);
 	var methodanimationobj = {};
	var vMethod = methodanimationrow.find("[name=Method]").text();
			methodanimationobj['Method'] = vMethod;
			methodanimationobj['index'] = index;
var vParameters = methodanimationrow.find("[name=Parameters]").text();
			methodanimationobj['Parameters'] = vParameters;
			methodanimationobj['index'] = index;
var vReturnType = methodanimationrow.find("[name=ReturnType]").text();
			methodanimationobj['ReturnType'] = vReturnType;
			methodanimationobj['index'] = index;
var vDescription = methodanimationrow.find("[name=Description]").text();
			methodanimationobj['Description'] = vDescription;
			methodanimationobj['index'] = index;

	methodanimationdata.push(methodanimationobj);
});
return methodanimationdata;
	}
function getRowstblcssanimation(){
	var tblcssanimationdata = [];
	tblcssanimationrows = $("#tblcssanimation tbody tr");
tblcssanimationrows.each(function (index) {
    var tblcssanimationrow = $(this);
 	var tblcssanimationobj = {};
	var vProperty = tblcssanimationrow.find("[name=Property]").text();
			tblcssanimationobj['Property'] = vProperty;
			tblcssanimationobj['index'] = index;
var vType = tblcssanimationrow.find("[name=Type]").text();
			tblcssanimationobj['Type'] = vType;
			tblcssanimationobj['index'] = index;
var vDefaultValue = tblcssanimationrow.find("[name=DefaultValue]").text();
			tblcssanimationobj['DefaultValue'] = vDefaultValue;
			tblcssanimationobj['index'] = index;
var vDescription = tblcssanimationrow.find("[name=Description]").text();
			tblcssanimationobj['Description'] = vDescription;
			tblcssanimationobj['index'] = index;

	tblcssanimationdata.push(tblcssanimationobj);
});
return tblcssanimationdata;
	}
function getRowsmethodcssanimation(){
	var methodcssanimationdata = [];
	methodcssanimationrows = $("#methodcssanimation tbody tr");
methodcssanimationrows.each(function (index) {
    var methodcssanimationrow = $(this);
 	var methodcssanimationobj = {};
	var vMethod = methodcssanimationrow.find("[name=Method]").text();
			methodcssanimationobj['Method'] = vMethod;
			methodcssanimationobj['index'] = index;
var vParameters = methodcssanimationrow.find("[name=Parameters]").text();
			methodcssanimationobj['Parameters'] = vParameters;
			methodcssanimationobj['index'] = index;
var vReturnType = methodcssanimationrow.find("[name=ReturnType]").text();
			methodcssanimationobj['ReturnType'] = vReturnType;
			methodcssanimationobj['index'] = index;
var vDescription = methodcssanimationrow.find("[name=Description]").text();
			methodcssanimationobj['Description'] = vDescription;
			methodcssanimationobj['index'] = index;

	methodcssanimationdata.push(methodcssanimationobj);
});
return methodcssanimationdata;
	}
function getRowstblcssanimationdirection(){
	var tblcssanimationdirectiondata = [];
	tblcssanimationdirectionrows = $("#tblcssanimationdirection tbody tr");
tblcssanimationdirectionrows.each(function (index) {
    var tblcssanimationdirectionrow = $(this);
 	var tblcssanimationdirectionobj = {};
	var vProperty = tblcssanimationdirectionrow.find("[name=Property]").text();
			tblcssanimationdirectionobj['Property'] = vProperty;
			tblcssanimationdirectionobj['index'] = index;
var vType = tblcssanimationdirectionrow.find("[name=Type]").text();
			tblcssanimationdirectionobj['Type'] = vType;
			tblcssanimationdirectionobj['index'] = index;
var vDefaultValue = tblcssanimationdirectionrow.find("[name=DefaultValue]").text();
			tblcssanimationdirectionobj['DefaultValue'] = vDefaultValue;
			tblcssanimationdirectionobj['index'] = index;
var vDescription = tblcssanimationdirectionrow.find("[name=Description]").text();
			tblcssanimationdirectionobj['Description'] = vDescription;
			tblcssanimationdirectionobj['index'] = index;

	tblcssanimationdirectiondata.push(tblcssanimationdirectionobj);
});
return tblcssanimationdirectiondata;
	}
function getRowsmethodcssanimationdirection(){
	var methodcssanimationdirectiondata = [];
	methodcssanimationdirectionrows = $("#methodcssanimationdirection tbody tr");
methodcssanimationdirectionrows.each(function (index) {
    var methodcssanimationdirectionrow = $(this);
 	var methodcssanimationdirectionobj = {};
	var vMethod = methodcssanimationdirectionrow.find("[name=Method]").text();
			methodcssanimationdirectionobj['Method'] = vMethod;
			methodcssanimationdirectionobj['index'] = index;
var vParameters = methodcssanimationdirectionrow.find("[name=Parameters]").text();
			methodcssanimationdirectionobj['Parameters'] = vParameters;
			methodcssanimationdirectionobj['index'] = index;
var vReturnType = methodcssanimationdirectionrow.find("[name=ReturnType]").text();
			methodcssanimationdirectionobj['ReturnType'] = vReturnType;
			methodcssanimationdirectionobj['index'] = index;
var vDescription = methodcssanimationdirectionrow.find("[name=Description]").text();
			methodcssanimationdirectionobj['Description'] = vDescription;
			methodcssanimationdirectionobj['index'] = index;

	methodcssanimationdirectiondata.push(methodcssanimationdirectionobj);
});
return methodcssanimationdirectiondata;
	}
function getRowstblcssbackground(){
	var tblcssbackgrounddata = [];
	tblcssbackgroundrows = $("#tblcssbackground tbody tr");
tblcssbackgroundrows.each(function (index) {
    var tblcssbackgroundrow = $(this);
 	var tblcssbackgroundobj = {};
	var vProperty = tblcssbackgroundrow.find("[name=Property]").text();
			tblcssbackgroundobj['Property'] = vProperty;
			tblcssbackgroundobj['index'] = index;
var vType = tblcssbackgroundrow.find("[name=Type]").text();
			tblcssbackgroundobj['Type'] = vType;
			tblcssbackgroundobj['index'] = index;
var vDefaultValue = tblcssbackgroundrow.find("[name=DefaultValue]").text();
			tblcssbackgroundobj['DefaultValue'] = vDefaultValue;
			tblcssbackgroundobj['index'] = index;
var vDescription = tblcssbackgroundrow.find("[name=Description]").text();
			tblcssbackgroundobj['Description'] = vDescription;
			tblcssbackgroundobj['index'] = index;

	tblcssbackgrounddata.push(tblcssbackgroundobj);
});
return tblcssbackgrounddata;
	}
function getRowsmethodcssbackground(){
	var methodcssbackgrounddata = [];
	methodcssbackgroundrows = $("#methodcssbackground tbody tr");
methodcssbackgroundrows.each(function (index) {
    var methodcssbackgroundrow = $(this);
 	var methodcssbackgroundobj = {};
	var vMethod = methodcssbackgroundrow.find("[name=Method]").text();
			methodcssbackgroundobj['Method'] = vMethod;
			methodcssbackgroundobj['index'] = index;
var vParameters = methodcssbackgroundrow.find("[name=Parameters]").text();
			methodcssbackgroundobj['Parameters'] = vParameters;
			methodcssbackgroundobj['index'] = index;
var vReturnType = methodcssbackgroundrow.find("[name=ReturnType]").text();
			methodcssbackgroundobj['ReturnType'] = vReturnType;
			methodcssbackgroundobj['index'] = index;
var vDescription = methodcssbackgroundrow.find("[name=Description]").text();
			methodcssbackgroundobj['Description'] = vDescription;
			methodcssbackgroundobj['index'] = index;

	methodcssbackgrounddata.push(methodcssbackgroundobj);
});
return methodcssbackgrounddata;
	}
function getRowstblcssborder(){
	var tblcssborderdata = [];
	tblcssborderrows = $("#tblcssborder tbody tr");
tblcssborderrows.each(function (index) {
    var tblcssborderrow = $(this);
 	var tblcssborderobj = {};
	var vProperty = tblcssborderrow.find("[name=Property]").text();
			tblcssborderobj['Property'] = vProperty;
			tblcssborderobj['index'] = index;
var vType = tblcssborderrow.find("[name=Type]").text();
			tblcssborderobj['Type'] = vType;
			tblcssborderobj['index'] = index;
var vDefaultValue = tblcssborderrow.find("[name=DefaultValue]").text();
			tblcssborderobj['DefaultValue'] = vDefaultValue;
			tblcssborderobj['index'] = index;
var vDescription = tblcssborderrow.find("[name=Description]").text();
			tblcssborderobj['Description'] = vDescription;
			tblcssborderobj['index'] = index;

	tblcssborderdata.push(tblcssborderobj);
});
return tblcssborderdata;
	}
function getRowsmethodcssborder(){
	var methodcssborderdata = [];
	methodcssborderrows = $("#methodcssborder tbody tr");
methodcssborderrows.each(function (index) {
    var methodcssborderrow = $(this);
 	var methodcssborderobj = {};
	var vMethod = methodcssborderrow.find("[name=Method]").text();
			methodcssborderobj['Method'] = vMethod;
			methodcssborderobj['index'] = index;
var vParameters = methodcssborderrow.find("[name=Parameters]").text();
			methodcssborderobj['Parameters'] = vParameters;
			methodcssborderobj['index'] = index;
var vReturnType = methodcssborderrow.find("[name=ReturnType]").text();
			methodcssborderobj['ReturnType'] = vReturnType;
			methodcssborderobj['index'] = index;
var vDescription = methodcssborderrow.find("[name=Description]").text();
			methodcssborderobj['Description'] = vDescription;
			methodcssborderobj['index'] = index;

	methodcssborderdata.push(methodcssborderobj);
});
return methodcssborderdata;
	}
function getRowstblcssborderimage(){
	var tblcssborderimagedata = [];
	tblcssborderimagerows = $("#tblcssborderimage tbody tr");
tblcssborderimagerows.each(function (index) {
    var tblcssborderimagerow = $(this);
 	var tblcssborderimageobj = {};
	var vProperty = tblcssborderimagerow.find("[name=Property]").text();
			tblcssborderimageobj['Property'] = vProperty;
			tblcssborderimageobj['index'] = index;
var vType = tblcssborderimagerow.find("[name=Type]").text();
			tblcssborderimageobj['Type'] = vType;
			tblcssborderimageobj['index'] = index;
var vDefaultValue = tblcssborderimagerow.find("[name=DefaultValue]").text();
			tblcssborderimageobj['DefaultValue'] = vDefaultValue;
			tblcssborderimageobj['index'] = index;
var vDescription = tblcssborderimagerow.find("[name=Description]").text();
			tblcssborderimageobj['Description'] = vDescription;
			tblcssborderimageobj['index'] = index;

	tblcssborderimagedata.push(tblcssborderimageobj);
});
return tblcssborderimagedata;
	}
function getRowsmethodcssborderimage(){
	var methodcssborderimagedata = [];
	methodcssborderimagerows = $("#methodcssborderimage tbody tr");
methodcssborderimagerows.each(function (index) {
    var methodcssborderimagerow = $(this);
 	var methodcssborderimageobj = {};
	var vMethod = methodcssborderimagerow.find("[name=Method]").text();
			methodcssborderimageobj['Method'] = vMethod;
			methodcssborderimageobj['index'] = index;
var vParameters = methodcssborderimagerow.find("[name=Parameters]").text();
			methodcssborderimageobj['Parameters'] = vParameters;
			methodcssborderimageobj['index'] = index;
var vReturnType = methodcssborderimagerow.find("[name=ReturnType]").text();
			methodcssborderimageobj['ReturnType'] = vReturnType;
			methodcssborderimageobj['index'] = index;
var vDescription = methodcssborderimagerow.find("[name=Description]").text();
			methodcssborderimageobj['Description'] = vDescription;
			methodcssborderimageobj['index'] = index;

	methodcssborderimagedata.push(methodcssborderimageobj);
});
return methodcssborderimagedata;
	}
function getRowstblcssborderstyle(){
	var tblcssborderstyledata = [];
	tblcssborderstylerows = $("#tblcssborderstyle tbody tr");
tblcssborderstylerows.each(function (index) {
    var tblcssborderstylerow = $(this);
 	var tblcssborderstyleobj = {};
	var vProperty = tblcssborderstylerow.find("[name=Property]").text();
			tblcssborderstyleobj['Property'] = vProperty;
			tblcssborderstyleobj['index'] = index;
var vType = tblcssborderstylerow.find("[name=Type]").text();
			tblcssborderstyleobj['Type'] = vType;
			tblcssborderstyleobj['index'] = index;
var vDefaultValue = tblcssborderstylerow.find("[name=DefaultValue]").text();
			tblcssborderstyleobj['DefaultValue'] = vDefaultValue;
			tblcssborderstyleobj['index'] = index;
var vDescription = tblcssborderstylerow.find("[name=Description]").text();
			tblcssborderstyleobj['Description'] = vDescription;
			tblcssborderstyleobj['index'] = index;

	tblcssborderstyledata.push(tblcssborderstyleobj);
});
return tblcssborderstyledata;
	}
function getRowsmethodcssborderstyle(){
	var methodcssborderstyledata = [];
	methodcssborderstylerows = $("#methodcssborderstyle tbody tr");
methodcssborderstylerows.each(function (index) {
    var methodcssborderstylerow = $(this);
 	var methodcssborderstyleobj = {};
	var vMethod = methodcssborderstylerow.find("[name=Method]").text();
			methodcssborderstyleobj['Method'] = vMethod;
			methodcssborderstyleobj['index'] = index;
var vParameters = methodcssborderstylerow.find("[name=Parameters]").text();
			methodcssborderstyleobj['Parameters'] = vParameters;
			methodcssborderstyleobj['index'] = index;
var vReturnType = methodcssborderstylerow.find("[name=ReturnType]").text();
			methodcssborderstyleobj['ReturnType'] = vReturnType;
			methodcssborderstyleobj['index'] = index;
var vDescription = methodcssborderstylerow.find("[name=Description]").text();
			methodcssborderstyleobj['Description'] = vDescription;
			methodcssborderstyleobj['index'] = index;

	methodcssborderstyledata.push(methodcssborderstyleobj);
});
return methodcssborderstyledata;
	}
function getRowstblcssbox(){
	var tblcssboxdata = [];
	tblcssboxrows = $("#tblcssbox tbody tr");
tblcssboxrows.each(function (index) {
    var tblcssboxrow = $(this);
 	var tblcssboxobj = {};
	var vProperty = tblcssboxrow.find("[name=Property]").text();
			tblcssboxobj['Property'] = vProperty;
			tblcssboxobj['index'] = index;
var vType = tblcssboxrow.find("[name=Type]").text();
			tblcssboxobj['Type'] = vType;
			tblcssboxobj['index'] = index;
var vDefaultValue = tblcssboxrow.find("[name=DefaultValue]").text();
			tblcssboxobj['DefaultValue'] = vDefaultValue;
			tblcssboxobj['index'] = index;
var vDescription = tblcssboxrow.find("[name=Description]").text();
			tblcssboxobj['Description'] = vDescription;
			tblcssboxobj['index'] = index;

	tblcssboxdata.push(tblcssboxobj);
});
return tblcssboxdata;
	}
function getRowsmethodcssbox(){
	var methodcssboxdata = [];
	methodcssboxrows = $("#methodcssbox tbody tr");
methodcssboxrows.each(function (index) {
    var methodcssboxrow = $(this);
 	var methodcssboxobj = {};
	var vMethod = methodcssboxrow.find("[name=Method]").text();
			methodcssboxobj['Method'] = vMethod;
			methodcssboxobj['index'] = index;
var vParameters = methodcssboxrow.find("[name=Parameters]").text();
			methodcssboxobj['Parameters'] = vParameters;
			methodcssboxobj['index'] = index;
var vReturnType = methodcssboxrow.find("[name=ReturnType]").text();
			methodcssboxobj['ReturnType'] = vReturnType;
			methodcssboxobj['index'] = index;
var vDescription = methodcssboxrow.find("[name=Description]").text();
			methodcssboxobj['Description'] = vDescription;
			methodcssboxobj['index'] = index;

	methodcssboxdata.push(methodcssboxobj);
});
return methodcssboxdata;
	}
function getRowstblcssfilter(){
	var tblcssfilterdata = [];
	tblcssfilterrows = $("#tblcssfilter tbody tr");
tblcssfilterrows.each(function (index) {
    var tblcssfilterrow = $(this);
 	var tblcssfilterobj = {};
	var vProperty = tblcssfilterrow.find("[name=Property]").text();
			tblcssfilterobj['Property'] = vProperty;
			tblcssfilterobj['index'] = index;
var vType = tblcssfilterrow.find("[name=Type]").text();
			tblcssfilterobj['Type'] = vType;
			tblcssfilterobj['index'] = index;
var vDefaultValue = tblcssfilterrow.find("[name=DefaultValue]").text();
			tblcssfilterobj['DefaultValue'] = vDefaultValue;
			tblcssfilterobj['index'] = index;
var vDescription = tblcssfilterrow.find("[name=Description]").text();
			tblcssfilterobj['Description'] = vDescription;
			tblcssfilterobj['index'] = index;

	tblcssfilterdata.push(tblcssfilterobj);
});
return tblcssfilterdata;
	}
function getRowsmethodcssfilter(){
	var methodcssfilterdata = [];
	methodcssfilterrows = $("#methodcssfilter tbody tr");
methodcssfilterrows.each(function (index) {
    var methodcssfilterrow = $(this);
 	var methodcssfilterobj = {};
	var vMethod = methodcssfilterrow.find("[name=Method]").text();
			methodcssfilterobj['Method'] = vMethod;
			methodcssfilterobj['index'] = index;
var vParameters = methodcssfilterrow.find("[name=Parameters]").text();
			methodcssfilterobj['Parameters'] = vParameters;
			methodcssfilterobj['index'] = index;
var vReturnType = methodcssfilterrow.find("[name=ReturnType]").text();
			methodcssfilterobj['ReturnType'] = vReturnType;
			methodcssfilterobj['index'] = index;
var vDescription = methodcssfilterrow.find("[name=Description]").text();
			methodcssfilterobj['Description'] = vDescription;
			methodcssfilterobj['index'] = index;

	methodcssfilterdata.push(methodcssfilterobj);
});
return methodcssfilterdata;
	}
function getRowstblcssfont(){
	var tblcssfontdata = [];
	tblcssfontrows = $("#tblcssfont tbody tr");
tblcssfontrows.each(function (index) {
    var tblcssfontrow = $(this);
 	var tblcssfontobj = {};
	var vProperty = tblcssfontrow.find("[name=Property]").text();
			tblcssfontobj['Property'] = vProperty;
			tblcssfontobj['index'] = index;
var vType = tblcssfontrow.find("[name=Type]").text();
			tblcssfontobj['Type'] = vType;
			tblcssfontobj['index'] = index;
var vDefaultValue = tblcssfontrow.find("[name=DefaultValue]").text();
			tblcssfontobj['DefaultValue'] = vDefaultValue;
			tblcssfontobj['index'] = index;
var vDescription = tblcssfontrow.find("[name=Description]").text();
			tblcssfontobj['Description'] = vDescription;
			tblcssfontobj['index'] = index;

	tblcssfontdata.push(tblcssfontobj);
});
return tblcssfontdata;
	}
function getRowsmethodcssfont(){
	var methodcssfontdata = [];
	methodcssfontrows = $("#methodcssfont tbody tr");
methodcssfontrows.each(function (index) {
    var methodcssfontrow = $(this);
 	var methodcssfontobj = {};
	var vMethod = methodcssfontrow.find("[name=Method]").text();
			methodcssfontobj['Method'] = vMethod;
			methodcssfontobj['index'] = index;
var vParameters = methodcssfontrow.find("[name=Parameters]").text();
			methodcssfontobj['Parameters'] = vParameters;
			methodcssfontobj['index'] = index;
var vReturnType = methodcssfontrow.find("[name=ReturnType]").text();
			methodcssfontobj['ReturnType'] = vReturnType;
			methodcssfontobj['index'] = index;
var vDescription = methodcssfontrow.find("[name=Description]").text();
			methodcssfontobj['Description'] = vDescription;
			methodcssfontobj['index'] = index;

	methodcssfontdata.push(methodcssfontobj);
});
return methodcssfontdata;
	}
function getRowstblcsslist(){
	var tblcsslistdata = [];
	tblcsslistrows = $("#tblcsslist tbody tr");
tblcsslistrows.each(function (index) {
    var tblcsslistrow = $(this);
 	var tblcsslistobj = {};
	var vProperty = tblcsslistrow.find("[name=Property]").text();
			tblcsslistobj['Property'] = vProperty;
			tblcsslistobj['index'] = index;
var vType = tblcsslistrow.find("[name=Type]").text();
			tblcsslistobj['Type'] = vType;
			tblcsslistobj['index'] = index;
var vDefaultValue = tblcsslistrow.find("[name=DefaultValue]").text();
			tblcsslistobj['DefaultValue'] = vDefaultValue;
			tblcsslistobj['index'] = index;
var vDescription = tblcsslistrow.find("[name=Description]").text();
			tblcsslistobj['Description'] = vDescription;
			tblcsslistobj['index'] = index;

	tblcsslistdata.push(tblcsslistobj);
});
return tblcsslistdata;
	}
function getRowsmethodcsslist(){
	var methodcsslistdata = [];
	methodcsslistrows = $("#methodcsslist tbody tr");
methodcsslistrows.each(function (index) {
    var methodcsslistrow = $(this);
 	var methodcsslistobj = {};
	var vMethod = methodcsslistrow.find("[name=Method]").text();
			methodcsslistobj['Method'] = vMethod;
			methodcsslistobj['index'] = index;
var vParameters = methodcsslistrow.find("[name=Parameters]").text();
			methodcsslistobj['Parameters'] = vParameters;
			methodcsslistobj['index'] = index;
var vReturnType = methodcsslistrow.find("[name=ReturnType]").text();
			methodcsslistobj['ReturnType'] = vReturnType;
			methodcsslistobj['index'] = index;
var vDescription = methodcsslistrow.find("[name=Description]").text();
			methodcsslistobj['Description'] = vDescription;
			methodcsslistobj['index'] = index;

	methodcsslistdata.push(methodcsslistobj);
});
return methodcsslistdata;
	}
function getRowstblcssoutline(){
	var tblcssoutlinedata = [];
	tblcssoutlinerows = $("#tblcssoutline tbody tr");
tblcssoutlinerows.each(function (index) {
    var tblcssoutlinerow = $(this);
 	var tblcssoutlineobj = {};
	var vProperty = tblcssoutlinerow.find("[name=Property]").text();
			tblcssoutlineobj['Property'] = vProperty;
			tblcssoutlineobj['index'] = index;
var vType = tblcssoutlinerow.find("[name=Type]").text();
			tblcssoutlineobj['Type'] = vType;
			tblcssoutlineobj['index'] = index;
var vDefaultValue = tblcssoutlinerow.find("[name=DefaultValue]").text();
			tblcssoutlineobj['DefaultValue'] = vDefaultValue;
			tblcssoutlineobj['index'] = index;
var vDescription = tblcssoutlinerow.find("[name=Description]").text();
			tblcssoutlineobj['Description'] = vDescription;
			tblcssoutlineobj['index'] = index;

	tblcssoutlinedata.push(tblcssoutlineobj);
});
return tblcssoutlinedata;
	}
function getRowsmethodcssoutline(){
	var methodcssoutlinedata = [];
	methodcssoutlinerows = $("#methodcssoutline tbody tr");
methodcssoutlinerows.each(function (index) {
    var methodcssoutlinerow = $(this);
 	var methodcssoutlineobj = {};
	var vMethod = methodcssoutlinerow.find("[name=Method]").text();
			methodcssoutlineobj['Method'] = vMethod;
			methodcssoutlineobj['index'] = index;
var vParameters = methodcssoutlinerow.find("[name=Parameters]").text();
			methodcssoutlineobj['Parameters'] = vParameters;
			methodcssoutlineobj['index'] = index;
var vReturnType = methodcssoutlinerow.find("[name=ReturnType]").text();
			methodcssoutlineobj['ReturnType'] = vReturnType;
			methodcssoutlineobj['index'] = index;
var vDescription = methodcssoutlinerow.find("[name=Description]").text();
			methodcssoutlineobj['Description'] = vDescription;
			methodcssoutlineobj['index'] = index;

	methodcssoutlinedata.push(methodcssoutlineobj);
});
return methodcssoutlinedata;
	}
function getRowstblcssoverflow(){
	var tblcssoverflowdata = [];
	tblcssoverflowrows = $("#tblcssoverflow tbody tr");
tblcssoverflowrows.each(function (index) {
    var tblcssoverflowrow = $(this);
 	var tblcssoverflowobj = {};
	var vProperty = tblcssoverflowrow.find("[name=Property]").text();
			tblcssoverflowobj['Property'] = vProperty;
			tblcssoverflowobj['index'] = index;
var vType = tblcssoverflowrow.find("[name=Type]").text();
			tblcssoverflowobj['Type'] = vType;
			tblcssoverflowobj['index'] = index;
var vDefaultValue = tblcssoverflowrow.find("[name=DefaultValue]").text();
			tblcssoverflowobj['DefaultValue'] = vDefaultValue;
			tblcssoverflowobj['index'] = index;
var vDescription = tblcssoverflowrow.find("[name=Description]").text();
			tblcssoverflowobj['Description'] = vDescription;
			tblcssoverflowobj['index'] = index;

	tblcssoverflowdata.push(tblcssoverflowobj);
});
return tblcssoverflowdata;
	}
function getRowsmethodcssoverflow(){
	var methodcssoverflowdata = [];
	methodcssoverflowrows = $("#methodcssoverflow tbody tr");
methodcssoverflowrows.each(function (index) {
    var methodcssoverflowrow = $(this);
 	var methodcssoverflowobj = {};
	var vMethod = methodcssoverflowrow.find("[name=Method]").text();
			methodcssoverflowobj['Method'] = vMethod;
			methodcssoverflowobj['index'] = index;
var vParameters = methodcssoverflowrow.find("[name=Parameters]").text();
			methodcssoverflowobj['Parameters'] = vParameters;
			methodcssoverflowobj['index'] = index;
var vReturnType = methodcssoverflowrow.find("[name=ReturnType]").text();
			methodcssoverflowobj['ReturnType'] = vReturnType;
			methodcssoverflowobj['index'] = index;
var vDescription = methodcssoverflowrow.find("[name=Description]").text();
			methodcssoverflowobj['Description'] = vDescription;
			methodcssoverflowobj['index'] = index;

	methodcssoverflowdata.push(methodcssoverflowobj);
});
return methodcssoverflowdata;
	}
function getRowstblcsspositions(){
	var tblcsspositionsdata = [];
	tblcsspositionsrows = $("#tblcsspositions tbody tr");
tblcsspositionsrows.each(function (index) {
    var tblcsspositionsrow = $(this);
 	var tblcsspositionsobj = {};
	var vProperty = tblcsspositionsrow.find("[name=Property]").text();
			tblcsspositionsobj['Property'] = vProperty;
			tblcsspositionsobj['index'] = index;
var vType = tblcsspositionsrow.find("[name=Type]").text();
			tblcsspositionsobj['Type'] = vType;
			tblcsspositionsobj['index'] = index;
var vDefaultValue = tblcsspositionsrow.find("[name=DefaultValue]").text();
			tblcsspositionsobj['DefaultValue'] = vDefaultValue;
			tblcsspositionsobj['index'] = index;
var vDescription = tblcsspositionsrow.find("[name=Description]").text();
			tblcsspositionsobj['Description'] = vDescription;
			tblcsspositionsobj['index'] = index;

	tblcsspositionsdata.push(tblcsspositionsobj);
});
return tblcsspositionsdata;
	}
function getRowsmethodcsspositions(){
	var methodcsspositionsdata = [];
	methodcsspositionsrows = $("#methodcsspositions tbody tr");
methodcsspositionsrows.each(function (index) {
    var methodcsspositionsrow = $(this);
 	var methodcsspositionsobj = {};
	var vMethod = methodcsspositionsrow.find("[name=Method]").text();
			methodcsspositionsobj['Method'] = vMethod;
			methodcsspositionsobj['index'] = index;
var vParameters = methodcsspositionsrow.find("[name=Parameters]").text();
			methodcsspositionsobj['Parameters'] = vParameters;
			methodcsspositionsobj['index'] = index;
var vReturnType = methodcsspositionsrow.find("[name=ReturnType]").text();
			methodcsspositionsobj['ReturnType'] = vReturnType;
			methodcsspositionsobj['index'] = index;
var vDescription = methodcsspositionsrow.find("[name=Description]").text();
			methodcsspositionsobj['Description'] = vDescription;
			methodcsspositionsobj['index'] = index;

	methodcsspositionsdata.push(methodcsspositionsobj);
});
return methodcsspositionsdata;
	}
function getRowstblcsssize(){
	var tblcsssizedata = [];
	tblcsssizerows = $("#tblcsssize tbody tr");
tblcsssizerows.each(function (index) {
    var tblcsssizerow = $(this);
 	var tblcsssizeobj = {};
	var vProperty = tblcsssizerow.find("[name=Property]").text();
			tblcsssizeobj['Property'] = vProperty;
			tblcsssizeobj['index'] = index;
var vType = tblcsssizerow.find("[name=Type]").text();
			tblcsssizeobj['Type'] = vType;
			tblcsssizeobj['index'] = index;
var vDefaultValue = tblcsssizerow.find("[name=DefaultValue]").text();
			tblcsssizeobj['DefaultValue'] = vDefaultValue;
			tblcsssizeobj['index'] = index;
var vDescription = tblcsssizerow.find("[name=Description]").text();
			tblcsssizeobj['Description'] = vDescription;
			tblcsssizeobj['index'] = index;

	tblcsssizedata.push(tblcsssizeobj);
});
return tblcsssizedata;
	}
function getRowsmethodcsssize(){
	var methodcsssizedata = [];
	methodcsssizerows = $("#methodcsssize tbody tr");
methodcsssizerows.each(function (index) {
    var methodcsssizerow = $(this);
 	var methodcsssizeobj = {};
	var vMethod = methodcsssizerow.find("[name=Method]").text();
			methodcsssizeobj['Method'] = vMethod;
			methodcsssizeobj['index'] = index;
var vParameters = methodcsssizerow.find("[name=Parameters]").text();
			methodcsssizeobj['Parameters'] = vParameters;
			methodcsssizeobj['index'] = index;
var vReturnType = methodcsssizerow.find("[name=ReturnType]").text();
			methodcsssizeobj['ReturnType'] = vReturnType;
			methodcsssizeobj['index'] = index;
var vDescription = methodcsssizerow.find("[name=Description]").text();
			methodcsssizeobj['Description'] = vDescription;
			methodcsssizeobj['index'] = index;

	methodcsssizedata.push(methodcsssizeobj);
});
return methodcsssizedata;
	}
function getRowstblcssstroke(){
	var tblcssstrokedata = [];
	tblcssstrokerows = $("#tblcssstroke tbody tr");
tblcssstrokerows.each(function (index) {
    var tblcssstrokerow = $(this);
 	var tblcssstrokeobj = {};
	var vProperty = tblcssstrokerow.find("[name=Property]").text();
			tblcssstrokeobj['Property'] = vProperty;
			tblcssstrokeobj['index'] = index;
var vType = tblcssstrokerow.find("[name=Type]").text();
			tblcssstrokeobj['Type'] = vType;
			tblcssstrokeobj['index'] = index;
var vDefaultValue = tblcssstrokerow.find("[name=DefaultValue]").text();
			tblcssstrokeobj['DefaultValue'] = vDefaultValue;
			tblcssstrokeobj['index'] = index;
var vDescription = tblcssstrokerow.find("[name=Description]").text();
			tblcssstrokeobj['Description'] = vDescription;
			tblcssstrokeobj['index'] = index;

	tblcssstrokedata.push(tblcssstrokeobj);
});
return tblcssstrokedata;
	}
function getRowsmethodcssstroke(){
	var methodcssstrokedata = [];
	methodcssstrokerows = $("#methodcssstroke tbody tr");
methodcssstrokerows.each(function (index) {
    var methodcssstrokerow = $(this);
 	var methodcssstrokeobj = {};
	var vMethod = methodcssstrokerow.find("[name=Method]").text();
			methodcssstrokeobj['Method'] = vMethod;
			methodcssstrokeobj['index'] = index;
var vParameters = methodcssstrokerow.find("[name=Parameters]").text();
			methodcssstrokeobj['Parameters'] = vParameters;
			methodcssstrokeobj['index'] = index;
var vReturnType = methodcssstrokerow.find("[name=ReturnType]").text();
			methodcssstrokeobj['ReturnType'] = vReturnType;
			methodcssstrokeobj['index'] = index;
var vDescription = methodcssstrokerow.find("[name=Description]").text();
			methodcssstrokeobj['Description'] = vDescription;
			methodcssstrokeobj['index'] = index;

	methodcssstrokedata.push(methodcssstrokeobj);
});
return methodcssstrokedata;
	}
function getRowstblcsstext(){
	var tblcsstextdata = [];
	tblcsstextrows = $("#tblcsstext tbody tr");
tblcsstextrows.each(function (index) {
    var tblcsstextrow = $(this);
 	var tblcsstextobj = {};
	var vProperty = tblcsstextrow.find("[name=Property]").text();
			tblcsstextobj['Property'] = vProperty;
			tblcsstextobj['index'] = index;
var vType = tblcsstextrow.find("[name=Type]").text();
			tblcsstextobj['Type'] = vType;
			tblcsstextobj['index'] = index;
var vDefaultValue = tblcsstextrow.find("[name=DefaultValue]").text();
			tblcsstextobj['DefaultValue'] = vDefaultValue;
			tblcsstextobj['index'] = index;
var vDescription = tblcsstextrow.find("[name=Description]").text();
			tblcsstextobj['Description'] = vDescription;
			tblcsstextobj['index'] = index;

	tblcsstextdata.push(tblcsstextobj);
});
return tblcsstextdata;
	}
function getRowsmethodcsstext(){
	var methodcsstextdata = [];
	methodcsstextrows = $("#methodcsstext tbody tr");
methodcsstextrows.each(function (index) {
    var methodcsstextrow = $(this);
 	var methodcsstextobj = {};
	var vMethod = methodcsstextrow.find("[name=Method]").text();
			methodcsstextobj['Method'] = vMethod;
			methodcsstextobj['index'] = index;
var vParameters = methodcsstextrow.find("[name=Parameters]").text();
			methodcsstextobj['Parameters'] = vParameters;
			methodcsstextobj['index'] = index;
var vReturnType = methodcsstextrow.find("[name=ReturnType]").text();
			methodcsstextobj['ReturnType'] = vReturnType;
			methodcsstextobj['index'] = index;
var vDescription = methodcsstextrow.find("[name=Description]").text();
			methodcsstextobj['Description'] = vDescription;
			methodcsstextobj['index'] = index;

	methodcsstextdata.push(methodcsstextobj);
});
return methodcsstextdata;
	}
function getRowstblcsstextalign(){
	var tblcsstextaligndata = [];
	tblcsstextalignrows = $("#tblcsstextalign tbody tr");
tblcsstextalignrows.each(function (index) {
    var tblcsstextalignrow = $(this);
 	var tblcsstextalignobj = {};
	var vProperty = tblcsstextalignrow.find("[name=Property]").text();
			tblcsstextalignobj['Property'] = vProperty;
			tblcsstextalignobj['index'] = index;
var vType = tblcsstextalignrow.find("[name=Type]").text();
			tblcsstextalignobj['Type'] = vType;
			tblcsstextalignobj['index'] = index;
var vDefaultValue = tblcsstextalignrow.find("[name=DefaultValue]").text();
			tblcsstextalignobj['DefaultValue'] = vDefaultValue;
			tblcsstextalignobj['index'] = index;
var vDescription = tblcsstextalignrow.find("[name=Description]").text();
			tblcsstextalignobj['Description'] = vDescription;
			tblcsstextalignobj['index'] = index;

	tblcsstextaligndata.push(tblcsstextalignobj);
});
return tblcsstextaligndata;
	}
function getRowsmethodcsstextalign(){
	var methodcsstextaligndata = [];
	methodcsstextalignrows = $("#methodcsstextalign tbody tr");
methodcsstextalignrows.each(function (index) {
    var methodcsstextalignrow = $(this);
 	var methodcsstextalignobj = {};
	var vMethod = methodcsstextalignrow.find("[name=Method]").text();
			methodcsstextalignobj['Method'] = vMethod;
			methodcsstextalignobj['index'] = index;
var vParameters = methodcsstextalignrow.find("[name=Parameters]").text();
			methodcsstextalignobj['Parameters'] = vParameters;
			methodcsstextalignobj['index'] = index;
var vReturnType = methodcsstextalignrow.find("[name=ReturnType]").text();
			methodcsstextalignobj['ReturnType'] = vReturnType;
			methodcsstextalignobj['index'] = index;
var vDescription = methodcsstextalignrow.find("[name=Description]").text();
			methodcsstextalignobj['Description'] = vDescription;
			methodcsstextalignobj['index'] = index;

	methodcsstextaligndata.push(methodcsstextalignobj);
});
return methodcsstextaligndata;
	}
function getRowstblcsstransform(){
	var tblcsstransformdata = [];
	tblcsstransformrows = $("#tblcsstransform tbody tr");
tblcsstransformrows.each(function (index) {
    var tblcsstransformrow = $(this);
 	var tblcsstransformobj = {};
	var vProperty = tblcsstransformrow.find("[name=Property]").text();
			tblcsstransformobj['Property'] = vProperty;
			tblcsstransformobj['index'] = index;
var vType = tblcsstransformrow.find("[name=Type]").text();
			tblcsstransformobj['Type'] = vType;
			tblcsstransformobj['index'] = index;
var vDefaultValue = tblcsstransformrow.find("[name=DefaultValue]").text();
			tblcsstransformobj['DefaultValue'] = vDefaultValue;
			tblcsstransformobj['index'] = index;
var vDescription = tblcsstransformrow.find("[name=Description]").text();
			tblcsstransformobj['Description'] = vDescription;
			tblcsstransformobj['index'] = index;

	tblcsstransformdata.push(tblcsstransformobj);
});
return tblcsstransformdata;
	}
function getRowsmethodcsstransform(){
	var methodcsstransformdata = [];
	methodcsstransformrows = $("#methodcsstransform tbody tr");
methodcsstransformrows.each(function (index) {
    var methodcsstransformrow = $(this);
 	var methodcsstransformobj = {};
	var vMethod = methodcsstransformrow.find("[name=Method]").text();
			methodcsstransformobj['Method'] = vMethod;
			methodcsstransformobj['index'] = index;
var vParameters = methodcsstransformrow.find("[name=Parameters]").text();
			methodcsstransformobj['Parameters'] = vParameters;
			methodcsstransformobj['index'] = index;
var vReturnType = methodcsstransformrow.find("[name=ReturnType]").text();
			methodcsstransformobj['ReturnType'] = vReturnType;
			methodcsstransformobj['index'] = index;
var vDescription = methodcsstransformrow.find("[name=Description]").text();
			methodcsstransformobj['Description'] = vDescription;
			methodcsstransformobj['index'] = index;

	methodcsstransformdata.push(methodcsstransformobj);
});
return methodcsstransformdata;
	}
function getRowstblcsstransition(){
	var tblcsstransitiondata = [];
	tblcsstransitionrows = $("#tblcsstransition tbody tr");
tblcsstransitionrows.each(function (index) {
    var tblcsstransitionrow = $(this);
 	var tblcsstransitionobj = {};
	var vProperty = tblcsstransitionrow.find("[name=Property]").text();
			tblcsstransitionobj['Property'] = vProperty;
			tblcsstransitionobj['index'] = index;
var vType = tblcsstransitionrow.find("[name=Type]").text();
			tblcsstransitionobj['Type'] = vType;
			tblcsstransitionobj['index'] = index;
var vDefaultValue = tblcsstransitionrow.find("[name=DefaultValue]").text();
			tblcsstransitionobj['DefaultValue'] = vDefaultValue;
			tblcsstransitionobj['index'] = index;
var vDescription = tblcsstransitionrow.find("[name=Description]").text();
			tblcsstransitionobj['Description'] = vDescription;
			tblcsstransitionobj['index'] = index;

	tblcsstransitiondata.push(tblcsstransitionobj);
});
return tblcsstransitiondata;
	}
function getRowsmethodcsstransition(){
	var methodcsstransitiondata = [];
	methodcsstransitionrows = $("#methodcsstransition tbody tr");
methodcsstransitionrows.each(function (index) {
    var methodcsstransitionrow = $(this);
 	var methodcsstransitionobj = {};
	var vMethod = methodcsstransitionrow.find("[name=Method]").text();
			methodcsstransitionobj['Method'] = vMethod;
			methodcsstransitionobj['index'] = index;
var vParameters = methodcsstransitionrow.find("[name=Parameters]").text();
			methodcsstransitionobj['Parameters'] = vParameters;
			methodcsstransitionobj['index'] = index;
var vReturnType = methodcsstransitionrow.find("[name=ReturnType]").text();
			methodcsstransitionobj['ReturnType'] = vReturnType;
			methodcsstransitionobj['index'] = index;
var vDescription = methodcsstransitionrow.find("[name=Description]").text();
			methodcsstransitionobj['Description'] = vDescription;
			methodcsstransitionobj['index'] = index;

	methodcsstransitiondata.push(methodcsstransitionobj);
});
return methodcsstransitiondata;
	}
function getRowstblcssuserselect(){
	var tblcssuserselectdata = [];
	tblcssuserselectrows = $("#tblcssuserselect tbody tr");
tblcssuserselectrows.each(function (index) {
    var tblcssuserselectrow = $(this);
 	var tblcssuserselectobj = {};
	var vProperty = tblcssuserselectrow.find("[name=Property]").text();
			tblcssuserselectobj['Property'] = vProperty;
			tblcssuserselectobj['index'] = index;
var vType = tblcssuserselectrow.find("[name=Type]").text();
			tblcssuserselectobj['Type'] = vType;
			tblcssuserselectobj['index'] = index;
var vDefaultValue = tblcssuserselectrow.find("[name=DefaultValue]").text();
			tblcssuserselectobj['DefaultValue'] = vDefaultValue;
			tblcssuserselectobj['index'] = index;
var vDescription = tblcssuserselectrow.find("[name=Description]").text();
			tblcssuserselectobj['Description'] = vDescription;
			tblcssuserselectobj['index'] = index;

	tblcssuserselectdata.push(tblcssuserselectobj);
});
return tblcssuserselectdata;
	}
function getRowsmethodcssuserselect(){
	var methodcssuserselectdata = [];
	methodcssuserselectrows = $("#methodcssuserselect tbody tr");
methodcssuserselectrows.each(function (index) {
    var methodcssuserselectrow = $(this);
 	var methodcssuserselectobj = {};
	var vMethod = methodcssuserselectrow.find("[name=Method]").text();
			methodcssuserselectobj['Method'] = vMethod;
			methodcssuserselectobj['index'] = index;
var vParameters = methodcssuserselectrow.find("[name=Parameters]").text();
			methodcssuserselectobj['Parameters'] = vParameters;
			methodcssuserselectobj['index'] = index;
var vReturnType = methodcssuserselectrow.find("[name=ReturnType]").text();
			methodcssuserselectobj['ReturnType'] = vReturnType;
			methodcssuserselectobj['index'] = index;
var vDescription = methodcssuserselectrow.find("[name=Description]").text();
			methodcssuserselectobj['Description'] = vDescription;
			methodcssuserselectobj['index'] = index;

	methodcssuserselectdata.push(methodcssuserselectobj);
});
return methodcssuserselectdata;
	}
function getRowstblcssverticalalign(){
	var tblcssverticalaligndata = [];
	tblcssverticalalignrows = $("#tblcssverticalalign tbody tr");
tblcssverticalalignrows.each(function (index) {
    var tblcssverticalalignrow = $(this);
 	var tblcssverticalalignobj = {};
	var vProperty = tblcssverticalalignrow.find("[name=Property]").text();
			tblcssverticalalignobj['Property'] = vProperty;
			tblcssverticalalignobj['index'] = index;
var vType = tblcssverticalalignrow.find("[name=Type]").text();
			tblcssverticalalignobj['Type'] = vType;
			tblcssverticalalignobj['index'] = index;
var vDefaultValue = tblcssverticalalignrow.find("[name=DefaultValue]").text();
			tblcssverticalalignobj['DefaultValue'] = vDefaultValue;
			tblcssverticalalignobj['index'] = index;
var vDescription = tblcssverticalalignrow.find("[name=Description]").text();
			tblcssverticalalignobj['Description'] = vDescription;
			tblcssverticalalignobj['index'] = index;

	tblcssverticalaligndata.push(tblcssverticalalignobj);
});
return tblcssverticalaligndata;
	}
function getRowsmethodcssverticalalign(){
	var methodcssverticalaligndata = [];
	methodcssverticalalignrows = $("#methodcssverticalalign tbody tr");
methodcssverticalalignrows.each(function (index) {
    var methodcssverticalalignrow = $(this);
 	var methodcssverticalalignobj = {};
	var vMethod = methodcssverticalalignrow.find("[name=Method]").text();
			methodcssverticalalignobj['Method'] = vMethod;
			methodcssverticalalignobj['index'] = index;
var vParameters = methodcssverticalalignrow.find("[name=Parameters]").text();
			methodcssverticalalignobj['Parameters'] = vParameters;
			methodcssverticalalignobj['index'] = index;
var vReturnType = methodcssverticalalignrow.find("[name=ReturnType]").text();
			methodcssverticalalignobj['ReturnType'] = vReturnType;
			methodcssverticalalignobj['index'] = index;
var vDescription = methodcssverticalalignrow.find("[name=Description]").text();
			methodcssverticalalignobj['Description'] = vDescription;
			methodcssverticalalignobj['index'] = index;

	methodcssverticalaligndata.push(methodcssverticalalignobj);
});
return methodcssverticalaligndata;
	}
function getRowstblcssvisibility(){
	var tblcssvisibilitydata = [];
	tblcssvisibilityrows = $("#tblcssvisibility tbody tr");
tblcssvisibilityrows.each(function (index) {
    var tblcssvisibilityrow = $(this);
 	var tblcssvisibilityobj = {};
	var vProperty = tblcssvisibilityrow.find("[name=Property]").text();
			tblcssvisibilityobj['Property'] = vProperty;
			tblcssvisibilityobj['index'] = index;
var vType = tblcssvisibilityrow.find("[name=Type]").text();
			tblcssvisibilityobj['Type'] = vType;
			tblcssvisibilityobj['index'] = index;
var vDefaultValue = tblcssvisibilityrow.find("[name=DefaultValue]").text();
			tblcssvisibilityobj['DefaultValue'] = vDefaultValue;
			tblcssvisibilityobj['index'] = index;
var vDescription = tblcssvisibilityrow.find("[name=Description]").text();
			tblcssvisibilityobj['Description'] = vDescription;
			tblcssvisibilityobj['index'] = index;

	tblcssvisibilitydata.push(tblcssvisibilityobj);
});
return tblcssvisibilitydata;
	}
function getRowsmethodcssvisibility(){
	var methodcssvisibilitydata = [];
	methodcssvisibilityrows = $("#methodcssvisibility tbody tr");
methodcssvisibilityrows.each(function (index) {
    var methodcssvisibilityrow = $(this);
 	var methodcssvisibilityobj = {};
	var vMethod = methodcssvisibilityrow.find("[name=Method]").text();
			methodcssvisibilityobj['Method'] = vMethod;
			methodcssvisibilityobj['index'] = index;
var vParameters = methodcssvisibilityrow.find("[name=Parameters]").text();
			methodcssvisibilityobj['Parameters'] = vParameters;
			methodcssvisibilityobj['index'] = index;
var vReturnType = methodcssvisibilityrow.find("[name=ReturnType]").text();
			methodcssvisibilityobj['ReturnType'] = vReturnType;
			methodcssvisibilityobj['index'] = index;
var vDescription = methodcssvisibilityrow.find("[name=Description]").text();
			methodcssvisibilityobj['Description'] = vDescription;
			methodcssvisibilityobj['index'] = index;

	methodcssvisibilitydata.push(methodcssvisibilityobj);
});
return methodcssvisibilitydata;
	}
function getRowstblcsswhitespace(){
	var tblcsswhitespacedata = [];
	tblcsswhitespacerows = $("#tblcsswhitespace tbody tr");
tblcsswhitespacerows.each(function (index) {
    var tblcsswhitespacerow = $(this);
 	var tblcsswhitespaceobj = {};
	var vProperty = tblcsswhitespacerow.find("[name=Property]").text();
			tblcsswhitespaceobj['Property'] = vProperty;
			tblcsswhitespaceobj['index'] = index;
var vType = tblcsswhitespacerow.find("[name=Type]").text();
			tblcsswhitespaceobj['Type'] = vType;
			tblcsswhitespaceobj['index'] = index;
var vDefaultValue = tblcsswhitespacerow.find("[name=DefaultValue]").text();
			tblcsswhitespaceobj['DefaultValue'] = vDefaultValue;
			tblcsswhitespaceobj['index'] = index;
var vDescription = tblcsswhitespacerow.find("[name=Description]").text();
			tblcsswhitespaceobj['Description'] = vDescription;
			tblcsswhitespaceobj['index'] = index;

	tblcsswhitespacedata.push(tblcsswhitespaceobj);
});
return tblcsswhitespacedata;
	}
function getRowsmethodcsswhitespace(){
	var methodcsswhitespacedata = [];
	methodcsswhitespacerows = $("#methodcsswhitespace tbody tr");
methodcsswhitespacerows.each(function (index) {
    var methodcsswhitespacerow = $(this);
 	var methodcsswhitespaceobj = {};
	var vMethod = methodcsswhitespacerow.find("[name=Method]").text();
			methodcsswhitespaceobj['Method'] = vMethod;
			methodcsswhitespaceobj['index'] = index;
var vParameters = methodcsswhitespacerow.find("[name=Parameters]").text();
			methodcsswhitespaceobj['Parameters'] = vParameters;
			methodcsswhitespaceobj['index'] = index;
var vReturnType = methodcsswhitespacerow.find("[name=ReturnType]").text();
			methodcsswhitespaceobj['ReturnType'] = vReturnType;
			methodcsswhitespaceobj['index'] = index;
var vDescription = methodcsswhitespacerow.find("[name=Description]").text();
			methodcsswhitespaceobj['Description'] = vDescription;
			methodcsswhitespaceobj['index'] = index;

	methodcsswhitespacedata.push(methodcsswhitespaceobj);
});
return methodcsswhitespacedata;
	}
function getRowstblcssword(){
	var tblcssworddata = [];
	tblcsswordrows = $("#tblcssword tbody tr");
tblcsswordrows.each(function (index) {
    var tblcsswordrow = $(this);
 	var tblcsswordobj = {};
	var vProperty = tblcsswordrow.find("[name=Property]").text();
			tblcsswordobj['Property'] = vProperty;
			tblcsswordobj['index'] = index;
var vType = tblcsswordrow.find("[name=Type]").text();
			tblcsswordobj['Type'] = vType;
			tblcsswordobj['index'] = index;
var vDefaultValue = tblcsswordrow.find("[name=DefaultValue]").text();
			tblcsswordobj['DefaultValue'] = vDefaultValue;
			tblcsswordobj['index'] = index;
var vDescription = tblcsswordrow.find("[name=Description]").text();
			tblcsswordobj['Description'] = vDescription;
			tblcsswordobj['index'] = index;

	tblcssworddata.push(tblcsswordobj);
});
return tblcssworddata;
	}
function getRowsmethodcssword(){
	var methodcssworddata = [];
	methodcsswordrows = $("#methodcssword tbody tr");
methodcsswordrows.each(function (index) {
    var methodcsswordrow = $(this);
 	var methodcsswordobj = {};
	var vMethod = methodcsswordrow.find("[name=Method]").text();
			methodcsswordobj['Method'] = vMethod;
			methodcsswordobj['index'] = index;
var vParameters = methodcsswordrow.find("[name=Parameters]").text();
			methodcsswordobj['Parameters'] = vParameters;
			methodcsswordobj['index'] = index;
var vReturnType = methodcsswordrow.find("[name=ReturnType]").text();
			methodcsswordobj['ReturnType'] = vReturnType;
			methodcsswordobj['index'] = index;
var vDescription = methodcsswordrow.find("[name=Description]").text();
			methodcsswordobj['Description'] = vDescription;
			methodcsswordobj['index'] = index;

	methodcssworddata.push(methodcsswordobj);
});
return methodcssworddata;
	}
function getRowstbleventobject(){
	var tbleventobjectdata = [];
	tbleventobjectrows = $("#tbleventobject tbody tr");
tbleventobjectrows.each(function (index) {
    var tbleventobjectrow = $(this);
 	var tbleventobjectobj = {};
	var vProperty = tbleventobjectrow.find("[name=Property]").text();
			tbleventobjectobj['Property'] = vProperty;
			tbleventobjectobj['index'] = index;
var vType = tbleventobjectrow.find("[name=Type]").text();
			tbleventobjectobj['Type'] = vType;
			tbleventobjectobj['index'] = index;
var vDefaultValue = tbleventobjectrow.find("[name=DefaultValue]").text();
			tbleventobjectobj['DefaultValue'] = vDefaultValue;
			tbleventobjectobj['index'] = index;
var vDescription = tbleventobjectrow.find("[name=Description]").text();
			tbleventobjectobj['Description'] = vDescription;
			tbleventobjectobj['index'] = index;

	tbleventobjectdata.push(tbleventobjectobj);
});
return tbleventobjectdata;
	}
function getRowsmethodeventobject(){
	var methodeventobjectdata = [];
	methodeventobjectrows = $("#methodeventobject tbody tr");
methodeventobjectrows.each(function (index) {
    var methodeventobjectrow = $(this);
 	var methodeventobjectobj = {};
	var vMethod = methodeventobjectrow.find("[name=Method]").text();
			methodeventobjectobj['Method'] = vMethod;
			methodeventobjectobj['index'] = index;
var vParameters = methodeventobjectrow.find("[name=Parameters]").text();
			methodeventobjectobj['Parameters'] = vParameters;
			methodeventobjectobj['index'] = index;
var vReturnType = methodeventobjectrow.find("[name=ReturnType]").text();
			methodeventobjectobj['ReturnType'] = vReturnType;
			methodeventobjectobj['index'] = index;
var vDescription = methodeventobjectrow.find("[name=Description]").text();
			methodeventobjectobj['Description'] = vDescription;
			methodeventobjectobj['index'] = index;

	methodeventobjectdata.push(methodeventobjectobj);
});
return methodeventobjectdata;
	}
function getRowstblgmapcircle(){
	var tblgmapcircledata = [];
	tblgmapcirclerows = $("#tblgmapcircle tbody tr");
tblgmapcirclerows.each(function (index) {
    var tblgmapcirclerow = $(this);
 	var tblgmapcircleobj = {};
	var vProperty = tblgmapcirclerow.find("[name=Property]").text();
			tblgmapcircleobj['Property'] = vProperty;
			tblgmapcircleobj['index'] = index;
var vType = tblgmapcirclerow.find("[name=Type]").text();
			tblgmapcircleobj['Type'] = vType;
			tblgmapcircleobj['index'] = index;
var vDefaultValue = tblgmapcirclerow.find("[name=DefaultValue]").text();
			tblgmapcircleobj['DefaultValue'] = vDefaultValue;
			tblgmapcircleobj['index'] = index;
var vDescription = tblgmapcirclerow.find("[name=Description]").text();
			tblgmapcircleobj['Description'] = vDescription;
			tblgmapcircleobj['index'] = index;

	tblgmapcircledata.push(tblgmapcircleobj);
});
return tblgmapcircledata;
	}
function getRowsmethodgmapcircle(){
	var methodgmapcircledata = [];
	methodgmapcirclerows = $("#methodgmapcircle tbody tr");
methodgmapcirclerows.each(function (index) {
    var methodgmapcirclerow = $(this);
 	var methodgmapcircleobj = {};
	var vMethod = methodgmapcirclerow.find("[name=Method]").text();
			methodgmapcircleobj['Method'] = vMethod;
			methodgmapcircleobj['index'] = index;
var vParameters = methodgmapcirclerow.find("[name=Parameters]").text();
			methodgmapcircleobj['Parameters'] = vParameters;
			methodgmapcircleobj['index'] = index;
var vReturnType = methodgmapcirclerow.find("[name=ReturnType]").text();
			methodgmapcircleobj['ReturnType'] = vReturnType;
			methodgmapcircleobj['index'] = index;
var vDescription = methodgmapcirclerow.find("[name=Description]").text();
			methodgmapcircleobj['Description'] = vDescription;
			methodgmapcircleobj['index'] = index;

	methodgmapcircledata.push(methodgmapcircleobj);
});
return methodgmapcircledata;
	}
function getRowstblgmapmarker(){
	var tblgmapmarkerdata = [];
	tblgmapmarkerrows = $("#tblgmapmarker tbody tr");
tblgmapmarkerrows.each(function (index) {
    var tblgmapmarkerrow = $(this);
 	var tblgmapmarkerobj = {};
	var vProperty = tblgmapmarkerrow.find("[name=Property]").text();
			tblgmapmarkerobj['Property'] = vProperty;
			tblgmapmarkerobj['index'] = index;
var vType = tblgmapmarkerrow.find("[name=Type]").text();
			tblgmapmarkerobj['Type'] = vType;
			tblgmapmarkerobj['index'] = index;
var vDefaultValue = tblgmapmarkerrow.find("[name=DefaultValue]").text();
			tblgmapmarkerobj['DefaultValue'] = vDefaultValue;
			tblgmapmarkerobj['index'] = index;
var vDescription = tblgmapmarkerrow.find("[name=Description]").text();
			tblgmapmarkerobj['Description'] = vDescription;
			tblgmapmarkerobj['index'] = index;

	tblgmapmarkerdata.push(tblgmapmarkerobj);
});
return tblgmapmarkerdata;
	}
function getRowsmethodgmapmarker(){
	var methodgmapmarkerdata = [];
	methodgmapmarkerrows = $("#methodgmapmarker tbody tr");
methodgmapmarkerrows.each(function (index) {
    var methodgmapmarkerrow = $(this);
 	var methodgmapmarkerobj = {};
	var vMethod = methodgmapmarkerrow.find("[name=Method]").text();
			methodgmapmarkerobj['Method'] = vMethod;
			methodgmapmarkerobj['index'] = index;
var vParameters = methodgmapmarkerrow.find("[name=Parameters]").text();
			methodgmapmarkerobj['Parameters'] = vParameters;
			methodgmapmarkerobj['index'] = index;
var vReturnType = methodgmapmarkerrow.find("[name=ReturnType]").text();
			methodgmapmarkerobj['ReturnType'] = vReturnType;
			methodgmapmarkerobj['index'] = index;
var vDescription = methodgmapmarkerrow.find("[name=Description]").text();
			methodgmapmarkerobj['Description'] = vDescription;
			methodgmapmarkerobj['index'] = index;

	methodgmapmarkerdata.push(methodgmapmarkerobj);
});
return methodgmapmarkerdata;
	}
function getRowstblgmappolygon(){
	var tblgmappolygondata = [];
	tblgmappolygonrows = $("#tblgmappolygon tbody tr");
tblgmappolygonrows.each(function (index) {
    var tblgmappolygonrow = $(this);
 	var tblgmappolygonobj = {};
	var vProperty = tblgmappolygonrow.find("[name=Property]").text();
			tblgmappolygonobj['Property'] = vProperty;
			tblgmappolygonobj['index'] = index;
var vType = tblgmappolygonrow.find("[name=Type]").text();
			tblgmappolygonobj['Type'] = vType;
			tblgmappolygonobj['index'] = index;
var vDefaultValue = tblgmappolygonrow.find("[name=DefaultValue]").text();
			tblgmappolygonobj['DefaultValue'] = vDefaultValue;
			tblgmappolygonobj['index'] = index;
var vDescription = tblgmappolygonrow.find("[name=Description]").text();
			tblgmappolygonobj['Description'] = vDescription;
			tblgmappolygonobj['index'] = index;

	tblgmappolygondata.push(tblgmappolygonobj);
});
return tblgmappolygondata;
	}
function getRowsmethodgmappolygon(){
	var methodgmappolygondata = [];
	methodgmappolygonrows = $("#methodgmappolygon tbody tr");
methodgmappolygonrows.each(function (index) {
    var methodgmappolygonrow = $(this);
 	var methodgmappolygonobj = {};
	var vMethod = methodgmappolygonrow.find("[name=Method]").text();
			methodgmappolygonobj['Method'] = vMethod;
			methodgmappolygonobj['index'] = index;
var vParameters = methodgmappolygonrow.find("[name=Parameters]").text();
			methodgmappolygonobj['Parameters'] = vParameters;
			methodgmappolygonobj['index'] = index;
var vReturnType = methodgmappolygonrow.find("[name=ReturnType]").text();
			methodgmappolygonobj['ReturnType'] = vReturnType;
			methodgmappolygonobj['index'] = index;
var vDescription = methodgmappolygonrow.find("[name=Description]").text();
			methodgmappolygonobj['Description'] = vDescription;
			methodgmappolygonobj['index'] = index;

	methodgmappolygondata.push(methodgmappolygonobj);
});
return methodgmappolygondata;
	}
function getRowstblgmappolyline(){
	var tblgmappolylinedata = [];
	tblgmappolylinerows = $("#tblgmappolyline tbody tr");
tblgmappolylinerows.each(function (index) {
    var tblgmappolylinerow = $(this);
 	var tblgmappolylineobj = {};
	var vProperty = tblgmappolylinerow.find("[name=Property]").text();
			tblgmappolylineobj['Property'] = vProperty;
			tblgmappolylineobj['index'] = index;
var vType = tblgmappolylinerow.find("[name=Type]").text();
			tblgmappolylineobj['Type'] = vType;
			tblgmappolylineobj['index'] = index;
var vDefaultValue = tblgmappolylinerow.find("[name=DefaultValue]").text();
			tblgmappolylineobj['DefaultValue'] = vDefaultValue;
			tblgmappolylineobj['index'] = index;
var vDescription = tblgmappolylinerow.find("[name=Description]").text();
			tblgmappolylineobj['Description'] = vDescription;
			tblgmappolylineobj['index'] = index;

	tblgmappolylinedata.push(tblgmappolylineobj);
});
return tblgmappolylinedata;
	}
function getRowsmethodgmappolyline(){
	var methodgmappolylinedata = [];
	methodgmappolylinerows = $("#methodgmappolyline tbody tr");
methodgmappolylinerows.each(function (index) {
    var methodgmappolylinerow = $(this);
 	var methodgmappolylineobj = {};
	var vMethod = methodgmappolylinerow.find("[name=Method]").text();
			methodgmappolylineobj['Method'] = vMethod;
			methodgmappolylineobj['index'] = index;
var vParameters = methodgmappolylinerow.find("[name=Parameters]").text();
			methodgmappolylineobj['Parameters'] = vParameters;
			methodgmappolylineobj['index'] = index;
var vReturnType = methodgmappolylinerow.find("[name=ReturnType]").text();
			methodgmappolylineobj['ReturnType'] = vReturnType;
			methodgmappolylineobj['index'] = index;
var vDescription = methodgmappolylinerow.find("[name=Description]").text();
			methodgmappolylineobj['Description'] = vDescription;
			methodgmappolylineobj['index'] = index;

	methodgmappolylinedata.push(methodgmappolylineobj);
});
return methodgmappolylinedata;
	}
function getRowstblhtmlelement(){
	var tblhtmlelementdata = [];
	tblhtmlelementrows = $("#tblhtmlelement tbody tr");
tblhtmlelementrows.each(function (index) {
    var tblhtmlelementrow = $(this);
 	var tblhtmlelementobj = {};
	var vProperty = tblhtmlelementrow.find("[name=Property]").text();
			tblhtmlelementobj['Property'] = vProperty;
			tblhtmlelementobj['index'] = index;
var vType = tblhtmlelementrow.find("[name=Type]").text();
			tblhtmlelementobj['Type'] = vType;
			tblhtmlelementobj['index'] = index;
var vDefaultValue = tblhtmlelementrow.find("[name=DefaultValue]").text();
			tblhtmlelementobj['DefaultValue'] = vDefaultValue;
			tblhtmlelementobj['index'] = index;
var vDescription = tblhtmlelementrow.find("[name=Description]").text();
			tblhtmlelementobj['Description'] = vDescription;
			tblhtmlelementobj['index'] = index;

	tblhtmlelementdata.push(tblhtmlelementobj);
});
return tblhtmlelementdata;
	}
function getRowsmethodhtmlelement(){
	var methodhtmlelementdata = [];
	methodhtmlelementrows = $("#methodhtmlelement tbody tr");
methodhtmlelementrows.each(function (index) {
    var methodhtmlelementrow = $(this);
 	var methodhtmlelementobj = {};
	var vMethod = methodhtmlelementrow.find("[name=Method]").text();
			methodhtmlelementobj['Method'] = vMethod;
			methodhtmlelementobj['index'] = index;
var vParameters = methodhtmlelementrow.find("[name=Parameters]").text();
			methodhtmlelementobj['Parameters'] = vParameters;
			methodhtmlelementobj['index'] = index;
var vReturnType = methodhtmlelementrow.find("[name=ReturnType]").text();
			methodhtmlelementobj['ReturnType'] = vReturnType;
			methodhtmlelementobj['index'] = index;
var vDescription = methodhtmlelementrow.find("[name=Description]").text();
			methodhtmlelementobj['Description'] = vDescription;
			methodhtmlelementobj['index'] = index;

	methodhtmlelementdata.push(methodhtmlelementobj);
});
return methodhtmlelementdata;
	}
function getRowstblmdicons(){
	var tblmdiconsdata = [];
	tblmdiconsrows = $("#tblmdicons tbody tr");
tblmdiconsrows.each(function (index) {
    var tblmdiconsrow = $(this);
 	var tblmdiconsobj = {};
	var vProperty = tblmdiconsrow.find("[name=Property]").text();
			tblmdiconsobj['Property'] = vProperty;
			tblmdiconsobj['index'] = index;
var vType = tblmdiconsrow.find("[name=Type]").text();
			tblmdiconsobj['Type'] = vType;
			tblmdiconsobj['index'] = index;
var vDefaultValue = tblmdiconsrow.find("[name=DefaultValue]").text();
			tblmdiconsobj['DefaultValue'] = vDefaultValue;
			tblmdiconsobj['index'] = index;
var vDescription = tblmdiconsrow.find("[name=Description]").text();
			tblmdiconsobj['Description'] = vDescription;
			tblmdiconsobj['index'] = index;

	tblmdiconsdata.push(tblmdiconsobj);
});
return tblmdiconsdata;
	}
function getRowsmethodmdicons(){
	var methodmdiconsdata = [];
	methodmdiconsrows = $("#methodmdicons tbody tr");
methodmdiconsrows.each(function (index) {
    var methodmdiconsrow = $(this);
 	var methodmdiconsobj = {};
	var vMethod = methodmdiconsrow.find("[name=Method]").text();
			methodmdiconsobj['Method'] = vMethod;
			methodmdiconsobj['index'] = index;
var vParameters = methodmdiconsrow.find("[name=Parameters]").text();
			methodmdiconsobj['Parameters'] = vParameters;
			methodmdiconsobj['index'] = index;
var vReturnType = methodmdiconsrow.find("[name=ReturnType]").text();
			methodmdiconsobj['ReturnType'] = vReturnType;
			methodmdiconsobj['index'] = index;
var vDescription = methodmdiconsrow.find("[name=Description]").text();
			methodmdiconsobj['Description'] = vDescription;
			methodmdiconsobj['index'] = index;

	methodmdiconsdata.push(methodmdiconsobj);
});
return methodmdiconsdata;
	}
function getRowstbluoealert(){
	var tbluoealertdata = [];
	tbluoealertrows = $("#tbluoealert tbody tr");
tbluoealertrows.each(function (index) {
    var tbluoealertrow = $(this);
 	var tbluoealertobj = {};
	var vProperty = tbluoealertrow.find("[name=Property]").text();
			tbluoealertobj['Property'] = vProperty;
			tbluoealertobj['index'] = index;
var vType = tbluoealertrow.find("[name=Type]").text();
			tbluoealertobj['Type'] = vType;
			tbluoealertobj['index'] = index;
var vDefaultValue = tbluoealertrow.find("[name=DefaultValue]").text();
			tbluoealertobj['DefaultValue'] = vDefaultValue;
			tbluoealertobj['index'] = index;
var vDescription = tbluoealertrow.find("[name=Description]").text();
			tbluoealertobj['Description'] = vDescription;
			tbluoealertobj['index'] = index;

	tbluoealertdata.push(tbluoealertobj);
});
return tbluoealertdata;
	}
function getRowsmethoduoealert(){
	var methoduoealertdata = [];
	methoduoealertrows = $("#methoduoealert tbody tr");
methoduoealertrows.each(function (index) {
    var methoduoealertrow = $(this);
 	var methoduoealertobj = {};
	var vMethod = methoduoealertrow.find("[name=Method]").text();
			methoduoealertobj['Method'] = vMethod;
			methoduoealertobj['index'] = index;
var vParameters = methoduoealertrow.find("[name=Parameters]").text();
			methoduoealertobj['Parameters'] = vParameters;
			methoduoealertobj['index'] = index;
var vReturnType = methoduoealertrow.find("[name=ReturnType]").text();
			methoduoealertobj['ReturnType'] = vReturnType;
			methoduoealertobj['index'] = index;
var vDescription = methoduoealertrow.find("[name=Description]").text();
			methoduoealertobj['Description'] = vDescription;
			methoduoealertobj['index'] = index;

	methoduoealertdata.push(methoduoealertobj);
});
return methoduoealertdata;
	}
function getRowstbluoealignment(){
	var tbluoealignmentdata = [];
	tbluoealignmentrows = $("#tbluoealignment tbody tr");
tbluoealignmentrows.each(function (index) {
    var tbluoealignmentrow = $(this);
 	var tbluoealignmentobj = {};
	var vProperty = tbluoealignmentrow.find("[name=Property]").text();
			tbluoealignmentobj['Property'] = vProperty;
			tbluoealignmentobj['index'] = index;
var vType = tbluoealignmentrow.find("[name=Type]").text();
			tbluoealignmentobj['Type'] = vType;
			tbluoealignmentobj['index'] = index;
var vDefaultValue = tbluoealignmentrow.find("[name=DefaultValue]").text();
			tbluoealignmentobj['DefaultValue'] = vDefaultValue;
			tbluoealignmentobj['index'] = index;
var vDescription = tbluoealignmentrow.find("[name=Description]").text();
			tbluoealignmentobj['Description'] = vDescription;
			tbluoealignmentobj['index'] = index;

	tbluoealignmentdata.push(tbluoealignmentobj);
});
return tbluoealignmentdata;
	}
function getRowsmethoduoealignment(){
	var methoduoealignmentdata = [];
	methoduoealignmentrows = $("#methoduoealignment tbody tr");
methoduoealignmentrows.each(function (index) {
    var methoduoealignmentrow = $(this);
 	var methoduoealignmentobj = {};
	var vMethod = methoduoealignmentrow.find("[name=Method]").text();
			methoduoealignmentobj['Method'] = vMethod;
			methoduoealignmentobj['index'] = index;
var vParameters = methoduoealignmentrow.find("[name=Parameters]").text();
			methoduoealignmentobj['Parameters'] = vParameters;
			methoduoealignmentobj['index'] = index;
var vReturnType = methoduoealignmentrow.find("[name=ReturnType]").text();
			methoduoealignmentobj['ReturnType'] = vReturnType;
			methoduoealignmentobj['index'] = index;
var vDescription = methoduoealignmentrow.find("[name=Description]").text();
			methoduoealignmentobj['Description'] = vDescription;
			methoduoealignmentobj['index'] = index;

	methoduoealignmentdata.push(methoduoealignmentobj);
});
return methoduoealignmentdata;
	}
function getRowstbluoeanchor(){
	var tbluoeanchordata = [];
	tbluoeanchorrows = $("#tbluoeanchor tbody tr");
tbluoeanchorrows.each(function (index) {
    var tbluoeanchorrow = $(this);
 	var tbluoeanchorobj = {};
	var vProperty = tbluoeanchorrow.find("[name=Property]").text();
			tbluoeanchorobj['Property'] = vProperty;
			tbluoeanchorobj['index'] = index;
var vType = tbluoeanchorrow.find("[name=Type]").text();
			tbluoeanchorobj['Type'] = vType;
			tbluoeanchorobj['index'] = index;
var vDefaultValue = tbluoeanchorrow.find("[name=DefaultValue]").text();
			tbluoeanchorobj['DefaultValue'] = vDefaultValue;
			tbluoeanchorobj['index'] = index;
var vDescription = tbluoeanchorrow.find("[name=Description]").text();
			tbluoeanchorobj['Description'] = vDescription;
			tbluoeanchorobj['index'] = index;

	tbluoeanchordata.push(tbluoeanchorobj);
});
return tbluoeanchordata;
	}
function getRowsmethoduoeanchor(){
	var methoduoeanchordata = [];
	methoduoeanchorrows = $("#methoduoeanchor tbody tr");
methoduoeanchorrows.each(function (index) {
    var methoduoeanchorrow = $(this);
 	var methoduoeanchorobj = {};
	var vMethod = methoduoeanchorrow.find("[name=Method]").text();
			methoduoeanchorobj['Method'] = vMethod;
			methoduoeanchorobj['index'] = index;
var vParameters = methoduoeanchorrow.find("[name=Parameters]").text();
			methoduoeanchorobj['Parameters'] = vParameters;
			methoduoeanchorobj['index'] = index;
var vReturnType = methoduoeanchorrow.find("[name=ReturnType]").text();
			methoduoeanchorobj['ReturnType'] = vReturnType;
			methoduoeanchorobj['index'] = index;
var vDescription = methoduoeanchorrow.find("[name=Description]").text();
			methoduoeanchorobj['Description'] = vDescription;
			methoduoeanchorobj['index'] = index;

	methoduoeanchordata.push(methoduoeanchorobj);
});
return methoduoeanchordata;
	}
function getRowstbluoeanchoricon(){
	var tbluoeanchoricondata = [];
	tbluoeanchoriconrows = $("#tbluoeanchoricon tbody tr");
tbluoeanchoriconrows.each(function (index) {
    var tbluoeanchoriconrow = $(this);
 	var tbluoeanchoriconobj = {};
	var vProperty = tbluoeanchoriconrow.find("[name=Property]").text();
			tbluoeanchoriconobj['Property'] = vProperty;
			tbluoeanchoriconobj['index'] = index;
var vType = tbluoeanchoriconrow.find("[name=Type]").text();
			tbluoeanchoriconobj['Type'] = vType;
			tbluoeanchoriconobj['index'] = index;
var vDefaultValue = tbluoeanchoriconrow.find("[name=DefaultValue]").text();
			tbluoeanchoriconobj['DefaultValue'] = vDefaultValue;
			tbluoeanchoriconobj['index'] = index;
var vDescription = tbluoeanchoriconrow.find("[name=Description]").text();
			tbluoeanchoriconobj['Description'] = vDescription;
			tbluoeanchoriconobj['index'] = index;

	tbluoeanchoricondata.push(tbluoeanchoriconobj);
});
return tbluoeanchoricondata;
	}
function getRowsmethoduoeanchoricon(){
	var methoduoeanchoricondata = [];
	methoduoeanchoriconrows = $("#methoduoeanchoricon tbody tr");
methoduoeanchoriconrows.each(function (index) {
    var methoduoeanchoriconrow = $(this);
 	var methoduoeanchoriconobj = {};
	var vMethod = methoduoeanchoriconrow.find("[name=Method]").text();
			methoduoeanchoriconobj['Method'] = vMethod;
			methoduoeanchoriconobj['index'] = index;
var vParameters = methoduoeanchoriconrow.find("[name=Parameters]").text();
			methoduoeanchoriconobj['Parameters'] = vParameters;
			methoduoeanchoriconobj['index'] = index;
var vReturnType = methoduoeanchoriconrow.find("[name=ReturnType]").text();
			methoduoeanchoriconobj['ReturnType'] = vReturnType;
			methoduoeanchoriconobj['index'] = index;
var vDescription = methoduoeanchoriconrow.find("[name=Description]").text();
			methoduoeanchoriconobj['Description'] = vDescription;
			methoduoeanchoriconobj['index'] = index;

	methoduoeanchoricondata.push(methoduoeanchoriconobj);
});
return methoduoeanchoricondata;
	}
function getRowstbluoeanglearctype(){
	var tbluoeanglearctypedata = [];
	tbluoeanglearctyperows = $("#tbluoeanglearctype tbody tr");
tbluoeanglearctyperows.each(function (index) {
    var tbluoeanglearctyperow = $(this);
 	var tbluoeanglearctypeobj = {};
	var vProperty = tbluoeanglearctyperow.find("[name=Property]").text();
			tbluoeanglearctypeobj['Property'] = vProperty;
			tbluoeanglearctypeobj['index'] = index;
var vType = tbluoeanglearctyperow.find("[name=Type]").text();
			tbluoeanglearctypeobj['Type'] = vType;
			tbluoeanglearctypeobj['index'] = index;
var vDefaultValue = tbluoeanglearctyperow.find("[name=DefaultValue]").text();
			tbluoeanglearctypeobj['DefaultValue'] = vDefaultValue;
			tbluoeanglearctypeobj['index'] = index;
var vDescription = tbluoeanglearctyperow.find("[name=Description]").text();
			tbluoeanglearctypeobj['Description'] = vDescription;
			tbluoeanglearctypeobj['index'] = index;

	tbluoeanglearctypedata.push(tbluoeanglearctypeobj);
});
return tbluoeanglearctypedata;
	}
function getRowsmethoduoeanglearctype(){
	var methoduoeanglearctypedata = [];
	methoduoeanglearctyperows = $("#methoduoeanglearctype tbody tr");
methoduoeanglearctyperows.each(function (index) {
    var methoduoeanglearctyperow = $(this);
 	var methoduoeanglearctypeobj = {};
	var vMethod = methoduoeanglearctyperow.find("[name=Method]").text();
			methoduoeanglearctypeobj['Method'] = vMethod;
			methoduoeanglearctypeobj['index'] = index;
var vParameters = methoduoeanglearctyperow.find("[name=Parameters]").text();
			methoduoeanglearctypeobj['Parameters'] = vParameters;
			methoduoeanglearctypeobj['index'] = index;
var vReturnType = methoduoeanglearctyperow.find("[name=ReturnType]").text();
			methoduoeanglearctypeobj['ReturnType'] = vReturnType;
			methoduoeanglearctypeobj['index'] = index;
var vDescription = methoduoeanglearctyperow.find("[name=Description]").text();
			methoduoeanglearctypeobj['Description'] = vDescription;
			methoduoeanglearctypeobj['index'] = index;

	methoduoeanglearctypedata.push(methoduoeanglearctypeobj);
});
return methoduoeanglearctypedata;
	}
function getRowstbluoeangleoffsettype(){
	var tbluoeangleoffsettypedata = [];
	tbluoeangleoffsettyperows = $("#tbluoeangleoffsettype tbody tr");
tbluoeangleoffsettyperows.each(function (index) {
    var tbluoeangleoffsettyperow = $(this);
 	var tbluoeangleoffsettypeobj = {};
	var vProperty = tbluoeangleoffsettyperow.find("[name=Property]").text();
			tbluoeangleoffsettypeobj['Property'] = vProperty;
			tbluoeangleoffsettypeobj['index'] = index;
var vType = tbluoeangleoffsettyperow.find("[name=Type]").text();
			tbluoeangleoffsettypeobj['Type'] = vType;
			tbluoeangleoffsettypeobj['index'] = index;
var vDefaultValue = tbluoeangleoffsettyperow.find("[name=DefaultValue]").text();
			tbluoeangleoffsettypeobj['DefaultValue'] = vDefaultValue;
			tbluoeangleoffsettypeobj['index'] = index;
var vDescription = tbluoeangleoffsettyperow.find("[name=Description]").text();
			tbluoeangleoffsettypeobj['Description'] = vDescription;
			tbluoeangleoffsettypeobj['index'] = index;

	tbluoeangleoffsettypedata.push(tbluoeangleoffsettypeobj);
});
return tbluoeangleoffsettypedata;
	}
function getRowsmethoduoeangleoffsettype(){
	var methoduoeangleoffsettypedata = [];
	methoduoeangleoffsettyperows = $("#methoduoeangleoffsettype tbody tr");
methoduoeangleoffsettyperows.each(function (index) {
    var methoduoeangleoffsettyperow = $(this);
 	var methoduoeangleoffsettypeobj = {};
	var vMethod = methoduoeangleoffsettyperow.find("[name=Method]").text();
			methoduoeangleoffsettypeobj['Method'] = vMethod;
			methoduoeangleoffsettypeobj['index'] = index;
var vParameters = methoduoeangleoffsettyperow.find("[name=Parameters]").text();
			methoduoeangleoffsettypeobj['Parameters'] = vParameters;
			methoduoeangleoffsettypeobj['index'] = index;
var vReturnType = methoduoeangleoffsettyperow.find("[name=ReturnType]").text();
			methoduoeangleoffsettypeobj['ReturnType'] = vReturnType;
			methoduoeangleoffsettypeobj['index'] = index;
var vDescription = methoduoeangleoffsettyperow.find("[name=Description]").text();
			methoduoeangleoffsettypeobj['Description'] = vDescription;
			methoduoeangleoffsettypeobj['index'] = index;

	methoduoeangleoffsettypedata.push(methoduoeangleoffsettypeobj);
});
return methoduoeangleoffsettypedata;
	}
function getRowstbluoeanimation(){
	var tbluoeanimationdata = [];
	tbluoeanimationrows = $("#tbluoeanimation tbody tr");
tbluoeanimationrows.each(function (index) {
    var tbluoeanimationrow = $(this);
 	var tbluoeanimationobj = {};
	var vProperty = tbluoeanimationrow.find("[name=Property]").text();
			tbluoeanimationobj['Property'] = vProperty;
			tbluoeanimationobj['index'] = index;
var vType = tbluoeanimationrow.find("[name=Type]").text();
			tbluoeanimationobj['Type'] = vType;
			tbluoeanimationobj['index'] = index;
var vDefaultValue = tbluoeanimationrow.find("[name=DefaultValue]").text();
			tbluoeanimationobj['DefaultValue'] = vDefaultValue;
			tbluoeanimationobj['index'] = index;
var vDescription = tbluoeanimationrow.find("[name=Description]").text();
			tbluoeanimationobj['Description'] = vDescription;
			tbluoeanimationobj['index'] = index;

	tbluoeanimationdata.push(tbluoeanimationobj);
});
return tbluoeanimationdata;
	}
function getRowsmethoduoeanimation(){
	var methoduoeanimationdata = [];
	methoduoeanimationrows = $("#methoduoeanimation tbody tr");
methoduoeanimationrows.each(function (index) {
    var methoduoeanimationrow = $(this);
 	var methoduoeanimationobj = {};
	var vMethod = methoduoeanimationrow.find("[name=Method]").text();
			methoduoeanimationobj['Method'] = vMethod;
			methoduoeanimationobj['index'] = index;
var vParameters = methoduoeanimationrow.find("[name=Parameters]").text();
			methoduoeanimationobj['Parameters'] = vParameters;
			methoduoeanimationobj['index'] = index;
var vReturnType = methoduoeanimationrow.find("[name=ReturnType]").text();
			methoduoeanimationobj['ReturnType'] = vReturnType;
			methoduoeanimationobj['index'] = index;
var vDescription = methoduoeanimationrow.find("[name=Description]").text();
			methoduoeanimationobj['Description'] = vDescription;
			methoduoeanimationobj['index'] = index;

	methoduoeanimationdata.push(methoduoeanimationobj);
});
return methoduoeanimationdata;
	}
function getRowstbluoeapp(){
	var tbluoeappdata = [];
	tbluoeapprows = $("#tbluoeapp tbody tr");
tbluoeapprows.each(function (index) {
    var tbluoeapprow = $(this);
 	var tbluoeappobj = {};
	var vProperty = tbluoeapprow.find("[name=Property]").text();
			tbluoeappobj['Property'] = vProperty;
			tbluoeappobj['index'] = index;
var vType = tbluoeapprow.find("[name=Type]").text();
			tbluoeappobj['Type'] = vType;
			tbluoeappobj['index'] = index;
var vDefaultValue = tbluoeapprow.find("[name=DefaultValue]").text();
			tbluoeappobj['DefaultValue'] = vDefaultValue;
			tbluoeappobj['index'] = index;
var vDescription = tbluoeapprow.find("[name=Description]").text();
			tbluoeappobj['Description'] = vDescription;
			tbluoeappobj['index'] = index;

	tbluoeappdata.push(tbluoeappobj);
});
return tbluoeappdata;
	}
function getRowsmethoduoeapp(){
	var methoduoeappdata = [];
	methoduoeapprows = $("#methoduoeapp tbody tr");
methoduoeapprows.each(function (index) {
    var methoduoeapprow = $(this);
 	var methoduoeappobj = {};
	var vMethod = methoduoeapprow.find("[name=Method]").text();
			methoduoeappobj['Method'] = vMethod;
			methoduoeappobj['index'] = index;
var vParameters = methoduoeapprow.find("[name=Parameters]").text();
			methoduoeappobj['Parameters'] = vParameters;
			methoduoeappobj['index'] = index;
var vReturnType = methoduoeapprow.find("[name=ReturnType]").text();
			methoduoeappobj['ReturnType'] = vReturnType;
			methoduoeappobj['index'] = index;
var vDescription = methoduoeapprow.find("[name=Description]").text();
			methoduoeappobj['Description'] = vDescription;
			methoduoeappobj['index'] = index;

	methoduoeappdata.push(methoduoeappobj);
});
return methoduoeappdata;
	}
function getRowstbluoeaxios(){
	var tbluoeaxiosdata = [];
	tbluoeaxiosrows = $("#tbluoeaxios tbody tr");
tbluoeaxiosrows.each(function (index) {
    var tbluoeaxiosrow = $(this);
 	var tbluoeaxiosobj = {};
	var vProperty = tbluoeaxiosrow.find("[name=Property]").text();
			tbluoeaxiosobj['Property'] = vProperty;
			tbluoeaxiosobj['index'] = index;
var vType = tbluoeaxiosrow.find("[name=Type]").text();
			tbluoeaxiosobj['Type'] = vType;
			tbluoeaxiosobj['index'] = index;
var vDefaultValue = tbluoeaxiosrow.find("[name=DefaultValue]").text();
			tbluoeaxiosobj['DefaultValue'] = vDefaultValue;
			tbluoeaxiosobj['index'] = index;
var vDescription = tbluoeaxiosrow.find("[name=Description]").text();
			tbluoeaxiosobj['Description'] = vDescription;
			tbluoeaxiosobj['index'] = index;

	tbluoeaxiosdata.push(tbluoeaxiosobj);
});
return tbluoeaxiosdata;
	}
function getRowsmethoduoeaxios(){
	var methoduoeaxiosdata = [];
	methoduoeaxiosrows = $("#methoduoeaxios tbody tr");
methoduoeaxiosrows.each(function (index) {
    var methoduoeaxiosrow = $(this);
 	var methoduoeaxiosobj = {};
	var vMethod = methoduoeaxiosrow.find("[name=Method]").text();
			methoduoeaxiosobj['Method'] = vMethod;
			methoduoeaxiosobj['index'] = index;
var vParameters = methoduoeaxiosrow.find("[name=Parameters]").text();
			methoduoeaxiosobj['Parameters'] = vParameters;
			methoduoeaxiosobj['index'] = index;
var vReturnType = methoduoeaxiosrow.find("[name=ReturnType]").text();
			methoduoeaxiosobj['ReturnType'] = vReturnType;
			methoduoeaxiosobj['index'] = index;
var vDescription = methoduoeaxiosrow.find("[name=Description]").text();
			methoduoeaxiosobj['Description'] = vDescription;
			methoduoeaxiosobj['index'] = index;

	methoduoeaxiosdata.push(methoduoeaxiosobj);
});
return methoduoeaxiosdata;
	}
function getRowstbluoebackgroundvideo(){
	var tbluoebackgroundvideodata = [];
	tbluoebackgroundvideorows = $("#tbluoebackgroundvideo tbody tr");
tbluoebackgroundvideorows.each(function (index) {
    var tbluoebackgroundvideorow = $(this);
 	var tbluoebackgroundvideoobj = {};
	var vProperty = tbluoebackgroundvideorow.find("[name=Property]").text();
			tbluoebackgroundvideoobj['Property'] = vProperty;
			tbluoebackgroundvideoobj['index'] = index;
var vType = tbluoebackgroundvideorow.find("[name=Type]").text();
			tbluoebackgroundvideoobj['Type'] = vType;
			tbluoebackgroundvideoobj['index'] = index;
var vDefaultValue = tbluoebackgroundvideorow.find("[name=DefaultValue]").text();
			tbluoebackgroundvideoobj['DefaultValue'] = vDefaultValue;
			tbluoebackgroundvideoobj['index'] = index;
var vDescription = tbluoebackgroundvideorow.find("[name=Description]").text();
			tbluoebackgroundvideoobj['Description'] = vDescription;
			tbluoebackgroundvideoobj['index'] = index;

	tbluoebackgroundvideodata.push(tbluoebackgroundvideoobj);
});
return tbluoebackgroundvideodata;
	}
function getRowsmethoduoebackgroundvideo(){
	var methoduoebackgroundvideodata = [];
	methoduoebackgroundvideorows = $("#methoduoebackgroundvideo tbody tr");
methoduoebackgroundvideorows.each(function (index) {
    var methoduoebackgroundvideorow = $(this);
 	var methoduoebackgroundvideoobj = {};
	var vMethod = methoduoebackgroundvideorow.find("[name=Method]").text();
			methoduoebackgroundvideoobj['Method'] = vMethod;
			methoduoebackgroundvideoobj['index'] = index;
var vParameters = methoduoebackgroundvideorow.find("[name=Parameters]").text();
			methoduoebackgroundvideoobj['Parameters'] = vParameters;
			methoduoebackgroundvideoobj['index'] = index;
var vReturnType = methoduoebackgroundvideorow.find("[name=ReturnType]").text();
			methoduoebackgroundvideoobj['ReturnType'] = vReturnType;
			methoduoebackgroundvideoobj['index'] = index;
var vDescription = methoduoebackgroundvideorow.find("[name=Description]").text();
			methoduoebackgroundvideoobj['Description'] = vDescription;
			methoduoebackgroundvideoobj['index'] = index;

	methoduoebackgroundvideodata.push(methoduoebackgroundvideoobj);
});
return methoduoebackgroundvideodata;
	}
function getRowstbluoebadge(){
	var tbluoebadgedata = [];
	tbluoebadgerows = $("#tbluoebadge tbody tr");
tbluoebadgerows.each(function (index) {
    var tbluoebadgerow = $(this);
 	var tbluoebadgeobj = {};
	var vProperty = tbluoebadgerow.find("[name=Property]").text();
			tbluoebadgeobj['Property'] = vProperty;
			tbluoebadgeobj['index'] = index;
var vType = tbluoebadgerow.find("[name=Type]").text();
			tbluoebadgeobj['Type'] = vType;
			tbluoebadgeobj['index'] = index;
var vDefaultValue = tbluoebadgerow.find("[name=DefaultValue]").text();
			tbluoebadgeobj['DefaultValue'] = vDefaultValue;
			tbluoebadgeobj['index'] = index;
var vDescription = tbluoebadgerow.find("[name=Description]").text();
			tbluoebadgeobj['Description'] = vDescription;
			tbluoebadgeobj['index'] = index;

	tbluoebadgedata.push(tbluoebadgeobj);
});
return tbluoebadgedata;
	}
function getRowsmethoduoebadge(){
	var methoduoebadgedata = [];
	methoduoebadgerows = $("#methoduoebadge tbody tr");
methoduoebadgerows.each(function (index) {
    var methoduoebadgerow = $(this);
 	var methoduoebadgeobj = {};
	var vMethod = methoduoebadgerow.find("[name=Method]").text();
			methoduoebadgeobj['Method'] = vMethod;
			methoduoebadgeobj['index'] = index;
var vParameters = methoduoebadgerow.find("[name=Parameters]").text();
			methoduoebadgeobj['Parameters'] = vParameters;
			methoduoebadgeobj['index'] = index;
var vReturnType = methoduoebadgerow.find("[name=ReturnType]").text();
			methoduoebadgeobj['ReturnType'] = vReturnType;
			methoduoebadgeobj['index'] = index;
var vDescription = methoduoebadgerow.find("[name=Description]").text();
			methoduoebadgeobj['Description'] = vDescription;
			methoduoebadgeobj['index'] = index;

	methoduoebadgedata.push(methoduoebadgeobj);
});
return methoduoebadgedata;
	}
function getRowstbluoebillboardchart(){
	var tbluoebillboardchartdata = [];
	tbluoebillboardchartrows = $("#tbluoebillboardchart tbody tr");
tbluoebillboardchartrows.each(function (index) {
    var tbluoebillboardchartrow = $(this);
 	var tbluoebillboardchartobj = {};
	var vProperty = tbluoebillboardchartrow.find("[name=Property]").text();
			tbluoebillboardchartobj['Property'] = vProperty;
			tbluoebillboardchartobj['index'] = index;
var vType = tbluoebillboardchartrow.find("[name=Type]").text();
			tbluoebillboardchartobj['Type'] = vType;
			tbluoebillboardchartobj['index'] = index;
var vDefaultValue = tbluoebillboardchartrow.find("[name=DefaultValue]").text();
			tbluoebillboardchartobj['DefaultValue'] = vDefaultValue;
			tbluoebillboardchartobj['index'] = index;
var vDescription = tbluoebillboardchartrow.find("[name=Description]").text();
			tbluoebillboardchartobj['Description'] = vDescription;
			tbluoebillboardchartobj['index'] = index;

	tbluoebillboardchartdata.push(tbluoebillboardchartobj);
});
return tbluoebillboardchartdata;
	}
function getRowsmethoduoebillboardchart(){
	var methoduoebillboardchartdata = [];
	methoduoebillboardchartrows = $("#methoduoebillboardchart tbody tr");
methoduoebillboardchartrows.each(function (index) {
    var methoduoebillboardchartrow = $(this);
 	var methoduoebillboardchartobj = {};
	var vMethod = methoduoebillboardchartrow.find("[name=Method]").text();
			methoduoebillboardchartobj['Method'] = vMethod;
			methoduoebillboardchartobj['index'] = index;
var vParameters = methoduoebillboardchartrow.find("[name=Parameters]").text();
			methoduoebillboardchartobj['Parameters'] = vParameters;
			methoduoebillboardchartobj['index'] = index;
var vReturnType = methoduoebillboardchartrow.find("[name=ReturnType]").text();
			methoduoebillboardchartobj['ReturnType'] = vReturnType;
			methoduoebillboardchartobj['index'] = index;
var vDescription = methoduoebillboardchartrow.find("[name=Description]").text();
			methoduoebillboardchartobj['Description'] = vDescription;
			methoduoebillboardchartobj['index'] = index;

	methoduoebillboardchartdata.push(methoduoebillboardchartobj);
});
return methoduoebillboardchartdata;
	}
function getRowstbluoebillboardcharttype(){
	var tbluoebillboardcharttypedata = [];
	tbluoebillboardcharttyperows = $("#tbluoebillboardcharttype tbody tr");
tbluoebillboardcharttyperows.each(function (index) {
    var tbluoebillboardcharttyperow = $(this);
 	var tbluoebillboardcharttypeobj = {};
	var vProperty = tbluoebillboardcharttyperow.find("[name=Property]").text();
			tbluoebillboardcharttypeobj['Property'] = vProperty;
			tbluoebillboardcharttypeobj['index'] = index;
var vType = tbluoebillboardcharttyperow.find("[name=Type]").text();
			tbluoebillboardcharttypeobj['Type'] = vType;
			tbluoebillboardcharttypeobj['index'] = index;
var vDefaultValue = tbluoebillboardcharttyperow.find("[name=DefaultValue]").text();
			tbluoebillboardcharttypeobj['DefaultValue'] = vDefaultValue;
			tbluoebillboardcharttypeobj['index'] = index;
var vDescription = tbluoebillboardcharttyperow.find("[name=Description]").text();
			tbluoebillboardcharttypeobj['Description'] = vDescription;
			tbluoebillboardcharttypeobj['index'] = index;

	tbluoebillboardcharttypedata.push(tbluoebillboardcharttypeobj);
});
return tbluoebillboardcharttypedata;
	}
function getRowsmethoduoebillboardcharttype(){
	var methoduoebillboardcharttypedata = [];
	methoduoebillboardcharttyperows = $("#methoduoebillboardcharttype tbody tr");
methoduoebillboardcharttyperows.each(function (index) {
    var methoduoebillboardcharttyperow = $(this);
 	var methoduoebillboardcharttypeobj = {};
	var vMethod = methoduoebillboardcharttyperow.find("[name=Method]").text();
			methoduoebillboardcharttypeobj['Method'] = vMethod;
			methoduoebillboardcharttypeobj['index'] = index;
var vParameters = methoduoebillboardcharttyperow.find("[name=Parameters]").text();
			methoduoebillboardcharttypeobj['Parameters'] = vParameters;
			methoduoebillboardcharttypeobj['index'] = index;
var vReturnType = methoduoebillboardcharttyperow.find("[name=ReturnType]").text();
			methoduoebillboardcharttypeobj['ReturnType'] = vReturnType;
			methoduoebillboardcharttypeobj['index'] = index;
var vDescription = methoduoebillboardcharttyperow.find("[name=Description]").text();
			methoduoebillboardcharttypeobj['Description'] = vDescription;
			methoduoebillboardcharttypeobj['index'] = index;

	methoduoebillboardcharttypedata.push(methoduoebillboardcharttypeobj);
});
return methoduoebillboardcharttypedata;
	}
function getRowstbluoebillboarddonuttype(){
	var tbluoebillboarddonuttypedata = [];
	tbluoebillboarddonuttyperows = $("#tbluoebillboarddonuttype tbody tr");
tbluoebillboarddonuttyperows.each(function (index) {
    var tbluoebillboarddonuttyperow = $(this);
 	var tbluoebillboarddonuttypeobj = {};
	var vProperty = tbluoebillboarddonuttyperow.find("[name=Property]").text();
			tbluoebillboarddonuttypeobj['Property'] = vProperty;
			tbluoebillboarddonuttypeobj['index'] = index;
var vType = tbluoebillboarddonuttyperow.find("[name=Type]").text();
			tbluoebillboarddonuttypeobj['Type'] = vType;
			tbluoebillboarddonuttypeobj['index'] = index;
var vDefaultValue = tbluoebillboarddonuttyperow.find("[name=DefaultValue]").text();
			tbluoebillboarddonuttypeobj['DefaultValue'] = vDefaultValue;
			tbluoebillboarddonuttypeobj['index'] = index;
var vDescription = tbluoebillboarddonuttyperow.find("[name=Description]").text();
			tbluoebillboarddonuttypeobj['Description'] = vDescription;
			tbluoebillboarddonuttypeobj['index'] = index;

	tbluoebillboarddonuttypedata.push(tbluoebillboarddonuttypeobj);
});
return tbluoebillboarddonuttypedata;
	}
function getRowsmethoduoebillboarddonuttype(){
	var methoduoebillboarddonuttypedata = [];
	methoduoebillboarddonuttyperows = $("#methoduoebillboarddonuttype tbody tr");
methoduoebillboarddonuttyperows.each(function (index) {
    var methoduoebillboarddonuttyperow = $(this);
 	var methoduoebillboarddonuttypeobj = {};
	var vMethod = methoduoebillboarddonuttyperow.find("[name=Method]").text();
			methoduoebillboarddonuttypeobj['Method'] = vMethod;
			methoduoebillboarddonuttypeobj['index'] = index;
var vParameters = methoduoebillboarddonuttyperow.find("[name=Parameters]").text();
			methoduoebillboarddonuttypeobj['Parameters'] = vParameters;
			methoduoebillboarddonuttypeobj['index'] = index;
var vReturnType = methoduoebillboarddonuttyperow.find("[name=ReturnType]").text();
			methoduoebillboarddonuttypeobj['ReturnType'] = vReturnType;
			methoduoebillboarddonuttypeobj['index'] = index;
var vDescription = methoduoebillboarddonuttyperow.find("[name=Description]").text();
			methoduoebillboarddonuttypeobj['Description'] = vDescription;
			methoduoebillboarddonuttypeobj['index'] = index;

	methoduoebillboarddonuttypedata.push(methoduoebillboarddonuttypeobj);
});
return methoduoebillboarddonuttypedata;
	}
function getRowstbluoebillboardgaugetype(){
	var tbluoebillboardgaugetypedata = [];
	tbluoebillboardgaugetyperows = $("#tbluoebillboardgaugetype tbody tr");
tbluoebillboardgaugetyperows.each(function (index) {
    var tbluoebillboardgaugetyperow = $(this);
 	var tbluoebillboardgaugetypeobj = {};
	var vProperty = tbluoebillboardgaugetyperow.find("[name=Property]").text();
			tbluoebillboardgaugetypeobj['Property'] = vProperty;
			tbluoebillboardgaugetypeobj['index'] = index;
var vType = tbluoebillboardgaugetyperow.find("[name=Type]").text();
			tbluoebillboardgaugetypeobj['Type'] = vType;
			tbluoebillboardgaugetypeobj['index'] = index;
var vDefaultValue = tbluoebillboardgaugetyperow.find("[name=DefaultValue]").text();
			tbluoebillboardgaugetypeobj['DefaultValue'] = vDefaultValue;
			tbluoebillboardgaugetypeobj['index'] = index;
var vDescription = tbluoebillboardgaugetyperow.find("[name=Description]").text();
			tbluoebillboardgaugetypeobj['Description'] = vDescription;
			tbluoebillboardgaugetypeobj['index'] = index;

	tbluoebillboardgaugetypedata.push(tbluoebillboardgaugetypeobj);
});
return tbluoebillboardgaugetypedata;
	}
function getRowsmethoduoebillboardgaugetype(){
	var methoduoebillboardgaugetypedata = [];
	methoduoebillboardgaugetyperows = $("#methoduoebillboardgaugetype tbody tr");
methoduoebillboardgaugetyperows.each(function (index) {
    var methoduoebillboardgaugetyperow = $(this);
 	var methoduoebillboardgaugetypeobj = {};
	var vMethod = methoduoebillboardgaugetyperow.find("[name=Method]").text();
			methoduoebillboardgaugetypeobj['Method'] = vMethod;
			methoduoebillboardgaugetypeobj['index'] = index;
var vParameters = methoduoebillboardgaugetyperow.find("[name=Parameters]").text();
			methoduoebillboardgaugetypeobj['Parameters'] = vParameters;
			methoduoebillboardgaugetypeobj['index'] = index;
var vReturnType = methoduoebillboardgaugetyperow.find("[name=ReturnType]").text();
			methoduoebillboardgaugetypeobj['ReturnType'] = vReturnType;
			methoduoebillboardgaugetypeobj['index'] = index;
var vDescription = methoduoebillboardgaugetyperow.find("[name=Description]").text();
			methoduoebillboardgaugetypeobj['Description'] = vDescription;
			methoduoebillboardgaugetypeobj['index'] = index;

	methoduoebillboardgaugetypedata.push(methoduoebillboardgaugetypeobj);
});
return methoduoebillboardgaugetypedata;
	}
function getRowstbluoebillboardlegendpositiontype(){
	var tbluoebillboardlegendpositiontypedata = [];
	tbluoebillboardlegendpositiontyperows = $("#tbluoebillboardlegendpositiontype tbody tr");
tbluoebillboardlegendpositiontyperows.each(function (index) {
    var tbluoebillboardlegendpositiontyperow = $(this);
 	var tbluoebillboardlegendpositiontypeobj = {};
	var vProperty = tbluoebillboardlegendpositiontyperow.find("[name=Property]").text();
			tbluoebillboardlegendpositiontypeobj['Property'] = vProperty;
			tbluoebillboardlegendpositiontypeobj['index'] = index;
var vType = tbluoebillboardlegendpositiontyperow.find("[name=Type]").text();
			tbluoebillboardlegendpositiontypeobj['Type'] = vType;
			tbluoebillboardlegendpositiontypeobj['index'] = index;
var vDefaultValue = tbluoebillboardlegendpositiontyperow.find("[name=DefaultValue]").text();
			tbluoebillboardlegendpositiontypeobj['DefaultValue'] = vDefaultValue;
			tbluoebillboardlegendpositiontypeobj['index'] = index;
var vDescription = tbluoebillboardlegendpositiontyperow.find("[name=Description]").text();
			tbluoebillboardlegendpositiontypeobj['Description'] = vDescription;
			tbluoebillboardlegendpositiontypeobj['index'] = index;

	tbluoebillboardlegendpositiontypedata.push(tbluoebillboardlegendpositiontypeobj);
});
return tbluoebillboardlegendpositiontypedata;
	}
function getRowsmethoduoebillboardlegendpositiontype(){
	var methoduoebillboardlegendpositiontypedata = [];
	methoduoebillboardlegendpositiontyperows = $("#methoduoebillboardlegendpositiontype tbody tr");
methoduoebillboardlegendpositiontyperows.each(function (index) {
    var methoduoebillboardlegendpositiontyperow = $(this);
 	var methoduoebillboardlegendpositiontypeobj = {};
	var vMethod = methoduoebillboardlegendpositiontyperow.find("[name=Method]").text();
			methoduoebillboardlegendpositiontypeobj['Method'] = vMethod;
			methoduoebillboardlegendpositiontypeobj['index'] = index;
var vParameters = methoduoebillboardlegendpositiontyperow.find("[name=Parameters]").text();
			methoduoebillboardlegendpositiontypeobj['Parameters'] = vParameters;
			methoduoebillboardlegendpositiontypeobj['index'] = index;
var vReturnType = methoduoebillboardlegendpositiontyperow.find("[name=ReturnType]").text();
			methoduoebillboardlegendpositiontypeobj['ReturnType'] = vReturnType;
			methoduoebillboardlegendpositiontypeobj['index'] = index;
var vDescription = methoduoebillboardlegendpositiontyperow.find("[name=Description]").text();
			methoduoebillboardlegendpositiontypeobj['Description'] = vDescription;
			methoduoebillboardlegendpositiontypeobj['index'] = index;

	methoduoebillboardlegendpositiontypedata.push(methoduoebillboardlegendpositiontypeobj);
});
return methoduoebillboardlegendpositiontypedata;
	}
function getRowstbluoebillboardlegendtype(){
	var tbluoebillboardlegendtypedata = [];
	tbluoebillboardlegendtyperows = $("#tbluoebillboardlegendtype tbody tr");
tbluoebillboardlegendtyperows.each(function (index) {
    var tbluoebillboardlegendtyperow = $(this);
 	var tbluoebillboardlegendtypeobj = {};
	var vProperty = tbluoebillboardlegendtyperow.find("[name=Property]").text();
			tbluoebillboardlegendtypeobj['Property'] = vProperty;
			tbluoebillboardlegendtypeobj['index'] = index;
var vType = tbluoebillboardlegendtyperow.find("[name=Type]").text();
			tbluoebillboardlegendtypeobj['Type'] = vType;
			tbluoebillboardlegendtypeobj['index'] = index;
var vDefaultValue = tbluoebillboardlegendtyperow.find("[name=DefaultValue]").text();
			tbluoebillboardlegendtypeobj['DefaultValue'] = vDefaultValue;
			tbluoebillboardlegendtypeobj['index'] = index;
var vDescription = tbluoebillboardlegendtyperow.find("[name=Description]").text();
			tbluoebillboardlegendtypeobj['Description'] = vDescription;
			tbluoebillboardlegendtypeobj['index'] = index;

	tbluoebillboardlegendtypedata.push(tbluoebillboardlegendtypeobj);
});
return tbluoebillboardlegendtypedata;
	}
function getRowsmethoduoebillboardlegendtype(){
	var methoduoebillboardlegendtypedata = [];
	methoduoebillboardlegendtyperows = $("#methoduoebillboardlegendtype tbody tr");
methoduoebillboardlegendtyperows.each(function (index) {
    var methoduoebillboardlegendtyperow = $(this);
 	var methoduoebillboardlegendtypeobj = {};
	var vMethod = methoduoebillboardlegendtyperow.find("[name=Method]").text();
			methoduoebillboardlegendtypeobj['Method'] = vMethod;
			methoduoebillboardlegendtypeobj['index'] = index;
var vParameters = methoduoebillboardlegendtyperow.find("[name=Parameters]").text();
			methoduoebillboardlegendtypeobj['Parameters'] = vParameters;
			methoduoebillboardlegendtypeobj['index'] = index;
var vReturnType = methoduoebillboardlegendtyperow.find("[name=ReturnType]").text();
			methoduoebillboardlegendtypeobj['ReturnType'] = vReturnType;
			methoduoebillboardlegendtypeobj['index'] = index;
var vDescription = methoduoebillboardlegendtyperow.find("[name=Description]").text();
			methoduoebillboardlegendtypeobj['Description'] = vDescription;
			methoduoebillboardlegendtypeobj['index'] = index;

	methoduoebillboardlegendtypedata.push(methoduoebillboardlegendtypeobj);
});
return methoduoebillboardlegendtypedata;
	}
function getRowstbluoebillboardpietype(){
	var tbluoebillboardpietypedata = [];
	tbluoebillboardpietyperows = $("#tbluoebillboardpietype tbody tr");
tbluoebillboardpietyperows.each(function (index) {
    var tbluoebillboardpietyperow = $(this);
 	var tbluoebillboardpietypeobj = {};
	var vProperty = tbluoebillboardpietyperow.find("[name=Property]").text();
			tbluoebillboardpietypeobj['Property'] = vProperty;
			tbluoebillboardpietypeobj['index'] = index;
var vType = tbluoebillboardpietyperow.find("[name=Type]").text();
			tbluoebillboardpietypeobj['Type'] = vType;
			tbluoebillboardpietypeobj['index'] = index;
var vDefaultValue = tbluoebillboardpietyperow.find("[name=DefaultValue]").text();
			tbluoebillboardpietypeobj['DefaultValue'] = vDefaultValue;
			tbluoebillboardpietypeobj['index'] = index;
var vDescription = tbluoebillboardpietyperow.find("[name=Description]").text();
			tbluoebillboardpietypeobj['Description'] = vDescription;
			tbluoebillboardpietypeobj['index'] = index;

	tbluoebillboardpietypedata.push(tbluoebillboardpietypeobj);
});
return tbluoebillboardpietypedata;
	}
function getRowsmethoduoebillboardpietype(){
	var methoduoebillboardpietypedata = [];
	methoduoebillboardpietyperows = $("#methoduoebillboardpietype tbody tr");
methoduoebillboardpietyperows.each(function (index) {
    var methoduoebillboardpietyperow = $(this);
 	var methoduoebillboardpietypeobj = {};
	var vMethod = methoduoebillboardpietyperow.find("[name=Method]").text();
			methoduoebillboardpietypeobj['Method'] = vMethod;
			methoduoebillboardpietypeobj['index'] = index;
var vParameters = methoduoebillboardpietyperow.find("[name=Parameters]").text();
			methoduoebillboardpietypeobj['Parameters'] = vParameters;
			methoduoebillboardpietypeobj['index'] = index;
var vReturnType = methoduoebillboardpietyperow.find("[name=ReturnType]").text();
			methoduoebillboardpietypeobj['ReturnType'] = vReturnType;
			methoduoebillboardpietypeobj['index'] = index;
var vDescription = methoduoebillboardpietyperow.find("[name=Description]").text();
			methoduoebillboardpietypeobj['Description'] = vDescription;
			methoduoebillboardpietypeobj['index'] = index;

	methoduoebillboardpietypedata.push(methoduoebillboardpietypeobj);
});
return methoduoebillboardpietypedata;
	}
function getRowstbluoebillboardradartype(){
	var tbluoebillboardradartypedata = [];
	tbluoebillboardradartyperows = $("#tbluoebillboardradartype tbody tr");
tbluoebillboardradartyperows.each(function (index) {
    var tbluoebillboardradartyperow = $(this);
 	var tbluoebillboardradartypeobj = {};
	var vProperty = tbluoebillboardradartyperow.find("[name=Property]").text();
			tbluoebillboardradartypeobj['Property'] = vProperty;
			tbluoebillboardradartypeobj['index'] = index;
var vType = tbluoebillboardradartyperow.find("[name=Type]").text();
			tbluoebillboardradartypeobj['Type'] = vType;
			tbluoebillboardradartypeobj['index'] = index;
var vDefaultValue = tbluoebillboardradartyperow.find("[name=DefaultValue]").text();
			tbluoebillboardradartypeobj['DefaultValue'] = vDefaultValue;
			tbluoebillboardradartypeobj['index'] = index;
var vDescription = tbluoebillboardradartyperow.find("[name=Description]").text();
			tbluoebillboardradartypeobj['Description'] = vDescription;
			tbluoebillboardradartypeobj['index'] = index;

	tbluoebillboardradartypedata.push(tbluoebillboardradartypeobj);
});
return tbluoebillboardradartypedata;
	}
function getRowsmethoduoebillboardradartype(){
	var methoduoebillboardradartypedata = [];
	methoduoebillboardradartyperows = $("#methoduoebillboardradartype tbody tr");
methoduoebillboardradartyperows.each(function (index) {
    var methoduoebillboardradartyperow = $(this);
 	var methoduoebillboardradartypeobj = {};
	var vMethod = methoduoebillboardradartyperow.find("[name=Method]").text();
			methoduoebillboardradartypeobj['Method'] = vMethod;
			methoduoebillboardradartypeobj['index'] = index;
var vParameters = methoduoebillboardradartyperow.find("[name=Parameters]").text();
			methoduoebillboardradartypeobj['Parameters'] = vParameters;
			methoduoebillboardradartypeobj['index'] = index;
var vReturnType = methoduoebillboardradartyperow.find("[name=ReturnType]").text();
			methoduoebillboardradartypeobj['ReturnType'] = vReturnType;
			methoduoebillboardradartypeobj['index'] = index;
var vDescription = methoduoebillboardradartyperow.find("[name=Description]").text();
			methoduoebillboardradartypeobj['Description'] = vDescription;
			methoduoebillboardradartypeobj['index'] = index;

	methoduoebillboardradartypedata.push(methoduoebillboardradartypeobj);
});
return methoduoebillboardradartypedata;
	}
function getRowstbluoebreadcrumbs(){
	var tbluoebreadcrumbsdata = [];
	tbluoebreadcrumbsrows = $("#tbluoebreadcrumbs tbody tr");
tbluoebreadcrumbsrows.each(function (index) {
    var tbluoebreadcrumbsrow = $(this);
 	var tbluoebreadcrumbsobj = {};
	var vProperty = tbluoebreadcrumbsrow.find("[name=Property]").text();
			tbluoebreadcrumbsobj['Property'] = vProperty;
			tbluoebreadcrumbsobj['index'] = index;
var vType = tbluoebreadcrumbsrow.find("[name=Type]").text();
			tbluoebreadcrumbsobj['Type'] = vType;
			tbluoebreadcrumbsobj['index'] = index;
var vDefaultValue = tbluoebreadcrumbsrow.find("[name=DefaultValue]").text();
			tbluoebreadcrumbsobj['DefaultValue'] = vDefaultValue;
			tbluoebreadcrumbsobj['index'] = index;
var vDescription = tbluoebreadcrumbsrow.find("[name=Description]").text();
			tbluoebreadcrumbsobj['Description'] = vDescription;
			tbluoebreadcrumbsobj['index'] = index;

	tbluoebreadcrumbsdata.push(tbluoebreadcrumbsobj);
});
return tbluoebreadcrumbsdata;
	}
function getRowsmethoduoebreadcrumbs(){
	var methoduoebreadcrumbsdata = [];
	methoduoebreadcrumbsrows = $("#methoduoebreadcrumbs tbody tr");
methoduoebreadcrumbsrows.each(function (index) {
    var methoduoebreadcrumbsrow = $(this);
 	var methoduoebreadcrumbsobj = {};
	var vMethod = methoduoebreadcrumbsrow.find("[name=Method]").text();
			methoduoebreadcrumbsobj['Method'] = vMethod;
			methoduoebreadcrumbsobj['index'] = index;
var vParameters = methoduoebreadcrumbsrow.find("[name=Parameters]").text();
			methoduoebreadcrumbsobj['Parameters'] = vParameters;
			methoduoebreadcrumbsobj['index'] = index;
var vReturnType = methoduoebreadcrumbsrow.find("[name=ReturnType]").text();
			methoduoebreadcrumbsobj['ReturnType'] = vReturnType;
			methoduoebreadcrumbsobj['index'] = index;
var vDescription = methoduoebreadcrumbsrow.find("[name=Description]").text();
			methoduoebreadcrumbsobj['Description'] = vDescription;
			methoduoebreadcrumbsobj['index'] = index;

	methoduoebreadcrumbsdata.push(methoduoebreadcrumbsobj);
});
return methoduoebreadcrumbsdata;
	}
function getRowstbluoebutton(){
	var tbluoebuttondata = [];
	tbluoebuttonrows = $("#tbluoebutton tbody tr");
tbluoebuttonrows.each(function (index) {
    var tbluoebuttonrow = $(this);
 	var tbluoebuttonobj = {};
	var vProperty = tbluoebuttonrow.find("[name=Property]").text();
			tbluoebuttonobj['Property'] = vProperty;
			tbluoebuttonobj['index'] = index;
var vType = tbluoebuttonrow.find("[name=Type]").text();
			tbluoebuttonobj['Type'] = vType;
			tbluoebuttonobj['index'] = index;
var vDefaultValue = tbluoebuttonrow.find("[name=DefaultValue]").text();
			tbluoebuttonobj['DefaultValue'] = vDefaultValue;
			tbluoebuttonobj['index'] = index;
var vDescription = tbluoebuttonrow.find("[name=Description]").text();
			tbluoebuttonobj['Description'] = vDescription;
			tbluoebuttonobj['index'] = index;

	tbluoebuttondata.push(tbluoebuttonobj);
});
return tbluoebuttondata;
	}
function getRowsmethoduoebutton(){
	var methoduoebuttondata = [];
	methoduoebuttonrows = $("#methoduoebutton tbody tr");
methoduoebuttonrows.each(function (index) {
    var methoduoebuttonrow = $(this);
 	var methoduoebuttonobj = {};
	var vMethod = methoduoebuttonrow.find("[name=Method]").text();
			methoduoebuttonobj['Method'] = vMethod;
			methoduoebuttonobj['index'] = index;
var vParameters = methoduoebuttonrow.find("[name=Parameters]").text();
			methoduoebuttonobj['Parameters'] = vParameters;
			methoduoebuttonobj['index'] = index;
var vReturnType = methoduoebuttonrow.find("[name=ReturnType]").text();
			methoduoebuttonobj['ReturnType'] = vReturnType;
			methoduoebuttonobj['index'] = index;
var vDescription = methoduoebuttonrow.find("[name=Description]").text();
			methoduoebuttonobj['Description'] = vDescription;
			methoduoebuttonobj['index'] = index;

	methoduoebuttondata.push(methoduoebuttonobj);
});
return methoduoebuttondata;
	}
function getRowstbluoebuttonsize(){
	var tbluoebuttonsizedata = [];
	tbluoebuttonsizerows = $("#tbluoebuttonsize tbody tr");
tbluoebuttonsizerows.each(function (index) {
    var tbluoebuttonsizerow = $(this);
 	var tbluoebuttonsizeobj = {};
	var vProperty = tbluoebuttonsizerow.find("[name=Property]").text();
			tbluoebuttonsizeobj['Property'] = vProperty;
			tbluoebuttonsizeobj['index'] = index;
var vType = tbluoebuttonsizerow.find("[name=Type]").text();
			tbluoebuttonsizeobj['Type'] = vType;
			tbluoebuttonsizeobj['index'] = index;
var vDefaultValue = tbluoebuttonsizerow.find("[name=DefaultValue]").text();
			tbluoebuttonsizeobj['DefaultValue'] = vDefaultValue;
			tbluoebuttonsizeobj['index'] = index;
var vDescription = tbluoebuttonsizerow.find("[name=Description]").text();
			tbluoebuttonsizeobj['Description'] = vDescription;
			tbluoebuttonsizeobj['index'] = index;

	tbluoebuttonsizedata.push(tbluoebuttonsizeobj);
});
return tbluoebuttonsizedata;
	}
function getRowsmethoduoebuttonsize(){
	var methoduoebuttonsizedata = [];
	methoduoebuttonsizerows = $("#methoduoebuttonsize tbody tr");
methoduoebuttonsizerows.each(function (index) {
    var methoduoebuttonsizerow = $(this);
 	var methoduoebuttonsizeobj = {};
	var vMethod = methoduoebuttonsizerow.find("[name=Method]").text();
			methoduoebuttonsizeobj['Method'] = vMethod;
			methoduoebuttonsizeobj['index'] = index;
var vParameters = methoduoebuttonsizerow.find("[name=Parameters]").text();
			methoduoebuttonsizeobj['Parameters'] = vParameters;
			methoduoebuttonsizeobj['index'] = index;
var vReturnType = methoduoebuttonsizerow.find("[name=ReturnType]").text();
			methoduoebuttonsizeobj['ReturnType'] = vReturnType;
			methoduoebuttonsizeobj['index'] = index;
var vDescription = methoduoebuttonsizerow.find("[name=Description]").text();
			methoduoebuttonsizeobj['Description'] = vDescription;
			methoduoebuttonsizeobj['index'] = index;

	methoduoebuttonsizedata.push(methoduoebuttonsizeobj);
});
return methoduoebuttonsizedata;
	}
function getRowstbluoebuttontype(){
	var tbluoebuttontypedata = [];
	tbluoebuttontyperows = $("#tbluoebuttontype tbody tr");
tbluoebuttontyperows.each(function (index) {
    var tbluoebuttontyperow = $(this);
 	var tbluoebuttontypeobj = {};
	var vProperty = tbluoebuttontyperow.find("[name=Property]").text();
			tbluoebuttontypeobj['Property'] = vProperty;
			tbluoebuttontypeobj['index'] = index;
var vType = tbluoebuttontyperow.find("[name=Type]").text();
			tbluoebuttontypeobj['Type'] = vType;
			tbluoebuttontypeobj['index'] = index;
var vDefaultValue = tbluoebuttontyperow.find("[name=DefaultValue]").text();
			tbluoebuttontypeobj['DefaultValue'] = vDefaultValue;
			tbluoebuttontypeobj['index'] = index;
var vDescription = tbluoebuttontyperow.find("[name=Description]").text();
			tbluoebuttontypeobj['Description'] = vDescription;
			tbluoebuttontypeobj['index'] = index;

	tbluoebuttontypedata.push(tbluoebuttontypeobj);
});
return tbluoebuttontypedata;
	}
function getRowsmethoduoebuttontype(){
	var methoduoebuttontypedata = [];
	methoduoebuttontyperows = $("#methoduoebuttontype tbody tr");
methoduoebuttontyperows.each(function (index) {
    var methoduoebuttontyperow = $(this);
 	var methoduoebuttontypeobj = {};
	var vMethod = methoduoebuttontyperow.find("[name=Method]").text();
			methoduoebuttontypeobj['Method'] = vMethod;
			methoduoebuttontypeobj['index'] = index;
var vParameters = methoduoebuttontyperow.find("[name=Parameters]").text();
			methoduoebuttontypeobj['Parameters'] = vParameters;
			methoduoebuttontypeobj['index'] = index;
var vReturnType = methoduoebuttontyperow.find("[name=ReturnType]").text();
			methoduoebuttontypeobj['ReturnType'] = vReturnType;
			methoduoebuttontypeobj['index'] = index;
var vDescription = methoduoebuttontyperow.find("[name=Description]").text();
			methoduoebuttontypeobj['Description'] = vDescription;
			methoduoebuttontypeobj['index'] = index;

	methoduoebuttontypedata.push(methoduoebuttontypeobj);
});
return methoduoebuttontypedata;
	}
function getRowstbluoecard(){
	var tbluoecarddata = [];
	tbluoecardrows = $("#tbluoecard tbody tr");
tbluoecardrows.each(function (index) {
    var tbluoecardrow = $(this);
 	var tbluoecardobj = {};
	var vProperty = tbluoecardrow.find("[name=Property]").text();
			tbluoecardobj['Property'] = vProperty;
			tbluoecardobj['index'] = index;
var vType = tbluoecardrow.find("[name=Type]").text();
			tbluoecardobj['Type'] = vType;
			tbluoecardobj['index'] = index;
var vDefaultValue = tbluoecardrow.find("[name=DefaultValue]").text();
			tbluoecardobj['DefaultValue'] = vDefaultValue;
			tbluoecardobj['index'] = index;
var vDescription = tbluoecardrow.find("[name=Description]").text();
			tbluoecardobj['Description'] = vDescription;
			tbluoecardobj['index'] = index;

	tbluoecarddata.push(tbluoecardobj);
});
return tbluoecarddata;
	}
function getRowsmethoduoecard(){
	var methoduoecarddata = [];
	methoduoecardrows = $("#methoduoecard tbody tr");
methoduoecardrows.each(function (index) {
    var methoduoecardrow = $(this);
 	var methoduoecardobj = {};
	var vMethod = methoduoecardrow.find("[name=Method]").text();
			methoduoecardobj['Method'] = vMethod;
			methoduoecardobj['index'] = index;
var vParameters = methoduoecardrow.find("[name=Parameters]").text();
			methoduoecardobj['Parameters'] = vParameters;
			methoduoecardobj['index'] = index;
var vReturnType = methoduoecardrow.find("[name=ReturnType]").text();
			methoduoecardobj['ReturnType'] = vReturnType;
			methoduoecardobj['index'] = index;
var vDescription = methoduoecardrow.find("[name=Description]").text();
			methoduoecardobj['Description'] = vDescription;
			methoduoecardobj['index'] = index;

	methoduoecarddata.push(methoduoecardobj);
});
return methoduoecarddata;
	}
function getRowstbluoecardsize(){
	var tbluoecardsizedata = [];
	tbluoecardsizerows = $("#tbluoecardsize tbody tr");
tbluoecardsizerows.each(function (index) {
    var tbluoecardsizerow = $(this);
 	var tbluoecardsizeobj = {};
	var vProperty = tbluoecardsizerow.find("[name=Property]").text();
			tbluoecardsizeobj['Property'] = vProperty;
			tbluoecardsizeobj['index'] = index;
var vType = tbluoecardsizerow.find("[name=Type]").text();
			tbluoecardsizeobj['Type'] = vType;
			tbluoecardsizeobj['index'] = index;
var vDefaultValue = tbluoecardsizerow.find("[name=DefaultValue]").text();
			tbluoecardsizeobj['DefaultValue'] = vDefaultValue;
			tbluoecardsizeobj['index'] = index;
var vDescription = tbluoecardsizerow.find("[name=Description]").text();
			tbluoecardsizeobj['Description'] = vDescription;
			tbluoecardsizeobj['index'] = index;

	tbluoecardsizedata.push(tbluoecardsizeobj);
});
return tbluoecardsizedata;
	}
function getRowsmethoduoecardsize(){
	var methoduoecardsizedata = [];
	methoduoecardsizerows = $("#methoduoecardsize tbody tr");
methoduoecardsizerows.each(function (index) {
    var methoduoecardsizerow = $(this);
 	var methoduoecardsizeobj = {};
	var vMethod = methoduoecardsizerow.find("[name=Method]").text();
			methoduoecardsizeobj['Method'] = vMethod;
			methoduoecardsizeobj['index'] = index;
var vParameters = methoduoecardsizerow.find("[name=Parameters]").text();
			methoduoecardsizeobj['Parameters'] = vParameters;
			methoduoecardsizeobj['index'] = index;
var vReturnType = methoduoecardsizerow.find("[name=ReturnType]").text();
			methoduoecardsizeobj['ReturnType'] = vReturnType;
			methoduoecardsizeobj['index'] = index;
var vDescription = methoduoecardsizerow.find("[name=Description]").text();
			methoduoecardsizeobj['Description'] = vDescription;
			methoduoecardsizeobj['index'] = index;

	methoduoecardsizedata.push(methoduoecardsizeobj);
});
return methoduoecardsizedata;
	}
function getRowstbluoecardtype(){
	var tbluoecardtypedata = [];
	tbluoecardtyperows = $("#tbluoecardtype tbody tr");
tbluoecardtyperows.each(function (index) {
    var tbluoecardtyperow = $(this);
 	var tbluoecardtypeobj = {};
	var vProperty = tbluoecardtyperow.find("[name=Property]").text();
			tbluoecardtypeobj['Property'] = vProperty;
			tbluoecardtypeobj['index'] = index;
var vType = tbluoecardtyperow.find("[name=Type]").text();
			tbluoecardtypeobj['Type'] = vType;
			tbluoecardtypeobj['index'] = index;
var vDefaultValue = tbluoecardtyperow.find("[name=DefaultValue]").text();
			tbluoecardtypeobj['DefaultValue'] = vDefaultValue;
			tbluoecardtypeobj['index'] = index;
var vDescription = tbluoecardtyperow.find("[name=Description]").text();
			tbluoecardtypeobj['Description'] = vDescription;
			tbluoecardtypeobj['index'] = index;

	tbluoecardtypedata.push(tbluoecardtypeobj);
});
return tbluoecardtypedata;
	}
function getRowsmethoduoecardtype(){
	var methoduoecardtypedata = [];
	methoduoecardtyperows = $("#methoduoecardtype tbody tr");
methoduoecardtyperows.each(function (index) {
    var methoduoecardtyperow = $(this);
 	var methoduoecardtypeobj = {};
	var vMethod = methoduoecardtyperow.find("[name=Method]").text();
			methoduoecardtypeobj['Method'] = vMethod;
			methoduoecardtypeobj['index'] = index;
var vParameters = methoduoecardtyperow.find("[name=Parameters]").text();
			methoduoecardtypeobj['Parameters'] = vParameters;
			methoduoecardtypeobj['index'] = index;
var vReturnType = methoduoecardtyperow.find("[name=ReturnType]").text();
			methoduoecardtypeobj['ReturnType'] = vReturnType;
			methoduoecardtypeobj['index'] = index;
var vDescription = methoduoecardtyperow.find("[name=Description]").text();
			methoduoecardtypeobj['Description'] = vDescription;
			methoduoecardtypeobj['index'] = index;

	methoduoecardtypedata.push(methoduoecardtypeobj);
});
return methoduoecardtypedata;
	}
function getRowstbluoecarousel(){
	var tbluoecarouseldata = [];
	tbluoecarouselrows = $("#tbluoecarousel tbody tr");
tbluoecarouselrows.each(function (index) {
    var tbluoecarouselrow = $(this);
 	var tbluoecarouselobj = {};
	var vProperty = tbluoecarouselrow.find("[name=Property]").text();
			tbluoecarouselobj['Property'] = vProperty;
			tbluoecarouselobj['index'] = index;
var vType = tbluoecarouselrow.find("[name=Type]").text();
			tbluoecarouselobj['Type'] = vType;
			tbluoecarouselobj['index'] = index;
var vDefaultValue = tbluoecarouselrow.find("[name=DefaultValue]").text();
			tbluoecarouselobj['DefaultValue'] = vDefaultValue;
			tbluoecarouselobj['index'] = index;
var vDescription = tbluoecarouselrow.find("[name=Description]").text();
			tbluoecarouselobj['Description'] = vDescription;
			tbluoecarouselobj['index'] = index;

	tbluoecarouseldata.push(tbluoecarouselobj);
});
return tbluoecarouseldata;
	}
function getRowsmethoduoecarousel(){
	var methoduoecarouseldata = [];
	methoduoecarouselrows = $("#methoduoecarousel tbody tr");
methoduoecarouselrows.each(function (index) {
    var methoduoecarouselrow = $(this);
 	var methoduoecarouselobj = {};
	var vMethod = methoduoecarouselrow.find("[name=Method]").text();
			methoduoecarouselobj['Method'] = vMethod;
			methoduoecarouselobj['index'] = index;
var vParameters = methoduoecarouselrow.find("[name=Parameters]").text();
			methoduoecarouselobj['Parameters'] = vParameters;
			methoduoecarouselobj['index'] = index;
var vReturnType = methoduoecarouselrow.find("[name=ReturnType]").text();
			methoduoecarouselobj['ReturnType'] = vReturnType;
			methoduoecarouselobj['index'] = index;
var vDescription = methoduoecarouselrow.find("[name=Description]").text();
			methoduoecarouselobj['Description'] = vDescription;
			methoduoecarouselobj['index'] = index;

	methoduoecarouseldata.push(methoduoecarouselobj);
});
return methoduoecarouseldata;
	}
function getRowstbluoecheckbox(){
	var tbluoecheckboxdata = [];
	tbluoecheckboxrows = $("#tbluoecheckbox tbody tr");
tbluoecheckboxrows.each(function (index) {
    var tbluoecheckboxrow = $(this);
 	var tbluoecheckboxobj = {};
	var vProperty = tbluoecheckboxrow.find("[name=Property]").text();
			tbluoecheckboxobj['Property'] = vProperty;
			tbluoecheckboxobj['index'] = index;
var vType = tbluoecheckboxrow.find("[name=Type]").text();
			tbluoecheckboxobj['Type'] = vType;
			tbluoecheckboxobj['index'] = index;
var vDefaultValue = tbluoecheckboxrow.find("[name=DefaultValue]").text();
			tbluoecheckboxobj['DefaultValue'] = vDefaultValue;
			tbluoecheckboxobj['index'] = index;
var vDescription = tbluoecheckboxrow.find("[name=Description]").text();
			tbluoecheckboxobj['Description'] = vDescription;
			tbluoecheckboxobj['index'] = index;

	tbluoecheckboxdata.push(tbluoecheckboxobj);
});
return tbluoecheckboxdata;
	}
function getRowsmethoduoecheckbox(){
	var methoduoecheckboxdata = [];
	methoduoecheckboxrows = $("#methoduoecheckbox tbody tr");
methoduoecheckboxrows.each(function (index) {
    var methoduoecheckboxrow = $(this);
 	var methoduoecheckboxobj = {};
	var vMethod = methoduoecheckboxrow.find("[name=Method]").text();
			methoduoecheckboxobj['Method'] = vMethod;
			methoduoecheckboxobj['index'] = index;
var vParameters = methoduoecheckboxrow.find("[name=Parameters]").text();
			methoduoecheckboxobj['Parameters'] = vParameters;
			methoduoecheckboxobj['index'] = index;
var vReturnType = methoduoecheckboxrow.find("[name=ReturnType]").text();
			methoduoecheckboxobj['ReturnType'] = vReturnType;
			methoduoecheckboxobj['index'] = index;
var vDescription = methoduoecheckboxrow.find("[name=Description]").text();
			methoduoecheckboxobj['Description'] = vDescription;
			methoduoecheckboxobj['index'] = index;

	methoduoecheckboxdata.push(methoduoecheckboxobj);
});
return methoduoecheckboxdata;
	}
function getRowstbluoecheckgroup(){
	var tbluoecheckgroupdata = [];
	tbluoecheckgrouprows = $("#tbluoecheckgroup tbody tr");
tbluoecheckgrouprows.each(function (index) {
    var tbluoecheckgrouprow = $(this);
 	var tbluoecheckgroupobj = {};
	var vProperty = tbluoecheckgrouprow.find("[name=Property]").text();
			tbluoecheckgroupobj['Property'] = vProperty;
			tbluoecheckgroupobj['index'] = index;
var vType = tbluoecheckgrouprow.find("[name=Type]").text();
			tbluoecheckgroupobj['Type'] = vType;
			tbluoecheckgroupobj['index'] = index;
var vDefaultValue = tbluoecheckgrouprow.find("[name=DefaultValue]").text();
			tbluoecheckgroupobj['DefaultValue'] = vDefaultValue;
			tbluoecheckgroupobj['index'] = index;
var vDescription = tbluoecheckgrouprow.find("[name=Description]").text();
			tbluoecheckgroupobj['Description'] = vDescription;
			tbluoecheckgroupobj['index'] = index;

	tbluoecheckgroupdata.push(tbluoecheckgroupobj);
});
return tbluoecheckgroupdata;
	}
function getRowsmethoduoecheckgroup(){
	var methoduoecheckgroupdata = [];
	methoduoecheckgrouprows = $("#methoduoecheckgroup tbody tr");
methoduoecheckgrouprows.each(function (index) {
    var methoduoecheckgrouprow = $(this);
 	var methoduoecheckgroupobj = {};
	var vMethod = methoduoecheckgrouprow.find("[name=Method]").text();
			methoduoecheckgroupobj['Method'] = vMethod;
			methoduoecheckgroupobj['index'] = index;
var vParameters = methoduoecheckgrouprow.find("[name=Parameters]").text();
			methoduoecheckgroupobj['Parameters'] = vParameters;
			methoduoecheckgroupobj['index'] = index;
var vReturnType = methoduoecheckgrouprow.find("[name=ReturnType]").text();
			methoduoecheckgroupobj['ReturnType'] = vReturnType;
			methoduoecheckgroupobj['index'] = index;
var vDescription = methoduoecheckgrouprow.find("[name=Description]").text();
			methoduoecheckgroupobj['Description'] = vDescription;
			methoduoecheckgroupobj['index'] = index;

	methoduoecheckgroupdata.push(methoduoecheckgroupobj);
});
return methoduoecheckgroupdata;
	}
function getRowstbluoechip(){
	var tbluoechipdata = [];
	tbluoechiprows = $("#tbluoechip tbody tr");
tbluoechiprows.each(function (index) {
    var tbluoechiprow = $(this);
 	var tbluoechipobj = {};
	var vProperty = tbluoechiprow.find("[name=Property]").text();
			tbluoechipobj['Property'] = vProperty;
			tbluoechipobj['index'] = index;
var vType = tbluoechiprow.find("[name=Type]").text();
			tbluoechipobj['Type'] = vType;
			tbluoechipobj['index'] = index;
var vDefaultValue = tbluoechiprow.find("[name=DefaultValue]").text();
			tbluoechipobj['DefaultValue'] = vDefaultValue;
			tbluoechipobj['index'] = index;
var vDescription = tbluoechiprow.find("[name=Description]").text();
			tbluoechipobj['Description'] = vDescription;
			tbluoechipobj['index'] = index;

	tbluoechipdata.push(tbluoechipobj);
});
return tbluoechipdata;
	}
function getRowsmethoduoechip(){
	var methoduoechipdata = [];
	methoduoechiprows = $("#methoduoechip tbody tr");
methoduoechiprows.each(function (index) {
    var methoduoechiprow = $(this);
 	var methoduoechipobj = {};
	var vMethod = methoduoechiprow.find("[name=Method]").text();
			methoduoechipobj['Method'] = vMethod;
			methoduoechipobj['index'] = index;
var vParameters = methoduoechiprow.find("[name=Parameters]").text();
			methoduoechipobj['Parameters'] = vParameters;
			methoduoechipobj['index'] = index;
var vReturnType = methoduoechiprow.find("[name=ReturnType]").text();
			methoduoechipobj['ReturnType'] = vReturnType;
			methoduoechipobj['index'] = index;
var vDescription = methoduoechiprow.find("[name=Description]").text();
			methoduoechipobj['Description'] = vDescription;
			methoduoechipobj['index'] = index;

	methoduoechipdata.push(methoduoechipobj);
});
return methoduoechipdata;
	}
function getRowstbluoechips(){
	var tbluoechipsdata = [];
	tbluoechipsrows = $("#tbluoechips tbody tr");
tbluoechipsrows.each(function (index) {
    var tbluoechipsrow = $(this);
 	var tbluoechipsobj = {};
	var vProperty = tbluoechipsrow.find("[name=Property]").text();
			tbluoechipsobj['Property'] = vProperty;
			tbluoechipsobj['index'] = index;
var vType = tbluoechipsrow.find("[name=Type]").text();
			tbluoechipsobj['Type'] = vType;
			tbluoechipsobj['index'] = index;
var vDefaultValue = tbluoechipsrow.find("[name=DefaultValue]").text();
			tbluoechipsobj['DefaultValue'] = vDefaultValue;
			tbluoechipsobj['index'] = index;
var vDescription = tbluoechipsrow.find("[name=Description]").text();
			tbluoechipsobj['Description'] = vDescription;
			tbluoechipsobj['index'] = index;

	tbluoechipsdata.push(tbluoechipsobj);
});
return tbluoechipsdata;
	}
function getRowsmethoduoechips(){
	var methoduoechipsdata = [];
	methoduoechipsrows = $("#methoduoechips tbody tr");
methoduoechipsrows.each(function (index) {
    var methoduoechipsrow = $(this);
 	var methoduoechipsobj = {};
	var vMethod = methoduoechipsrow.find("[name=Method]").text();
			methoduoechipsobj['Method'] = vMethod;
			methoduoechipsobj['index'] = index;
var vParameters = methoduoechipsrow.find("[name=Parameters]").text();
			methoduoechipsobj['Parameters'] = vParameters;
			methoduoechipsobj['index'] = index;
var vReturnType = methoduoechipsrow.find("[name=ReturnType]").text();
			methoduoechipsobj['ReturnType'] = vReturnType;
			methoduoechipsobj['index'] = index;
var vDescription = methoduoechipsrow.find("[name=Description]").text();
			methoduoechipsobj['Description'] = vDescription;
			methoduoechipsobj['index'] = index;

	methoduoechipsdata.push(methoduoechipsobj);
});
return methoduoechipsdata;
	}
function getRowstbluoecollapsible(){
	var tbluoecollapsibledata = [];
	tbluoecollapsiblerows = $("#tbluoecollapsible tbody tr");
tbluoecollapsiblerows.each(function (index) {
    var tbluoecollapsiblerow = $(this);
 	var tbluoecollapsibleobj = {};
	var vProperty = tbluoecollapsiblerow.find("[name=Property]").text();
			tbluoecollapsibleobj['Property'] = vProperty;
			tbluoecollapsibleobj['index'] = index;
var vType = tbluoecollapsiblerow.find("[name=Type]").text();
			tbluoecollapsibleobj['Type'] = vType;
			tbluoecollapsibleobj['index'] = index;
var vDefaultValue = tbluoecollapsiblerow.find("[name=DefaultValue]").text();
			tbluoecollapsibleobj['DefaultValue'] = vDefaultValue;
			tbluoecollapsibleobj['index'] = index;
var vDescription = tbluoecollapsiblerow.find("[name=Description]").text();
			tbluoecollapsibleobj['Description'] = vDescription;
			tbluoecollapsibleobj['index'] = index;

	tbluoecollapsibledata.push(tbluoecollapsibleobj);
});
return tbluoecollapsibledata;
	}
function getRowsmethoduoecollapsible(){
	var methoduoecollapsibledata = [];
	methoduoecollapsiblerows = $("#methoduoecollapsible tbody tr");
methoduoecollapsiblerows.each(function (index) {
    var methoduoecollapsiblerow = $(this);
 	var methoduoecollapsibleobj = {};
	var vMethod = methoduoecollapsiblerow.find("[name=Method]").text();
			methoduoecollapsibleobj['Method'] = vMethod;
			methoduoecollapsibleobj['index'] = index;
var vParameters = methoduoecollapsiblerow.find("[name=Parameters]").text();
			methoduoecollapsibleobj['Parameters'] = vParameters;
			methoduoecollapsibleobj['index'] = index;
var vReturnType = methoduoecollapsiblerow.find("[name=ReturnType]").text();
			methoduoecollapsibleobj['ReturnType'] = vReturnType;
			methoduoecollapsibleobj['index'] = index;
var vDescription = methoduoecollapsiblerow.find("[name=Description]").text();
			methoduoecollapsibleobj['Description'] = vDescription;
			methoduoecollapsibleobj['index'] = index;

	methoduoecollapsibledata.push(methoduoecollapsibleobj);
});
return methoduoecollapsibledata;
	}
function getRowstbluoecollapsibletype(){
	var tbluoecollapsibletypedata = [];
	tbluoecollapsibletyperows = $("#tbluoecollapsibletype tbody tr");
tbluoecollapsibletyperows.each(function (index) {
    var tbluoecollapsibletyperow = $(this);
 	var tbluoecollapsibletypeobj = {};
	var vProperty = tbluoecollapsibletyperow.find("[name=Property]").text();
			tbluoecollapsibletypeobj['Property'] = vProperty;
			tbluoecollapsibletypeobj['index'] = index;
var vType = tbluoecollapsibletyperow.find("[name=Type]").text();
			tbluoecollapsibletypeobj['Type'] = vType;
			tbluoecollapsibletypeobj['index'] = index;
var vDefaultValue = tbluoecollapsibletyperow.find("[name=DefaultValue]").text();
			tbluoecollapsibletypeobj['DefaultValue'] = vDefaultValue;
			tbluoecollapsibletypeobj['index'] = index;
var vDescription = tbluoecollapsibletyperow.find("[name=Description]").text();
			tbluoecollapsibletypeobj['Description'] = vDescription;
			tbluoecollapsibletypeobj['index'] = index;

	tbluoecollapsibletypedata.push(tbluoecollapsibletypeobj);
});
return tbluoecollapsibletypedata;
	}
function getRowsmethoduoecollapsibletype(){
	var methoduoecollapsibletypedata = [];
	methoduoecollapsibletyperows = $("#methoduoecollapsibletype tbody tr");
methoduoecollapsibletyperows.each(function (index) {
    var methoduoecollapsibletyperow = $(this);
 	var methoduoecollapsibletypeobj = {};
	var vMethod = methoduoecollapsibletyperow.find("[name=Method]").text();
			methoduoecollapsibletypeobj['Method'] = vMethod;
			methoduoecollapsibletypeobj['index'] = index;
var vParameters = methoduoecollapsibletyperow.find("[name=Parameters]").text();
			methoduoecollapsibletypeobj['Parameters'] = vParameters;
			methoduoecollapsibletypeobj['index'] = index;
var vReturnType = methoduoecollapsibletyperow.find("[name=ReturnType]").text();
			methoduoecollapsibletypeobj['ReturnType'] = vReturnType;
			methoduoecollapsibletypeobj['index'] = index;
var vDescription = methoduoecollapsibletyperow.find("[name=Description]").text();
			methoduoecollapsibletypeobj['Description'] = vDescription;
			methoduoecollapsibletypeobj['index'] = index;

	methoduoecollapsibletypedata.push(methoduoecollapsibletypeobj);
});
return methoduoecollapsibletypedata;
	}
function getRowstbluoecollections(){
	var tbluoecollectionsdata = [];
	tbluoecollectionsrows = $("#tbluoecollections tbody tr");
tbluoecollectionsrows.each(function (index) {
    var tbluoecollectionsrow = $(this);
 	var tbluoecollectionsobj = {};
	var vProperty = tbluoecollectionsrow.find("[name=Property]").text();
			tbluoecollectionsobj['Property'] = vProperty;
			tbluoecollectionsobj['index'] = index;
var vType = tbluoecollectionsrow.find("[name=Type]").text();
			tbluoecollectionsobj['Type'] = vType;
			tbluoecollectionsobj['index'] = index;
var vDefaultValue = tbluoecollectionsrow.find("[name=DefaultValue]").text();
			tbluoecollectionsobj['DefaultValue'] = vDefaultValue;
			tbluoecollectionsobj['index'] = index;
var vDescription = tbluoecollectionsrow.find("[name=Description]").text();
			tbluoecollectionsobj['Description'] = vDescription;
			tbluoecollectionsobj['index'] = index;

	tbluoecollectionsdata.push(tbluoecollectionsobj);
});
return tbluoecollectionsdata;
	}
function getRowsmethoduoecollections(){
	var methoduoecollectionsdata = [];
	methoduoecollectionsrows = $("#methoduoecollections tbody tr");
methoduoecollectionsrows.each(function (index) {
    var methoduoecollectionsrow = $(this);
 	var methoduoecollectionsobj = {};
	var vMethod = methoduoecollectionsrow.find("[name=Method]").text();
			methoduoecollectionsobj['Method'] = vMethod;
			methoduoecollectionsobj['index'] = index;
var vParameters = methoduoecollectionsrow.find("[name=Parameters]").text();
			methoduoecollectionsobj['Parameters'] = vParameters;
			methoduoecollectionsobj['index'] = index;
var vReturnType = methoduoecollectionsrow.find("[name=ReturnType]").text();
			methoduoecollectionsobj['ReturnType'] = vReturnType;
			methoduoecollectionsobj['index'] = index;
var vDescription = methoduoecollectionsrow.find("[name=Description]").text();
			methoduoecollectionsobj['Description'] = vDescription;
			methoduoecollectionsobj['index'] = index;

	methoduoecollectionsdata.push(methoduoecollectionsobj);
});
return methoduoecollectionsdata;
	}
function getRowstbluoecolor(){
	var tbluoecolordata = [];
	tbluoecolorrows = $("#tbluoecolor tbody tr");
tbluoecolorrows.each(function (index) {
    var tbluoecolorrow = $(this);
 	var tbluoecolorobj = {};
	var vProperty = tbluoecolorrow.find("[name=Property]").text();
			tbluoecolorobj['Property'] = vProperty;
			tbluoecolorobj['index'] = index;
var vType = tbluoecolorrow.find("[name=Type]").text();
			tbluoecolorobj['Type'] = vType;
			tbluoecolorobj['index'] = index;
var vDefaultValue = tbluoecolorrow.find("[name=DefaultValue]").text();
			tbluoecolorobj['DefaultValue'] = vDefaultValue;
			tbluoecolorobj['index'] = index;
var vDescription = tbluoecolorrow.find("[name=Description]").text();
			tbluoecolorobj['Description'] = vDescription;
			tbluoecolorobj['index'] = index;

	tbluoecolordata.push(tbluoecolorobj);
});
return tbluoecolordata;
	}
function getRowsmethoduoecolor(){
	var methoduoecolordata = [];
	methoduoecolorrows = $("#methoduoecolor tbody tr");
methoduoecolorrows.each(function (index) {
    var methoduoecolorrow = $(this);
 	var methoduoecolorobj = {};
	var vMethod = methoduoecolorrow.find("[name=Method]").text();
			methoduoecolorobj['Method'] = vMethod;
			methoduoecolorobj['index'] = index;
var vParameters = methoduoecolorrow.find("[name=Parameters]").text();
			methoduoecolorobj['Parameters'] = vParameters;
			methoduoecolorobj['index'] = index;
var vReturnType = methoduoecolorrow.find("[name=ReturnType]").text();
			methoduoecolorobj['ReturnType'] = vReturnType;
			methoduoecolorobj['index'] = index;
var vDescription = methoduoecolorrow.find("[name=Description]").text();
			methoduoecolorobj['Description'] = vDescription;
			methoduoecolorobj['index'] = index;

	methoduoecolordata.push(methoduoecolorobj);
});
return methoduoecolordata;
	}
function getRowstbluoecolumn(){
	var tbluoecolumndata = [];
	tbluoecolumnrows = $("#tbluoecolumn tbody tr");
tbluoecolumnrows.each(function (index) {
    var tbluoecolumnrow = $(this);
 	var tbluoecolumnobj = {};
	var vProperty = tbluoecolumnrow.find("[name=Property]").text();
			tbluoecolumnobj['Property'] = vProperty;
			tbluoecolumnobj['index'] = index;
var vType = tbluoecolumnrow.find("[name=Type]").text();
			tbluoecolumnobj['Type'] = vType;
			tbluoecolumnobj['index'] = index;
var vDefaultValue = tbluoecolumnrow.find("[name=DefaultValue]").text();
			tbluoecolumnobj['DefaultValue'] = vDefaultValue;
			tbluoecolumnobj['index'] = index;
var vDescription = tbluoecolumnrow.find("[name=Description]").text();
			tbluoecolumnobj['Description'] = vDescription;
			tbluoecolumnobj['index'] = index;

	tbluoecolumndata.push(tbluoecolumnobj);
});
return tbluoecolumndata;
	}
function getRowsmethoduoecolumn(){
	var methoduoecolumndata = [];
	methoduoecolumnrows = $("#methoduoecolumn tbody tr");
methoduoecolumnrows.each(function (index) {
    var methoduoecolumnrow = $(this);
 	var methoduoecolumnobj = {};
	var vMethod = methoduoecolumnrow.find("[name=Method]").text();
			methoduoecolumnobj['Method'] = vMethod;
			methoduoecolumnobj['index'] = index;
var vParameters = methoduoecolumnrow.find("[name=Parameters]").text();
			methoduoecolumnobj['Parameters'] = vParameters;
			methoduoecolumnobj['index'] = index;
var vReturnType = methoduoecolumnrow.find("[name=ReturnType]").text();
			methoduoecolumnobj['ReturnType'] = vReturnType;
			methoduoecolumnobj['index'] = index;
var vDescription = methoduoecolumnrow.find("[name=Description]").text();
			methoduoecolumnobj['Description'] = vDescription;
			methoduoecolumnobj['index'] = index;

	methoduoecolumndata.push(methoduoecolumnobj);
});
return methoduoecolumndata;
	}
function getRowstbluoecontainer(){
	var tbluoecontainerdata = [];
	tbluoecontainerrows = $("#tbluoecontainer tbody tr");
tbluoecontainerrows.each(function (index) {
    var tbluoecontainerrow = $(this);
 	var tbluoecontainerobj = {};
	var vProperty = tbluoecontainerrow.find("[name=Property]").text();
			tbluoecontainerobj['Property'] = vProperty;
			tbluoecontainerobj['index'] = index;
var vType = tbluoecontainerrow.find("[name=Type]").text();
			tbluoecontainerobj['Type'] = vType;
			tbluoecontainerobj['index'] = index;
var vDefaultValue = tbluoecontainerrow.find("[name=DefaultValue]").text();
			tbluoecontainerobj['DefaultValue'] = vDefaultValue;
			tbluoecontainerobj['index'] = index;
var vDescription = tbluoecontainerrow.find("[name=Description]").text();
			tbluoecontainerobj['Description'] = vDescription;
			tbluoecontainerobj['index'] = index;

	tbluoecontainerdata.push(tbluoecontainerobj);
});
return tbluoecontainerdata;
	}
function getRowsmethoduoecontainer(){
	var methoduoecontainerdata = [];
	methoduoecontainerrows = $("#methoduoecontainer tbody tr");
methoduoecontainerrows.each(function (index) {
    var methoduoecontainerrow = $(this);
 	var methoduoecontainerobj = {};
	var vMethod = methoduoecontainerrow.find("[name=Method]").text();
			methoduoecontainerobj['Method'] = vMethod;
			methoduoecontainerobj['index'] = index;
var vParameters = methoduoecontainerrow.find("[name=Parameters]").text();
			methoduoecontainerobj['Parameters'] = vParameters;
			methoduoecontainerobj['index'] = index;
var vReturnType = methoduoecontainerrow.find("[name=ReturnType]").text();
			methoduoecontainerobj['ReturnType'] = vReturnType;
			methoduoecontainerobj['index'] = index;
var vDescription = methoduoecontainerrow.find("[name=Description]").text();
			methoduoecontainerobj['Description'] = vDescription;
			methoduoecontainerobj['index'] = index;

	methoduoecontainerdata.push(methoduoecontainerobj);
});
return methoduoecontainerdata;
	}
function getRowstbluoecopyrights(){
	var tbluoecopyrightsdata = [];
	tbluoecopyrightsrows = $("#tbluoecopyrights tbody tr");
tbluoecopyrightsrows.each(function (index) {
    var tbluoecopyrightsrow = $(this);
 	var tbluoecopyrightsobj = {};
	var vProperty = tbluoecopyrightsrow.find("[name=Property]").text();
			tbluoecopyrightsobj['Property'] = vProperty;
			tbluoecopyrightsobj['index'] = index;
var vType = tbluoecopyrightsrow.find("[name=Type]").text();
			tbluoecopyrightsobj['Type'] = vType;
			tbluoecopyrightsobj['index'] = index;
var vDefaultValue = tbluoecopyrightsrow.find("[name=DefaultValue]").text();
			tbluoecopyrightsobj['DefaultValue'] = vDefaultValue;
			tbluoecopyrightsobj['index'] = index;
var vDescription = tbluoecopyrightsrow.find("[name=Description]").text();
			tbluoecopyrightsobj['Description'] = vDescription;
			tbluoecopyrightsobj['index'] = index;

	tbluoecopyrightsdata.push(tbluoecopyrightsobj);
});
return tbluoecopyrightsdata;
	}
function getRowsmethoduoecopyrights(){
	var methoduoecopyrightsdata = [];
	methoduoecopyrightsrows = $("#methoduoecopyrights tbody tr");
methoduoecopyrightsrows.each(function (index) {
    var methoduoecopyrightsrow = $(this);
 	var methoduoecopyrightsobj = {};
	var vMethod = methoduoecopyrightsrow.find("[name=Method]").text();
			methoduoecopyrightsobj['Method'] = vMethod;
			methoduoecopyrightsobj['index'] = index;
var vParameters = methoduoecopyrightsrow.find("[name=Parameters]").text();
			methoduoecopyrightsobj['Parameters'] = vParameters;
			methoduoecopyrightsobj['index'] = index;
var vReturnType = methoduoecopyrightsrow.find("[name=ReturnType]").text();
			methoduoecopyrightsobj['ReturnType'] = vReturnType;
			methoduoecopyrightsobj['index'] = index;
var vDescription = methoduoecopyrightsrow.find("[name=Description]").text();
			methoduoecopyrightsobj['Description'] = vDescription;
			methoduoecopyrightsobj['index'] = index;

	methoduoecopyrightsdata.push(methoduoecopyrightsobj);
});
return methoduoecopyrightsdata;
	}
function getRowstbluoecss(){
	var tbluoecssdata = [];
	tbluoecssrows = $("#tbluoecss tbody tr");
tbluoecssrows.each(function (index) {
    var tbluoecssrow = $(this);
 	var tbluoecssobj = {};
	var vProperty = tbluoecssrow.find("[name=Property]").text();
			tbluoecssobj['Property'] = vProperty;
			tbluoecssobj['index'] = index;
var vType = tbluoecssrow.find("[name=Type]").text();
			tbluoecssobj['Type'] = vType;
			tbluoecssobj['index'] = index;
var vDefaultValue = tbluoecssrow.find("[name=DefaultValue]").text();
			tbluoecssobj['DefaultValue'] = vDefaultValue;
			tbluoecssobj['index'] = index;
var vDescription = tbluoecssrow.find("[name=Description]").text();
			tbluoecssobj['Description'] = vDescription;
			tbluoecssobj['index'] = index;

	tbluoecssdata.push(tbluoecssobj);
});
return tbluoecssdata;
	}
function getRowsmethoduoecss(){
	var methoduoecssdata = [];
	methoduoecssrows = $("#methoduoecss tbody tr");
methoduoecssrows.each(function (index) {
    var methoduoecssrow = $(this);
 	var methoduoecssobj = {};
	var vMethod = methoduoecssrow.find("[name=Method]").text();
			methoduoecssobj['Method'] = vMethod;
			methoduoecssobj['index'] = index;
var vParameters = methoduoecssrow.find("[name=Parameters]").text();
			methoduoecssobj['Parameters'] = vParameters;
			methoduoecssobj['index'] = index;
var vReturnType = methoduoecssrow.find("[name=ReturnType]").text();
			methoduoecssobj['ReturnType'] = vReturnType;
			methoduoecssobj['index'] = index;
var vDescription = methoduoecssrow.find("[name=Description]").text();
			methoduoecssobj['Description'] = vDescription;
			methoduoecssobj['index'] = index;

	methoduoecssdata.push(methoduoecssobj);
});
return methoduoecssdata;
	}
function getRowstbluoedatepicker(){
	var tbluoedatepickerdata = [];
	tbluoedatepickerrows = $("#tbluoedatepicker tbody tr");
tbluoedatepickerrows.each(function (index) {
    var tbluoedatepickerrow = $(this);
 	var tbluoedatepickerobj = {};
	var vProperty = tbluoedatepickerrow.find("[name=Property]").text();
			tbluoedatepickerobj['Property'] = vProperty;
			tbluoedatepickerobj['index'] = index;
var vType = tbluoedatepickerrow.find("[name=Type]").text();
			tbluoedatepickerobj['Type'] = vType;
			tbluoedatepickerobj['index'] = index;
var vDefaultValue = tbluoedatepickerrow.find("[name=DefaultValue]").text();
			tbluoedatepickerobj['DefaultValue'] = vDefaultValue;
			tbluoedatepickerobj['index'] = index;
var vDescription = tbluoedatepickerrow.find("[name=Description]").text();
			tbluoedatepickerobj['Description'] = vDescription;
			tbluoedatepickerobj['index'] = index;

	tbluoedatepickerdata.push(tbluoedatepickerobj);
});
return tbluoedatepickerdata;
	}
function getRowsmethoduoedatepicker(){
	var methoduoedatepickerdata = [];
	methoduoedatepickerrows = $("#methoduoedatepicker tbody tr");
methoduoedatepickerrows.each(function (index) {
    var methoduoedatepickerrow = $(this);
 	var methoduoedatepickerobj = {};
	var vMethod = methoduoedatepickerrow.find("[name=Method]").text();
			methoduoedatepickerobj['Method'] = vMethod;
			methoduoedatepickerobj['index'] = index;
var vParameters = methoduoedatepickerrow.find("[name=Parameters]").text();
			methoduoedatepickerobj['Parameters'] = vParameters;
			methoduoedatepickerobj['index'] = index;
var vReturnType = methoduoedatepickerrow.find("[name=ReturnType]").text();
			methoduoedatepickerobj['ReturnType'] = vReturnType;
			methoduoedatepickerobj['index'] = index;
var vDescription = methoduoedatepickerrow.find("[name=Description]").text();
			methoduoedatepickerobj['Description'] = vDescription;
			methoduoedatepickerobj['index'] = index;

	methoduoedatepickerdata.push(methoduoedatepickerobj);
});
return methoduoedatepickerdata;
	}
function getRowstbluoedatetimetype(){
	var tbluoedatetimetypedata = [];
	tbluoedatetimetyperows = $("#tbluoedatetimetype tbody tr");
tbluoedatetimetyperows.each(function (index) {
    var tbluoedatetimetyperow = $(this);
 	var tbluoedatetimetypeobj = {};
	var vProperty = tbluoedatetimetyperow.find("[name=Property]").text();
			tbluoedatetimetypeobj['Property'] = vProperty;
			tbluoedatetimetypeobj['index'] = index;
var vType = tbluoedatetimetyperow.find("[name=Type]").text();
			tbluoedatetimetypeobj['Type'] = vType;
			tbluoedatetimetypeobj['index'] = index;
var vDefaultValue = tbluoedatetimetyperow.find("[name=DefaultValue]").text();
			tbluoedatetimetypeobj['DefaultValue'] = vDefaultValue;
			tbluoedatetimetypeobj['index'] = index;
var vDescription = tbluoedatetimetyperow.find("[name=Description]").text();
			tbluoedatetimetypeobj['Description'] = vDescription;
			tbluoedatetimetypeobj['index'] = index;

	tbluoedatetimetypedata.push(tbluoedatetimetypeobj);
});
return tbluoedatetimetypedata;
	}
function getRowsmethoduoedatetimetype(){
	var methoduoedatetimetypedata = [];
	methoduoedatetimetyperows = $("#methoduoedatetimetype tbody tr");
methoduoedatetimetyperows.each(function (index) {
    var methoduoedatetimetyperow = $(this);
 	var methoduoedatetimetypeobj = {};
	var vMethod = methoduoedatetimetyperow.find("[name=Method]").text();
			methoduoedatetimetypeobj['Method'] = vMethod;
			methoduoedatetimetypeobj['index'] = index;
var vParameters = methoduoedatetimetyperow.find("[name=Parameters]").text();
			methoduoedatetimetypeobj['Parameters'] = vParameters;
			methoduoedatetimetypeobj['index'] = index;
var vReturnType = methoduoedatetimetyperow.find("[name=ReturnType]").text();
			methoduoedatetimetypeobj['ReturnType'] = vReturnType;
			methoduoedatetimetypeobj['index'] = index;
var vDescription = methoduoedatetimetyperow.find("[name=Description]").text();
			methoduoedatetimetypeobj['Description'] = vDescription;
			methoduoedatetimetypeobj['index'] = index;

	methoduoedatetimetypedata.push(methoduoedatetimetypeobj);
});
return methoduoedatetimetypedata;
	}
function getRowstbluoedb(){
	var tbluoedbdata = [];
	tbluoedbrows = $("#tbluoedb tbody tr");
tbluoedbrows.each(function (index) {
    var tbluoedbrow = $(this);
 	var tbluoedbobj = {};
	var vProperty = tbluoedbrow.find("[name=Property]").text();
			tbluoedbobj['Property'] = vProperty;
			tbluoedbobj['index'] = index;
var vType = tbluoedbrow.find("[name=Type]").text();
			tbluoedbobj['Type'] = vType;
			tbluoedbobj['index'] = index;
var vDefaultValue = tbluoedbrow.find("[name=DefaultValue]").text();
			tbluoedbobj['DefaultValue'] = vDefaultValue;
			tbluoedbobj['index'] = index;
var vDescription = tbluoedbrow.find("[name=Description]").text();
			tbluoedbobj['Description'] = vDescription;
			tbluoedbobj['index'] = index;

	tbluoedbdata.push(tbluoedbobj);
});
return tbluoedbdata;
	}
function getRowsmethoduoedb(){
	var methoduoedbdata = [];
	methoduoedbrows = $("#methoduoedb tbody tr");
methoduoedbrows.each(function (index) {
    var methoduoedbrow = $(this);
 	var methoduoedbobj = {};
	var vMethod = methoduoedbrow.find("[name=Method]").text();
			methoduoedbobj['Method'] = vMethod;
			methoduoedbobj['index'] = index;
var vParameters = methoduoedbrow.find("[name=Parameters]").text();
			methoduoedbobj['Parameters'] = vParameters;
			methoduoedbobj['index'] = index;
var vReturnType = methoduoedbrow.find("[name=ReturnType]").text();
			methoduoedbobj['ReturnType'] = vReturnType;
			methoduoedbobj['index'] = index;
var vDescription = methoduoedbrow.find("[name=Description]").text();
			methoduoedbobj['Description'] = vDescription;
			methoduoedbobj['index'] = index;

	methoduoedbdata.push(methoduoedbobj);
});
return methoduoedbdata;
	}
function getRowstbluoedial(){
	var tbluoedialdata = [];
	tbluoedialrows = $("#tbluoedial tbody tr");
tbluoedialrows.each(function (index) {
    var tbluoedialrow = $(this);
 	var tbluoedialobj = {};
	var vProperty = tbluoedialrow.find("[name=Property]").text();
			tbluoedialobj['Property'] = vProperty;
			tbluoedialobj['index'] = index;
var vType = tbluoedialrow.find("[name=Type]").text();
			tbluoedialobj['Type'] = vType;
			tbluoedialobj['index'] = index;
var vDefaultValue = tbluoedialrow.find("[name=DefaultValue]").text();
			tbluoedialobj['DefaultValue'] = vDefaultValue;
			tbluoedialobj['index'] = index;
var vDescription = tbluoedialrow.find("[name=Description]").text();
			tbluoedialobj['Description'] = vDescription;
			tbluoedialobj['index'] = index;

	tbluoedialdata.push(tbluoedialobj);
});
return tbluoedialdata;
	}
function getRowsmethoduoedial(){
	var methoduoedialdata = [];
	methoduoedialrows = $("#methoduoedial tbody tr");
methoduoedialrows.each(function (index) {
    var methoduoedialrow = $(this);
 	var methoduoedialobj = {};
	var vMethod = methoduoedialrow.find("[name=Method]").text();
			methoduoedialobj['Method'] = vMethod;
			methoduoedialobj['index'] = index;
var vParameters = methoduoedialrow.find("[name=Parameters]").text();
			methoduoedialobj['Parameters'] = vParameters;
			methoduoedialobj['index'] = index;
var vReturnType = methoduoedialrow.find("[name=ReturnType]").text();
			methoduoedialobj['ReturnType'] = vReturnType;
			methoduoedialobj['index'] = index;
var vDescription = methoduoedialrow.find("[name=Description]").text();
			methoduoedialobj['Description'] = vDescription;
			methoduoedialobj['index'] = index;

	methoduoedialdata.push(methoduoedialobj);
});
return methoduoedialdata;
	}
function getRowstbluoedisplaytype(){
	var tbluoedisplaytypedata = [];
	tbluoedisplaytyperows = $("#tbluoedisplaytype tbody tr");
tbluoedisplaytyperows.each(function (index) {
    var tbluoedisplaytyperow = $(this);
 	var tbluoedisplaytypeobj = {};
	var vProperty = tbluoedisplaytyperow.find("[name=Property]").text();
			tbluoedisplaytypeobj['Property'] = vProperty;
			tbluoedisplaytypeobj['index'] = index;
var vType = tbluoedisplaytyperow.find("[name=Type]").text();
			tbluoedisplaytypeobj['Type'] = vType;
			tbluoedisplaytypeobj['index'] = index;
var vDefaultValue = tbluoedisplaytyperow.find("[name=DefaultValue]").text();
			tbluoedisplaytypeobj['DefaultValue'] = vDefaultValue;
			tbluoedisplaytypeobj['index'] = index;
var vDescription = tbluoedisplaytyperow.find("[name=Description]").text();
			tbluoedisplaytypeobj['Description'] = vDescription;
			tbluoedisplaytypeobj['index'] = index;

	tbluoedisplaytypedata.push(tbluoedisplaytypeobj);
});
return tbluoedisplaytypedata;
	}
function getRowsmethoduoedisplaytype(){
	var methoduoedisplaytypedata = [];
	methoduoedisplaytyperows = $("#methoduoedisplaytype tbody tr");
methoduoedisplaytyperows.each(function (index) {
    var methoduoedisplaytyperow = $(this);
 	var methoduoedisplaytypeobj = {};
	var vMethod = methoduoedisplaytyperow.find("[name=Method]").text();
			methoduoedisplaytypeobj['Method'] = vMethod;
			methoduoedisplaytypeobj['index'] = index;
var vParameters = methoduoedisplaytyperow.find("[name=Parameters]").text();
			methoduoedisplaytypeobj['Parameters'] = vParameters;
			methoduoedisplaytypeobj['index'] = index;
var vReturnType = methoduoedisplaytyperow.find("[name=ReturnType]").text();
			methoduoedisplaytypeobj['ReturnType'] = vReturnType;
			methoduoedisplaytypeobj['index'] = index;
var vDescription = methoduoedisplaytyperow.find("[name=Description]").text();
			methoduoedisplaytypeobj['Description'] = vDescription;
			methoduoedisplaytypeobj['index'] = index;

	methoduoedisplaytypedata.push(methoduoedisplaytypeobj);
});
return methoduoedisplaytypedata;
	}
function getRowstbluoedivider(){
	var tbluoedividerdata = [];
	tbluoedividerrows = $("#tbluoedivider tbody tr");
tbluoedividerrows.each(function (index) {
    var tbluoedividerrow = $(this);
 	var tbluoedividerobj = {};
	var vProperty = tbluoedividerrow.find("[name=Property]").text();
			tbluoedividerobj['Property'] = vProperty;
			tbluoedividerobj['index'] = index;
var vType = tbluoedividerrow.find("[name=Type]").text();
			tbluoedividerobj['Type'] = vType;
			tbluoedividerobj['index'] = index;
var vDefaultValue = tbluoedividerrow.find("[name=DefaultValue]").text();
			tbluoedividerobj['DefaultValue'] = vDefaultValue;
			tbluoedividerobj['index'] = index;
var vDescription = tbluoedividerrow.find("[name=Description]").text();
			tbluoedividerobj['Description'] = vDescription;
			tbluoedividerobj['index'] = index;

	tbluoedividerdata.push(tbluoedividerobj);
});
return tbluoedividerdata;
	}
function getRowsmethoduoedivider(){
	var methoduoedividerdata = [];
	methoduoedividerrows = $("#methoduoedivider tbody tr");
methoduoedividerrows.each(function (index) {
    var methoduoedividerrow = $(this);
 	var methoduoedividerobj = {};
	var vMethod = methoduoedividerrow.find("[name=Method]").text();
			methoduoedividerobj['Method'] = vMethod;
			methoduoedividerobj['index'] = index;
var vParameters = methoduoedividerrow.find("[name=Parameters]").text();
			methoduoedividerobj['Parameters'] = vParameters;
			methoduoedividerobj['index'] = index;
var vReturnType = methoduoedividerrow.find("[name=ReturnType]").text();
			methoduoedividerobj['ReturnType'] = vReturnType;
			methoduoedividerobj['index'] = index;
var vDescription = methoduoedividerrow.find("[name=Description]").text();
			methoduoedividerobj['Description'] = vDescription;
			methoduoedividerobj['index'] = index;

	methoduoedividerdata.push(methoduoedividerobj);
});
return methoduoedividerdata;
	}
function getRowstbluoedropdown(){
	var tbluoedropdowndata = [];
	tbluoedropdownrows = $("#tbluoedropdown tbody tr");
tbluoedropdownrows.each(function (index) {
    var tbluoedropdownrow = $(this);
 	var tbluoedropdownobj = {};
	var vProperty = tbluoedropdownrow.find("[name=Property]").text();
			tbluoedropdownobj['Property'] = vProperty;
			tbluoedropdownobj['index'] = index;
var vType = tbluoedropdownrow.find("[name=Type]").text();
			tbluoedropdownobj['Type'] = vType;
			tbluoedropdownobj['index'] = index;
var vDefaultValue = tbluoedropdownrow.find("[name=DefaultValue]").text();
			tbluoedropdownobj['DefaultValue'] = vDefaultValue;
			tbluoedropdownobj['index'] = index;
var vDescription = tbluoedropdownrow.find("[name=Description]").text();
			tbluoedropdownobj['Description'] = vDescription;
			tbluoedropdownobj['index'] = index;

	tbluoedropdowndata.push(tbluoedropdownobj);
});
return tbluoedropdowndata;
	}
function getRowsmethoduoedropdown(){
	var methoduoedropdowndata = [];
	methoduoedropdownrows = $("#methoduoedropdown tbody tr");
methoduoedropdownrows.each(function (index) {
    var methoduoedropdownrow = $(this);
 	var methoduoedropdownobj = {};
	var vMethod = methoduoedropdownrow.find("[name=Method]").text();
			methoduoedropdownobj['Method'] = vMethod;
			methoduoedropdownobj['index'] = index;
var vParameters = methoduoedropdownrow.find("[name=Parameters]").text();
			methoduoedropdownobj['Parameters'] = vParameters;
			methoduoedropdownobj['index'] = index;
var vReturnType = methoduoedropdownrow.find("[name=ReturnType]").text();
			methoduoedropdownobj['ReturnType'] = vReturnType;
			methoduoedropdownobj['index'] = index;
var vDescription = methoduoedropdownrow.find("[name=Description]").text();
			methoduoedropdownobj['Description'] = vDescription;
			methoduoedropdownobj['index'] = index;

	methoduoedropdowndata.push(methoduoedropdownobj);
});
return methoduoedropdowndata;
	}
function getRowstbluoedropdownitem(){
	var tbluoedropdownitemdata = [];
	tbluoedropdownitemrows = $("#tbluoedropdownitem tbody tr");
tbluoedropdownitemrows.each(function (index) {
    var tbluoedropdownitemrow = $(this);
 	var tbluoedropdownitemobj = {};
	var vProperty = tbluoedropdownitemrow.find("[name=Property]").text();
			tbluoedropdownitemobj['Property'] = vProperty;
			tbluoedropdownitemobj['index'] = index;
var vType = tbluoedropdownitemrow.find("[name=Type]").text();
			tbluoedropdownitemobj['Type'] = vType;
			tbluoedropdownitemobj['index'] = index;
var vDefaultValue = tbluoedropdownitemrow.find("[name=DefaultValue]").text();
			tbluoedropdownitemobj['DefaultValue'] = vDefaultValue;
			tbluoedropdownitemobj['index'] = index;
var vDescription = tbluoedropdownitemrow.find("[name=Description]").text();
			tbluoedropdownitemobj['Description'] = vDescription;
			tbluoedropdownitemobj['index'] = index;

	tbluoedropdownitemdata.push(tbluoedropdownitemobj);
});
return tbluoedropdownitemdata;
	}
function getRowsmethoduoedropdownitem(){
	var methoduoedropdownitemdata = [];
	methoduoedropdownitemrows = $("#methoduoedropdownitem tbody tr");
methoduoedropdownitemrows.each(function (index) {
    var methoduoedropdownitemrow = $(this);
 	var methoduoedropdownitemobj = {};
	var vMethod = methoduoedropdownitemrow.find("[name=Method]").text();
			methoduoedropdownitemobj['Method'] = vMethod;
			methoduoedropdownitemobj['index'] = index;
var vParameters = methoduoedropdownitemrow.find("[name=Parameters]").text();
			methoduoedropdownitemobj['Parameters'] = vParameters;
			methoduoedropdownitemobj['index'] = index;
var vReturnType = methoduoedropdownitemrow.find("[name=ReturnType]").text();
			methoduoedropdownitemobj['ReturnType'] = vReturnType;
			methoduoedropdownitemobj['index'] = index;
var vDescription = methoduoedropdownitemrow.find("[name=Description]").text();
			methoduoedropdownitemobj['Description'] = vDescription;
			methoduoedropdownitemobj['index'] = index;

	methoduoedropdownitemdata.push(methoduoedropdownitemobj);
});
return methoduoedropdownitemdata;
	}
function getRowstbluoeeasing(){
	var tbluoeeasingdata = [];
	tbluoeeasingrows = $("#tbluoeeasing tbody tr");
tbluoeeasingrows.each(function (index) {
    var tbluoeeasingrow = $(this);
 	var tbluoeeasingobj = {};
	var vProperty = tbluoeeasingrow.find("[name=Property]").text();
			tbluoeeasingobj['Property'] = vProperty;
			tbluoeeasingobj['index'] = index;
var vType = tbluoeeasingrow.find("[name=Type]").text();
			tbluoeeasingobj['Type'] = vType;
			tbluoeeasingobj['index'] = index;
var vDefaultValue = tbluoeeasingrow.find("[name=DefaultValue]").text();
			tbluoeeasingobj['DefaultValue'] = vDefaultValue;
			tbluoeeasingobj['index'] = index;
var vDescription = tbluoeeasingrow.find("[name=Description]").text();
			tbluoeeasingobj['Description'] = vDescription;
			tbluoeeasingobj['index'] = index;

	tbluoeeasingdata.push(tbluoeeasingobj);
});
return tbluoeeasingdata;
	}
function getRowsmethoduoeeasing(){
	var methoduoeeasingdata = [];
	methoduoeeasingrows = $("#methoduoeeasing tbody tr");
methoduoeeasingrows.each(function (index) {
    var methoduoeeasingrow = $(this);
 	var methoduoeeasingobj = {};
	var vMethod = methoduoeeasingrow.find("[name=Method]").text();
			methoduoeeasingobj['Method'] = vMethod;
			methoduoeeasingobj['index'] = index;
var vParameters = methoduoeeasingrow.find("[name=Parameters]").text();
			methoduoeeasingobj['Parameters'] = vParameters;
			methoduoeeasingobj['index'] = index;
var vReturnType = methoduoeeasingrow.find("[name=ReturnType]").text();
			methoduoeeasingobj['ReturnType'] = vReturnType;
			methoduoeeasingobj['index'] = index;
var vDescription = methoduoeeasingrow.find("[name=Description]").text();
			methoduoeeasingobj['Description'] = vDescription;
			methoduoeeasingobj['index'] = index;

	methoduoeeasingdata.push(methoduoeeasingobj);
});
return methoduoeeasingdata;
	}
function getRowstbluoeeasyticker(){
	var tbluoeeasytickerdata = [];
	tbluoeeasytickerrows = $("#tbluoeeasyticker tbody tr");
tbluoeeasytickerrows.each(function (index) {
    var tbluoeeasytickerrow = $(this);
 	var tbluoeeasytickerobj = {};
	var vProperty = tbluoeeasytickerrow.find("[name=Property]").text();
			tbluoeeasytickerobj['Property'] = vProperty;
			tbluoeeasytickerobj['index'] = index;
var vType = tbluoeeasytickerrow.find("[name=Type]").text();
			tbluoeeasytickerobj['Type'] = vType;
			tbluoeeasytickerobj['index'] = index;
var vDefaultValue = tbluoeeasytickerrow.find("[name=DefaultValue]").text();
			tbluoeeasytickerobj['DefaultValue'] = vDefaultValue;
			tbluoeeasytickerobj['index'] = index;
var vDescription = tbluoeeasytickerrow.find("[name=Description]").text();
			tbluoeeasytickerobj['Description'] = vDescription;
			tbluoeeasytickerobj['index'] = index;

	tbluoeeasytickerdata.push(tbluoeeasytickerobj);
});
return tbluoeeasytickerdata;
	}
function getRowsmethoduoeeasyticker(){
	var methoduoeeasytickerdata = [];
	methoduoeeasytickerrows = $("#methoduoeeasyticker tbody tr");
methoduoeeasytickerrows.each(function (index) {
    var methoduoeeasytickerrow = $(this);
 	var methoduoeeasytickerobj = {};
	var vMethod = methoduoeeasytickerrow.find("[name=Method]").text();
			methoduoeeasytickerobj['Method'] = vMethod;
			methoduoeeasytickerobj['index'] = index;
var vParameters = methoduoeeasytickerrow.find("[name=Parameters]").text();
			methoduoeeasytickerobj['Parameters'] = vParameters;
			methoduoeeasytickerobj['index'] = index;
var vReturnType = methoduoeeasytickerrow.find("[name=ReturnType]").text();
			methoduoeeasytickerobj['ReturnType'] = vReturnType;
			methoduoeeasytickerobj['index'] = index;
var vDescription = methoduoeeasytickerrow.find("[name=Description]").text();
			methoduoeeasytickerobj['Description'] = vDescription;
			methoduoeeasytickerobj['index'] = index;

	methoduoeeasytickerdata.push(methoduoeeasytickerobj);
});
return methoduoeeasytickerdata;
	}
function getRowstbluoeeditor(){
	var tbluoeeditordata = [];
	tbluoeeditorrows = $("#tbluoeeditor tbody tr");
tbluoeeditorrows.each(function (index) {
    var tbluoeeditorrow = $(this);
 	var tbluoeeditorobj = {};
	var vProperty = tbluoeeditorrow.find("[name=Property]").text();
			tbluoeeditorobj['Property'] = vProperty;
			tbluoeeditorobj['index'] = index;
var vType = tbluoeeditorrow.find("[name=Type]").text();
			tbluoeeditorobj['Type'] = vType;
			tbluoeeditorobj['index'] = index;
var vDefaultValue = tbluoeeditorrow.find("[name=DefaultValue]").text();
			tbluoeeditorobj['DefaultValue'] = vDefaultValue;
			tbluoeeditorobj['index'] = index;
var vDescription = tbluoeeditorrow.find("[name=Description]").text();
			tbluoeeditorobj['Description'] = vDescription;
			tbluoeeditorobj['index'] = index;

	tbluoeeditordata.push(tbluoeeditorobj);
});
return tbluoeeditordata;
	}
function getRowsmethoduoeeditor(){
	var methoduoeeditordata = [];
	methoduoeeditorrows = $("#methoduoeeditor tbody tr");
methoduoeeditorrows.each(function (index) {
    var methoduoeeditorrow = $(this);
 	var methoduoeeditorobj = {};
	var vMethod = methoduoeeditorrow.find("[name=Method]").text();
			methoduoeeditorobj['Method'] = vMethod;
			methoduoeeditorobj['index'] = index;
var vParameters = methoduoeeditorrow.find("[name=Parameters]").text();
			methoduoeeditorobj['Parameters'] = vParameters;
			methoduoeeditorobj['index'] = index;
var vReturnType = methoduoeeditorrow.find("[name=ReturnType]").text();
			methoduoeeditorobj['ReturnType'] = vReturnType;
			methoduoeeditorobj['index'] = index;
var vDescription = methoduoeeditorrow.find("[name=Description]").text();
			methoduoeeditorobj['Description'] = vDescription;
			methoduoeeditorobj['index'] = index;

	methoduoeeditordata.push(methoduoeeditorobj);
});
return methoduoeeditordata;
	}
function getRowstbluoeembed(){
	var tbluoeembeddata = [];
	tbluoeembedrows = $("#tbluoeembed tbody tr");
tbluoeembedrows.each(function (index) {
    var tbluoeembedrow = $(this);
 	var tbluoeembedobj = {};
	var vProperty = tbluoeembedrow.find("[name=Property]").text();
			tbluoeembedobj['Property'] = vProperty;
			tbluoeembedobj['index'] = index;
var vType = tbluoeembedrow.find("[name=Type]").text();
			tbluoeembedobj['Type'] = vType;
			tbluoeembedobj['index'] = index;
var vDefaultValue = tbluoeembedrow.find("[name=DefaultValue]").text();
			tbluoeembedobj['DefaultValue'] = vDefaultValue;
			tbluoeembedobj['index'] = index;
var vDescription = tbluoeembedrow.find("[name=Description]").text();
			tbluoeembedobj['Description'] = vDescription;
			tbluoeembedobj['index'] = index;

	tbluoeembeddata.push(tbluoeembedobj);
});
return tbluoeembeddata;
	}
function getRowsmethoduoeembed(){
	var methoduoeembeddata = [];
	methoduoeembedrows = $("#methoduoeembed tbody tr");
methoduoeembedrows.each(function (index) {
    var methoduoeembedrow = $(this);
 	var methoduoeembedobj = {};
	var vMethod = methoduoeembedrow.find("[name=Method]").text();
			methoduoeembedobj['Method'] = vMethod;
			methoduoeembedobj['index'] = index;
var vParameters = methoduoeembedrow.find("[name=Parameters]").text();
			methoduoeembedobj['Parameters'] = vParameters;
			methoduoeembedobj['index'] = index;
var vReturnType = methoduoeembedrow.find("[name=ReturnType]").text();
			methoduoeembedobj['ReturnType'] = vReturnType;
			methoduoeembedobj['index'] = index;
var vDescription = methoduoeembedrow.find("[name=Description]").text();
			methoduoeembedobj['Description'] = vDescription;
			methoduoeembedobj['index'] = index;

	methoduoeembeddata.push(methoduoeembedobj);
});
return methoduoeembeddata;
	}
function getRowstbluoeevents(){
	var tbluoeeventsdata = [];
	tbluoeeventsrows = $("#tbluoeevents tbody tr");
tbluoeeventsrows.each(function (index) {
    var tbluoeeventsrow = $(this);
 	var tbluoeeventsobj = {};
	var vProperty = tbluoeeventsrow.find("[name=Property]").text();
			tbluoeeventsobj['Property'] = vProperty;
			tbluoeeventsobj['index'] = index;
var vType = tbluoeeventsrow.find("[name=Type]").text();
			tbluoeeventsobj['Type'] = vType;
			tbluoeeventsobj['index'] = index;
var vDefaultValue = tbluoeeventsrow.find("[name=DefaultValue]").text();
			tbluoeeventsobj['DefaultValue'] = vDefaultValue;
			tbluoeeventsobj['index'] = index;
var vDescription = tbluoeeventsrow.find("[name=Description]").text();
			tbluoeeventsobj['Description'] = vDescription;
			tbluoeeventsobj['index'] = index;

	tbluoeeventsdata.push(tbluoeeventsobj);
});
return tbluoeeventsdata;
	}
function getRowsmethoduoeevents(){
	var methoduoeeventsdata = [];
	methoduoeeventsrows = $("#methoduoeevents tbody tr");
methoduoeeventsrows.each(function (index) {
    var methoduoeeventsrow = $(this);
 	var methoduoeeventsobj = {};
	var vMethod = methoduoeeventsrow.find("[name=Method]").text();
			methoduoeeventsobj['Method'] = vMethod;
			methoduoeeventsobj['index'] = index;
var vParameters = methoduoeeventsrow.find("[name=Parameters]").text();
			methoduoeeventsobj['Parameters'] = vParameters;
			methoduoeeventsobj['index'] = index;
var vReturnType = methoduoeeventsrow.find("[name=ReturnType]").text();
			methoduoeeventsobj['ReturnType'] = vReturnType;
			methoduoeeventsobj['index'] = index;
var vDescription = methoduoeeventsrow.find("[name=Description]").text();
			methoduoeeventsobj['Description'] = vDescription;
			methoduoeeventsobj['index'] = index;

	methoduoeeventsdata.push(methoduoeeventsobj);
});
return methoduoeeventsdata;
	}
function getRowstbluoefab(){
	var tbluoefabdata = [];
	tbluoefabrows = $("#tbluoefab tbody tr");
tbluoefabrows.each(function (index) {
    var tbluoefabrow = $(this);
 	var tbluoefabobj = {};
	var vProperty = tbluoefabrow.find("[name=Property]").text();
			tbluoefabobj['Property'] = vProperty;
			tbluoefabobj['index'] = index;
var vType = tbluoefabrow.find("[name=Type]").text();
			tbluoefabobj['Type'] = vType;
			tbluoefabobj['index'] = index;
var vDefaultValue = tbluoefabrow.find("[name=DefaultValue]").text();
			tbluoefabobj['DefaultValue'] = vDefaultValue;
			tbluoefabobj['index'] = index;
var vDescription = tbluoefabrow.find("[name=Description]").text();
			tbluoefabobj['Description'] = vDescription;
			tbluoefabobj['index'] = index;

	tbluoefabdata.push(tbluoefabobj);
});
return tbluoefabdata;
	}
function getRowsmethoduoefab(){
	var methoduoefabdata = [];
	methoduoefabrows = $("#methoduoefab tbody tr");
methoduoefabrows.each(function (index) {
    var methoduoefabrow = $(this);
 	var methoduoefabobj = {};
	var vMethod = methoduoefabrow.find("[name=Method]").text();
			methoduoefabobj['Method'] = vMethod;
			methoduoefabobj['index'] = index;
var vParameters = methoduoefabrow.find("[name=Parameters]").text();
			methoduoefabobj['Parameters'] = vParameters;
			methoduoefabobj['index'] = index;
var vReturnType = methoduoefabrow.find("[name=ReturnType]").text();
			methoduoefabobj['ReturnType'] = vReturnType;
			methoduoefabobj['index'] = index;
var vDescription = methoduoefabrow.find("[name=Description]").text();
			methoduoefabobj['Description'] = vDescription;
			methoduoefabobj['index'] = index;

	methoduoefabdata.push(methoduoefabobj);
});
return methoduoefabdata;
	}
function getRowstbluoefabdirection(){
	var tbluoefabdirectiondata = [];
	tbluoefabdirectionrows = $("#tbluoefabdirection tbody tr");
tbluoefabdirectionrows.each(function (index) {
    var tbluoefabdirectionrow = $(this);
 	var tbluoefabdirectionobj = {};
	var vProperty = tbluoefabdirectionrow.find("[name=Property]").text();
			tbluoefabdirectionobj['Property'] = vProperty;
			tbluoefabdirectionobj['index'] = index;
var vType = tbluoefabdirectionrow.find("[name=Type]").text();
			tbluoefabdirectionobj['Type'] = vType;
			tbluoefabdirectionobj['index'] = index;
var vDefaultValue = tbluoefabdirectionrow.find("[name=DefaultValue]").text();
			tbluoefabdirectionobj['DefaultValue'] = vDefaultValue;
			tbluoefabdirectionobj['index'] = index;
var vDescription = tbluoefabdirectionrow.find("[name=Description]").text();
			tbluoefabdirectionobj['Description'] = vDescription;
			tbluoefabdirectionobj['index'] = index;

	tbluoefabdirectiondata.push(tbluoefabdirectionobj);
});
return tbluoefabdirectiondata;
	}
function getRowsmethoduoefabdirection(){
	var methoduoefabdirectiondata = [];
	methoduoefabdirectionrows = $("#methoduoefabdirection tbody tr");
methoduoefabdirectionrows.each(function (index) {
    var methoduoefabdirectionrow = $(this);
 	var methoduoefabdirectionobj = {};
	var vMethod = methoduoefabdirectionrow.find("[name=Method]").text();
			methoduoefabdirectionobj['Method'] = vMethod;
			methoduoefabdirectionobj['index'] = index;
var vParameters = methoduoefabdirectionrow.find("[name=Parameters]").text();
			methoduoefabdirectionobj['Parameters'] = vParameters;
			methoduoefabdirectionobj['index'] = index;
var vReturnType = methoduoefabdirectionrow.find("[name=ReturnType]").text();
			methoduoefabdirectionobj['ReturnType'] = vReturnType;
			methoduoefabdirectionobj['index'] = index;
var vDescription = methoduoefabdirectionrow.find("[name=Description]").text();
			methoduoefabdirectionobj['Description'] = vDescription;
			methoduoefabdirectionobj['index'] = index;

	methoduoefabdirectiondata.push(methoduoefabdirectionobj);
});
return methoduoefabdirectiondata;
	}
function getRowstbluoefcoperation(){
	var tbluoefcoperationdata = [];
	tbluoefcoperationrows = $("#tbluoefcoperation tbody tr");
tbluoefcoperationrows.each(function (index) {
    var tbluoefcoperationrow = $(this);
 	var tbluoefcoperationobj = {};
	var vProperty = tbluoefcoperationrow.find("[name=Property]").text();
			tbluoefcoperationobj['Property'] = vProperty;
			tbluoefcoperationobj['index'] = index;
var vType = tbluoefcoperationrow.find("[name=Type]").text();
			tbluoefcoperationobj['Type'] = vType;
			tbluoefcoperationobj['index'] = index;
var vDefaultValue = tbluoefcoperationrow.find("[name=DefaultValue]").text();
			tbluoefcoperationobj['DefaultValue'] = vDefaultValue;
			tbluoefcoperationobj['index'] = index;
var vDescription = tbluoefcoperationrow.find("[name=Description]").text();
			tbluoefcoperationobj['Description'] = vDescription;
			tbluoefcoperationobj['index'] = index;

	tbluoefcoperationdata.push(tbluoefcoperationobj);
});
return tbluoefcoperationdata;
	}
function getRowsmethoduoefcoperation(){
	var methoduoefcoperationdata = [];
	methoduoefcoperationrows = $("#methoduoefcoperation tbody tr");
methoduoefcoperationrows.each(function (index) {
    var methoduoefcoperationrow = $(this);
 	var methoduoefcoperationobj = {};
	var vMethod = methoduoefcoperationrow.find("[name=Method]").text();
			methoduoefcoperationobj['Method'] = vMethod;
			methoduoefcoperationobj['index'] = index;
var vParameters = methoduoefcoperationrow.find("[name=Parameters]").text();
			methoduoefcoperationobj['Parameters'] = vParameters;
			methoduoefcoperationobj['index'] = index;
var vReturnType = methoduoefcoperationrow.find("[name=ReturnType]").text();
			methoduoefcoperationobj['ReturnType'] = vReturnType;
			methoduoefcoperationobj['index'] = index;
var vDescription = methoduoefcoperationrow.find("[name=Description]").text();
			methoduoefcoperationobj['Description'] = vDescription;
			methoduoefcoperationobj['index'] = index;

	methoduoefcoperationdata.push(methoduoefcoperationobj);
});
return methoduoefcoperationdata;
	}
function getRowstbluoefcpositiontype(){
	var tbluoefcpositiontypedata = [];
	tbluoefcpositiontyperows = $("#tbluoefcpositiontype tbody tr");
tbluoefcpositiontyperows.each(function (index) {
    var tbluoefcpositiontyperow = $(this);
 	var tbluoefcpositiontypeobj = {};
	var vProperty = tbluoefcpositiontyperow.find("[name=Property]").text();
			tbluoefcpositiontypeobj['Property'] = vProperty;
			tbluoefcpositiontypeobj['index'] = index;
var vType = tbluoefcpositiontyperow.find("[name=Type]").text();
			tbluoefcpositiontypeobj['Type'] = vType;
			tbluoefcpositiontypeobj['index'] = index;
var vDefaultValue = tbluoefcpositiontyperow.find("[name=DefaultValue]").text();
			tbluoefcpositiontypeobj['DefaultValue'] = vDefaultValue;
			tbluoefcpositiontypeobj['index'] = index;
var vDescription = tbluoefcpositiontyperow.find("[name=Description]").text();
			tbluoefcpositiontypeobj['Description'] = vDescription;
			tbluoefcpositiontypeobj['index'] = index;

	tbluoefcpositiontypedata.push(tbluoefcpositiontypeobj);
});
return tbluoefcpositiontypedata;
	}
function getRowsmethoduoefcpositiontype(){
	var methoduoefcpositiontypedata = [];
	methoduoefcpositiontyperows = $("#methoduoefcpositiontype tbody tr");
methoduoefcpositiontyperows.each(function (index) {
    var methoduoefcpositiontyperow = $(this);
 	var methoduoefcpositiontypeobj = {};
	var vMethod = methoduoefcpositiontyperow.find("[name=Method]").text();
			methoduoefcpositiontypeobj['Method'] = vMethod;
			methoduoefcpositiontypeobj['index'] = index;
var vParameters = methoduoefcpositiontyperow.find("[name=Parameters]").text();
			methoduoefcpositiontypeobj['Parameters'] = vParameters;
			methoduoefcpositiontypeobj['index'] = index;
var vReturnType = methoduoefcpositiontyperow.find("[name=ReturnType]").text();
			methoduoefcpositiontypeobj['ReturnType'] = vReturnType;
			methoduoefcpositiontypeobj['index'] = index;
var vDescription = methoduoefcpositiontyperow.find("[name=Description]").text();
			methoduoefcpositiontypeobj['Description'] = vDescription;
			methoduoefcpositiontypeobj['index'] = index;

	methoduoefcpositiontypedata.push(methoduoefcpositiontypeobj);
});
return methoduoefcpositiontypedata;
	}
function getRowstbluoefeature(){
	var tbluoefeaturedata = [];
	tbluoefeaturerows = $("#tbluoefeature tbody tr");
tbluoefeaturerows.each(function (index) {
    var tbluoefeaturerow = $(this);
 	var tbluoefeatureobj = {};
	var vProperty = tbluoefeaturerow.find("[name=Property]").text();
			tbluoefeatureobj['Property'] = vProperty;
			tbluoefeatureobj['index'] = index;
var vType = tbluoefeaturerow.find("[name=Type]").text();
			tbluoefeatureobj['Type'] = vType;
			tbluoefeatureobj['index'] = index;
var vDefaultValue = tbluoefeaturerow.find("[name=DefaultValue]").text();
			tbluoefeatureobj['DefaultValue'] = vDefaultValue;
			tbluoefeatureobj['index'] = index;
var vDescription = tbluoefeaturerow.find("[name=Description]").text();
			tbluoefeatureobj['Description'] = vDescription;
			tbluoefeatureobj['index'] = index;

	tbluoefeaturedata.push(tbluoefeatureobj);
});
return tbluoefeaturedata;
	}
function getRowsmethoduoefeature(){
	var methoduoefeaturedata = [];
	methoduoefeaturerows = $("#methoduoefeature tbody tr");
methoduoefeaturerows.each(function (index) {
    var methoduoefeaturerow = $(this);
 	var methoduoefeatureobj = {};
	var vMethod = methoduoefeaturerow.find("[name=Method]").text();
			methoduoefeatureobj['Method'] = vMethod;
			methoduoefeatureobj['index'] = index;
var vParameters = methoduoefeaturerow.find("[name=Parameters]").text();
			methoduoefeatureobj['Parameters'] = vParameters;
			methoduoefeatureobj['index'] = index;
var vReturnType = methoduoefeaturerow.find("[name=ReturnType]").text();
			methoduoefeatureobj['ReturnType'] = vReturnType;
			methoduoefeatureobj['index'] = index;
var vDescription = methoduoefeaturerow.find("[name=Description]").text();
			methoduoefeatureobj['Description'] = vDescription;
			methoduoefeatureobj['index'] = index;

	methoduoefeaturedata.push(methoduoefeatureobj);
});
return methoduoefeaturedata;
	}
function getRowstbluoefile(){
	var tbluoefiledata = [];
	tbluoefilerows = $("#tbluoefile tbody tr");
tbluoefilerows.each(function (index) {
    var tbluoefilerow = $(this);
 	var tbluoefileobj = {};
	var vProperty = tbluoefilerow.find("[name=Property]").text();
			tbluoefileobj['Property'] = vProperty;
			tbluoefileobj['index'] = index;
var vType = tbluoefilerow.find("[name=Type]").text();
			tbluoefileobj['Type'] = vType;
			tbluoefileobj['index'] = index;
var vDefaultValue = tbluoefilerow.find("[name=DefaultValue]").text();
			tbluoefileobj['DefaultValue'] = vDefaultValue;
			tbluoefileobj['index'] = index;
var vDescription = tbluoefilerow.find("[name=Description]").text();
			tbluoefileobj['Description'] = vDescription;
			tbluoefileobj['index'] = index;

	tbluoefiledata.push(tbluoefileobj);
});
return tbluoefiledata;
	}
function getRowsmethoduoefile(){
	var methoduoefiledata = [];
	methoduoefilerows = $("#methoduoefile tbody tr");
methoduoefilerows.each(function (index) {
    var methoduoefilerow = $(this);
 	var methoduoefileobj = {};
	var vMethod = methoduoefilerow.find("[name=Method]").text();
			methoduoefileobj['Method'] = vMethod;
			methoduoefileobj['index'] = index;
var vParameters = methoduoefilerow.find("[name=Parameters]").text();
			methoduoefileobj['Parameters'] = vParameters;
			methoduoefileobj['index'] = index;
var vReturnType = methoduoefilerow.find("[name=ReturnType]").text();
			methoduoefileobj['ReturnType'] = vReturnType;
			methoduoefileobj['index'] = index;
var vDescription = methoduoefilerow.find("[name=Description]").text();
			methoduoefileobj['Description'] = vDescription;
			methoduoefileobj['index'] = index;

	methoduoefiledata.push(methoduoefileobj);
});
return methoduoefiledata;
	}
function getRowstbluoefirebase(){
	var tbluoefirebasedata = [];
	tbluoefirebaserows = $("#tbluoefirebase tbody tr");
tbluoefirebaserows.each(function (index) {
    var tbluoefirebaserow = $(this);
 	var tbluoefirebaseobj = {};
	var vProperty = tbluoefirebaserow.find("[name=Property]").text();
			tbluoefirebaseobj['Property'] = vProperty;
			tbluoefirebaseobj['index'] = index;
var vType = tbluoefirebaserow.find("[name=Type]").text();
			tbluoefirebaseobj['Type'] = vType;
			tbluoefirebaseobj['index'] = index;
var vDefaultValue = tbluoefirebaserow.find("[name=DefaultValue]").text();
			tbluoefirebaseobj['DefaultValue'] = vDefaultValue;
			tbluoefirebaseobj['index'] = index;
var vDescription = tbluoefirebaserow.find("[name=Description]").text();
			tbluoefirebaseobj['Description'] = vDescription;
			tbluoefirebaseobj['index'] = index;

	tbluoefirebasedata.push(tbluoefirebaseobj);
});
return tbluoefirebasedata;
	}
function getRowsmethoduoefirebase(){
	var methoduoefirebasedata = [];
	methoduoefirebaserows = $("#methoduoefirebase tbody tr");
methoduoefirebaserows.each(function (index) {
    var methoduoefirebaserow = $(this);
 	var methoduoefirebaseobj = {};
	var vMethod = methoduoefirebaserow.find("[name=Method]").text();
			methoduoefirebaseobj['Method'] = vMethod;
			methoduoefirebaseobj['index'] = index;
var vParameters = methoduoefirebaserow.find("[name=Parameters]").text();
			methoduoefirebaseobj['Parameters'] = vParameters;
			methoduoefirebaseobj['index'] = index;
var vReturnType = methoduoefirebaserow.find("[name=ReturnType]").text();
			methoduoefirebaseobj['ReturnType'] = vReturnType;
			methoduoefirebaseobj['index'] = index;
var vDescription = methoduoefirebaserow.find("[name=Description]").text();
			methoduoefirebaseobj['Description'] = vDescription;
			methoduoefirebaseobj['index'] = index;

	methoduoefirebasedata.push(methoduoefirebaseobj);
});
return methoduoefirebasedata;
	}
function getRowstbluoefloattype(){
	var tbluoefloattypedata = [];
	tbluoefloattyperows = $("#tbluoefloattype tbody tr");
tbluoefloattyperows.each(function (index) {
    var tbluoefloattyperow = $(this);
 	var tbluoefloattypeobj = {};
	var vProperty = tbluoefloattyperow.find("[name=Property]").text();
			tbluoefloattypeobj['Property'] = vProperty;
			tbluoefloattypeobj['index'] = index;
var vType = tbluoefloattyperow.find("[name=Type]").text();
			tbluoefloattypeobj['Type'] = vType;
			tbluoefloattypeobj['index'] = index;
var vDefaultValue = tbluoefloattyperow.find("[name=DefaultValue]").text();
			tbluoefloattypeobj['DefaultValue'] = vDefaultValue;
			tbluoefloattypeobj['index'] = index;
var vDescription = tbluoefloattyperow.find("[name=Description]").text();
			tbluoefloattypeobj['Description'] = vDescription;
			tbluoefloattypeobj['index'] = index;

	tbluoefloattypedata.push(tbluoefloattypeobj);
});
return tbluoefloattypedata;
	}
function getRowsmethoduoefloattype(){
	var methoduoefloattypedata = [];
	methoduoefloattyperows = $("#methoduoefloattype tbody tr");
methoduoefloattyperows.each(function (index) {
    var methoduoefloattyperow = $(this);
 	var methoduoefloattypeobj = {};
	var vMethod = methoduoefloattyperow.find("[name=Method]").text();
			methoduoefloattypeobj['Method'] = vMethod;
			methoduoefloattypeobj['index'] = index;
var vParameters = methoduoefloattyperow.find("[name=Parameters]").text();
			methoduoefloattypeobj['Parameters'] = vParameters;
			methoduoefloattypeobj['index'] = index;
var vReturnType = methoduoefloattyperow.find("[name=ReturnType]").text();
			methoduoefloattypeobj['ReturnType'] = vReturnType;
			methoduoefloattypeobj['index'] = index;
var vDescription = methoduoefloattyperow.find("[name=Description]").text();
			methoduoefloattypeobj['Description'] = vDescription;
			methoduoefloattypeobj['index'] = index;

	methoduoefloattypedata.push(methoduoefloattypeobj);
});
return methoduoefloattypedata;
	}
function getRowstbluoeflowchart(){
	var tbluoeflowchartdata = [];
	tbluoeflowchartrows = $("#tbluoeflowchart tbody tr");
tbluoeflowchartrows.each(function (index) {
    var tbluoeflowchartrow = $(this);
 	var tbluoeflowchartobj = {};
	var vProperty = tbluoeflowchartrow.find("[name=Property]").text();
			tbluoeflowchartobj['Property'] = vProperty;
			tbluoeflowchartobj['index'] = index;
var vType = tbluoeflowchartrow.find("[name=Type]").text();
			tbluoeflowchartobj['Type'] = vType;
			tbluoeflowchartobj['index'] = index;
var vDefaultValue = tbluoeflowchartrow.find("[name=DefaultValue]").text();
			tbluoeflowchartobj['DefaultValue'] = vDefaultValue;
			tbluoeflowchartobj['index'] = index;
var vDescription = tbluoeflowchartrow.find("[name=Description]").text();
			tbluoeflowchartobj['Description'] = vDescription;
			tbluoeflowchartobj['index'] = index;

	tbluoeflowchartdata.push(tbluoeflowchartobj);
});
return tbluoeflowchartdata;
	}
function getRowsmethoduoeflowchart(){
	var methoduoeflowchartdata = [];
	methoduoeflowchartrows = $("#methoduoeflowchart tbody tr");
methoduoeflowchartrows.each(function (index) {
    var methoduoeflowchartrow = $(this);
 	var methoduoeflowchartobj = {};
	var vMethod = methoduoeflowchartrow.find("[name=Method]").text();
			methoduoeflowchartobj['Method'] = vMethod;
			methoduoeflowchartobj['index'] = index;
var vParameters = methoduoeflowchartrow.find("[name=Parameters]").text();
			methoduoeflowchartobj['Parameters'] = vParameters;
			methoduoeflowchartobj['index'] = index;
var vReturnType = methoduoeflowchartrow.find("[name=ReturnType]").text();
			methoduoeflowchartobj['ReturnType'] = vReturnType;
			methoduoeflowchartobj['index'] = index;
var vDescription = methoduoeflowchartrow.find("[name=Description]").text();
			methoduoeflowchartobj['Description'] = vDescription;
			methoduoeflowchartobj['index'] = index;

	methoduoeflowchartdata.push(methoduoeflowchartobj);
});
return methoduoeflowchartdata;
	}
function getRowstbluoeframeworks(){
	var tbluoeframeworksdata = [];
	tbluoeframeworksrows = $("#tbluoeframeworks tbody tr");
tbluoeframeworksrows.each(function (index) {
    var tbluoeframeworksrow = $(this);
 	var tbluoeframeworksobj = {};
	var vProperty = tbluoeframeworksrow.find("[name=Property]").text();
			tbluoeframeworksobj['Property'] = vProperty;
			tbluoeframeworksobj['index'] = index;
var vType = tbluoeframeworksrow.find("[name=Type]").text();
			tbluoeframeworksobj['Type'] = vType;
			tbluoeframeworksobj['index'] = index;
var vDefaultValue = tbluoeframeworksrow.find("[name=DefaultValue]").text();
			tbluoeframeworksobj['DefaultValue'] = vDefaultValue;
			tbluoeframeworksobj['index'] = index;
var vDescription = tbluoeframeworksrow.find("[name=Description]").text();
			tbluoeframeworksobj['Description'] = vDescription;
			tbluoeframeworksobj['index'] = index;

	tbluoeframeworksdata.push(tbluoeframeworksobj);
});
return tbluoeframeworksdata;
	}
function getRowsmethoduoeframeworks(){
	var methoduoeframeworksdata = [];
	methoduoeframeworksrows = $("#methoduoeframeworks tbody tr");
methoduoeframeworksrows.each(function (index) {
    var methoduoeframeworksrow = $(this);
 	var methoduoeframeworksobj = {};
	var vMethod = methoduoeframeworksrow.find("[name=Method]").text();
			methoduoeframeworksobj['Method'] = vMethod;
			methoduoeframeworksobj['index'] = index;
var vParameters = methoduoeframeworksrow.find("[name=Parameters]").text();
			methoduoeframeworksobj['Parameters'] = vParameters;
			methoduoeframeworksobj['index'] = index;
var vReturnType = methoduoeframeworksrow.find("[name=ReturnType]").text();
			methoduoeframeworksobj['ReturnType'] = vReturnType;
			methoduoeframeworksobj['index'] = index;
var vDescription = methoduoeframeworksrow.find("[name=Description]").text();
			methoduoeframeworksobj['Description'] = vDescription;
			methoduoeframeworksobj['index'] = index;

	methoduoeframeworksdata.push(methoduoeframeworksobj);
});
return methoduoeframeworksdata;
	}
function getRowstbluoegallery(){
	var tbluoegallerydata = [];
	tbluoegalleryrows = $("#tbluoegallery tbody tr");
tbluoegalleryrows.each(function (index) {
    var tbluoegalleryrow = $(this);
 	var tbluoegalleryobj = {};
	var vProperty = tbluoegalleryrow.find("[name=Property]").text();
			tbluoegalleryobj['Property'] = vProperty;
			tbluoegalleryobj['index'] = index;
var vType = tbluoegalleryrow.find("[name=Type]").text();
			tbluoegalleryobj['Type'] = vType;
			tbluoegalleryobj['index'] = index;
var vDefaultValue = tbluoegalleryrow.find("[name=DefaultValue]").text();
			tbluoegalleryobj['DefaultValue'] = vDefaultValue;
			tbluoegalleryobj['index'] = index;
var vDescription = tbluoegalleryrow.find("[name=Description]").text();
			tbluoegalleryobj['Description'] = vDescription;
			tbluoegalleryobj['index'] = index;

	tbluoegallerydata.push(tbluoegalleryobj);
});
return tbluoegallerydata;
	}
function getRowsmethoduoegallery(){
	var methoduoegallerydata = [];
	methoduoegalleryrows = $("#methoduoegallery tbody tr");
methoduoegalleryrows.each(function (index) {
    var methoduoegalleryrow = $(this);
 	var methoduoegalleryobj = {};
	var vMethod = methoduoegalleryrow.find("[name=Method]").text();
			methoduoegalleryobj['Method'] = vMethod;
			methoduoegalleryobj['index'] = index;
var vParameters = methoduoegalleryrow.find("[name=Parameters]").text();
			methoduoegalleryobj['Parameters'] = vParameters;
			methoduoegalleryobj['index'] = index;
var vReturnType = methoduoegalleryrow.find("[name=ReturnType]").text();
			methoduoegalleryobj['ReturnType'] = vReturnType;
			methoduoegalleryobj['index'] = index;
var vDescription = methoduoegalleryrow.find("[name=Description]").text();
			methoduoegalleryobj['Description'] = vDescription;
			methoduoegalleryobj['index'] = index;

	methoduoegallerydata.push(methoduoegalleryobj);
});
return methoduoegallerydata;
	}
function getRowstbluoegmaps(){
	var tbluoegmapsdata = [];
	tbluoegmapsrows = $("#tbluoegmaps tbody tr");
tbluoegmapsrows.each(function (index) {
    var tbluoegmapsrow = $(this);
 	var tbluoegmapsobj = {};
	var vProperty = tbluoegmapsrow.find("[name=Property]").text();
			tbluoegmapsobj['Property'] = vProperty;
			tbluoegmapsobj['index'] = index;
var vType = tbluoegmapsrow.find("[name=Type]").text();
			tbluoegmapsobj['Type'] = vType;
			tbluoegmapsobj['index'] = index;
var vDefaultValue = tbluoegmapsrow.find("[name=DefaultValue]").text();
			tbluoegmapsobj['DefaultValue'] = vDefaultValue;
			tbluoegmapsobj['index'] = index;
var vDescription = tbluoegmapsrow.find("[name=Description]").text();
			tbluoegmapsobj['Description'] = vDescription;
			tbluoegmapsobj['index'] = index;

	tbluoegmapsdata.push(tbluoegmapsobj);
});
return tbluoegmapsdata;
	}
function getRowsmethoduoegmaps(){
	var methoduoegmapsdata = [];
	methoduoegmapsrows = $("#methoduoegmaps tbody tr");
methoduoegmapsrows.each(function (index) {
    var methoduoegmapsrow = $(this);
 	var methoduoegmapsobj = {};
	var vMethod = methoduoegmapsrow.find("[name=Method]").text();
			methoduoegmapsobj['Method'] = vMethod;
			methoduoegmapsobj['index'] = index;
var vParameters = methoduoegmapsrow.find("[name=Parameters]").text();
			methoduoegmapsobj['Parameters'] = vParameters;
			methoduoegmapsobj['index'] = index;
var vReturnType = methoduoegmapsrow.find("[name=ReturnType]").text();
			methoduoegmapsobj['ReturnType'] = vReturnType;
			methoduoegmapsobj['index'] = index;
var vDescription = methoduoegmapsrow.find("[name=Description]").text();
			methoduoegmapsobj['Description'] = vDescription;
			methoduoegmapsobj['index'] = index;

	methoduoegmapsdata.push(methoduoegmapsobj);
});
return methoduoegmapsdata;
	}
function getRowstbluoegrid(){
	var tbluoegriddata = [];
	tbluoegridrows = $("#tbluoegrid tbody tr");
tbluoegridrows.each(function (index) {
    var tbluoegridrow = $(this);
 	var tbluoegridobj = {};
	var vProperty = tbluoegridrow.find("[name=Property]").text();
			tbluoegridobj['Property'] = vProperty;
			tbluoegridobj['index'] = index;
var vType = tbluoegridrow.find("[name=Type]").text();
			tbluoegridobj['Type'] = vType;
			tbluoegridobj['index'] = index;
var vDefaultValue = tbluoegridrow.find("[name=DefaultValue]").text();
			tbluoegridobj['DefaultValue'] = vDefaultValue;
			tbluoegridobj['index'] = index;
var vDescription = tbluoegridrow.find("[name=Description]").text();
			tbluoegridobj['Description'] = vDescription;
			tbluoegridobj['index'] = index;

	tbluoegriddata.push(tbluoegridobj);
});
return tbluoegriddata;
	}
function getRowsmethoduoegrid(){
	var methoduoegriddata = [];
	methoduoegridrows = $("#methoduoegrid tbody tr");
methoduoegridrows.each(function (index) {
    var methoduoegridrow = $(this);
 	var methoduoegridobj = {};
	var vMethod = methoduoegridrow.find("[name=Method]").text();
			methoduoegridobj['Method'] = vMethod;
			methoduoegridobj['index'] = index;
var vParameters = methoduoegridrow.find("[name=Parameters]").text();
			methoduoegridobj['Parameters'] = vParameters;
			methoduoegridobj['index'] = index;
var vReturnType = methoduoegridrow.find("[name=ReturnType]").text();
			methoduoegridobj['ReturnType'] = vReturnType;
			methoduoegridobj['index'] = index;
var vDescription = methoduoegridrow.find("[name=Description]").text();
			methoduoegridobj['Description'] = vDescription;
			methoduoegridobj['index'] = index;

	methoduoegriddata.push(methoduoegridobj);
});
return methoduoegriddata;
	}
function getRowstbluoehexcolors(){
	var tbluoehexcolorsdata = [];
	tbluoehexcolorsrows = $("#tbluoehexcolors tbody tr");
tbluoehexcolorsrows.each(function (index) {
    var tbluoehexcolorsrow = $(this);
 	var tbluoehexcolorsobj = {};
	var vProperty = tbluoehexcolorsrow.find("[name=Property]").text();
			tbluoehexcolorsobj['Property'] = vProperty;
			tbluoehexcolorsobj['index'] = index;
var vType = tbluoehexcolorsrow.find("[name=Type]").text();
			tbluoehexcolorsobj['Type'] = vType;
			tbluoehexcolorsobj['index'] = index;
var vDefaultValue = tbluoehexcolorsrow.find("[name=DefaultValue]").text();
			tbluoehexcolorsobj['DefaultValue'] = vDefaultValue;
			tbluoehexcolorsobj['index'] = index;
var vDescription = tbluoehexcolorsrow.find("[name=Description]").text();
			tbluoehexcolorsobj['Description'] = vDescription;
			tbluoehexcolorsobj['index'] = index;

	tbluoehexcolorsdata.push(tbluoehexcolorsobj);
});
return tbluoehexcolorsdata;
	}
function getRowsmethoduoehexcolors(){
	var methoduoehexcolorsdata = [];
	methoduoehexcolorsrows = $("#methoduoehexcolors tbody tr");
methoduoehexcolorsrows.each(function (index) {
    var methoduoehexcolorsrow = $(this);
 	var methoduoehexcolorsobj = {};
	var vMethod = methoduoehexcolorsrow.find("[name=Method]").text();
			methoduoehexcolorsobj['Method'] = vMethod;
			methoduoehexcolorsobj['index'] = index;
var vParameters = methoduoehexcolorsrow.find("[name=Parameters]").text();
			methoduoehexcolorsobj['Parameters'] = vParameters;
			methoduoehexcolorsobj['index'] = index;
var vReturnType = methoduoehexcolorsrow.find("[name=ReturnType]").text();
			methoduoehexcolorsobj['ReturnType'] = vReturnType;
			methoduoehexcolorsobj['index'] = index;
var vDescription = methoduoehexcolorsrow.find("[name=Description]").text();
			methoduoehexcolorsobj['Description'] = vDescription;
			methoduoehexcolorsobj['index'] = index;

	methoduoehexcolorsdata.push(methoduoehexcolorsobj);
});
return methoduoehexcolorsdata;
	}
function getRowstbluoehtml5video(){
	var tbluoehtml5videodata = [];
	tbluoehtml5videorows = $("#tbluoehtml5video tbody tr");
tbluoehtml5videorows.each(function (index) {
    var tbluoehtml5videorow = $(this);
 	var tbluoehtml5videoobj = {};
	var vProperty = tbluoehtml5videorow.find("[name=Property]").text();
			tbluoehtml5videoobj['Property'] = vProperty;
			tbluoehtml5videoobj['index'] = index;
var vType = tbluoehtml5videorow.find("[name=Type]").text();
			tbluoehtml5videoobj['Type'] = vType;
			tbluoehtml5videoobj['index'] = index;
var vDefaultValue = tbluoehtml5videorow.find("[name=DefaultValue]").text();
			tbluoehtml5videoobj['DefaultValue'] = vDefaultValue;
			tbluoehtml5videoobj['index'] = index;
var vDescription = tbluoehtml5videorow.find("[name=Description]").text();
			tbluoehtml5videoobj['Description'] = vDescription;
			tbluoehtml5videoobj['index'] = index;

	tbluoehtml5videodata.push(tbluoehtml5videoobj);
});
return tbluoehtml5videodata;
	}
function getRowsmethoduoehtml5video(){
	var methoduoehtml5videodata = [];
	methoduoehtml5videorows = $("#methoduoehtml5video tbody tr");
methoduoehtml5videorows.each(function (index) {
    var methoduoehtml5videorow = $(this);
 	var methoduoehtml5videoobj = {};
	var vMethod = methoduoehtml5videorow.find("[name=Method]").text();
			methoduoehtml5videoobj['Method'] = vMethod;
			methoduoehtml5videoobj['index'] = index;
var vParameters = methoduoehtml5videorow.find("[name=Parameters]").text();
			methoduoehtml5videoobj['Parameters'] = vParameters;
			methoduoehtml5videoobj['index'] = index;
var vReturnType = methoduoehtml5videorow.find("[name=ReturnType]").text();
			methoduoehtml5videoobj['ReturnType'] = vReturnType;
			methoduoehtml5videoobj['index'] = index;
var vDescription = methoduoehtml5videorow.find("[name=Description]").text();
			methoduoehtml5videoobj['Description'] = vDescription;
			methoduoehtml5videoobj['index'] = index;

	methoduoehtml5videodata.push(methoduoehtml5videoobj);
});
return methoduoehtml5videodata;
	}
function getRowstbluoeicon(){
	var tbluoeicondata = [];
	tbluoeiconrows = $("#tbluoeicon tbody tr");
tbluoeiconrows.each(function (index) {
    var tbluoeiconrow = $(this);
 	var tbluoeiconobj = {};
	var vProperty = tbluoeiconrow.find("[name=Property]").text();
			tbluoeiconobj['Property'] = vProperty;
			tbluoeiconobj['index'] = index;
var vType = tbluoeiconrow.find("[name=Type]").text();
			tbluoeiconobj['Type'] = vType;
			tbluoeiconobj['index'] = index;
var vDefaultValue = tbluoeiconrow.find("[name=DefaultValue]").text();
			tbluoeiconobj['DefaultValue'] = vDefaultValue;
			tbluoeiconobj['index'] = index;
var vDescription = tbluoeiconrow.find("[name=Description]").text();
			tbluoeiconobj['Description'] = vDescription;
			tbluoeiconobj['index'] = index;

	tbluoeicondata.push(tbluoeiconobj);
});
return tbluoeicondata;
	}
function getRowsmethoduoeicon(){
	var methoduoeicondata = [];
	methoduoeiconrows = $("#methoduoeicon tbody tr");
methoduoeiconrows.each(function (index) {
    var methoduoeiconrow = $(this);
 	var methoduoeiconobj = {};
	var vMethod = methoduoeiconrow.find("[name=Method]").text();
			methoduoeiconobj['Method'] = vMethod;
			methoduoeiconobj['index'] = index;
var vParameters = methoduoeiconrow.find("[name=Parameters]").text();
			methoduoeiconobj['Parameters'] = vParameters;
			methoduoeiconobj['index'] = index;
var vReturnType = methoduoeiconrow.find("[name=ReturnType]").text();
			methoduoeiconobj['ReturnType'] = vReturnType;
			methoduoeiconobj['index'] = index;
var vDescription = methoduoeiconrow.find("[name=Description]").text();
			methoduoeiconobj['Description'] = vDescription;
			methoduoeiconobj['index'] = index;

	methoduoeicondata.push(methoduoeiconobj);
});
return methoduoeicondata;
	}
function getRowstbluoeiconsize(){
	var tbluoeiconsizedata = [];
	tbluoeiconsizerows = $("#tbluoeiconsize tbody tr");
tbluoeiconsizerows.each(function (index) {
    var tbluoeiconsizerow = $(this);
 	var tbluoeiconsizeobj = {};
	var vProperty = tbluoeiconsizerow.find("[name=Property]").text();
			tbluoeiconsizeobj['Property'] = vProperty;
			tbluoeiconsizeobj['index'] = index;
var vType = tbluoeiconsizerow.find("[name=Type]").text();
			tbluoeiconsizeobj['Type'] = vType;
			tbluoeiconsizeobj['index'] = index;
var vDefaultValue = tbluoeiconsizerow.find("[name=DefaultValue]").text();
			tbluoeiconsizeobj['DefaultValue'] = vDefaultValue;
			tbluoeiconsizeobj['index'] = index;
var vDescription = tbluoeiconsizerow.find("[name=Description]").text();
			tbluoeiconsizeobj['Description'] = vDescription;
			tbluoeiconsizeobj['index'] = index;

	tbluoeiconsizedata.push(tbluoeiconsizeobj);
});
return tbluoeiconsizedata;
	}
function getRowsmethoduoeiconsize(){
	var methoduoeiconsizedata = [];
	methoduoeiconsizerows = $("#methoduoeiconsize tbody tr");
methoduoeiconsizerows.each(function (index) {
    var methoduoeiconsizerow = $(this);
 	var methoduoeiconsizeobj = {};
	var vMethod = methoduoeiconsizerow.find("[name=Method]").text();
			methoduoeiconsizeobj['Method'] = vMethod;
			methoduoeiconsizeobj['index'] = index;
var vParameters = methoduoeiconsizerow.find("[name=Parameters]").text();
			methoduoeiconsizeobj['Parameters'] = vParameters;
			methoduoeiconsizeobj['index'] = index;
var vReturnType = methoduoeiconsizerow.find("[name=ReturnType]").text();
			methoduoeiconsizeobj['ReturnType'] = vReturnType;
			methoduoeiconsizeobj['index'] = index;
var vDescription = methoduoeiconsizerow.find("[name=Description]").text();
			methoduoeiconsizeobj['Description'] = vDescription;
			methoduoeiconsizeobj['index'] = index;

	methoduoeiconsizedata.push(methoduoeiconsizeobj);
});
return methoduoeiconsizedata;
	}
function getRowstbluoeimage(){
	var tbluoeimagedata = [];
	tbluoeimagerows = $("#tbluoeimage tbody tr");
tbluoeimagerows.each(function (index) {
    var tbluoeimagerow = $(this);
 	var tbluoeimageobj = {};
	var vProperty = tbluoeimagerow.find("[name=Property]").text();
			tbluoeimageobj['Property'] = vProperty;
			tbluoeimageobj['index'] = index;
var vType = tbluoeimagerow.find("[name=Type]").text();
			tbluoeimageobj['Type'] = vType;
			tbluoeimageobj['index'] = index;
var vDefaultValue = tbluoeimagerow.find("[name=DefaultValue]").text();
			tbluoeimageobj['DefaultValue'] = vDefaultValue;
			tbluoeimageobj['index'] = index;
var vDescription = tbluoeimagerow.find("[name=Description]").text();
			tbluoeimageobj['Description'] = vDescription;
			tbluoeimageobj['index'] = index;

	tbluoeimagedata.push(tbluoeimageobj);
});
return tbluoeimagedata;
	}
function getRowsmethoduoeimage(){
	var methoduoeimagedata = [];
	methoduoeimagerows = $("#methoduoeimage tbody tr");
methoduoeimagerows.each(function (index) {
    var methoduoeimagerow = $(this);
 	var methoduoeimageobj = {};
	var vMethod = methoduoeimagerow.find("[name=Method]").text();
			methoduoeimageobj['Method'] = vMethod;
			methoduoeimageobj['index'] = index;
var vParameters = methoduoeimagerow.find("[name=Parameters]").text();
			methoduoeimageobj['Parameters'] = vParameters;
			methoduoeimageobj['index'] = index;
var vReturnType = methoduoeimagerow.find("[name=ReturnType]").text();
			methoduoeimageobj['ReturnType'] = vReturnType;
			methoduoeimageobj['index'] = index;
var vDescription = methoduoeimagerow.find("[name=Description]").text();
			methoduoeimageobj['Description'] = vDescription;
			methoduoeimageobj['index'] = index;

	methoduoeimagedata.push(methoduoeimageobj);
});
return methoduoeimagedata;
	}
function getRowstbluoeinfobox(){
	var tbluoeinfoboxdata = [];
	tbluoeinfoboxrows = $("#tbluoeinfobox tbody tr");
tbluoeinfoboxrows.each(function (index) {
    var tbluoeinfoboxrow = $(this);
 	var tbluoeinfoboxobj = {};
	var vProperty = tbluoeinfoboxrow.find("[name=Property]").text();
			tbluoeinfoboxobj['Property'] = vProperty;
			tbluoeinfoboxobj['index'] = index;
var vType = tbluoeinfoboxrow.find("[name=Type]").text();
			tbluoeinfoboxobj['Type'] = vType;
			tbluoeinfoboxobj['index'] = index;
var vDefaultValue = tbluoeinfoboxrow.find("[name=DefaultValue]").text();
			tbluoeinfoboxobj['DefaultValue'] = vDefaultValue;
			tbluoeinfoboxobj['index'] = index;
var vDescription = tbluoeinfoboxrow.find("[name=Description]").text();
			tbluoeinfoboxobj['Description'] = vDescription;
			tbluoeinfoboxobj['index'] = index;

	tbluoeinfoboxdata.push(tbluoeinfoboxobj);
});
return tbluoeinfoboxdata;
	}
function getRowsmethoduoeinfobox(){
	var methoduoeinfoboxdata = [];
	methoduoeinfoboxrows = $("#methoduoeinfobox tbody tr");
methoduoeinfoboxrows.each(function (index) {
    var methoduoeinfoboxrow = $(this);
 	var methoduoeinfoboxobj = {};
	var vMethod = methoduoeinfoboxrow.find("[name=Method]").text();
			methoduoeinfoboxobj['Method'] = vMethod;
			methoduoeinfoboxobj['index'] = index;
var vParameters = methoduoeinfoboxrow.find("[name=Parameters]").text();
			methoduoeinfoboxobj['Parameters'] = vParameters;
			methoduoeinfoboxobj['index'] = index;
var vReturnType = methoduoeinfoboxrow.find("[name=ReturnType]").text();
			methoduoeinfoboxobj['ReturnType'] = vReturnType;
			methoduoeinfoboxobj['index'] = index;
var vDescription = methoduoeinfoboxrow.find("[name=Description]").text();
			methoduoeinfoboxobj['Description'] = vDescription;
			methoduoeinfoboxobj['index'] = index;

	methoduoeinfoboxdata.push(methoduoeinfoboxobj);
});
return methoduoeinfoboxdata;
	}
function getRowstbluoeinput(){
	var tbluoeinputdata = [];
	tbluoeinputrows = $("#tbluoeinput tbody tr");
tbluoeinputrows.each(function (index) {
    var tbluoeinputrow = $(this);
 	var tbluoeinputobj = {};
	var vProperty = tbluoeinputrow.find("[name=Property]").text();
			tbluoeinputobj['Property'] = vProperty;
			tbluoeinputobj['index'] = index;
var vType = tbluoeinputrow.find("[name=Type]").text();
			tbluoeinputobj['Type'] = vType;
			tbluoeinputobj['index'] = index;
var vDefaultValue = tbluoeinputrow.find("[name=DefaultValue]").text();
			tbluoeinputobj['DefaultValue'] = vDefaultValue;
			tbluoeinputobj['index'] = index;
var vDescription = tbluoeinputrow.find("[name=Description]").text();
			tbluoeinputobj['Description'] = vDescription;
			tbluoeinputobj['index'] = index;

	tbluoeinputdata.push(tbluoeinputobj);
});
return tbluoeinputdata;
	}
function getRowsmethoduoeinput(){
	var methoduoeinputdata = [];
	methoduoeinputrows = $("#methoduoeinput tbody tr");
methoduoeinputrows.each(function (index) {
    var methoduoeinputrow = $(this);
 	var methoduoeinputobj = {};
	var vMethod = methoduoeinputrow.find("[name=Method]").text();
			methoduoeinputobj['Method'] = vMethod;
			methoduoeinputobj['index'] = index;
var vParameters = methoduoeinputrow.find("[name=Parameters]").text();
			methoduoeinputobj['Parameters'] = vParameters;
			methoduoeinputobj['index'] = index;
var vReturnType = methoduoeinputrow.find("[name=ReturnType]").text();
			methoduoeinputobj['ReturnType'] = vReturnType;
			methoduoeinputobj['index'] = index;
var vDescription = methoduoeinputrow.find("[name=Description]").text();
			methoduoeinputobj['Description'] = vDescription;
			methoduoeinputobj['index'] = index;

	methoduoeinputdata.push(methoduoeinputobj);
});
return methoduoeinputdata;
	}
function getRowstbluoeinputtype(){
	var tbluoeinputtypedata = [];
	tbluoeinputtyperows = $("#tbluoeinputtype tbody tr");
tbluoeinputtyperows.each(function (index) {
    var tbluoeinputtyperow = $(this);
 	var tbluoeinputtypeobj = {};
	var vProperty = tbluoeinputtyperow.find("[name=Property]").text();
			tbluoeinputtypeobj['Property'] = vProperty;
			tbluoeinputtypeobj['index'] = index;
var vType = tbluoeinputtyperow.find("[name=Type]").text();
			tbluoeinputtypeobj['Type'] = vType;
			tbluoeinputtypeobj['index'] = index;
var vDefaultValue = tbluoeinputtyperow.find("[name=DefaultValue]").text();
			tbluoeinputtypeobj['DefaultValue'] = vDefaultValue;
			tbluoeinputtypeobj['index'] = index;
var vDescription = tbluoeinputtyperow.find("[name=Description]").text();
			tbluoeinputtypeobj['Description'] = vDescription;
			tbluoeinputtypeobj['index'] = index;

	tbluoeinputtypedata.push(tbluoeinputtypeobj);
});
return tbluoeinputtypedata;
	}
function getRowsmethoduoeinputtype(){
	var methoduoeinputtypedata = [];
	methoduoeinputtyperows = $("#methoduoeinputtype tbody tr");
methoduoeinputtyperows.each(function (index) {
    var methoduoeinputtyperow = $(this);
 	var methoduoeinputtypeobj = {};
	var vMethod = methoduoeinputtyperow.find("[name=Method]").text();
			methoduoeinputtypeobj['Method'] = vMethod;
			methoduoeinputtypeobj['index'] = index;
var vParameters = methoduoeinputtyperow.find("[name=Parameters]").text();
			methoduoeinputtypeobj['Parameters'] = vParameters;
			methoduoeinputtypeobj['index'] = index;
var vReturnType = methoduoeinputtyperow.find("[name=ReturnType]").text();
			methoduoeinputtypeobj['ReturnType'] = vReturnType;
			methoduoeinputtypeobj['index'] = index;
var vDescription = methoduoeinputtyperow.find("[name=Description]").text();
			methoduoeinputtypeobj['Description'] = vDescription;
			methoduoeinputtypeobj['index'] = index;

	methoduoeinputtypedata.push(methoduoeinputtypeobj);
});
return methoduoeinputtypedata;
	}
function getRowstbluoeintensity(){
	var tbluoeintensitydata = [];
	tbluoeintensityrows = $("#tbluoeintensity tbody tr");
tbluoeintensityrows.each(function (index) {
    var tbluoeintensityrow = $(this);
 	var tbluoeintensityobj = {};
	var vProperty = tbluoeintensityrow.find("[name=Property]").text();
			tbluoeintensityobj['Property'] = vProperty;
			tbluoeintensityobj['index'] = index;
var vType = tbluoeintensityrow.find("[name=Type]").text();
			tbluoeintensityobj['Type'] = vType;
			tbluoeintensityobj['index'] = index;
var vDefaultValue = tbluoeintensityrow.find("[name=DefaultValue]").text();
			tbluoeintensityobj['DefaultValue'] = vDefaultValue;
			tbluoeintensityobj['index'] = index;
var vDescription = tbluoeintensityrow.find("[name=Description]").text();
			tbluoeintensityobj['Description'] = vDescription;
			tbluoeintensityobj['index'] = index;

	tbluoeintensitydata.push(tbluoeintensityobj);
});
return tbluoeintensitydata;
	}
function getRowsmethoduoeintensity(){
	var methoduoeintensitydata = [];
	methoduoeintensityrows = $("#methoduoeintensity tbody tr");
methoduoeintensityrows.each(function (index) {
    var methoduoeintensityrow = $(this);
 	var methoduoeintensityobj = {};
	var vMethod = methoduoeintensityrow.find("[name=Method]").text();
			methoduoeintensityobj['Method'] = vMethod;
			methoduoeintensityobj['index'] = index;
var vParameters = methoduoeintensityrow.find("[name=Parameters]").text();
			methoduoeintensityobj['Parameters'] = vParameters;
			methoduoeintensityobj['index'] = index;
var vReturnType = methoduoeintensityrow.find("[name=ReturnType]").text();
			methoduoeintensityobj['ReturnType'] = vReturnType;
			methoduoeintensityobj['index'] = index;
var vDescription = methoduoeintensityrow.find("[name=Description]").text();
			methoduoeintensityobj['Description'] = vDescription;
			methoduoeintensityobj['index'] = index;

	methoduoeintensitydata.push(methoduoeintensityobj);
});
return methoduoeintensitydata;
	}
function getRowstbluoeintervaltype(){
	var tbluoeintervaltypedata = [];
	tbluoeintervaltyperows = $("#tbluoeintervaltype tbody tr");
tbluoeintervaltyperows.each(function (index) {
    var tbluoeintervaltyperow = $(this);
 	var tbluoeintervaltypeobj = {};
	var vProperty = tbluoeintervaltyperow.find("[name=Property]").text();
			tbluoeintervaltypeobj['Property'] = vProperty;
			tbluoeintervaltypeobj['index'] = index;
var vType = tbluoeintervaltyperow.find("[name=Type]").text();
			tbluoeintervaltypeobj['Type'] = vType;
			tbluoeintervaltypeobj['index'] = index;
var vDefaultValue = tbluoeintervaltyperow.find("[name=DefaultValue]").text();
			tbluoeintervaltypeobj['DefaultValue'] = vDefaultValue;
			tbluoeintervaltypeobj['index'] = index;
var vDescription = tbluoeintervaltyperow.find("[name=Description]").text();
			tbluoeintervaltypeobj['Description'] = vDescription;
			tbluoeintervaltypeobj['index'] = index;

	tbluoeintervaltypedata.push(tbluoeintervaltypeobj);
});
return tbluoeintervaltypedata;
	}
function getRowsmethoduoeintervaltype(){
	var methoduoeintervaltypedata = [];
	methoduoeintervaltyperows = $("#methoduoeintervaltype tbody tr");
methoduoeintervaltyperows.each(function (index) {
    var methoduoeintervaltyperow = $(this);
 	var methoduoeintervaltypeobj = {};
	var vMethod = methoduoeintervaltyperow.find("[name=Method]").text();
			methoduoeintervaltypeobj['Method'] = vMethod;
			methoduoeintervaltypeobj['index'] = index;
var vParameters = methoduoeintervaltyperow.find("[name=Parameters]").text();
			methoduoeintervaltypeobj['Parameters'] = vParameters;
			methoduoeintervaltypeobj['index'] = index;
var vReturnType = methoduoeintervaltyperow.find("[name=ReturnType]").text();
			methoduoeintervaltypeobj['ReturnType'] = vReturnType;
			methoduoeintervaltypeobj['index'] = index;
var vDescription = methoduoeintervaltyperow.find("[name=Description]").text();
			methoduoeintervaltypeobj['Description'] = vDescription;
			methoduoeintervaltypeobj['index'] = index;

	methoduoeintervaltypedata.push(methoduoeintervaltypeobj);
});
return methoduoeintervaltypedata;
	}
function getRowstbluoejs(){
	var tbluoejsdata = [];
	tbluoejsrows = $("#tbluoejs tbody tr");
tbluoejsrows.each(function (index) {
    var tbluoejsrow = $(this);
 	var tbluoejsobj = {};
	var vProperty = tbluoejsrow.find("[name=Property]").text();
			tbluoejsobj['Property'] = vProperty;
			tbluoejsobj['index'] = index;
var vType = tbluoejsrow.find("[name=Type]").text();
			tbluoejsobj['Type'] = vType;
			tbluoejsobj['index'] = index;
var vDefaultValue = tbluoejsrow.find("[name=DefaultValue]").text();
			tbluoejsobj['DefaultValue'] = vDefaultValue;
			tbluoejsobj['index'] = index;
var vDescription = tbluoejsrow.find("[name=Description]").text();
			tbluoejsobj['Description'] = vDescription;
			tbluoejsobj['index'] = index;

	tbluoejsdata.push(tbluoejsobj);
});
return tbluoejsdata;
	}
function getRowsmethoduoejs(){
	var methoduoejsdata = [];
	methoduoejsrows = $("#methoduoejs tbody tr");
methoduoejsrows.each(function (index) {
    var methoduoejsrow = $(this);
 	var methoduoejsobj = {};
	var vMethod = methoduoejsrow.find("[name=Method]").text();
			methoduoejsobj['Method'] = vMethod;
			methoduoejsobj['index'] = index;
var vParameters = methoduoejsrow.find("[name=Parameters]").text();
			methoduoejsobj['Parameters'] = vParameters;
			methoduoejsobj['index'] = index;
var vReturnType = methoduoejsrow.find("[name=ReturnType]").text();
			methoduoejsobj['ReturnType'] = vReturnType;
			methoduoejsobj['index'] = index;
var vDescription = methoduoejsrow.find("[name=Description]").text();
			methoduoejsobj['Description'] = vDescription;
			methoduoejsobj['index'] = index;

	methoduoejsdata.push(methoduoejsobj);
});
return methoduoejsdata;
	}
function getRowstbluoelabel(){
	var tbluoelabeldata = [];
	tbluoelabelrows = $("#tbluoelabel tbody tr");
tbluoelabelrows.each(function (index) {
    var tbluoelabelrow = $(this);
 	var tbluoelabelobj = {};
	var vProperty = tbluoelabelrow.find("[name=Property]").text();
			tbluoelabelobj['Property'] = vProperty;
			tbluoelabelobj['index'] = index;
var vType = tbluoelabelrow.find("[name=Type]").text();
			tbluoelabelobj['Type'] = vType;
			tbluoelabelobj['index'] = index;
var vDefaultValue = tbluoelabelrow.find("[name=DefaultValue]").text();
			tbluoelabelobj['DefaultValue'] = vDefaultValue;
			tbluoelabelobj['index'] = index;
var vDescription = tbluoelabelrow.find("[name=Description]").text();
			tbluoelabelobj['Description'] = vDescription;
			tbluoelabelobj['index'] = index;

	tbluoelabeldata.push(tbluoelabelobj);
});
return tbluoelabeldata;
	}
function getRowsmethoduoelabel(){
	var methoduoelabeldata = [];
	methoduoelabelrows = $("#methoduoelabel tbody tr");
methoduoelabelrows.each(function (index) {
    var methoduoelabelrow = $(this);
 	var methoduoelabelobj = {};
	var vMethod = methoduoelabelrow.find("[name=Method]").text();
			methoduoelabelobj['Method'] = vMethod;
			methoduoelabelobj['index'] = index;
var vParameters = methoduoelabelrow.find("[name=Parameters]").text();
			methoduoelabelobj['Parameters'] = vParameters;
			methoduoelabelobj['index'] = index;
var vReturnType = methoduoelabelrow.find("[name=ReturnType]").text();
			methoduoelabelobj['ReturnType'] = vReturnType;
			methoduoelabelobj['index'] = index;
var vDescription = methoduoelabelrow.find("[name=Description]").text();
			methoduoelabelobj['Description'] = vDescription;
			methoduoelabelobj['index'] = index;

	methoduoelabeldata.push(methoduoelabelobj);
});
return methoduoelabeldata;
	}
function getRowstbluoelabelsize(){
	var tbluoelabelsizedata = [];
	tbluoelabelsizerows = $("#tbluoelabelsize tbody tr");
tbluoelabelsizerows.each(function (index) {
    var tbluoelabelsizerow = $(this);
 	var tbluoelabelsizeobj = {};
	var vProperty = tbluoelabelsizerow.find("[name=Property]").text();
			tbluoelabelsizeobj['Property'] = vProperty;
			tbluoelabelsizeobj['index'] = index;
var vType = tbluoelabelsizerow.find("[name=Type]").text();
			tbluoelabelsizeobj['Type'] = vType;
			tbluoelabelsizeobj['index'] = index;
var vDefaultValue = tbluoelabelsizerow.find("[name=DefaultValue]").text();
			tbluoelabelsizeobj['DefaultValue'] = vDefaultValue;
			tbluoelabelsizeobj['index'] = index;
var vDescription = tbluoelabelsizerow.find("[name=Description]").text();
			tbluoelabelsizeobj['Description'] = vDescription;
			tbluoelabelsizeobj['index'] = index;

	tbluoelabelsizedata.push(tbluoelabelsizeobj);
});
return tbluoelabelsizedata;
	}
function getRowsmethoduoelabelsize(){
	var methoduoelabelsizedata = [];
	methoduoelabelsizerows = $("#methoduoelabelsize tbody tr");
methoduoelabelsizerows.each(function (index) {
    var methoduoelabelsizerow = $(this);
 	var methoduoelabelsizeobj = {};
	var vMethod = methoduoelabelsizerow.find("[name=Method]").text();
			methoduoelabelsizeobj['Method'] = vMethod;
			methoduoelabelsizeobj['index'] = index;
var vParameters = methoduoelabelsizerow.find("[name=Parameters]").text();
			methoduoelabelsizeobj['Parameters'] = vParameters;
			methoduoelabelsizeobj['index'] = index;
var vReturnType = methoduoelabelsizerow.find("[name=ReturnType]").text();
			methoduoelabelsizeobj['ReturnType'] = vReturnType;
			methoduoelabelsizeobj['index'] = index;
var vDescription = methoduoelabelsizerow.find("[name=Description]").text();
			methoduoelabelsizeobj['Description'] = vDescription;
			methoduoelabelsizeobj['index'] = index;

	methoduoelabelsizedata.push(methoduoelabelsizeobj);
});
return methoduoelabelsizedata;
	}
function getRowstbluoelatlng(){
	var tbluoelatlngdata = [];
	tbluoelatlngrows = $("#tbluoelatlng tbody tr");
tbluoelatlngrows.each(function (index) {
    var tbluoelatlngrow = $(this);
 	var tbluoelatlngobj = {};
	var vProperty = tbluoelatlngrow.find("[name=Property]").text();
			tbluoelatlngobj['Property'] = vProperty;
			tbluoelatlngobj['index'] = index;
var vType = tbluoelatlngrow.find("[name=Type]").text();
			tbluoelatlngobj['Type'] = vType;
			tbluoelatlngobj['index'] = index;
var vDefaultValue = tbluoelatlngrow.find("[name=DefaultValue]").text();
			tbluoelatlngobj['DefaultValue'] = vDefaultValue;
			tbluoelatlngobj['index'] = index;
var vDescription = tbluoelatlngrow.find("[name=Description]").text();
			tbluoelatlngobj['Description'] = vDescription;
			tbluoelatlngobj['index'] = index;

	tbluoelatlngdata.push(tbluoelatlngobj);
});
return tbluoelatlngdata;
	}
function getRowsmethoduoelatlng(){
	var methoduoelatlngdata = [];
	methoduoelatlngrows = $("#methoduoelatlng tbody tr");
methoduoelatlngrows.each(function (index) {
    var methoduoelatlngrow = $(this);
 	var methoduoelatlngobj = {};
	var vMethod = methoduoelatlngrow.find("[name=Method]").text();
			methoduoelatlngobj['Method'] = vMethod;
			methoduoelatlngobj['index'] = index;
var vParameters = methoduoelatlngrow.find("[name=Parameters]").text();
			methoduoelatlngobj['Parameters'] = vParameters;
			methoduoelatlngobj['index'] = index;
var vReturnType = methoduoelatlngrow.find("[name=ReturnType]").text();
			methoduoelatlngobj['ReturnType'] = vReturnType;
			methoduoelatlngobj['index'] = index;
var vDescription = methoduoelatlngrow.find("[name=Description]").text();
			methoduoelatlngobj['Description'] = vDescription;
			methoduoelatlngobj['index'] = index;

	methoduoelatlngdata.push(methoduoelatlngobj);
});
return methoduoelatlngdata;
	}
function getRowstbluoeleaflet(){
	var tbluoeleafletdata = [];
	tbluoeleafletrows = $("#tbluoeleaflet tbody tr");
tbluoeleafletrows.each(function (index) {
    var tbluoeleafletrow = $(this);
 	var tbluoeleafletobj = {};
	var vProperty = tbluoeleafletrow.find("[name=Property]").text();
			tbluoeleafletobj['Property'] = vProperty;
			tbluoeleafletobj['index'] = index;
var vType = tbluoeleafletrow.find("[name=Type]").text();
			tbluoeleafletobj['Type'] = vType;
			tbluoeleafletobj['index'] = index;
var vDefaultValue = tbluoeleafletrow.find("[name=DefaultValue]").text();
			tbluoeleafletobj['DefaultValue'] = vDefaultValue;
			tbluoeleafletobj['index'] = index;
var vDescription = tbluoeleafletrow.find("[name=Description]").text();
			tbluoeleafletobj['Description'] = vDescription;
			tbluoeleafletobj['index'] = index;

	tbluoeleafletdata.push(tbluoeleafletobj);
});
return tbluoeleafletdata;
	}
function getRowsmethoduoeleaflet(){
	var methoduoeleafletdata = [];
	methoduoeleafletrows = $("#methoduoeleaflet tbody tr");
methoduoeleafletrows.each(function (index) {
    var methoduoeleafletrow = $(this);
 	var methoduoeleafletobj = {};
	var vMethod = methoduoeleafletrow.find("[name=Method]").text();
			methoduoeleafletobj['Method'] = vMethod;
			methoduoeleafletobj['index'] = index;
var vParameters = methoduoeleafletrow.find("[name=Parameters]").text();
			methoduoeleafletobj['Parameters'] = vParameters;
			methoduoeleafletobj['index'] = index;
var vReturnType = methoduoeleafletrow.find("[name=ReturnType]").text();
			methoduoeleafletobj['ReturnType'] = vReturnType;
			methoduoeleafletobj['index'] = index;
var vDescription = methoduoeleafletrow.find("[name=Description]").text();
			methoduoeleafletobj['Description'] = vDescription;
			methoduoeleafletobj['index'] = index;

	methoduoeleafletdata.push(methoduoeleafletobj);
});
return methoduoeleafletdata;
	}
function getRowstbluoelinecapof(){
	var tbluoelinecapofdata = [];
	tbluoelinecapofrows = $("#tbluoelinecapof tbody tr");
tbluoelinecapofrows.each(function (index) {
    var tbluoelinecapofrow = $(this);
 	var tbluoelinecapofobj = {};
	var vProperty = tbluoelinecapofrow.find("[name=Property]").text();
			tbluoelinecapofobj['Property'] = vProperty;
			tbluoelinecapofobj['index'] = index;
var vType = tbluoelinecapofrow.find("[name=Type]").text();
			tbluoelinecapofobj['Type'] = vType;
			tbluoelinecapofobj['index'] = index;
var vDefaultValue = tbluoelinecapofrow.find("[name=DefaultValue]").text();
			tbluoelinecapofobj['DefaultValue'] = vDefaultValue;
			tbluoelinecapofobj['index'] = index;
var vDescription = tbluoelinecapofrow.find("[name=Description]").text();
			tbluoelinecapofobj['Description'] = vDescription;
			tbluoelinecapofobj['index'] = index;

	tbluoelinecapofdata.push(tbluoelinecapofobj);
});
return tbluoelinecapofdata;
	}
function getRowsmethoduoelinecapof(){
	var methoduoelinecapofdata = [];
	methoduoelinecapofrows = $("#methoduoelinecapof tbody tr");
methoduoelinecapofrows.each(function (index) {
    var methoduoelinecapofrow = $(this);
 	var methoduoelinecapofobj = {};
	var vMethod = methoduoelinecapofrow.find("[name=Method]").text();
			methoduoelinecapofobj['Method'] = vMethod;
			methoduoelinecapofobj['index'] = index;
var vParameters = methoduoelinecapofrow.find("[name=Parameters]").text();
			methoduoelinecapofobj['Parameters'] = vParameters;
			methoduoelinecapofobj['index'] = index;
var vReturnType = methoduoelinecapofrow.find("[name=ReturnType]").text();
			methoduoelinecapofobj['ReturnType'] = vReturnType;
			methoduoelinecapofobj['index'] = index;
var vDescription = methoduoelinecapofrow.find("[name=Description]").text();
			methoduoelinecapofobj['Description'] = vDescription;
			methoduoelinecapofobj['index'] = index;

	methoduoelinecapofdata.push(methoduoelinecapofobj);
});
return methoduoelinecapofdata;
	}
function getRowstbluoelist(){
	var tbluoelistdata = [];
	tbluoelistrows = $("#tbluoelist tbody tr");
tbluoelistrows.each(function (index) {
    var tbluoelistrow = $(this);
 	var tbluoelistobj = {};
	var vProperty = tbluoelistrow.find("[name=Property]").text();
			tbluoelistobj['Property'] = vProperty;
			tbluoelistobj['index'] = index;
var vType = tbluoelistrow.find("[name=Type]").text();
			tbluoelistobj['Type'] = vType;
			tbluoelistobj['index'] = index;
var vDefaultValue = tbluoelistrow.find("[name=DefaultValue]").text();
			tbluoelistobj['DefaultValue'] = vDefaultValue;
			tbluoelistobj['index'] = index;
var vDescription = tbluoelistrow.find("[name=Description]").text();
			tbluoelistobj['Description'] = vDescription;
			tbluoelistobj['index'] = index;

	tbluoelistdata.push(tbluoelistobj);
});
return tbluoelistdata;
	}
function getRowsmethoduoelist(){
	var methoduoelistdata = [];
	methoduoelistrows = $("#methoduoelist tbody tr");
methoduoelistrows.each(function (index) {
    var methoduoelistrow = $(this);
 	var methoduoelistobj = {};
	var vMethod = methoduoelistrow.find("[name=Method]").text();
			methoduoelistobj['Method'] = vMethod;
			methoduoelistobj['index'] = index;
var vParameters = methoduoelistrow.find("[name=Parameters]").text();
			methoduoelistobj['Parameters'] = vParameters;
			methoduoelistobj['index'] = index;
var vReturnType = methoduoelistrow.find("[name=ReturnType]").text();
			methoduoelistobj['ReturnType'] = vReturnType;
			methoduoelistobj['index'] = index;
var vDescription = methoduoelistrow.find("[name=Description]").text();
			methoduoelistobj['Description'] = vDescription;
			methoduoelistobj['index'] = index;

	methoduoelistdata.push(methoduoelistobj);
});
return methoduoelistdata;
	}
function getRowstbluoelistview(){
	var tbluoelistviewdata = [];
	tbluoelistviewrows = $("#tbluoelistview tbody tr");
tbluoelistviewrows.each(function (index) {
    var tbluoelistviewrow = $(this);
 	var tbluoelistviewobj = {};
	var vProperty = tbluoelistviewrow.find("[name=Property]").text();
			tbluoelistviewobj['Property'] = vProperty;
			tbluoelistviewobj['index'] = index;
var vType = tbluoelistviewrow.find("[name=Type]").text();
			tbluoelistviewobj['Type'] = vType;
			tbluoelistviewobj['index'] = index;
var vDefaultValue = tbluoelistviewrow.find("[name=DefaultValue]").text();
			tbluoelistviewobj['DefaultValue'] = vDefaultValue;
			tbluoelistviewobj['index'] = index;
var vDescription = tbluoelistviewrow.find("[name=Description]").text();
			tbluoelistviewobj['Description'] = vDescription;
			tbluoelistviewobj['index'] = index;

	tbluoelistviewdata.push(tbluoelistviewobj);
});
return tbluoelistviewdata;
	}
function getRowsmethoduoelistview(){
	var methoduoelistviewdata = [];
	methoduoelistviewrows = $("#methoduoelistview tbody tr");
methoduoelistviewrows.each(function (index) {
    var methoduoelistviewrow = $(this);
 	var methoduoelistviewobj = {};
	var vMethod = methoduoelistviewrow.find("[name=Method]").text();
			methoduoelistviewobj['Method'] = vMethod;
			methoduoelistviewobj['index'] = index;
var vParameters = methoduoelistviewrow.find("[name=Parameters]").text();
			methoduoelistviewobj['Parameters'] = vParameters;
			methoduoelistviewobj['index'] = index;
var vReturnType = methoduoelistviewrow.find("[name=ReturnType]").text();
			methoduoelistviewobj['ReturnType'] = vReturnType;
			methoduoelistviewobj['index'] = index;
var vDescription = methoduoelistviewrow.find("[name=Description]").text();
			methoduoelistviewobj['Description'] = vDescription;
			methoduoelistviewobj['index'] = index;

	methoduoelistviewdata.push(methoduoelistviewobj);
});
return methoduoelistviewdata;
	}
function getRowstbluoelogoposition(){
	var tbluoelogopositiondata = [];
	tbluoelogopositionrows = $("#tbluoelogoposition tbody tr");
tbluoelogopositionrows.each(function (index) {
    var tbluoelogopositionrow = $(this);
 	var tbluoelogopositionobj = {};
	var vProperty = tbluoelogopositionrow.find("[name=Property]").text();
			tbluoelogopositionobj['Property'] = vProperty;
			tbluoelogopositionobj['index'] = index;
var vType = tbluoelogopositionrow.find("[name=Type]").text();
			tbluoelogopositionobj['Type'] = vType;
			tbluoelogopositionobj['index'] = index;
var vDefaultValue = tbluoelogopositionrow.find("[name=DefaultValue]").text();
			tbluoelogopositionobj['DefaultValue'] = vDefaultValue;
			tbluoelogopositionobj['index'] = index;
var vDescription = tbluoelogopositionrow.find("[name=Description]").text();
			tbluoelogopositionobj['Description'] = vDescription;
			tbluoelogopositionobj['index'] = index;

	tbluoelogopositiondata.push(tbluoelogopositionobj);
});
return tbluoelogopositiondata;
	}
function getRowsmethoduoelogoposition(){
	var methoduoelogopositiondata = [];
	methoduoelogopositionrows = $("#methoduoelogoposition tbody tr");
methoduoelogopositionrows.each(function (index) {
    var methoduoelogopositionrow = $(this);
 	var methoduoelogopositionobj = {};
	var vMethod = methoduoelogopositionrow.find("[name=Method]").text();
			methoduoelogopositionobj['Method'] = vMethod;
			methoduoelogopositionobj['index'] = index;
var vParameters = methoduoelogopositionrow.find("[name=Parameters]").text();
			methoduoelogopositionobj['Parameters'] = vParameters;
			methoduoelogopositionobj['index'] = index;
var vReturnType = methoduoelogopositionrow.find("[name=ReturnType]").text();
			methoduoelogopositionobj['ReturnType'] = vReturnType;
			methoduoelogopositionobj['index'] = index;
var vDescription = methoduoelogopositionrow.find("[name=Description]").text();
			methoduoelogopositionobj['Description'] = vDescription;
			methoduoelogopositionobj['index'] = index;

	methoduoelogopositiondata.push(methoduoelogopositionobj);
});
return methoduoelogopositiondata;
	}
function getRowstbluoemakiicons(){
	var tbluoemakiiconsdata = [];
	tbluoemakiiconsrows = $("#tbluoemakiicons tbody tr");
tbluoemakiiconsrows.each(function (index) {
    var tbluoemakiiconsrow = $(this);
 	var tbluoemakiiconsobj = {};
	var vProperty = tbluoemakiiconsrow.find("[name=Property]").text();
			tbluoemakiiconsobj['Property'] = vProperty;
			tbluoemakiiconsobj['index'] = index;
var vType = tbluoemakiiconsrow.find("[name=Type]").text();
			tbluoemakiiconsobj['Type'] = vType;
			tbluoemakiiconsobj['index'] = index;
var vDefaultValue = tbluoemakiiconsrow.find("[name=DefaultValue]").text();
			tbluoemakiiconsobj['DefaultValue'] = vDefaultValue;
			tbluoemakiiconsobj['index'] = index;
var vDescription = tbluoemakiiconsrow.find("[name=Description]").text();
			tbluoemakiiconsobj['Description'] = vDescription;
			tbluoemakiiconsobj['index'] = index;

	tbluoemakiiconsdata.push(tbluoemakiiconsobj);
});
return tbluoemakiiconsdata;
	}
function getRowsmethoduoemakiicons(){
	var methoduoemakiiconsdata = [];
	methoduoemakiiconsrows = $("#methoduoemakiicons tbody tr");
methoduoemakiiconsrows.each(function (index) {
    var methoduoemakiiconsrow = $(this);
 	var methoduoemakiiconsobj = {};
	var vMethod = methoduoemakiiconsrow.find("[name=Method]").text();
			methoduoemakiiconsobj['Method'] = vMethod;
			methoduoemakiiconsobj['index'] = index;
var vParameters = methoduoemakiiconsrow.find("[name=Parameters]").text();
			methoduoemakiiconsobj['Parameters'] = vParameters;
			methoduoemakiiconsobj['index'] = index;
var vReturnType = methoduoemakiiconsrow.find("[name=ReturnType]").text();
			methoduoemakiiconsobj['ReturnType'] = vReturnType;
			methoduoemakiiconsobj['index'] = index;
var vDescription = methoduoemakiiconsrow.find("[name=Description]").text();
			methoduoemakiiconsobj['Description'] = vDescription;
			methoduoemakiiconsobj['index'] = index;

	methoduoemakiiconsdata.push(methoduoemakiiconsobj);
});
return methoduoemakiiconsdata;
	}
function getRowstbluoemaptypeobj(){
	var tbluoemaptypeobjdata = [];
	tbluoemaptypeobjrows = $("#tbluoemaptypeobj tbody tr");
tbluoemaptypeobjrows.each(function (index) {
    var tbluoemaptypeobjrow = $(this);
 	var tbluoemaptypeobjobj = {};
	var vProperty = tbluoemaptypeobjrow.find("[name=Property]").text();
			tbluoemaptypeobjobj['Property'] = vProperty;
			tbluoemaptypeobjobj['index'] = index;
var vType = tbluoemaptypeobjrow.find("[name=Type]").text();
			tbluoemaptypeobjobj['Type'] = vType;
			tbluoemaptypeobjobj['index'] = index;
var vDefaultValue = tbluoemaptypeobjrow.find("[name=DefaultValue]").text();
			tbluoemaptypeobjobj['DefaultValue'] = vDefaultValue;
			tbluoemaptypeobjobj['index'] = index;
var vDescription = tbluoemaptypeobjrow.find("[name=Description]").text();
			tbluoemaptypeobjobj['Description'] = vDescription;
			tbluoemaptypeobjobj['index'] = index;

	tbluoemaptypeobjdata.push(tbluoemaptypeobjobj);
});
return tbluoemaptypeobjdata;
	}
function getRowsmethoduoemaptypeobj(){
	var methoduoemaptypeobjdata = [];
	methoduoemaptypeobjrows = $("#methoduoemaptypeobj tbody tr");
methoduoemaptypeobjrows.each(function (index) {
    var methoduoemaptypeobjrow = $(this);
 	var methoduoemaptypeobjobj = {};
	var vMethod = methoduoemaptypeobjrow.find("[name=Method]").text();
			methoduoemaptypeobjobj['Method'] = vMethod;
			methoduoemaptypeobjobj['index'] = index;
var vParameters = methoduoemaptypeobjrow.find("[name=Parameters]").text();
			methoduoemaptypeobjobj['Parameters'] = vParameters;
			methoduoemaptypeobjobj['index'] = index;
var vReturnType = methoduoemaptypeobjrow.find("[name=ReturnType]").text();
			methoduoemaptypeobjobj['ReturnType'] = vReturnType;
			methoduoemaptypeobjobj['index'] = index;
var vDescription = methoduoemaptypeobjrow.find("[name=Description]").text();
			methoduoemaptypeobjobj['Description'] = vDescription;
			methoduoemaptypeobjobj['index'] = index;

	methoduoemaptypeobjdata.push(methoduoemaptypeobjobj);
});
return methoduoemaptypeobjdata;
	}
function getRowstbluoembcircle(){
	var tbluoembcircledata = [];
	tbluoembcirclerows = $("#tbluoembcircle tbody tr");
tbluoembcirclerows.each(function (index) {
    var tbluoembcirclerow = $(this);
 	var tbluoembcircleobj = {};
	var vProperty = tbluoembcirclerow.find("[name=Property]").text();
			tbluoembcircleobj['Property'] = vProperty;
			tbluoembcircleobj['index'] = index;
var vType = tbluoembcirclerow.find("[name=Type]").text();
			tbluoembcircleobj['Type'] = vType;
			tbluoembcircleobj['index'] = index;
var vDefaultValue = tbluoembcirclerow.find("[name=DefaultValue]").text();
			tbluoembcircleobj['DefaultValue'] = vDefaultValue;
			tbluoembcircleobj['index'] = index;
var vDescription = tbluoembcirclerow.find("[name=Description]").text();
			tbluoembcircleobj['Description'] = vDescription;
			tbluoembcircleobj['index'] = index;

	tbluoembcircledata.push(tbluoembcircleobj);
});
return tbluoembcircledata;
	}
function getRowsmethoduoembcircle(){
	var methoduoembcircledata = [];
	methoduoembcirclerows = $("#methoduoembcircle tbody tr");
methoduoembcirclerows.each(function (index) {
    var methoduoembcirclerow = $(this);
 	var methoduoembcircleobj = {};
	var vMethod = methoduoembcirclerow.find("[name=Method]").text();
			methoduoembcircleobj['Method'] = vMethod;
			methoduoembcircleobj['index'] = index;
var vParameters = methoduoembcirclerow.find("[name=Parameters]").text();
			methoduoembcircleobj['Parameters'] = vParameters;
			methoduoembcircleobj['index'] = index;
var vReturnType = methoduoembcirclerow.find("[name=ReturnType]").text();
			methoduoembcircleobj['ReturnType'] = vReturnType;
			methoduoembcircleobj['index'] = index;
var vDescription = methoduoembcirclerow.find("[name=Description]").text();
			methoduoembcircleobj['Description'] = vDescription;
			methoduoembcircleobj['index'] = index;

	methoduoembcircledata.push(methoduoembcircleobj);
});
return methoduoembcircledata;
	}
function getRowstbluoembiconsize(){
	var tbluoembiconsizedata = [];
	tbluoembiconsizerows = $("#tbluoembiconsize tbody tr");
tbluoembiconsizerows.each(function (index) {
    var tbluoembiconsizerow = $(this);
 	var tbluoembiconsizeobj = {};
	var vProperty = tbluoembiconsizerow.find("[name=Property]").text();
			tbluoembiconsizeobj['Property'] = vProperty;
			tbluoembiconsizeobj['index'] = index;
var vType = tbluoembiconsizerow.find("[name=Type]").text();
			tbluoembiconsizeobj['Type'] = vType;
			tbluoembiconsizeobj['index'] = index;
var vDefaultValue = tbluoembiconsizerow.find("[name=DefaultValue]").text();
			tbluoembiconsizeobj['DefaultValue'] = vDefaultValue;
			tbluoembiconsizeobj['index'] = index;
var vDescription = tbluoembiconsizerow.find("[name=Description]").text();
			tbluoembiconsizeobj['Description'] = vDescription;
			tbluoembiconsizeobj['index'] = index;

	tbluoembiconsizedata.push(tbluoembiconsizeobj);
});
return tbluoembiconsizedata;
	}
function getRowsmethoduoembiconsize(){
	var methoduoembiconsizedata = [];
	methoduoembiconsizerows = $("#methoduoembiconsize tbody tr");
methoduoembiconsizerows.each(function (index) {
    var methoduoembiconsizerow = $(this);
 	var methoduoembiconsizeobj = {};
	var vMethod = methoduoembiconsizerow.find("[name=Method]").text();
			methoduoembiconsizeobj['Method'] = vMethod;
			methoduoembiconsizeobj['index'] = index;
var vParameters = methoduoembiconsizerow.find("[name=Parameters]").text();
			methoduoembiconsizeobj['Parameters'] = vParameters;
			methoduoembiconsizeobj['index'] = index;
var vReturnType = methoduoembiconsizerow.find("[name=ReturnType]").text();
			methoduoembiconsizeobj['ReturnType'] = vReturnType;
			methoduoembiconsizeobj['index'] = index;
var vDescription = methoduoembiconsizerow.find("[name=Description]").text();
			methoduoembiconsizeobj['Description'] = vDescription;
			methoduoembiconsizeobj['index'] = index;

	methoduoembiconsizedata.push(methoduoembiconsizeobj);
});
return methoduoembiconsizedata;
	}
function getRowstbluoembmarkertype(){
	var tbluoembmarkertypedata = [];
	tbluoembmarkertyperows = $("#tbluoembmarkertype tbody tr");
tbluoembmarkertyperows.each(function (index) {
    var tbluoembmarkertyperow = $(this);
 	var tbluoembmarkertypeobj = {};
	var vProperty = tbluoembmarkertyperow.find("[name=Property]").text();
			tbluoembmarkertypeobj['Property'] = vProperty;
			tbluoembmarkertypeobj['index'] = index;
var vType = tbluoembmarkertyperow.find("[name=Type]").text();
			tbluoembmarkertypeobj['Type'] = vType;
			tbluoembmarkertypeobj['index'] = index;
var vDefaultValue = tbluoembmarkertyperow.find("[name=DefaultValue]").text();
			tbluoembmarkertypeobj['DefaultValue'] = vDefaultValue;
			tbluoembmarkertypeobj['index'] = index;
var vDescription = tbluoembmarkertyperow.find("[name=Description]").text();
			tbluoembmarkertypeobj['Description'] = vDescription;
			tbluoembmarkertypeobj['index'] = index;

	tbluoembmarkertypedata.push(tbluoembmarkertypeobj);
});
return tbluoembmarkertypedata;
	}
function getRowsmethoduoembmarkertype(){
	var methoduoembmarkertypedata = [];
	methoduoembmarkertyperows = $("#methoduoembmarkertype tbody tr");
methoduoembmarkertyperows.each(function (index) {
    var methoduoembmarkertyperow = $(this);
 	var methoduoembmarkertypeobj = {};
	var vMethod = methoduoembmarkertyperow.find("[name=Method]").text();
			methoduoembmarkertypeobj['Method'] = vMethod;
			methoduoembmarkertypeobj['index'] = index;
var vParameters = methoduoembmarkertyperow.find("[name=Parameters]").text();
			methoduoembmarkertypeobj['Parameters'] = vParameters;
			methoduoembmarkertypeobj['index'] = index;
var vReturnType = methoduoembmarkertyperow.find("[name=ReturnType]").text();
			methoduoembmarkertypeobj['ReturnType'] = vReturnType;
			methoduoembmarkertypeobj['index'] = index;
var vDescription = methoduoembmarkertyperow.find("[name=Description]").text();
			methoduoembmarkertypeobj['Description'] = vDescription;
			methoduoembmarkertypeobj['index'] = index;

	methoduoembmarkertypedata.push(methoduoembmarkertypeobj);
});
return methoduoembmarkertypedata;
	}
function getRowstbluoembpolyline(){
	var tbluoembpolylinedata = [];
	tbluoembpolylinerows = $("#tbluoembpolyline tbody tr");
tbluoembpolylinerows.each(function (index) {
    var tbluoembpolylinerow = $(this);
 	var tbluoembpolylineobj = {};
	var vProperty = tbluoembpolylinerow.find("[name=Property]").text();
			tbluoembpolylineobj['Property'] = vProperty;
			tbluoembpolylineobj['index'] = index;
var vType = tbluoembpolylinerow.find("[name=Type]").text();
			tbluoembpolylineobj['Type'] = vType;
			tbluoembpolylineobj['index'] = index;
var vDefaultValue = tbluoembpolylinerow.find("[name=DefaultValue]").text();
			tbluoembpolylineobj['DefaultValue'] = vDefaultValue;
			tbluoembpolylineobj['index'] = index;
var vDescription = tbluoembpolylinerow.find("[name=Description]").text();
			tbluoembpolylineobj['Description'] = vDescription;
			tbluoembpolylineobj['index'] = index;

	tbluoembpolylinedata.push(tbluoembpolylineobj);
});
return tbluoembpolylinedata;
	}
function getRowsmethoduoembpolyline(){
	var methoduoembpolylinedata = [];
	methoduoembpolylinerows = $("#methoduoembpolyline tbody tr");
methoduoembpolylinerows.each(function (index) {
    var methoduoembpolylinerow = $(this);
 	var methoduoembpolylineobj = {};
	var vMethod = methoduoembpolylinerow.find("[name=Method]").text();
			methoduoembpolylineobj['Method'] = vMethod;
			methoduoembpolylineobj['index'] = index;
var vParameters = methoduoembpolylinerow.find("[name=Parameters]").text();
			methoduoembpolylineobj['Parameters'] = vParameters;
			methoduoembpolylineobj['index'] = index;
var vReturnType = methoduoembpolylinerow.find("[name=ReturnType]").text();
			methoduoembpolylineobj['ReturnType'] = vReturnType;
			methoduoembpolylineobj['index'] = index;
var vDescription = methoduoembpolylinerow.find("[name=Description]").text();
			methoduoembpolylineobj['Description'] = vDescription;
			methoduoembpolylineobj['index'] = index;

	methoduoembpolylinedata.push(methoduoembpolylineobj);
});
return methoduoembpolylinedata;
	}
function getRowstbluoemenupos(){
	var tbluoemenuposdata = [];
	tbluoemenuposrows = $("#tbluoemenupos tbody tr");
tbluoemenuposrows.each(function (index) {
    var tbluoemenuposrow = $(this);
 	var tbluoemenuposobj = {};
	var vProperty = tbluoemenuposrow.find("[name=Property]").text();
			tbluoemenuposobj['Property'] = vProperty;
			tbluoemenuposobj['index'] = index;
var vType = tbluoemenuposrow.find("[name=Type]").text();
			tbluoemenuposobj['Type'] = vType;
			tbluoemenuposobj['index'] = index;
var vDefaultValue = tbluoemenuposrow.find("[name=DefaultValue]").text();
			tbluoemenuposobj['DefaultValue'] = vDefaultValue;
			tbluoemenuposobj['index'] = index;
var vDescription = tbluoemenuposrow.find("[name=Description]").text();
			tbluoemenuposobj['Description'] = vDescription;
			tbluoemenuposobj['index'] = index;

	tbluoemenuposdata.push(tbluoemenuposobj);
});
return tbluoemenuposdata;
	}
function getRowsmethoduoemenupos(){
	var methoduoemenuposdata = [];
	methoduoemenuposrows = $("#methoduoemenupos tbody tr");
methoduoemenuposrows.each(function (index) {
    var methoduoemenuposrow = $(this);
 	var methoduoemenuposobj = {};
	var vMethod = methoduoemenuposrow.find("[name=Method]").text();
			methoduoemenuposobj['Method'] = vMethod;
			methoduoemenuposobj['index'] = index;
var vParameters = methoduoemenuposrow.find("[name=Parameters]").text();
			methoduoemenuposobj['Parameters'] = vParameters;
			methoduoemenuposobj['index'] = index;
var vReturnType = methoduoemenuposrow.find("[name=ReturnType]").text();
			methoduoemenuposobj['ReturnType'] = vReturnType;
			methoduoemenuposobj['index'] = index;
var vDescription = methoduoemenuposrow.find("[name=Description]").text();
			methoduoemenuposobj['Description'] = vDescription;
			methoduoemenuposobj['index'] = index;

	methoduoemenuposdata.push(methoduoemenuposobj);
});
return methoduoemenuposdata;
	}
function getRowstbluoemermaid(){
	var tbluoemermaiddata = [];
	tbluoemermaidrows = $("#tbluoemermaid tbody tr");
tbluoemermaidrows.each(function (index) {
    var tbluoemermaidrow = $(this);
 	var tbluoemermaidobj = {};
	var vProperty = tbluoemermaidrow.find("[name=Property]").text();
			tbluoemermaidobj['Property'] = vProperty;
			tbluoemermaidobj['index'] = index;
var vType = tbluoemermaidrow.find("[name=Type]").text();
			tbluoemermaidobj['Type'] = vType;
			tbluoemermaidobj['index'] = index;
var vDefaultValue = tbluoemermaidrow.find("[name=DefaultValue]").text();
			tbluoemermaidobj['DefaultValue'] = vDefaultValue;
			tbluoemermaidobj['index'] = index;
var vDescription = tbluoemermaidrow.find("[name=Description]").text();
			tbluoemermaidobj['Description'] = vDescription;
			tbluoemermaidobj['index'] = index;

	tbluoemermaiddata.push(tbluoemermaidobj);
});
return tbluoemermaiddata;
	}
function getRowsmethoduoemermaid(){
	var methoduoemermaiddata = [];
	methoduoemermaidrows = $("#methoduoemermaid tbody tr");
methoduoemermaidrows.each(function (index) {
    var methoduoemermaidrow = $(this);
 	var methoduoemermaidobj = {};
	var vMethod = methoduoemermaidrow.find("[name=Method]").text();
			methoduoemermaidobj['Method'] = vMethod;
			methoduoemermaidobj['index'] = index;
var vParameters = methoduoemermaidrow.find("[name=Parameters]").text();
			methoduoemermaidobj['Parameters'] = vParameters;
			methoduoemermaidobj['index'] = index;
var vReturnType = methoduoemermaidrow.find("[name=ReturnType]").text();
			methoduoemermaidobj['ReturnType'] = vReturnType;
			methoduoemermaidobj['index'] = index;
var vDescription = methoduoemermaidrow.find("[name=Description]").text();
			methoduoemermaidobj['Description'] = vDescription;
			methoduoemermaidobj['index'] = index;

	methoduoemermaiddata.push(methoduoemermaidobj);
});
return methoduoemermaiddata;
	}
function getRowstbluoemodal(){
	var tbluoemodaldata = [];
	tbluoemodalrows = $("#tbluoemodal tbody tr");
tbluoemodalrows.each(function (index) {
    var tbluoemodalrow = $(this);
 	var tbluoemodalobj = {};
	var vProperty = tbluoemodalrow.find("[name=Property]").text();
			tbluoemodalobj['Property'] = vProperty;
			tbluoemodalobj['index'] = index;
var vType = tbluoemodalrow.find("[name=Type]").text();
			tbluoemodalobj['Type'] = vType;
			tbluoemodalobj['index'] = index;
var vDefaultValue = tbluoemodalrow.find("[name=DefaultValue]").text();
			tbluoemodalobj['DefaultValue'] = vDefaultValue;
			tbluoemodalobj['index'] = index;
var vDescription = tbluoemodalrow.find("[name=Description]").text();
			tbluoemodalobj['Description'] = vDescription;
			tbluoemodalobj['index'] = index;

	tbluoemodaldata.push(tbluoemodalobj);
});
return tbluoemodaldata;
	}
function getRowsmethoduoemodal(){
	var methoduoemodaldata = [];
	methoduoemodalrows = $("#methoduoemodal tbody tr");
methoduoemodalrows.each(function (index) {
    var methoduoemodalrow = $(this);
 	var methoduoemodalobj = {};
	var vMethod = methoduoemodalrow.find("[name=Method]").text();
			methoduoemodalobj['Method'] = vMethod;
			methoduoemodalobj['index'] = index;
var vParameters = methoduoemodalrow.find("[name=Parameters]").text();
			methoduoemodalobj['Parameters'] = vParameters;
			methoduoemodalobj['index'] = index;
var vReturnType = methoduoemodalrow.find("[name=ReturnType]").text();
			methoduoemodalobj['ReturnType'] = vReturnType;
			methoduoemodalobj['index'] = index;
var vDescription = methoduoemodalrow.find("[name=Description]").text();
			methoduoemodalobj['Description'] = vDescription;
			methoduoemodalobj['index'] = index;

	methoduoemodaldata.push(methoduoemodalobj);
});
return methoduoemodaldata;
	}
function getRowstbluoemodetype(){
	var tbluoemodetypedata = [];
	tbluoemodetyperows = $("#tbluoemodetype tbody tr");
tbluoemodetyperows.each(function (index) {
    var tbluoemodetyperow = $(this);
 	var tbluoemodetypeobj = {};
	var vProperty = tbluoemodetyperow.find("[name=Property]").text();
			tbluoemodetypeobj['Property'] = vProperty;
			tbluoemodetypeobj['index'] = index;
var vType = tbluoemodetyperow.find("[name=Type]").text();
			tbluoemodetypeobj['Type'] = vType;
			tbluoemodetypeobj['index'] = index;
var vDefaultValue = tbluoemodetyperow.find("[name=DefaultValue]").text();
			tbluoemodetypeobj['DefaultValue'] = vDefaultValue;
			tbluoemodetypeobj['index'] = index;
var vDescription = tbluoemodetyperow.find("[name=Description]").text();
			tbluoemodetypeobj['Description'] = vDescription;
			tbluoemodetypeobj['index'] = index;

	tbluoemodetypedata.push(tbluoemodetypeobj);
});
return tbluoemodetypedata;
	}
function getRowsmethoduoemodetype(){
	var methoduoemodetypedata = [];
	methoduoemodetyperows = $("#methoduoemodetype tbody tr");
methoduoemodetyperows.each(function (index) {
    var methoduoemodetyperow = $(this);
 	var methoduoemodetypeobj = {};
	var vMethod = methoduoemodetyperow.find("[name=Method]").text();
			methoduoemodetypeobj['Method'] = vMethod;
			methoduoemodetypeobj['index'] = index;
var vParameters = methoduoemodetyperow.find("[name=Parameters]").text();
			methoduoemodetypeobj['Parameters'] = vParameters;
			methoduoemodetypeobj['index'] = index;
var vReturnType = methoduoemodetyperow.find("[name=ReturnType]").text();
			methoduoemodetypeobj['ReturnType'] = vReturnType;
			methoduoemodetypeobj['index'] = index;
var vDescription = methoduoemodetyperow.find("[name=Description]").text();
			methoduoemodetypeobj['Description'] = vDescription;
			methoduoemodetypeobj['index'] = index;

	methoduoemodetypedata.push(methoduoemodetypeobj);
});
return methoduoemodetypedata;
	}
function getRowstbluoenav(){
	var tbluoenavdata = [];
	tbluoenavrows = $("#tbluoenav tbody tr");
tbluoenavrows.each(function (index) {
    var tbluoenavrow = $(this);
 	var tbluoenavobj = {};
	var vProperty = tbluoenavrow.find("[name=Property]").text();
			tbluoenavobj['Property'] = vProperty;
			tbluoenavobj['index'] = index;
var vType = tbluoenavrow.find("[name=Type]").text();
			tbluoenavobj['Type'] = vType;
			tbluoenavobj['index'] = index;
var vDefaultValue = tbluoenavrow.find("[name=DefaultValue]").text();
			tbluoenavobj['DefaultValue'] = vDefaultValue;
			tbluoenavobj['index'] = index;
var vDescription = tbluoenavrow.find("[name=Description]").text();
			tbluoenavobj['Description'] = vDescription;
			tbluoenavobj['index'] = index;

	tbluoenavdata.push(tbluoenavobj);
});
return tbluoenavdata;
	}
function getRowsmethoduoenav(){
	var methoduoenavdata = [];
	methoduoenavrows = $("#methoduoenav tbody tr");
methoduoenavrows.each(function (index) {
    var methoduoenavrow = $(this);
 	var methoduoenavobj = {};
	var vMethod = methoduoenavrow.find("[name=Method]").text();
			methoduoenavobj['Method'] = vMethod;
			methoduoenavobj['index'] = index;
var vParameters = methoduoenavrow.find("[name=Parameters]").text();
			methoduoenavobj['Parameters'] = vParameters;
			methoduoenavobj['index'] = index;
var vReturnType = methoduoenavrow.find("[name=ReturnType]").text();
			methoduoenavobj['ReturnType'] = vReturnType;
			methoduoenavobj['index'] = index;
var vDescription = methoduoenavrow.find("[name=Description]").text();
			methoduoenavobj['Description'] = vDescription;
			methoduoenavobj['index'] = index;

	methoduoenavdata.push(methoduoenavobj);
});
return methoduoenavdata;
	}
function getRowstbluoeollapsibletype(){
	var tbluoeollapsibletypedata = [];
	tbluoeollapsibletyperows = $("#tbluoeollapsibletype tbody tr");
tbluoeollapsibletyperows.each(function (index) {
    var tbluoeollapsibletyperow = $(this);
 	var tbluoeollapsibletypeobj = {};
	var vProperty = tbluoeollapsibletyperow.find("[name=Property]").text();
			tbluoeollapsibletypeobj['Property'] = vProperty;
			tbluoeollapsibletypeobj['index'] = index;
var vType = tbluoeollapsibletyperow.find("[name=Type]").text();
			tbluoeollapsibletypeobj['Type'] = vType;
			tbluoeollapsibletypeobj['index'] = index;
var vDefaultValue = tbluoeollapsibletyperow.find("[name=DefaultValue]").text();
			tbluoeollapsibletypeobj['DefaultValue'] = vDefaultValue;
			tbluoeollapsibletypeobj['index'] = index;
var vDescription = tbluoeollapsibletyperow.find("[name=Description]").text();
			tbluoeollapsibletypeobj['Description'] = vDescription;
			tbluoeollapsibletypeobj['index'] = index;

	tbluoeollapsibletypedata.push(tbluoeollapsibletypeobj);
});
return tbluoeollapsibletypedata;
	}
function getRowsmethoduoeollapsibletype(){
	var methoduoeollapsibletypedata = [];
	methoduoeollapsibletyperows = $("#methoduoeollapsibletype tbody tr");
methoduoeollapsibletyperows.each(function (index) {
    var methoduoeollapsibletyperow = $(this);
 	var methoduoeollapsibletypeobj = {};
	var vMethod = methoduoeollapsibletyperow.find("[name=Method]").text();
			methoduoeollapsibletypeobj['Method'] = vMethod;
			methoduoeollapsibletypeobj['index'] = index;
var vParameters = methoduoeollapsibletyperow.find("[name=Parameters]").text();
			methoduoeollapsibletypeobj['Parameters'] = vParameters;
			methoduoeollapsibletypeobj['index'] = index;
var vReturnType = methoduoeollapsibletyperow.find("[name=ReturnType]").text();
			methoduoeollapsibletypeobj['ReturnType'] = vReturnType;
			methoduoeollapsibletypeobj['index'] = index;
var vDescription = methoduoeollapsibletyperow.find("[name=Description]").text();
			methoduoeollapsibletypeobj['Description'] = vDescription;
			methoduoeollapsibletypeobj['index'] = index;

	methoduoeollapsibletypedata.push(methoduoeollapsibletypeobj);
});
return methoduoeollapsibletypedata;
	}
function getRowstbluoeorientation(){
	var tbluoeorientationdata = [];
	tbluoeorientationrows = $("#tbluoeorientation tbody tr");
tbluoeorientationrows.each(function (index) {
    var tbluoeorientationrow = $(this);
 	var tbluoeorientationobj = {};
	var vProperty = tbluoeorientationrow.find("[name=Property]").text();
			tbluoeorientationobj['Property'] = vProperty;
			tbluoeorientationobj['index'] = index;
var vType = tbluoeorientationrow.find("[name=Type]").text();
			tbluoeorientationobj['Type'] = vType;
			tbluoeorientationobj['index'] = index;
var vDefaultValue = tbluoeorientationrow.find("[name=DefaultValue]").text();
			tbluoeorientationobj['DefaultValue'] = vDefaultValue;
			tbluoeorientationobj['index'] = index;
var vDescription = tbluoeorientationrow.find("[name=Description]").text();
			tbluoeorientationobj['Description'] = vDescription;
			tbluoeorientationobj['index'] = index;

	tbluoeorientationdata.push(tbluoeorientationobj);
});
return tbluoeorientationdata;
	}
function getRowsmethoduoeorientation(){
	var methoduoeorientationdata = [];
	methoduoeorientationrows = $("#methoduoeorientation tbody tr");
methoduoeorientationrows.each(function (index) {
    var methoduoeorientationrow = $(this);
 	var methoduoeorientationobj = {};
	var vMethod = methoduoeorientationrow.find("[name=Method]").text();
			methoduoeorientationobj['Method'] = vMethod;
			methoduoeorientationobj['index'] = index;
var vParameters = methoduoeorientationrow.find("[name=Parameters]").text();
			methoduoeorientationobj['Parameters'] = vParameters;
			methoduoeorientationobj['index'] = index;
var vReturnType = methoduoeorientationrow.find("[name=ReturnType]").text();
			methoduoeorientationobj['ReturnType'] = vReturnType;
			methoduoeorientationobj['index'] = index;
var vDescription = methoduoeorientationrow.find("[name=Description]").text();
			methoduoeorientationobj['Description'] = vDescription;
			methoduoeorientationobj['index'] = index;

	methoduoeorientationdata.push(methoduoeorientationobj);
});
return methoduoeorientationdata;
	}
function getRowstbluoepage(){
	var tbluoepagedata = [];
	tbluoepagerows = $("#tbluoepage tbody tr");
tbluoepagerows.each(function (index) {
    var tbluoepagerow = $(this);
 	var tbluoepageobj = {};
	var vProperty = tbluoepagerow.find("[name=Property]").text();
			tbluoepageobj['Property'] = vProperty;
			tbluoepageobj['index'] = index;
var vType = tbluoepagerow.find("[name=Type]").text();
			tbluoepageobj['Type'] = vType;
			tbluoepageobj['index'] = index;
var vDefaultValue = tbluoepagerow.find("[name=DefaultValue]").text();
			tbluoepageobj['DefaultValue'] = vDefaultValue;
			tbluoepageobj['index'] = index;
var vDescription = tbluoepagerow.find("[name=Description]").text();
			tbluoepageobj['Description'] = vDescription;
			tbluoepageobj['index'] = index;

	tbluoepagedata.push(tbluoepageobj);
});
return tbluoepagedata;
	}
function getRowsmethoduoepage(){
	var methoduoepagedata = [];
	methoduoepagerows = $("#methoduoepage tbody tr");
methoduoepagerows.each(function (index) {
    var methoduoepagerow = $(this);
 	var methoduoepageobj = {};
	var vMethod = methoduoepagerow.find("[name=Method]").text();
			methoduoepageobj['Method'] = vMethod;
			methoduoepageobj['index'] = index;
var vParameters = methoduoepagerow.find("[name=Parameters]").text();
			methoduoepageobj['Parameters'] = vParameters;
			methoduoepageobj['index'] = index;
var vReturnType = methoduoepagerow.find("[name=ReturnType]").text();
			methoduoepageobj['ReturnType'] = vReturnType;
			methoduoepageobj['index'] = index;
var vDescription = methoduoepagerow.find("[name=Description]").text();
			methoduoepageobj['Description'] = vDescription;
			methoduoepageobj['index'] = index;

	methoduoepagedata.push(methoduoepageobj);
});
return methoduoepagedata;
	}
function getRowstbluoepagination(){
	var tbluoepaginationdata = [];
	tbluoepaginationrows = $("#tbluoepagination tbody tr");
tbluoepaginationrows.each(function (index) {
    var tbluoepaginationrow = $(this);
 	var tbluoepaginationobj = {};
	var vProperty = tbluoepaginationrow.find("[name=Property]").text();
			tbluoepaginationobj['Property'] = vProperty;
			tbluoepaginationobj['index'] = index;
var vType = tbluoepaginationrow.find("[name=Type]").text();
			tbluoepaginationobj['Type'] = vType;
			tbluoepaginationobj['index'] = index;
var vDefaultValue = tbluoepaginationrow.find("[name=DefaultValue]").text();
			tbluoepaginationobj['DefaultValue'] = vDefaultValue;
			tbluoepaginationobj['index'] = index;
var vDescription = tbluoepaginationrow.find("[name=Description]").text();
			tbluoepaginationobj['Description'] = vDescription;
			tbluoepaginationobj['index'] = index;

	tbluoepaginationdata.push(tbluoepaginationobj);
});
return tbluoepaginationdata;
	}
function getRowsmethoduoepagination(){
	var methoduoepaginationdata = [];
	methoduoepaginationrows = $("#methoduoepagination tbody tr");
methoduoepaginationrows.each(function (index) {
    var methoduoepaginationrow = $(this);
 	var methoduoepaginationobj = {};
	var vMethod = methoduoepaginationrow.find("[name=Method]").text();
			methoduoepaginationobj['Method'] = vMethod;
			methoduoepaginationobj['index'] = index;
var vParameters = methoduoepaginationrow.find("[name=Parameters]").text();
			methoduoepaginationobj['Parameters'] = vParameters;
			methoduoepaginationobj['index'] = index;
var vReturnType = methoduoepaginationrow.find("[name=ReturnType]").text();
			methoduoepaginationobj['ReturnType'] = vReturnType;
			methoduoepaginationobj['index'] = index;
var vDescription = methoduoepaginationrow.find("[name=Description]").text();
			methoduoepaginationobj['Description'] = vDescription;
			methoduoepaginationobj['index'] = index;

	methoduoepaginationdata.push(methoduoepaginationobj);
});
return methoduoepaginationdata;
	}
function getRowstbluoepaginationtheme(){
	var tbluoepaginationthemedata = [];
	tbluoepaginationthemerows = $("#tbluoepaginationtheme tbody tr");
tbluoepaginationthemerows.each(function (index) {
    var tbluoepaginationthemerow = $(this);
 	var tbluoepaginationthemeobj = {};
	var vProperty = tbluoepaginationthemerow.find("[name=Property]").text();
			tbluoepaginationthemeobj['Property'] = vProperty;
			tbluoepaginationthemeobj['index'] = index;
var vType = tbluoepaginationthemerow.find("[name=Type]").text();
			tbluoepaginationthemeobj['Type'] = vType;
			tbluoepaginationthemeobj['index'] = index;
var vDefaultValue = tbluoepaginationthemerow.find("[name=DefaultValue]").text();
			tbluoepaginationthemeobj['DefaultValue'] = vDefaultValue;
			tbluoepaginationthemeobj['index'] = index;
var vDescription = tbluoepaginationthemerow.find("[name=Description]").text();
			tbluoepaginationthemeobj['Description'] = vDescription;
			tbluoepaginationthemeobj['index'] = index;

	tbluoepaginationthemedata.push(tbluoepaginationthemeobj);
});
return tbluoepaginationthemedata;
	}
function getRowsmethoduoepaginationtheme(){
	var methoduoepaginationthemedata = [];
	methoduoepaginationthemerows = $("#methoduoepaginationtheme tbody tr");
methoduoepaginationthemerows.each(function (index) {
    var methoduoepaginationthemerow = $(this);
 	var methoduoepaginationthemeobj = {};
	var vMethod = methoduoepaginationthemerow.find("[name=Method]").text();
			methoduoepaginationthemeobj['Method'] = vMethod;
			methoduoepaginationthemeobj['index'] = index;
var vParameters = methoduoepaginationthemerow.find("[name=Parameters]").text();
			methoduoepaginationthemeobj['Parameters'] = vParameters;
			methoduoepaginationthemeobj['index'] = index;
var vReturnType = methoduoepaginationthemerow.find("[name=ReturnType]").text();
			methoduoepaginationthemeobj['ReturnType'] = vReturnType;
			methoduoepaginationthemeobj['index'] = index;
var vDescription = methoduoepaginationthemerow.find("[name=Description]").text();
			methoduoepaginationthemeobj['Description'] = vDescription;
			methoduoepaginationthemeobj['index'] = index;

	methoduoepaginationthemedata.push(methoduoepaginationthemeobj);
});
return methoduoepaginationthemedata;
	}
function getRowstbluoeparallax(){
	var tbluoeparallaxdata = [];
	tbluoeparallaxrows = $("#tbluoeparallax tbody tr");
tbluoeparallaxrows.each(function (index) {
    var tbluoeparallaxrow = $(this);
 	var tbluoeparallaxobj = {};
	var vProperty = tbluoeparallaxrow.find("[name=Property]").text();
			tbluoeparallaxobj['Property'] = vProperty;
			tbluoeparallaxobj['index'] = index;
var vType = tbluoeparallaxrow.find("[name=Type]").text();
			tbluoeparallaxobj['Type'] = vType;
			tbluoeparallaxobj['index'] = index;
var vDefaultValue = tbluoeparallaxrow.find("[name=DefaultValue]").text();
			tbluoeparallaxobj['DefaultValue'] = vDefaultValue;
			tbluoeparallaxobj['index'] = index;
var vDescription = tbluoeparallaxrow.find("[name=Description]").text();
			tbluoeparallaxobj['Description'] = vDescription;
			tbluoeparallaxobj['index'] = index;

	tbluoeparallaxdata.push(tbluoeparallaxobj);
});
return tbluoeparallaxdata;
	}
function getRowsmethoduoeparallax(){
	var methoduoeparallaxdata = [];
	methoduoeparallaxrows = $("#methoduoeparallax tbody tr");
methoduoeparallaxrows.each(function (index) {
    var methoduoeparallaxrow = $(this);
 	var methoduoeparallaxobj = {};
	var vMethod = methoduoeparallaxrow.find("[name=Method]").text();
			methoduoeparallaxobj['Method'] = vMethod;
			methoduoeparallaxobj['index'] = index;
var vParameters = methoduoeparallaxrow.find("[name=Parameters]").text();
			methoduoeparallaxobj['Parameters'] = vParameters;
			methoduoeparallaxobj['index'] = index;
var vReturnType = methoduoeparallaxrow.find("[name=ReturnType]").text();
			methoduoeparallaxobj['ReturnType'] = vReturnType;
			methoduoeparallaxobj['index'] = index;
var vDescription = methoduoeparallaxrow.find("[name=Description]").text();
			methoduoeparallaxobj['Description'] = vDescription;
			methoduoeparallaxobj['index'] = index;

	methoduoeparallaxdata.push(methoduoeparallaxobj);
});
return methoduoeparallaxdata;
	}
function getRowstbluoepreloader(){
	var tbluoepreloaderdata = [];
	tbluoepreloaderrows = $("#tbluoepreloader tbody tr");
tbluoepreloaderrows.each(function (index) {
    var tbluoepreloaderrow = $(this);
 	var tbluoepreloaderobj = {};
	var vProperty = tbluoepreloaderrow.find("[name=Property]").text();
			tbluoepreloaderobj['Property'] = vProperty;
			tbluoepreloaderobj['index'] = index;
var vType = tbluoepreloaderrow.find("[name=Type]").text();
			tbluoepreloaderobj['Type'] = vType;
			tbluoepreloaderobj['index'] = index;
var vDefaultValue = tbluoepreloaderrow.find("[name=DefaultValue]").text();
			tbluoepreloaderobj['DefaultValue'] = vDefaultValue;
			tbluoepreloaderobj['index'] = index;
var vDescription = tbluoepreloaderrow.find("[name=Description]").text();
			tbluoepreloaderobj['Description'] = vDescription;
			tbluoepreloaderobj['index'] = index;

	tbluoepreloaderdata.push(tbluoepreloaderobj);
});
return tbluoepreloaderdata;
	}
function getRowsmethoduoepreloader(){
	var methoduoepreloaderdata = [];
	methoduoepreloaderrows = $("#methoduoepreloader tbody tr");
methoduoepreloaderrows.each(function (index) {
    var methoduoepreloaderrow = $(this);
 	var methoduoepreloaderobj = {};
	var vMethod = methoduoepreloaderrow.find("[name=Method]").text();
			methoduoepreloaderobj['Method'] = vMethod;
			methoduoepreloaderobj['index'] = index;
var vParameters = methoduoepreloaderrow.find("[name=Parameters]").text();
			methoduoepreloaderobj['Parameters'] = vParameters;
			methoduoepreloaderobj['index'] = index;
var vReturnType = methoduoepreloaderrow.find("[name=ReturnType]").text();
			methoduoepreloaderobj['ReturnType'] = vReturnType;
			methoduoepreloaderobj['index'] = index;
var vDescription = methoduoepreloaderrow.find("[name=Description]").text();
			methoduoepreloaderobj['Description'] = vDescription;
			methoduoepreloaderobj['index'] = index;

	methoduoepreloaderdata.push(methoduoepreloaderobj);
});
return methoduoepreloaderdata;
	}
function getRowstbluoeprism(){
	var tbluoeprismdata = [];
	tbluoeprismrows = $("#tbluoeprism tbody tr");
tbluoeprismrows.each(function (index) {
    var tbluoeprismrow = $(this);
 	var tbluoeprismobj = {};
	var vProperty = tbluoeprismrow.find("[name=Property]").text();
			tbluoeprismobj['Property'] = vProperty;
			tbluoeprismobj['index'] = index;
var vType = tbluoeprismrow.find("[name=Type]").text();
			tbluoeprismobj['Type'] = vType;
			tbluoeprismobj['index'] = index;
var vDefaultValue = tbluoeprismrow.find("[name=DefaultValue]").text();
			tbluoeprismobj['DefaultValue'] = vDefaultValue;
			tbluoeprismobj['index'] = index;
var vDescription = tbluoeprismrow.find("[name=Description]").text();
			tbluoeprismobj['Description'] = vDescription;
			tbluoeprismobj['index'] = index;

	tbluoeprismdata.push(tbluoeprismobj);
});
return tbluoeprismdata;
	}
function getRowsmethoduoeprism(){
	var methoduoeprismdata = [];
	methoduoeprismrows = $("#methoduoeprism tbody tr");
methoduoeprismrows.each(function (index) {
    var methoduoeprismrow = $(this);
 	var methoduoeprismobj = {};
	var vMethod = methoduoeprismrow.find("[name=Method]").text();
			methoduoeprismobj['Method'] = vMethod;
			methoduoeprismobj['index'] = index;
var vParameters = methoduoeprismrow.find("[name=Parameters]").text();
			methoduoeprismobj['Parameters'] = vParameters;
			methoduoeprismobj['index'] = index;
var vReturnType = methoduoeprismrow.find("[name=ReturnType]").text();
			methoduoeprismobj['ReturnType'] = vReturnType;
			methoduoeprismobj['index'] = index;
var vDescription = methoduoeprismrow.find("[name=Description]").text();
			methoduoeprismobj['Description'] = vDescription;
			methoduoeprismobj['index'] = index;

	methoduoeprismdata.push(methoduoeprismobj);
});
return methoduoeprismdata;
	}
function getRowstbluoeprogress(){
	var tbluoeprogressdata = [];
	tbluoeprogressrows = $("#tbluoeprogress tbody tr");
tbluoeprogressrows.each(function (index) {
    var tbluoeprogressrow = $(this);
 	var tbluoeprogressobj = {};
	var vProperty = tbluoeprogressrow.find("[name=Property]").text();
			tbluoeprogressobj['Property'] = vProperty;
			tbluoeprogressobj['index'] = index;
var vType = tbluoeprogressrow.find("[name=Type]").text();
			tbluoeprogressobj['Type'] = vType;
			tbluoeprogressobj['index'] = index;
var vDefaultValue = tbluoeprogressrow.find("[name=DefaultValue]").text();
			tbluoeprogressobj['DefaultValue'] = vDefaultValue;
			tbluoeprogressobj['index'] = index;
var vDescription = tbluoeprogressrow.find("[name=Description]").text();
			tbluoeprogressobj['Description'] = vDescription;
			tbluoeprogressobj['index'] = index;

	tbluoeprogressdata.push(tbluoeprogressobj);
});
return tbluoeprogressdata;
	}
function getRowsmethoduoeprogress(){
	var methoduoeprogressdata = [];
	methoduoeprogressrows = $("#methoduoeprogress tbody tr");
methoduoeprogressrows.each(function (index) {
    var methoduoeprogressrow = $(this);
 	var methoduoeprogressobj = {};
	var vMethod = methoduoeprogressrow.find("[name=Method]").text();
			methoduoeprogressobj['Method'] = vMethod;
			methoduoeprogressobj['index'] = index;
var vParameters = methoduoeprogressrow.find("[name=Parameters]").text();
			methoduoeprogressobj['Parameters'] = vParameters;
			methoduoeprogressobj['index'] = index;
var vReturnType = methoduoeprogressrow.find("[name=ReturnType]").text();
			methoduoeprogressobj['ReturnType'] = vReturnType;
			methoduoeprogressobj['index'] = index;
var vDescription = methoduoeprogressrow.find("[name=Description]").text();
			methoduoeprogressobj['Description'] = vDescription;
			methoduoeprogressobj['index'] = index;

	methoduoeprogressdata.push(methoduoeprogressobj);
});
return methoduoeprogressdata;
	}
function getRowstbluoequill(){
	var tbluoequilldata = [];
	tbluoequillrows = $("#tbluoequill tbody tr");
tbluoequillrows.each(function (index) {
    var tbluoequillrow = $(this);
 	var tbluoequillobj = {};
	var vProperty = tbluoequillrow.find("[name=Property]").text();
			tbluoequillobj['Property'] = vProperty;
			tbluoequillobj['index'] = index;
var vType = tbluoequillrow.find("[name=Type]").text();
			tbluoequillobj['Type'] = vType;
			tbluoequillobj['index'] = index;
var vDefaultValue = tbluoequillrow.find("[name=DefaultValue]").text();
			tbluoequillobj['DefaultValue'] = vDefaultValue;
			tbluoequillobj['index'] = index;
var vDescription = tbluoequillrow.find("[name=Description]").text();
			tbluoequillobj['Description'] = vDescription;
			tbluoequillobj['index'] = index;

	tbluoequilldata.push(tbluoequillobj);
});
return tbluoequilldata;
	}
function getRowsmethoduoequill(){
	var methoduoequilldata = [];
	methoduoequillrows = $("#methoduoequill tbody tr");
methoduoequillrows.each(function (index) {
    var methoduoequillrow = $(this);
 	var methoduoequillobj = {};
	var vMethod = methoduoequillrow.find("[name=Method]").text();
			methoduoequillobj['Method'] = vMethod;
			methoduoequillobj['index'] = index;
var vParameters = methoduoequillrow.find("[name=Parameters]").text();
			methoduoequillobj['Parameters'] = vParameters;
			methoduoequillobj['index'] = index;
var vReturnType = methoduoequillrow.find("[name=ReturnType]").text();
			methoduoequillobj['ReturnType'] = vReturnType;
			methoduoequillobj['index'] = index;
var vDescription = methoduoequillrow.find("[name=Description]").text();
			methoduoequillobj['Description'] = vDescription;
			methoduoequillobj['index'] = index;

	methoduoequilldata.push(methoduoequillobj);
});
return methoduoequilldata;
	}
function getRowstbluoeradio(){
	var tbluoeradiodata = [];
	tbluoeradiorows = $("#tbluoeradio tbody tr");
tbluoeradiorows.each(function (index) {
    var tbluoeradiorow = $(this);
 	var tbluoeradioobj = {};
	var vProperty = tbluoeradiorow.find("[name=Property]").text();
			tbluoeradioobj['Property'] = vProperty;
			tbluoeradioobj['index'] = index;
var vType = tbluoeradiorow.find("[name=Type]").text();
			tbluoeradioobj['Type'] = vType;
			tbluoeradioobj['index'] = index;
var vDefaultValue = tbluoeradiorow.find("[name=DefaultValue]").text();
			tbluoeradioobj['DefaultValue'] = vDefaultValue;
			tbluoeradioobj['index'] = index;
var vDescription = tbluoeradiorow.find("[name=Description]").text();
			tbluoeradioobj['Description'] = vDescription;
			tbluoeradioobj['index'] = index;

	tbluoeradiodata.push(tbluoeradioobj);
});
return tbluoeradiodata;
	}
function getRowsmethoduoeradio(){
	var methoduoeradiodata = [];
	methoduoeradiorows = $("#methoduoeradio tbody tr");
methoduoeradiorows.each(function (index) {
    var methoduoeradiorow = $(this);
 	var methoduoeradioobj = {};
	var vMethod = methoduoeradiorow.find("[name=Method]").text();
			methoduoeradioobj['Method'] = vMethod;
			methoduoeradioobj['index'] = index;
var vParameters = methoduoeradiorow.find("[name=Parameters]").text();
			methoduoeradioobj['Parameters'] = vParameters;
			methoduoeradioobj['index'] = index;
var vReturnType = methoduoeradiorow.find("[name=ReturnType]").text();
			methoduoeradioobj['ReturnType'] = vReturnType;
			methoduoeradioobj['index'] = index;
var vDescription = methoduoeradiorow.find("[name=Description]").text();
			methoduoeradioobj['Description'] = vDescription;
			methoduoeradioobj['index'] = index;

	methoduoeradiodata.push(methoduoeradioobj);
});
return methoduoeradiodata;
	}
function getRowstbluoeradiogroup(){
	var tbluoeradiogroupdata = [];
	tbluoeradiogrouprows = $("#tbluoeradiogroup tbody tr");
tbluoeradiogrouprows.each(function (index) {
    var tbluoeradiogrouprow = $(this);
 	var tbluoeradiogroupobj = {};
	var vProperty = tbluoeradiogrouprow.find("[name=Property]").text();
			tbluoeradiogroupobj['Property'] = vProperty;
			tbluoeradiogroupobj['index'] = index;
var vType = tbluoeradiogrouprow.find("[name=Type]").text();
			tbluoeradiogroupobj['Type'] = vType;
			tbluoeradiogroupobj['index'] = index;
var vDefaultValue = tbluoeradiogrouprow.find("[name=DefaultValue]").text();
			tbluoeradiogroupobj['DefaultValue'] = vDefaultValue;
			tbluoeradiogroupobj['index'] = index;
var vDescription = tbluoeradiogrouprow.find("[name=Description]").text();
			tbluoeradiogroupobj['Description'] = vDescription;
			tbluoeradiogroupobj['index'] = index;

	tbluoeradiogroupdata.push(tbluoeradiogroupobj);
});
return tbluoeradiogroupdata;
	}
function getRowsmethoduoeradiogroup(){
	var methoduoeradiogroupdata = [];
	methoduoeradiogrouprows = $("#methoduoeradiogroup tbody tr");
methoduoeradiogrouprows.each(function (index) {
    var methoduoeradiogrouprow = $(this);
 	var methoduoeradiogroupobj = {};
	var vMethod = methoduoeradiogrouprow.find("[name=Method]").text();
			methoduoeradiogroupobj['Method'] = vMethod;
			methoduoeradiogroupobj['index'] = index;
var vParameters = methoduoeradiogrouprow.find("[name=Parameters]").text();
			methoduoeradiogroupobj['Parameters'] = vParameters;
			methoduoeradiogroupobj['index'] = index;
var vReturnType = methoduoeradiogrouprow.find("[name=ReturnType]").text();
			methoduoeradiogroupobj['ReturnType'] = vReturnType;
			methoduoeradiogroupobj['index'] = index;
var vDescription = methoduoeradiogrouprow.find("[name=Description]").text();
			methoduoeradiogroupobj['Description'] = vDescription;
			methoduoeradiogroupobj['index'] = index;

	methoduoeradiogroupdata.push(methoduoeradiogroupobj);
});
return methoduoeradiogroupdata;
	}
function getRowstbluoerange(){
	var tbluoerangedata = [];
	tbluoerangerows = $("#tbluoerange tbody tr");
tbluoerangerows.each(function (index) {
    var tbluoerangerow = $(this);
 	var tbluoerangeobj = {};
	var vProperty = tbluoerangerow.find("[name=Property]").text();
			tbluoerangeobj['Property'] = vProperty;
			tbluoerangeobj['index'] = index;
var vType = tbluoerangerow.find("[name=Type]").text();
			tbluoerangeobj['Type'] = vType;
			tbluoerangeobj['index'] = index;
var vDefaultValue = tbluoerangerow.find("[name=DefaultValue]").text();
			tbluoerangeobj['DefaultValue'] = vDefaultValue;
			tbluoerangeobj['index'] = index;
var vDescription = tbluoerangerow.find("[name=Description]").text();
			tbluoerangeobj['Description'] = vDescription;
			tbluoerangeobj['index'] = index;

	tbluoerangedata.push(tbluoerangeobj);
});
return tbluoerangedata;
	}
function getRowsmethoduoerange(){
	var methoduoerangedata = [];
	methoduoerangerows = $("#methoduoerange tbody tr");
methoduoerangerows.each(function (index) {
    var methoduoerangerow = $(this);
 	var methoduoerangeobj = {};
	var vMethod = methoduoerangerow.find("[name=Method]").text();
			methoduoerangeobj['Method'] = vMethod;
			methoduoerangeobj['index'] = index;
var vParameters = methoduoerangerow.find("[name=Parameters]").text();
			methoduoerangeobj['Parameters'] = vParameters;
			methoduoerangeobj['index'] = index;
var vReturnType = methoduoerangerow.find("[name=ReturnType]").text();
			methoduoerangeobj['ReturnType'] = vReturnType;
			methoduoerangeobj['index'] = index;
var vDescription = methoduoerangerow.find("[name=Description]").text();
			methoduoerangeobj['Description'] = vDescription;
			methoduoerangeobj['index'] = index;

	methoduoerangedata.push(methoduoerangeobj);
});
return methoduoerangedata;
	}
function getRowstbluoerangeslider(){
	var tbluoerangesliderdata = [];
	tbluoerangesliderrows = $("#tbluoerangeslider tbody tr");
tbluoerangesliderrows.each(function (index) {
    var tbluoerangesliderrow = $(this);
 	var tbluoerangesliderobj = {};
	var vProperty = tbluoerangesliderrow.find("[name=Property]").text();
			tbluoerangesliderobj['Property'] = vProperty;
			tbluoerangesliderobj['index'] = index;
var vType = tbluoerangesliderrow.find("[name=Type]").text();
			tbluoerangesliderobj['Type'] = vType;
			tbluoerangesliderobj['index'] = index;
var vDefaultValue = tbluoerangesliderrow.find("[name=DefaultValue]").text();
			tbluoerangesliderobj['DefaultValue'] = vDefaultValue;
			tbluoerangesliderobj['index'] = index;
var vDescription = tbluoerangesliderrow.find("[name=Description]").text();
			tbluoerangesliderobj['Description'] = vDescription;
			tbluoerangesliderobj['index'] = index;

	tbluoerangesliderdata.push(tbluoerangesliderobj);
});
return tbluoerangesliderdata;
	}
function getRowsmethoduoerangeslider(){
	var methoduoerangesliderdata = [];
	methoduoerangesliderrows = $("#methoduoerangeslider tbody tr");
methoduoerangesliderrows.each(function (index) {
    var methoduoerangesliderrow = $(this);
 	var methoduoerangesliderobj = {};
	var vMethod = methoduoerangesliderrow.find("[name=Method]").text();
			methoduoerangesliderobj['Method'] = vMethod;
			methoduoerangesliderobj['index'] = index;
var vParameters = methoduoerangesliderrow.find("[name=Parameters]").text();
			methoduoerangesliderobj['Parameters'] = vParameters;
			methoduoerangesliderobj['index'] = index;
var vReturnType = methoduoerangesliderrow.find("[name=ReturnType]").text();
			methoduoerangesliderobj['ReturnType'] = vReturnType;
			methoduoerangesliderobj['index'] = index;
var vDescription = methoduoerangesliderrow.find("[name=Description]").text();
			methoduoerangesliderobj['Description'] = vDescription;
			methoduoerangesliderobj['index'] = index;

	methoduoerangesliderdata.push(methoduoerangesliderobj);
});
return methoduoerangesliderdata;
	}
function getRowstbluoeribbon(){
	var tbluoeribbondata = [];
	tbluoeribbonrows = $("#tbluoeribbon tbody tr");
tbluoeribbonrows.each(function (index) {
    var tbluoeribbonrow = $(this);
 	var tbluoeribbonobj = {};
	var vProperty = tbluoeribbonrow.find("[name=Property]").text();
			tbluoeribbonobj['Property'] = vProperty;
			tbluoeribbonobj['index'] = index;
var vType = tbluoeribbonrow.find("[name=Type]").text();
			tbluoeribbonobj['Type'] = vType;
			tbluoeribbonobj['index'] = index;
var vDefaultValue = tbluoeribbonrow.find("[name=DefaultValue]").text();
			tbluoeribbonobj['DefaultValue'] = vDefaultValue;
			tbluoeribbonobj['index'] = index;
var vDescription = tbluoeribbonrow.find("[name=Description]").text();
			tbluoeribbonobj['Description'] = vDescription;
			tbluoeribbonobj['index'] = index;

	tbluoeribbondata.push(tbluoeribbonobj);
});
return tbluoeribbondata;
	}
function getRowsmethoduoeribbon(){
	var methoduoeribbondata = [];
	methoduoeribbonrows = $("#methoduoeribbon tbody tr");
methoduoeribbonrows.each(function (index) {
    var methoduoeribbonrow = $(this);
 	var methoduoeribbonobj = {};
	var vMethod = methoduoeribbonrow.find("[name=Method]").text();
			methoduoeribbonobj['Method'] = vMethod;
			methoduoeribbonobj['index'] = index;
var vParameters = methoduoeribbonrow.find("[name=Parameters]").text();
			methoduoeribbonobj['Parameters'] = vParameters;
			methoduoeribbonobj['index'] = index;
var vReturnType = methoduoeribbonrow.find("[name=ReturnType]").text();
			methoduoeribbonobj['ReturnType'] = vReturnType;
			methoduoeribbonobj['index'] = index;
var vDescription = methoduoeribbonrow.find("[name=Description]").text();
			methoduoeribbonobj['Description'] = vDescription;
			methoduoeribbonobj['index'] = index;

	methoduoeribbondata.push(methoduoeribbonobj);
});
return methoduoeribbondata;
	}
function getRowstbluoerow(){
	var tbluoerowdata = [];
	tbluoerowrows = $("#tbluoerow tbody tr");
tbluoerowrows.each(function (index) {
    var tbluoerowrow = $(this);
 	var tbluoerowobj = {};
	var vProperty = tbluoerowrow.find("[name=Property]").text();
			tbluoerowobj['Property'] = vProperty;
			tbluoerowobj['index'] = index;
var vType = tbluoerowrow.find("[name=Type]").text();
			tbluoerowobj['Type'] = vType;
			tbluoerowobj['index'] = index;
var vDefaultValue = tbluoerowrow.find("[name=DefaultValue]").text();
			tbluoerowobj['DefaultValue'] = vDefaultValue;
			tbluoerowobj['index'] = index;
var vDescription = tbluoerowrow.find("[name=Description]").text();
			tbluoerowobj['Description'] = vDescription;
			tbluoerowobj['index'] = index;

	tbluoerowdata.push(tbluoerowobj);
});
return tbluoerowdata;
	}
function getRowsmethoduoerow(){
	var methoduoerowdata = [];
	methoduoerowrows = $("#methoduoerow tbody tr");
methoduoerowrows.each(function (index) {
    var methoduoerowrow = $(this);
 	var methoduoerowobj = {};
	var vMethod = methoduoerowrow.find("[name=Method]").text();
			methoduoerowobj['Method'] = vMethod;
			methoduoerowobj['index'] = index;
var vParameters = methoduoerowrow.find("[name=Parameters]").text();
			methoduoerowobj['Parameters'] = vParameters;
			methoduoerowobj['index'] = index;
var vReturnType = methoduoerowrow.find("[name=ReturnType]").text();
			methoduoerowobj['ReturnType'] = vReturnType;
			methoduoerowobj['index'] = index;
var vDescription = methoduoerowrow.find("[name=Description]").text();
			methoduoerowobj['Description'] = vDescription;
			methoduoerowobj['index'] = index;

	methoduoerowdata.push(methoduoerowobj);
});
return methoduoerowdata;
	}
function getRowstbluoescaletype(){
	var tbluoescaletypedata = [];
	tbluoescaletyperows = $("#tbluoescaletype tbody tr");
tbluoescaletyperows.each(function (index) {
    var tbluoescaletyperow = $(this);
 	var tbluoescaletypeobj = {};
	var vProperty = tbluoescaletyperow.find("[name=Property]").text();
			tbluoescaletypeobj['Property'] = vProperty;
			tbluoescaletypeobj['index'] = index;
var vType = tbluoescaletyperow.find("[name=Type]").text();
			tbluoescaletypeobj['Type'] = vType;
			tbluoescaletypeobj['index'] = index;
var vDefaultValue = tbluoescaletyperow.find("[name=DefaultValue]").text();
			tbluoescaletypeobj['DefaultValue'] = vDefaultValue;
			tbluoescaletypeobj['index'] = index;
var vDescription = tbluoescaletyperow.find("[name=Description]").text();
			tbluoescaletypeobj['Description'] = vDescription;
			tbluoescaletypeobj['index'] = index;

	tbluoescaletypedata.push(tbluoescaletypeobj);
});
return tbluoescaletypedata;
	}
function getRowsmethoduoescaletype(){
	var methoduoescaletypedata = [];
	methoduoescaletyperows = $("#methoduoescaletype tbody tr");
methoduoescaletyperows.each(function (index) {
    var methoduoescaletyperow = $(this);
 	var methoduoescaletypeobj = {};
	var vMethod = methoduoescaletyperow.find("[name=Method]").text();
			methoduoescaletypeobj['Method'] = vMethod;
			methoduoescaletypeobj['index'] = index;
var vParameters = methoduoescaletyperow.find("[name=Parameters]").text();
			methoduoescaletypeobj['Parameters'] = vParameters;
			methoduoescaletypeobj['index'] = index;
var vReturnType = methoduoescaletyperow.find("[name=ReturnType]").text();
			methoduoescaletypeobj['ReturnType'] = vReturnType;
			methoduoescaletypeobj['index'] = index;
var vDescription = methoduoescaletyperow.find("[name=Description]").text();
			methoduoescaletypeobj['Description'] = vDescription;
			methoduoescaletypeobj['index'] = index;

	methoduoescaletypedata.push(methoduoescaletypeobj);
});
return methoduoescaletypedata;
	}
function getRowstbluoesection(){
	var tbluoesectiondata = [];
	tbluoesectionrows = $("#tbluoesection tbody tr");
tbluoesectionrows.each(function (index) {
    var tbluoesectionrow = $(this);
 	var tbluoesectionobj = {};
	var vProperty = tbluoesectionrow.find("[name=Property]").text();
			tbluoesectionobj['Property'] = vProperty;
			tbluoesectionobj['index'] = index;
var vType = tbluoesectionrow.find("[name=Type]").text();
			tbluoesectionobj['Type'] = vType;
			tbluoesectionobj['index'] = index;
var vDefaultValue = tbluoesectionrow.find("[name=DefaultValue]").text();
			tbluoesectionobj['DefaultValue'] = vDefaultValue;
			tbluoesectionobj['index'] = index;
var vDescription = tbluoesectionrow.find("[name=Description]").text();
			tbluoesectionobj['Description'] = vDescription;
			tbluoesectionobj['index'] = index;

	tbluoesectiondata.push(tbluoesectionobj);
});
return tbluoesectiondata;
	}
function getRowsmethoduoesection(){
	var methoduoesectiondata = [];
	methoduoesectionrows = $("#methoduoesection tbody tr");
methoduoesectionrows.each(function (index) {
    var methoduoesectionrow = $(this);
 	var methoduoesectionobj = {};
	var vMethod = methoduoesectionrow.find("[name=Method]").text();
			methoduoesectionobj['Method'] = vMethod;
			methoduoesectionobj['index'] = index;
var vParameters = methoduoesectionrow.find("[name=Parameters]").text();
			methoduoesectionobj['Parameters'] = vParameters;
			methoduoesectionobj['index'] = index;
var vReturnType = methoduoesectionrow.find("[name=ReturnType]").text();
			methoduoesectionobj['ReturnType'] = vReturnType;
			methoduoesectionobj['index'] = index;
var vDescription = methoduoesectionrow.find("[name=Description]").text();
			methoduoesectionobj['Description'] = vDescription;
			methoduoesectionobj['index'] = index;

	methoduoesectiondata.push(methoduoesectionobj);
});
return methoduoesectiondata;
	}
function getRowstbluoeselect(){
	var tbluoeselectdata = [];
	tbluoeselectrows = $("#tbluoeselect tbody tr");
tbluoeselectrows.each(function (index) {
    var tbluoeselectrow = $(this);
 	var tbluoeselectobj = {};
	var vProperty = tbluoeselectrow.find("[name=Property]").text();
			tbluoeselectobj['Property'] = vProperty;
			tbluoeselectobj['index'] = index;
var vType = tbluoeselectrow.find("[name=Type]").text();
			tbluoeselectobj['Type'] = vType;
			tbluoeselectobj['index'] = index;
var vDefaultValue = tbluoeselectrow.find("[name=DefaultValue]").text();
			tbluoeselectobj['DefaultValue'] = vDefaultValue;
			tbluoeselectobj['index'] = index;
var vDescription = tbluoeselectrow.find("[name=Description]").text();
			tbluoeselectobj['Description'] = vDescription;
			tbluoeselectobj['index'] = index;

	tbluoeselectdata.push(tbluoeselectobj);
});
return tbluoeselectdata;
	}
function getRowsmethoduoeselect(){
	var methoduoeselectdata = [];
	methoduoeselectrows = $("#methoduoeselect tbody tr");
methoduoeselectrows.each(function (index) {
    var methoduoeselectrow = $(this);
 	var methoduoeselectobj = {};
	var vMethod = methoduoeselectrow.find("[name=Method]").text();
			methoduoeselectobj['Method'] = vMethod;
			methoduoeselectobj['index'] = index;
var vParameters = methoduoeselectrow.find("[name=Parameters]").text();
			methoduoeselectobj['Parameters'] = vParameters;
			methoduoeselectobj['index'] = index;
var vReturnType = methoduoeselectrow.find("[name=ReturnType]").text();
			methoduoeselectobj['ReturnType'] = vReturnType;
			methoduoeselectobj['index'] = index;
var vDescription = methoduoeselectrow.find("[name=Description]").text();
			methoduoeselectobj['Description'] = vDescription;
			methoduoeselectobj['index'] = index;

	methoduoeselectdata.push(methoduoeselectobj);
});
return methoduoeselectdata;
	}
function getRowstbluoesidebar(){
	var tbluoesidebardata = [];
	tbluoesidebarrows = $("#tbluoesidebar tbody tr");
tbluoesidebarrows.each(function (index) {
    var tbluoesidebarrow = $(this);
 	var tbluoesidebarobj = {};
	var vProperty = tbluoesidebarrow.find("[name=Property]").text();
			tbluoesidebarobj['Property'] = vProperty;
			tbluoesidebarobj['index'] = index;
var vType = tbluoesidebarrow.find("[name=Type]").text();
			tbluoesidebarobj['Type'] = vType;
			tbluoesidebarobj['index'] = index;
var vDefaultValue = tbluoesidebarrow.find("[name=DefaultValue]").text();
			tbluoesidebarobj['DefaultValue'] = vDefaultValue;
			tbluoesidebarobj['index'] = index;
var vDescription = tbluoesidebarrow.find("[name=Description]").text();
			tbluoesidebarobj['Description'] = vDescription;
			tbluoesidebarobj['index'] = index;

	tbluoesidebardata.push(tbluoesidebarobj);
});
return tbluoesidebardata;
	}
function getRowsmethoduoesidebar(){
	var methoduoesidebardata = [];
	methoduoesidebarrows = $("#methoduoesidebar tbody tr");
methoduoesidebarrows.each(function (index) {
    var methoduoesidebarrow = $(this);
 	var methoduoesidebarobj = {};
	var vMethod = methoduoesidebarrow.find("[name=Method]").text();
			methoduoesidebarobj['Method'] = vMethod;
			methoduoesidebarobj['index'] = index;
var vParameters = methoduoesidebarrow.find("[name=Parameters]").text();
			methoduoesidebarobj['Parameters'] = vParameters;
			methoduoesidebarobj['index'] = index;
var vReturnType = methoduoesidebarrow.find("[name=ReturnType]").text();
			methoduoesidebarobj['ReturnType'] = vReturnType;
			methoduoesidebarobj['index'] = index;
var vDescription = methoduoesidebarrow.find("[name=Description]").text();
			methoduoesidebarobj['Description'] = vDescription;
			methoduoesidebarobj['index'] = index;

	methoduoesidebardata.push(methoduoesidebarobj);
});
return methoduoesidebardata;
	}
function getRowstbluoeslider(){
	var tbluoesliderdata = [];
	tbluoesliderrows = $("#tbluoeslider tbody tr");
tbluoesliderrows.each(function (index) {
    var tbluoesliderrow = $(this);
 	var tbluoesliderobj = {};
	var vProperty = tbluoesliderrow.find("[name=Property]").text();
			tbluoesliderobj['Property'] = vProperty;
			tbluoesliderobj['index'] = index;
var vType = tbluoesliderrow.find("[name=Type]").text();
			tbluoesliderobj['Type'] = vType;
			tbluoesliderobj['index'] = index;
var vDefaultValue = tbluoesliderrow.find("[name=DefaultValue]").text();
			tbluoesliderobj['DefaultValue'] = vDefaultValue;
			tbluoesliderobj['index'] = index;
var vDescription = tbluoesliderrow.find("[name=Description]").text();
			tbluoesliderobj['Description'] = vDescription;
			tbluoesliderobj['index'] = index;

	tbluoesliderdata.push(tbluoesliderobj);
});
return tbluoesliderdata;
	}
function getRowsmethoduoeslider(){
	var methoduoesliderdata = [];
	methoduoesliderrows = $("#methoduoeslider tbody tr");
methoduoesliderrows.each(function (index) {
    var methoduoesliderrow = $(this);
 	var methoduoesliderobj = {};
	var vMethod = methoduoesliderrow.find("[name=Method]").text();
			methoduoesliderobj['Method'] = vMethod;
			methoduoesliderobj['index'] = index;
var vParameters = methoduoesliderrow.find("[name=Parameters]").text();
			methoduoesliderobj['Parameters'] = vParameters;
			methoduoesliderobj['index'] = index;
var vReturnType = methoduoesliderrow.find("[name=ReturnType]").text();
			methoduoesliderobj['ReturnType'] = vReturnType;
			methoduoesliderobj['index'] = index;
var vDescription = methoduoesliderrow.find("[name=Description]").text();
			methoduoesliderobj['Description'] = vDescription;
			methoduoesliderobj['index'] = index;

	methoduoesliderdata.push(methoduoesliderobj);
});
return methoduoesliderdata;
	}
function getRowstbluoesliderorientation(){
	var tbluoesliderorientationdata = [];
	tbluoesliderorientationrows = $("#tbluoesliderorientation tbody tr");
tbluoesliderorientationrows.each(function (index) {
    var tbluoesliderorientationrow = $(this);
 	var tbluoesliderorientationobj = {};
	var vProperty = tbluoesliderorientationrow.find("[name=Property]").text();
			tbluoesliderorientationobj['Property'] = vProperty;
			tbluoesliderorientationobj['index'] = index;
var vType = tbluoesliderorientationrow.find("[name=Type]").text();
			tbluoesliderorientationobj['Type'] = vType;
			tbluoesliderorientationobj['index'] = index;
var vDefaultValue = tbluoesliderorientationrow.find("[name=DefaultValue]").text();
			tbluoesliderorientationobj['DefaultValue'] = vDefaultValue;
			tbluoesliderorientationobj['index'] = index;
var vDescription = tbluoesliderorientationrow.find("[name=Description]").text();
			tbluoesliderorientationobj['Description'] = vDescription;
			tbluoesliderorientationobj['index'] = index;

	tbluoesliderorientationdata.push(tbluoesliderorientationobj);
});
return tbluoesliderorientationdata;
	}
function getRowsmethoduoesliderorientation(){
	var methoduoesliderorientationdata = [];
	methoduoesliderorientationrows = $("#methoduoesliderorientation tbody tr");
methoduoesliderorientationrows.each(function (index) {
    var methoduoesliderorientationrow = $(this);
 	var methoduoesliderorientationobj = {};
	var vMethod = methoduoesliderorientationrow.find("[name=Method]").text();
			methoduoesliderorientationobj['Method'] = vMethod;
			methoduoesliderorientationobj['index'] = index;
var vParameters = methoduoesliderorientationrow.find("[name=Parameters]").text();
			methoduoesliderorientationobj['Parameters'] = vParameters;
			methoduoesliderorientationobj['index'] = index;
var vReturnType = methoduoesliderorientationrow.find("[name=ReturnType]").text();
			methoduoesliderorientationobj['ReturnType'] = vReturnType;
			methoduoesliderorientationobj['index'] = index;
var vDescription = methoduoesliderorientationrow.find("[name=Description]").text();
			methoduoesliderorientationobj['Description'] = vDescription;
			methoduoesliderorientationobj['index'] = index;

	methoduoesliderorientationdata.push(methoduoesliderorientationobj);
});
return methoduoesliderorientationdata;
	}
function getRowstbluoesocialshare(){
	var tbluoesocialsharedata = [];
	tbluoesocialsharerows = $("#tbluoesocialshare tbody tr");
tbluoesocialsharerows.each(function (index) {
    var tbluoesocialsharerow = $(this);
 	var tbluoesocialshareobj = {};
	var vProperty = tbluoesocialsharerow.find("[name=Property]").text();
			tbluoesocialshareobj['Property'] = vProperty;
			tbluoesocialshareobj['index'] = index;
var vType = tbluoesocialsharerow.find("[name=Type]").text();
			tbluoesocialshareobj['Type'] = vType;
			tbluoesocialshareobj['index'] = index;
var vDefaultValue = tbluoesocialsharerow.find("[name=DefaultValue]").text();
			tbluoesocialshareobj['DefaultValue'] = vDefaultValue;
			tbluoesocialshareobj['index'] = index;
var vDescription = tbluoesocialsharerow.find("[name=Description]").text();
			tbluoesocialshareobj['Description'] = vDescription;
			tbluoesocialshareobj['index'] = index;

	tbluoesocialsharedata.push(tbluoesocialshareobj);
});
return tbluoesocialsharedata;
	}
function getRowsmethoduoesocialshare(){
	var methoduoesocialsharedata = [];
	methoduoesocialsharerows = $("#methoduoesocialshare tbody tr");
methoduoesocialsharerows.each(function (index) {
    var methoduoesocialsharerow = $(this);
 	var methoduoesocialshareobj = {};
	var vMethod = methoduoesocialsharerow.find("[name=Method]").text();
			methoduoesocialshareobj['Method'] = vMethod;
			methoduoesocialshareobj['index'] = index;
var vParameters = methoduoesocialsharerow.find("[name=Parameters]").text();
			methoduoesocialshareobj['Parameters'] = vParameters;
			methoduoesocialshareobj['index'] = index;
var vReturnType = methoduoesocialsharerow.find("[name=ReturnType]").text();
			methoduoesocialshareobj['ReturnType'] = vReturnType;
			methoduoesocialshareobj['index'] = index;
var vDescription = methoduoesocialsharerow.find("[name=Description]").text();
			methoduoesocialshareobj['Description'] = vDescription;
			methoduoesocialshareobj['index'] = index;

	methoduoesocialsharedata.push(methoduoesocialshareobj);
});
return methoduoesocialsharedata;
	}
function getRowstbluoesocialshareplatform(){
	var tbluoesocialshareplatformdata = [];
	tbluoesocialshareplatformrows = $("#tbluoesocialshareplatform tbody tr");
tbluoesocialshareplatformrows.each(function (index) {
    var tbluoesocialshareplatformrow = $(this);
 	var tbluoesocialshareplatformobj = {};
	var vProperty = tbluoesocialshareplatformrow.find("[name=Property]").text();
			tbluoesocialshareplatformobj['Property'] = vProperty;
			tbluoesocialshareplatformobj['index'] = index;
var vType = tbluoesocialshareplatformrow.find("[name=Type]").text();
			tbluoesocialshareplatformobj['Type'] = vType;
			tbluoesocialshareplatformobj['index'] = index;
var vDefaultValue = tbluoesocialshareplatformrow.find("[name=DefaultValue]").text();
			tbluoesocialshareplatformobj['DefaultValue'] = vDefaultValue;
			tbluoesocialshareplatformobj['index'] = index;
var vDescription = tbluoesocialshareplatformrow.find("[name=Description]").text();
			tbluoesocialshareplatformobj['Description'] = vDescription;
			tbluoesocialshareplatformobj['index'] = index;

	tbluoesocialshareplatformdata.push(tbluoesocialshareplatformobj);
});
return tbluoesocialshareplatformdata;
	}
function getRowsmethoduoesocialshareplatform(){
	var methoduoesocialshareplatformdata = [];
	methoduoesocialshareplatformrows = $("#methoduoesocialshareplatform tbody tr");
methoduoesocialshareplatformrows.each(function (index) {
    var methoduoesocialshareplatformrow = $(this);
 	var methoduoesocialshareplatformobj = {};
	var vMethod = methoduoesocialshareplatformrow.find("[name=Method]").text();
			methoduoesocialshareplatformobj['Method'] = vMethod;
			methoduoesocialshareplatformobj['index'] = index;
var vParameters = methoduoesocialshareplatformrow.find("[name=Parameters]").text();
			methoduoesocialshareplatformobj['Parameters'] = vParameters;
			methoduoesocialshareplatformobj['index'] = index;
var vReturnType = methoduoesocialshareplatformrow.find("[name=ReturnType]").text();
			methoduoesocialshareplatformobj['ReturnType'] = vReturnType;
			methoduoesocialshareplatformobj['index'] = index;
var vDescription = methoduoesocialshareplatformrow.find("[name=Description]").text();
			methoduoesocialshareplatformobj['Description'] = vDescription;
			methoduoesocialshareplatformobj['index'] = index;

	methoduoesocialshareplatformdata.push(methoduoesocialshareplatformobj);
});
return methoduoesocialshareplatformdata;
	}
function getRowstbluoesocialsharetheme(){
	var tbluoesocialsharethemedata = [];
	tbluoesocialsharethemerows = $("#tbluoesocialsharetheme tbody tr");
tbluoesocialsharethemerows.each(function (index) {
    var tbluoesocialsharethemerow = $(this);
 	var tbluoesocialsharethemeobj = {};
	var vProperty = tbluoesocialsharethemerow.find("[name=Property]").text();
			tbluoesocialsharethemeobj['Property'] = vProperty;
			tbluoesocialsharethemeobj['index'] = index;
var vType = tbluoesocialsharethemerow.find("[name=Type]").text();
			tbluoesocialsharethemeobj['Type'] = vType;
			tbluoesocialsharethemeobj['index'] = index;
var vDefaultValue = tbluoesocialsharethemerow.find("[name=DefaultValue]").text();
			tbluoesocialsharethemeobj['DefaultValue'] = vDefaultValue;
			tbluoesocialsharethemeobj['index'] = index;
var vDescription = tbluoesocialsharethemerow.find("[name=Description]").text();
			tbluoesocialsharethemeobj['Description'] = vDescription;
			tbluoesocialsharethemeobj['index'] = index;

	tbluoesocialsharethemedata.push(tbluoesocialsharethemeobj);
});
return tbluoesocialsharethemedata;
	}
function getRowsmethoduoesocialsharetheme(){
	var methoduoesocialsharethemedata = [];
	methoduoesocialsharethemerows = $("#methoduoesocialsharetheme tbody tr");
methoduoesocialsharethemerows.each(function (index) {
    var methoduoesocialsharethemerow = $(this);
 	var methoduoesocialsharethemeobj = {};
	var vMethod = methoduoesocialsharethemerow.find("[name=Method]").text();
			methoduoesocialsharethemeobj['Method'] = vMethod;
			methoduoesocialsharethemeobj['index'] = index;
var vParameters = methoduoesocialsharethemerow.find("[name=Parameters]").text();
			methoduoesocialsharethemeobj['Parameters'] = vParameters;
			methoduoesocialsharethemeobj['index'] = index;
var vReturnType = methoduoesocialsharethemerow.find("[name=ReturnType]").text();
			methoduoesocialsharethemeobj['ReturnType'] = vReturnType;
			methoduoesocialsharethemeobj['index'] = index;
var vDescription = methoduoesocialsharethemerow.find("[name=Description]").text();
			methoduoesocialsharethemeobj['Description'] = vDescription;
			methoduoesocialsharethemeobj['index'] = index;

	methoduoesocialsharethemedata.push(methoduoesocialsharethemeobj);
});
return methoduoesocialsharethemedata;
	}
function getRowstbluoespan(){
	var tbluoespandata = [];
	tbluoespanrows = $("#tbluoespan tbody tr");
tbluoespanrows.each(function (index) {
    var tbluoespanrow = $(this);
 	var tbluoespanobj = {};
	var vProperty = tbluoespanrow.find("[name=Property]").text();
			tbluoespanobj['Property'] = vProperty;
			tbluoespanobj['index'] = index;
var vType = tbluoespanrow.find("[name=Type]").text();
			tbluoespanobj['Type'] = vType;
			tbluoespanobj['index'] = index;
var vDefaultValue = tbluoespanrow.find("[name=DefaultValue]").text();
			tbluoespanobj['DefaultValue'] = vDefaultValue;
			tbluoespanobj['index'] = index;
var vDescription = tbluoespanrow.find("[name=Description]").text();
			tbluoespanobj['Description'] = vDescription;
			tbluoespanobj['index'] = index;

	tbluoespandata.push(tbluoespanobj);
});
return tbluoespandata;
	}
function getRowsmethoduoespan(){
	var methoduoespandata = [];
	methoduoespanrows = $("#methoduoespan tbody tr");
methoduoespanrows.each(function (index) {
    var methoduoespanrow = $(this);
 	var methoduoespanobj = {};
	var vMethod = methoduoespanrow.find("[name=Method]").text();
			methoduoespanobj['Method'] = vMethod;
			methoduoespanobj['index'] = index;
var vParameters = methoduoespanrow.find("[name=Parameters]").text();
			methoduoespanobj['Parameters'] = vParameters;
			methoduoespanobj['index'] = index;
var vReturnType = methoduoespanrow.find("[name=ReturnType]").text();
			methoduoespanobj['ReturnType'] = vReturnType;
			methoduoespanobj['index'] = index;
var vDescription = methoduoespanrow.find("[name=Description]").text();
			methoduoespanobj['Description'] = vDescription;
			methoduoespanobj['index'] = index;

	methoduoespandata.push(methoduoespanobj);
});
return methoduoespandata;
	}
function getRowstbluoesplitflap(){
	var tbluoesplitflapdata = [];
	tbluoesplitflaprows = $("#tbluoesplitflap tbody tr");
tbluoesplitflaprows.each(function (index) {
    var tbluoesplitflaprow = $(this);
 	var tbluoesplitflapobj = {};
	var vProperty = tbluoesplitflaprow.find("[name=Property]").text();
			tbluoesplitflapobj['Property'] = vProperty;
			tbluoesplitflapobj['index'] = index;
var vType = tbluoesplitflaprow.find("[name=Type]").text();
			tbluoesplitflapobj['Type'] = vType;
			tbluoesplitflapobj['index'] = index;
var vDefaultValue = tbluoesplitflaprow.find("[name=DefaultValue]").text();
			tbluoesplitflapobj['DefaultValue'] = vDefaultValue;
			tbluoesplitflapobj['index'] = index;
var vDescription = tbluoesplitflaprow.find("[name=Description]").text();
			tbluoesplitflapobj['Description'] = vDescription;
			tbluoesplitflapobj['index'] = index;

	tbluoesplitflapdata.push(tbluoesplitflapobj);
});
return tbluoesplitflapdata;
	}
function getRowsmethoduoesplitflap(){
	var methoduoesplitflapdata = [];
	methoduoesplitflaprows = $("#methoduoesplitflap tbody tr");
methoduoesplitflaprows.each(function (index) {
    var methoduoesplitflaprow = $(this);
 	var methoduoesplitflapobj = {};
	var vMethod = methoduoesplitflaprow.find("[name=Method]").text();
			methoduoesplitflapobj['Method'] = vMethod;
			methoduoesplitflapobj['index'] = index;
var vParameters = methoduoesplitflaprow.find("[name=Parameters]").text();
			methoduoesplitflapobj['Parameters'] = vParameters;
			methoduoesplitflapobj['index'] = index;
var vReturnType = methoduoesplitflaprow.find("[name=ReturnType]").text();
			methoduoesplitflapobj['ReturnType'] = vReturnType;
			methoduoesplitflapobj['index'] = index;
var vDescription = methoduoesplitflaprow.find("[name=Description]").text();
			methoduoesplitflapobj['Description'] = vDescription;
			methoduoesplitflapobj['index'] = index;

	methoduoesplitflapdata.push(methoduoesplitflapobj);
});
return methoduoesplitflapdata;
	}
function getRowstbluoesquire(){
	var tbluoesquiredata = [];
	tbluoesquirerows = $("#tbluoesquire tbody tr");
tbluoesquirerows.each(function (index) {
    var tbluoesquirerow = $(this);
 	var tbluoesquireobj = {};
	var vProperty = tbluoesquirerow.find("[name=Property]").text();
			tbluoesquireobj['Property'] = vProperty;
			tbluoesquireobj['index'] = index;
var vType = tbluoesquirerow.find("[name=Type]").text();
			tbluoesquireobj['Type'] = vType;
			tbluoesquireobj['index'] = index;
var vDefaultValue = tbluoesquirerow.find("[name=DefaultValue]").text();
			tbluoesquireobj['DefaultValue'] = vDefaultValue;
			tbluoesquireobj['index'] = index;
var vDescription = tbluoesquirerow.find("[name=Description]").text();
			tbluoesquireobj['Description'] = vDescription;
			tbluoesquireobj['index'] = index;

	tbluoesquiredata.push(tbluoesquireobj);
});
return tbluoesquiredata;
	}
function getRowsmethoduoesquire(){
	var methoduoesquiredata = [];
	methoduoesquirerows = $("#methoduoesquire tbody tr");
methoduoesquirerows.each(function (index) {
    var methoduoesquirerow = $(this);
 	var methoduoesquireobj = {};
	var vMethod = methoduoesquirerow.find("[name=Method]").text();
			methoduoesquireobj['Method'] = vMethod;
			methoduoesquireobj['index'] = index;
var vParameters = methoduoesquirerow.find("[name=Parameters]").text();
			methoduoesquireobj['Parameters'] = vParameters;
			methoduoesquireobj['index'] = index;
var vReturnType = methoduoesquirerow.find("[name=ReturnType]").text();
			methoduoesquireobj['ReturnType'] = vReturnType;
			methoduoesquireobj['index'] = index;
var vDescription = methoduoesquirerow.find("[name=Description]").text();
			methoduoesquireobj['Description'] = vDescription;
			methoduoesquireobj['index'] = index;

	methoduoesquiredata.push(methoduoesquireobj);
});
return methoduoesquiredata;
	}
function getRowstbluoestatstype(){
	var tbluoestatstypedata = [];
	tbluoestatstyperows = $("#tbluoestatstype tbody tr");
tbluoestatstyperows.each(function (index) {
    var tbluoestatstyperow = $(this);
 	var tbluoestatstypeobj = {};
	var vProperty = tbluoestatstyperow.find("[name=Property]").text();
			tbluoestatstypeobj['Property'] = vProperty;
			tbluoestatstypeobj['index'] = index;
var vType = tbluoestatstyperow.find("[name=Type]").text();
			tbluoestatstypeobj['Type'] = vType;
			tbluoestatstypeobj['index'] = index;
var vDefaultValue = tbluoestatstyperow.find("[name=DefaultValue]").text();
			tbluoestatstypeobj['DefaultValue'] = vDefaultValue;
			tbluoestatstypeobj['index'] = index;
var vDescription = tbluoestatstyperow.find("[name=Description]").text();
			tbluoestatstypeobj['Description'] = vDescription;
			tbluoestatstypeobj['index'] = index;

	tbluoestatstypedata.push(tbluoestatstypeobj);
});
return tbluoestatstypedata;
	}
function getRowsmethoduoestatstype(){
	var methoduoestatstypedata = [];
	methoduoestatstyperows = $("#methoduoestatstype tbody tr");
methoduoestatstyperows.each(function (index) {
    var methoduoestatstyperow = $(this);
 	var methoduoestatstypeobj = {};
	var vMethod = methoduoestatstyperow.find("[name=Method]").text();
			methoduoestatstypeobj['Method'] = vMethod;
			methoduoestatstypeobj['index'] = index;
var vParameters = methoduoestatstyperow.find("[name=Parameters]").text();
			methoduoestatstypeobj['Parameters'] = vParameters;
			methoduoestatstypeobj['index'] = index;
var vReturnType = methoduoestatstyperow.find("[name=ReturnType]").text();
			methoduoestatstypeobj['ReturnType'] = vReturnType;
			methoduoestatstypeobj['index'] = index;
var vDescription = methoduoestatstyperow.find("[name=Description]").text();
			methoduoestatstypeobj['Description'] = vDescription;
			methoduoestatstypeobj['index'] = index;

	methoduoestatstypedata.push(methoduoestatstypeobj);
});
return methoduoestatstypedata;
	}
function getRowstbluoesubmarkerdirectiontype(){
	var tbluoesubmarkerdirectiontypedata = [];
	tbluoesubmarkerdirectiontyperows = $("#tbluoesubmarkerdirectiontype tbody tr");
tbluoesubmarkerdirectiontyperows.each(function (index) {
    var tbluoesubmarkerdirectiontyperow = $(this);
 	var tbluoesubmarkerdirectiontypeobj = {};
	var vProperty = tbluoesubmarkerdirectiontyperow.find("[name=Property]").text();
			tbluoesubmarkerdirectiontypeobj['Property'] = vProperty;
			tbluoesubmarkerdirectiontypeobj['index'] = index;
var vType = tbluoesubmarkerdirectiontyperow.find("[name=Type]").text();
			tbluoesubmarkerdirectiontypeobj['Type'] = vType;
			tbluoesubmarkerdirectiontypeobj['index'] = index;
var vDefaultValue = tbluoesubmarkerdirectiontyperow.find("[name=DefaultValue]").text();
			tbluoesubmarkerdirectiontypeobj['DefaultValue'] = vDefaultValue;
			tbluoesubmarkerdirectiontypeobj['index'] = index;
var vDescription = tbluoesubmarkerdirectiontyperow.find("[name=Description]").text();
			tbluoesubmarkerdirectiontypeobj['Description'] = vDescription;
			tbluoesubmarkerdirectiontypeobj['index'] = index;

	tbluoesubmarkerdirectiontypedata.push(tbluoesubmarkerdirectiontypeobj);
});
return tbluoesubmarkerdirectiontypedata;
	}
function getRowsmethoduoesubmarkerdirectiontype(){
	var methoduoesubmarkerdirectiontypedata = [];
	methoduoesubmarkerdirectiontyperows = $("#methoduoesubmarkerdirectiontype tbody tr");
methoduoesubmarkerdirectiontyperows.each(function (index) {
    var methoduoesubmarkerdirectiontyperow = $(this);
 	var methoduoesubmarkerdirectiontypeobj = {};
	var vMethod = methoduoesubmarkerdirectiontyperow.find("[name=Method]").text();
			methoduoesubmarkerdirectiontypeobj['Method'] = vMethod;
			methoduoesubmarkerdirectiontypeobj['index'] = index;
var vParameters = methoduoesubmarkerdirectiontyperow.find("[name=Parameters]").text();
			methoduoesubmarkerdirectiontypeobj['Parameters'] = vParameters;
			methoduoesubmarkerdirectiontypeobj['index'] = index;
var vReturnType = methoduoesubmarkerdirectiontyperow.find("[name=ReturnType]").text();
			methoduoesubmarkerdirectiontypeobj['ReturnType'] = vReturnType;
			methoduoesubmarkerdirectiontypeobj['index'] = index;
var vDescription = methoduoesubmarkerdirectiontyperow.find("[name=Description]").text();
			methoduoesubmarkerdirectiontypeobj['Description'] = vDescription;
			methoduoesubmarkerdirectiontypeobj['index'] = index;

	methoduoesubmarkerdirectiontypedata.push(methoduoesubmarkerdirectiontypeobj);
});
return methoduoesubmarkerdirectiontypedata;
	}
function getRowstbluoesubmarkerinfotype(){
	var tbluoesubmarkerinfotypedata = [];
	tbluoesubmarkerinfotyperows = $("#tbluoesubmarkerinfotype tbody tr");
tbluoesubmarkerinfotyperows.each(function (index) {
    var tbluoesubmarkerinfotyperow = $(this);
 	var tbluoesubmarkerinfotypeobj = {};
	var vProperty = tbluoesubmarkerinfotyperow.find("[name=Property]").text();
			tbluoesubmarkerinfotypeobj['Property'] = vProperty;
			tbluoesubmarkerinfotypeobj['index'] = index;
var vType = tbluoesubmarkerinfotyperow.find("[name=Type]").text();
			tbluoesubmarkerinfotypeobj['Type'] = vType;
			tbluoesubmarkerinfotypeobj['index'] = index;
var vDefaultValue = tbluoesubmarkerinfotyperow.find("[name=DefaultValue]").text();
			tbluoesubmarkerinfotypeobj['DefaultValue'] = vDefaultValue;
			tbluoesubmarkerinfotypeobj['index'] = index;
var vDescription = tbluoesubmarkerinfotyperow.find("[name=Description]").text();
			tbluoesubmarkerinfotypeobj['Description'] = vDescription;
			tbluoesubmarkerinfotypeobj['index'] = index;

	tbluoesubmarkerinfotypedata.push(tbluoesubmarkerinfotypeobj);
});
return tbluoesubmarkerinfotypedata;
	}
function getRowsmethoduoesubmarkerinfotype(){
	var methoduoesubmarkerinfotypedata = [];
	methoduoesubmarkerinfotyperows = $("#methoduoesubmarkerinfotype tbody tr");
methoduoesubmarkerinfotyperows.each(function (index) {
    var methoduoesubmarkerinfotyperow = $(this);
 	var methoduoesubmarkerinfotypeobj = {};
	var vMethod = methoduoesubmarkerinfotyperow.find("[name=Method]").text();
			methoduoesubmarkerinfotypeobj['Method'] = vMethod;
			methoduoesubmarkerinfotypeobj['index'] = index;
var vParameters = methoduoesubmarkerinfotyperow.find("[name=Parameters]").text();
			methoduoesubmarkerinfotypeobj['Parameters'] = vParameters;
			methoduoesubmarkerinfotypeobj['index'] = index;
var vReturnType = methoduoesubmarkerinfotyperow.find("[name=ReturnType]").text();
			methoduoesubmarkerinfotypeobj['ReturnType'] = vReturnType;
			methoduoesubmarkerinfotypeobj['index'] = index;
var vDescription = methoduoesubmarkerinfotyperow.find("[name=Description]").text();
			methoduoesubmarkerinfotypeobj['Description'] = vDescription;
			methoduoesubmarkerinfotypeobj['index'] = index;

	methoduoesubmarkerinfotypedata.push(methoduoesubmarkerinfotypeobj);
});
return methoduoesubmarkerinfotypedata;
	}
function getRowstbluoesubmarkerpostype(){
	var tbluoesubmarkerpostypedata = [];
	tbluoesubmarkerpostyperows = $("#tbluoesubmarkerpostype tbody tr");
tbluoesubmarkerpostyperows.each(function (index) {
    var tbluoesubmarkerpostyperow = $(this);
 	var tbluoesubmarkerpostypeobj = {};
	var vProperty = tbluoesubmarkerpostyperow.find("[name=Property]").text();
			tbluoesubmarkerpostypeobj['Property'] = vProperty;
			tbluoesubmarkerpostypeobj['index'] = index;
var vType = tbluoesubmarkerpostyperow.find("[name=Type]").text();
			tbluoesubmarkerpostypeobj['Type'] = vType;
			tbluoesubmarkerpostypeobj['index'] = index;
var vDefaultValue = tbluoesubmarkerpostyperow.find("[name=DefaultValue]").text();
			tbluoesubmarkerpostypeobj['DefaultValue'] = vDefaultValue;
			tbluoesubmarkerpostypeobj['index'] = index;
var vDescription = tbluoesubmarkerpostyperow.find("[name=Description]").text();
			tbluoesubmarkerpostypeobj['Description'] = vDescription;
			tbluoesubmarkerpostypeobj['index'] = index;

	tbluoesubmarkerpostypedata.push(tbluoesubmarkerpostypeobj);
});
return tbluoesubmarkerpostypedata;
	}
function getRowsmethoduoesubmarkerpostype(){
	var methoduoesubmarkerpostypedata = [];
	methoduoesubmarkerpostyperows = $("#methoduoesubmarkerpostype tbody tr");
methoduoesubmarkerpostyperows.each(function (index) {
    var methoduoesubmarkerpostyperow = $(this);
 	var methoduoesubmarkerpostypeobj = {};
	var vMethod = methoduoesubmarkerpostyperow.find("[name=Method]").text();
			methoduoesubmarkerpostypeobj['Method'] = vMethod;
			methoduoesubmarkerpostypeobj['index'] = index;
var vParameters = methoduoesubmarkerpostyperow.find("[name=Parameters]").text();
			methoduoesubmarkerpostypeobj['Parameters'] = vParameters;
			methoduoesubmarkerpostypeobj['index'] = index;
var vReturnType = methoduoesubmarkerpostyperow.find("[name=ReturnType]").text();
			methoduoesubmarkerpostypeobj['ReturnType'] = vReturnType;
			methoduoesubmarkerpostypeobj['index'] = index;
var vDescription = methoduoesubmarkerpostyperow.find("[name=Description]").text();
			methoduoesubmarkerpostypeobj['Description'] = vDescription;
			methoduoesubmarkerpostypeobj['index'] = index;

	methoduoesubmarkerpostypedata.push(methoduoesubmarkerpostypeobj);
});
return methoduoesubmarkerpostypedata;
	}
function getRowstbluoesubmarkertype(){
	var tbluoesubmarkertypedata = [];
	tbluoesubmarkertyperows = $("#tbluoesubmarkertype tbody tr");
tbluoesubmarkertyperows.each(function (index) {
    var tbluoesubmarkertyperow = $(this);
 	var tbluoesubmarkertypeobj = {};
	var vProperty = tbluoesubmarkertyperow.find("[name=Property]").text();
			tbluoesubmarkertypeobj['Property'] = vProperty;
			tbluoesubmarkertypeobj['index'] = index;
var vType = tbluoesubmarkertyperow.find("[name=Type]").text();
			tbluoesubmarkertypeobj['Type'] = vType;
			tbluoesubmarkertypeobj['index'] = index;
var vDefaultValue = tbluoesubmarkertyperow.find("[name=DefaultValue]").text();
			tbluoesubmarkertypeobj['DefaultValue'] = vDefaultValue;
			tbluoesubmarkertypeobj['index'] = index;
var vDescription = tbluoesubmarkertyperow.find("[name=Description]").text();
			tbluoesubmarkertypeobj['Description'] = vDescription;
			tbluoesubmarkertypeobj['index'] = index;

	tbluoesubmarkertypedata.push(tbluoesubmarkertypeobj);
});
return tbluoesubmarkertypedata;
	}
function getRowsmethoduoesubmarkertype(){
	var methoduoesubmarkertypedata = [];
	methoduoesubmarkertyperows = $("#methoduoesubmarkertype tbody tr");
methoduoesubmarkertyperows.each(function (index) {
    var methoduoesubmarkertyperow = $(this);
 	var methoduoesubmarkertypeobj = {};
	var vMethod = methoduoesubmarkertyperow.find("[name=Method]").text();
			methoduoesubmarkertypeobj['Method'] = vMethod;
			methoduoesubmarkertypeobj['index'] = index;
var vParameters = methoduoesubmarkertyperow.find("[name=Parameters]").text();
			methoduoesubmarkertypeobj['Parameters'] = vParameters;
			methoduoesubmarkertypeobj['index'] = index;
var vReturnType = methoduoesubmarkertyperow.find("[name=ReturnType]").text();
			methoduoesubmarkertypeobj['ReturnType'] = vReturnType;
			methoduoesubmarkertypeobj['index'] = index;
var vDescription = methoduoesubmarkertyperow.find("[name=Description]").text();
			methoduoesubmarkertypeobj['Description'] = vDescription;
			methoduoesubmarkertypeobj['index'] = index;

	methoduoesubmarkertypedata.push(methoduoesubmarkertypeobj);
});
return methoduoesubmarkertypedata;
	}
function getRowstbluoesubway(){
	var tbluoesubwaydata = [];
	tbluoesubwayrows = $("#tbluoesubway tbody tr");
tbluoesubwayrows.each(function (index) {
    var tbluoesubwayrow = $(this);
 	var tbluoesubwayobj = {};
	var vProperty = tbluoesubwayrow.find("[name=Property]").text();
			tbluoesubwayobj['Property'] = vProperty;
			tbluoesubwayobj['index'] = index;
var vType = tbluoesubwayrow.find("[name=Type]").text();
			tbluoesubwayobj['Type'] = vType;
			tbluoesubwayobj['index'] = index;
var vDefaultValue = tbluoesubwayrow.find("[name=DefaultValue]").text();
			tbluoesubwayobj['DefaultValue'] = vDefaultValue;
			tbluoesubwayobj['index'] = index;
var vDescription = tbluoesubwayrow.find("[name=Description]").text();
			tbluoesubwayobj['Description'] = vDescription;
			tbluoesubwayobj['index'] = index;

	tbluoesubwaydata.push(tbluoesubwayobj);
});
return tbluoesubwaydata;
	}
function getRowsmethoduoesubway(){
	var methoduoesubwaydata = [];
	methoduoesubwayrows = $("#methoduoesubway tbody tr");
methoduoesubwayrows.each(function (index) {
    var methoduoesubwayrow = $(this);
 	var methoduoesubwayobj = {};
	var vMethod = methoduoesubwayrow.find("[name=Method]").text();
			methoduoesubwayobj['Method'] = vMethod;
			methoduoesubwayobj['index'] = index;
var vParameters = methoduoesubwayrow.find("[name=Parameters]").text();
			methoduoesubwayobj['Parameters'] = vParameters;
			methoduoesubwayobj['index'] = index;
var vReturnType = methoduoesubwayrow.find("[name=ReturnType]").text();
			methoduoesubwayobj['ReturnType'] = vReturnType;
			methoduoesubwayobj['index'] = index;
var vDescription = methoduoesubwayrow.find("[name=Description]").text();
			methoduoesubwayobj['Description'] = vDescription;
			methoduoesubwayobj['index'] = index;

	methoduoesubwaydata.push(methoduoesubwayobj);
});
return methoduoesubwaydata;
	}
function getRowstbluoesubwayitem(){
	var tbluoesubwayitemdata = [];
	tbluoesubwayitemrows = $("#tbluoesubwayitem tbody tr");
tbluoesubwayitemrows.each(function (index) {
    var tbluoesubwayitemrow = $(this);
 	var tbluoesubwayitemobj = {};
	var vProperty = tbluoesubwayitemrow.find("[name=Property]").text();
			tbluoesubwayitemobj['Property'] = vProperty;
			tbluoesubwayitemobj['index'] = index;
var vType = tbluoesubwayitemrow.find("[name=Type]").text();
			tbluoesubwayitemobj['Type'] = vType;
			tbluoesubwayitemobj['index'] = index;
var vDefaultValue = tbluoesubwayitemrow.find("[name=DefaultValue]").text();
			tbluoesubwayitemobj['DefaultValue'] = vDefaultValue;
			tbluoesubwayitemobj['index'] = index;
var vDescription = tbluoesubwayitemrow.find("[name=Description]").text();
			tbluoesubwayitemobj['Description'] = vDescription;
			tbluoesubwayitemobj['index'] = index;

	tbluoesubwayitemdata.push(tbluoesubwayitemobj);
});
return tbluoesubwayitemdata;
	}
function getRowsmethoduoesubwayitem(){
	var methoduoesubwayitemdata = [];
	methoduoesubwayitemrows = $("#methoduoesubwayitem tbody tr");
methoduoesubwayitemrows.each(function (index) {
    var methoduoesubwayitemrow = $(this);
 	var methoduoesubwayitemobj = {};
	var vMethod = methoduoesubwayitemrow.find("[name=Method]").text();
			methoduoesubwayitemobj['Method'] = vMethod;
			methoduoesubwayitemobj['index'] = index;
var vParameters = methoduoesubwayitemrow.find("[name=Parameters]").text();
			methoduoesubwayitemobj['Parameters'] = vParameters;
			methoduoesubwayitemobj['index'] = index;
var vReturnType = methoduoesubwayitemrow.find("[name=ReturnType]").text();
			methoduoesubwayitemobj['ReturnType'] = vReturnType;
			methoduoesubwayitemobj['index'] = index;
var vDescription = methoduoesubwayitemrow.find("[name=Description]").text();
			methoduoesubwayitemobj['Description'] = vDescription;
			methoduoesubwayitemobj['index'] = index;

	methoduoesubwayitemdata.push(methoduoesubwayitemobj);
});
return methoduoesubwayitemdata;
	}
function getRowstbluoesweetmodal(){
	var tbluoesweetmodaldata = [];
	tbluoesweetmodalrows = $("#tbluoesweetmodal tbody tr");
tbluoesweetmodalrows.each(function (index) {
    var tbluoesweetmodalrow = $(this);
 	var tbluoesweetmodalobj = {};
	var vProperty = tbluoesweetmodalrow.find("[name=Property]").text();
			tbluoesweetmodalobj['Property'] = vProperty;
			tbluoesweetmodalobj['index'] = index;
var vType = tbluoesweetmodalrow.find("[name=Type]").text();
			tbluoesweetmodalobj['Type'] = vType;
			tbluoesweetmodalobj['index'] = index;
var vDefaultValue = tbluoesweetmodalrow.find("[name=DefaultValue]").text();
			tbluoesweetmodalobj['DefaultValue'] = vDefaultValue;
			tbluoesweetmodalobj['index'] = index;
var vDescription = tbluoesweetmodalrow.find("[name=Description]").text();
			tbluoesweetmodalobj['Description'] = vDescription;
			tbluoesweetmodalobj['index'] = index;

	tbluoesweetmodaldata.push(tbluoesweetmodalobj);
});
return tbluoesweetmodaldata;
	}
function getRowsmethoduoesweetmodal(){
	var methoduoesweetmodaldata = [];
	methoduoesweetmodalrows = $("#methoduoesweetmodal tbody tr");
methoduoesweetmodalrows.each(function (index) {
    var methoduoesweetmodalrow = $(this);
 	var methoduoesweetmodalobj = {};
	var vMethod = methoduoesweetmodalrow.find("[name=Method]").text();
			methoduoesweetmodalobj['Method'] = vMethod;
			methoduoesweetmodalobj['index'] = index;
var vParameters = methoduoesweetmodalrow.find("[name=Parameters]").text();
			methoduoesweetmodalobj['Parameters'] = vParameters;
			methoduoesweetmodalobj['index'] = index;
var vReturnType = methoduoesweetmodalrow.find("[name=ReturnType]").text();
			methoduoesweetmodalobj['ReturnType'] = vReturnType;
			methoduoesweetmodalobj['index'] = index;
var vDescription = methoduoesweetmodalrow.find("[name=Description]").text();
			methoduoesweetmodalobj['Description'] = vDescription;
			methoduoesweetmodalobj['index'] = index;

	methoduoesweetmodaldata.push(methoduoesweetmodalobj);
});
return methoduoesweetmodaldata;
	}
function getRowstbluoeswitch(){
	var tbluoeswitchdata = [];
	tbluoeswitchrows = $("#tbluoeswitch tbody tr");
tbluoeswitchrows.each(function (index) {
    var tbluoeswitchrow = $(this);
 	var tbluoeswitchobj = {};
	var vProperty = tbluoeswitchrow.find("[name=Property]").text();
			tbluoeswitchobj['Property'] = vProperty;
			tbluoeswitchobj['index'] = index;
var vType = tbluoeswitchrow.find("[name=Type]").text();
			tbluoeswitchobj['Type'] = vType;
			tbluoeswitchobj['index'] = index;
var vDefaultValue = tbluoeswitchrow.find("[name=DefaultValue]").text();
			tbluoeswitchobj['DefaultValue'] = vDefaultValue;
			tbluoeswitchobj['index'] = index;
var vDescription = tbluoeswitchrow.find("[name=Description]").text();
			tbluoeswitchobj['Description'] = vDescription;
			tbluoeswitchobj['index'] = index;

	tbluoeswitchdata.push(tbluoeswitchobj);
});
return tbluoeswitchdata;
	}
function getRowsmethoduoeswitch(){
	var methoduoeswitchdata = [];
	methoduoeswitchrows = $("#methoduoeswitch tbody tr");
methoduoeswitchrows.each(function (index) {
    var methoduoeswitchrow = $(this);
 	var methoduoeswitchobj = {};
	var vMethod = methoduoeswitchrow.find("[name=Method]").text();
			methoduoeswitchobj['Method'] = vMethod;
			methoduoeswitchobj['index'] = index;
var vParameters = methoduoeswitchrow.find("[name=Parameters]").text();
			methoduoeswitchobj['Parameters'] = vParameters;
			methoduoeswitchobj['index'] = index;
var vReturnType = methoduoeswitchrow.find("[name=ReturnType]").text();
			methoduoeswitchobj['ReturnType'] = vReturnType;
			methoduoeswitchobj['index'] = index;
var vDescription = methoduoeswitchrow.find("[name=Description]").text();
			methoduoeswitchobj['Description'] = vDescription;
			methoduoeswitchobj['index'] = index;

	methoduoeswitchdata.push(methoduoeswitchobj);
});
return methoduoeswitchdata;
	}
function getRowstbluoetable(){
	var tbluoetabledata = [];
	tbluoetablerows = $("#tbluoetable tbody tr");
tbluoetablerows.each(function (index) {
    var tbluoetablerow = $(this);
 	var tbluoetableobj = {};
	var vProperty = tbluoetablerow.find("[name=Property]").text();
			tbluoetableobj['Property'] = vProperty;
			tbluoetableobj['index'] = index;
var vType = tbluoetablerow.find("[name=Type]").text();
			tbluoetableobj['Type'] = vType;
			tbluoetableobj['index'] = index;
var vDefaultValue = tbluoetablerow.find("[name=DefaultValue]").text();
			tbluoetableobj['DefaultValue'] = vDefaultValue;
			tbluoetableobj['index'] = index;
var vDescription = tbluoetablerow.find("[name=Description]").text();
			tbluoetableobj['Description'] = vDescription;
			tbluoetableobj['index'] = index;

	tbluoetabledata.push(tbluoetableobj);
});
return tbluoetabledata;
	}
function getRowsmethoduoetable(){
	var methoduoetabledata = [];
	methoduoetablerows = $("#methoduoetable tbody tr");
methoduoetablerows.each(function (index) {
    var methoduoetablerow = $(this);
 	var methoduoetableobj = {};
	var vMethod = methoduoetablerow.find("[name=Method]").text();
			methoduoetableobj['Method'] = vMethod;
			methoduoetableobj['index'] = index;
var vParameters = methoduoetablerow.find("[name=Parameters]").text();
			methoduoetableobj['Parameters'] = vParameters;
			methoduoetableobj['index'] = index;
var vReturnType = methoduoetablerow.find("[name=ReturnType]").text();
			methoduoetableobj['ReturnType'] = vReturnType;
			methoduoetableobj['index'] = index;
var vDescription = methoduoetablerow.find("[name=Description]").text();
			methoduoetableobj['Description'] = vDescription;
			methoduoetableobj['index'] = index;

	methoduoetabledata.push(methoduoetableobj);
});
return methoduoetabledata;
	}
function getRowstbluoetableexport(){
	var tbluoetableexportdata = [];
	tbluoetableexportrows = $("#tbluoetableexport tbody tr");
tbluoetableexportrows.each(function (index) {
    var tbluoetableexportrow = $(this);
 	var tbluoetableexportobj = {};
	var vProperty = tbluoetableexportrow.find("[name=Property]").text();
			tbluoetableexportobj['Property'] = vProperty;
			tbluoetableexportobj['index'] = index;
var vType = tbluoetableexportrow.find("[name=Type]").text();
			tbluoetableexportobj['Type'] = vType;
			tbluoetableexportobj['index'] = index;
var vDefaultValue = tbluoetableexportrow.find("[name=DefaultValue]").text();
			tbluoetableexportobj['DefaultValue'] = vDefaultValue;
			tbluoetableexportobj['index'] = index;
var vDescription = tbluoetableexportrow.find("[name=Description]").text();
			tbluoetableexportobj['Description'] = vDescription;
			tbluoetableexportobj['index'] = index;

	tbluoetableexportdata.push(tbluoetableexportobj);
});
return tbluoetableexportdata;
	}
function getRowsmethoduoetableexport(){
	var methoduoetableexportdata = [];
	methoduoetableexportrows = $("#methoduoetableexport tbody tr");
methoduoetableexportrows.each(function (index) {
    var methoduoetableexportrow = $(this);
 	var methoduoetableexportobj = {};
	var vMethod = methoduoetableexportrow.find("[name=Method]").text();
			methoduoetableexportobj['Method'] = vMethod;
			methoduoetableexportobj['index'] = index;
var vParameters = methoduoetableexportrow.find("[name=Parameters]").text();
			methoduoetableexportobj['Parameters'] = vParameters;
			methoduoetableexportobj['index'] = index;
var vReturnType = methoduoetableexportrow.find("[name=ReturnType]").text();
			methoduoetableexportobj['ReturnType'] = vReturnType;
			methoduoetableexportobj['index'] = index;
var vDescription = methoduoetableexportrow.find("[name=Description]").text();
			methoduoetableexportobj['Description'] = vDescription;
			methoduoetableexportobj['index'] = index;

	methoduoetableexportdata.push(methoduoetableexportobj);
});
return methoduoetableexportdata;
	}
function getRowstbluoetabs(){
	var tbluoetabsdata = [];
	tbluoetabsrows = $("#tbluoetabs tbody tr");
tbluoetabsrows.each(function (index) {
    var tbluoetabsrow = $(this);
 	var tbluoetabsobj = {};
	var vProperty = tbluoetabsrow.find("[name=Property]").text();
			tbluoetabsobj['Property'] = vProperty;
			tbluoetabsobj['index'] = index;
var vType = tbluoetabsrow.find("[name=Type]").text();
			tbluoetabsobj['Type'] = vType;
			tbluoetabsobj['index'] = index;
var vDefaultValue = tbluoetabsrow.find("[name=DefaultValue]").text();
			tbluoetabsobj['DefaultValue'] = vDefaultValue;
			tbluoetabsobj['index'] = index;
var vDescription = tbluoetabsrow.find("[name=Description]").text();
			tbluoetabsobj['Description'] = vDescription;
			tbluoetabsobj['index'] = index;

	tbluoetabsdata.push(tbluoetabsobj);
});
return tbluoetabsdata;
	}
function getRowsmethoduoetabs(){
	var methoduoetabsdata = [];
	methoduoetabsrows = $("#methoduoetabs tbody tr");
methoduoetabsrows.each(function (index) {
    var methoduoetabsrow = $(this);
 	var methoduoetabsobj = {};
	var vMethod = methoduoetabsrow.find("[name=Method]").text();
			methoduoetabsobj['Method'] = vMethod;
			methoduoetabsobj['index'] = index;
var vParameters = methoduoetabsrow.find("[name=Parameters]").text();
			methoduoetabsobj['Parameters'] = vParameters;
			methoduoetabsobj['index'] = index;
var vReturnType = methoduoetabsrow.find("[name=ReturnType]").text();
			methoduoetabsobj['ReturnType'] = vReturnType;
			methoduoetabsobj['index'] = index;
var vDescription = methoduoetabsrow.find("[name=Description]").text();
			methoduoetabsobj['Description'] = vDescription;
			methoduoetabsobj['index'] = index;

	methoduoetabsdata.push(methoduoetabsobj);
});
return methoduoetabsdata;
	}
function getRowstbluoetarget(){
	var tbluoetargetdata = [];
	tbluoetargetrows = $("#tbluoetarget tbody tr");
tbluoetargetrows.each(function (index) {
    var tbluoetargetrow = $(this);
 	var tbluoetargetobj = {};
	var vProperty = tbluoetargetrow.find("[name=Property]").text();
			tbluoetargetobj['Property'] = vProperty;
			tbluoetargetobj['index'] = index;
var vType = tbluoetargetrow.find("[name=Type]").text();
			tbluoetargetobj['Type'] = vType;
			tbluoetargetobj['index'] = index;
var vDefaultValue = tbluoetargetrow.find("[name=DefaultValue]").text();
			tbluoetargetobj['DefaultValue'] = vDefaultValue;
			tbluoetargetobj['index'] = index;
var vDescription = tbluoetargetrow.find("[name=Description]").text();
			tbluoetargetobj['Description'] = vDescription;
			tbluoetargetobj['index'] = index;

	tbluoetargetdata.push(tbluoetargetobj);
});
return tbluoetargetdata;
	}
function getRowsmethoduoetarget(){
	var methoduoetargetdata = [];
	methoduoetargetrows = $("#methoduoetarget tbody tr");
methoduoetargetrows.each(function (index) {
    var methoduoetargetrow = $(this);
 	var methoduoetargetobj = {};
	var vMethod = methoduoetargetrow.find("[name=Method]").text();
			methoduoetargetobj['Method'] = vMethod;
			methoduoetargetobj['index'] = index;
var vParameters = methoduoetargetrow.find("[name=Parameters]").text();
			methoduoetargetobj['Parameters'] = vParameters;
			methoduoetargetobj['index'] = index;
var vReturnType = methoduoetargetrow.find("[name=ReturnType]").text();
			methoduoetargetobj['ReturnType'] = vReturnType;
			methoduoetargetobj['index'] = index;
var vDescription = methoduoetargetrow.find("[name=Description]").text();
			methoduoetargetobj['Description'] = vDescription;
			methoduoetargetobj['index'] = index;

	methoduoetargetdata.push(methoduoetargetobj);
});
return methoduoetargetdata;
	}
function getRowstbluoetextalignment(){
	var tbluoetextalignmentdata = [];
	tbluoetextalignmentrows = $("#tbluoetextalignment tbody tr");
tbluoetextalignmentrows.each(function (index) {
    var tbluoetextalignmentrow = $(this);
 	var tbluoetextalignmentobj = {};
	var vProperty = tbluoetextalignmentrow.find("[name=Property]").text();
			tbluoetextalignmentobj['Property'] = vProperty;
			tbluoetextalignmentobj['index'] = index;
var vType = tbluoetextalignmentrow.find("[name=Type]").text();
			tbluoetextalignmentobj['Type'] = vType;
			tbluoetextalignmentobj['index'] = index;
var vDefaultValue = tbluoetextalignmentrow.find("[name=DefaultValue]").text();
			tbluoetextalignmentobj['DefaultValue'] = vDefaultValue;
			tbluoetextalignmentobj['index'] = index;
var vDescription = tbluoetextalignmentrow.find("[name=Description]").text();
			tbluoetextalignmentobj['Description'] = vDescription;
			tbluoetextalignmentobj['index'] = index;

	tbluoetextalignmentdata.push(tbluoetextalignmentobj);
});
return tbluoetextalignmentdata;
	}
function getRowsmethoduoetextalignment(){
	var methoduoetextalignmentdata = [];
	methoduoetextalignmentrows = $("#methoduoetextalignment tbody tr");
methoduoetextalignmentrows.each(function (index) {
    var methoduoetextalignmentrow = $(this);
 	var methoduoetextalignmentobj = {};
	var vMethod = methoduoetextalignmentrow.find("[name=Method]").text();
			methoduoetextalignmentobj['Method'] = vMethod;
			methoduoetextalignmentobj['index'] = index;
var vParameters = methoduoetextalignmentrow.find("[name=Parameters]").text();
			methoduoetextalignmentobj['Parameters'] = vParameters;
			methoduoetextalignmentobj['index'] = index;
var vReturnType = methoduoetextalignmentrow.find("[name=ReturnType]").text();
			methoduoetextalignmentobj['ReturnType'] = vReturnType;
			methoduoetextalignmentobj['index'] = index;
var vDescription = methoduoetextalignmentrow.find("[name=Description]").text();
			methoduoetextalignmentobj['Description'] = vDescription;
			methoduoetextalignmentobj['index'] = index;

	methoduoetextalignmentdata.push(methoduoetextalignmentobj);
});
return methoduoetextalignmentdata;
	}
function getRowstbluoetheme(){
	var tbluoethemedata = [];
	tbluoethemerows = $("#tbluoetheme tbody tr");
tbluoethemerows.each(function (index) {
    var tbluoethemerow = $(this);
 	var tbluoethemeobj = {};
	var vProperty = tbluoethemerow.find("[name=Property]").text();
			tbluoethemeobj['Property'] = vProperty;
			tbluoethemeobj['index'] = index;
var vType = tbluoethemerow.find("[name=Type]").text();
			tbluoethemeobj['Type'] = vType;
			tbluoethemeobj['index'] = index;
var vDefaultValue = tbluoethemerow.find("[name=DefaultValue]").text();
			tbluoethemeobj['DefaultValue'] = vDefaultValue;
			tbluoethemeobj['index'] = index;
var vDescription = tbluoethemerow.find("[name=Description]").text();
			tbluoethemeobj['Description'] = vDescription;
			tbluoethemeobj['index'] = index;

	tbluoethemedata.push(tbluoethemeobj);
});
return tbluoethemedata;
	}
function getRowsmethoduoetheme(){
	var methoduoethemedata = [];
	methoduoethemerows = $("#methoduoetheme tbody tr");
methoduoethemerows.each(function (index) {
    var methoduoethemerow = $(this);
 	var methoduoethemeobj = {};
	var vMethod = methoduoethemerow.find("[name=Method]").text();
			methoduoethemeobj['Method'] = vMethod;
			methoduoethemeobj['index'] = index;
var vParameters = methoduoethemerow.find("[name=Parameters]").text();
			methoduoethemeobj['Parameters'] = vParameters;
			methoduoethemeobj['index'] = index;
var vReturnType = methoduoethemerow.find("[name=ReturnType]").text();
			methoduoethemeobj['ReturnType'] = vReturnType;
			methoduoethemeobj['index'] = index;
var vDescription = methoduoethemerow.find("[name=Description]").text();
			methoduoethemeobj['Description'] = vDescription;
			methoduoethemeobj['index'] = index;

	methoduoethemedata.push(methoduoethemeobj);
});
return methoduoethemedata;
	}
function getRowstbluoethemes(){
	var tbluoethemesdata = [];
	tbluoethemesrows = $("#tbluoethemes tbody tr");
tbluoethemesrows.each(function (index) {
    var tbluoethemesrow = $(this);
 	var tbluoethemesobj = {};
	var vProperty = tbluoethemesrow.find("[name=Property]").text();
			tbluoethemesobj['Property'] = vProperty;
			tbluoethemesobj['index'] = index;
var vType = tbluoethemesrow.find("[name=Type]").text();
			tbluoethemesobj['Type'] = vType;
			tbluoethemesobj['index'] = index;
var vDefaultValue = tbluoethemesrow.find("[name=DefaultValue]").text();
			tbluoethemesobj['DefaultValue'] = vDefaultValue;
			tbluoethemesobj['index'] = index;
var vDescription = tbluoethemesrow.find("[name=Description]").text();
			tbluoethemesobj['Description'] = vDescription;
			tbluoethemesobj['index'] = index;

	tbluoethemesdata.push(tbluoethemesobj);
});
return tbluoethemesdata;
	}
function getRowsmethoduoethemes(){
	var methoduoethemesdata = [];
	methoduoethemesrows = $("#methoduoethemes tbody tr");
methoduoethemesrows.each(function (index) {
    var methoduoethemesrow = $(this);
 	var methoduoethemesobj = {};
	var vMethod = methoduoethemesrow.find("[name=Method]").text();
			methoduoethemesobj['Method'] = vMethod;
			methoduoethemesobj['index'] = index;
var vParameters = methoduoethemesrow.find("[name=Parameters]").text();
			methoduoethemesobj['Parameters'] = vParameters;
			methoduoethemesobj['index'] = index;
var vReturnType = methoduoethemesrow.find("[name=ReturnType]").text();
			methoduoethemesobj['ReturnType'] = vReturnType;
			methoduoethemesobj['index'] = index;
var vDescription = methoduoethemesrow.find("[name=Description]").text();
			methoduoethemesobj['Description'] = vDescription;
			methoduoethemesobj['index'] = index;

	methoduoethemesdata.push(methoduoethemesobj);
});
return methoduoethemesdata;
	}
function getRowstbluoethumbnailspositiontype(){
	var tbluoethumbnailspositiontypedata = [];
	tbluoethumbnailspositiontyperows = $("#tbluoethumbnailspositiontype tbody tr");
tbluoethumbnailspositiontyperows.each(function (index) {
    var tbluoethumbnailspositiontyperow = $(this);
 	var tbluoethumbnailspositiontypeobj = {};
	var vProperty = tbluoethumbnailspositiontyperow.find("[name=Property]").text();
			tbluoethumbnailspositiontypeobj['Property'] = vProperty;
			tbluoethumbnailspositiontypeobj['index'] = index;
var vType = tbluoethumbnailspositiontyperow.find("[name=Type]").text();
			tbluoethumbnailspositiontypeobj['Type'] = vType;
			tbluoethumbnailspositiontypeobj['index'] = index;
var vDefaultValue = tbluoethumbnailspositiontyperow.find("[name=DefaultValue]").text();
			tbluoethumbnailspositiontypeobj['DefaultValue'] = vDefaultValue;
			tbluoethumbnailspositiontypeobj['index'] = index;
var vDescription = tbluoethumbnailspositiontyperow.find("[name=Description]").text();
			tbluoethumbnailspositiontypeobj['Description'] = vDescription;
			tbluoethumbnailspositiontypeobj['index'] = index;

	tbluoethumbnailspositiontypedata.push(tbluoethumbnailspositiontypeobj);
});
return tbluoethumbnailspositiontypedata;
	}
function getRowsmethoduoethumbnailspositiontype(){
	var methoduoethumbnailspositiontypedata = [];
	methoduoethumbnailspositiontyperows = $("#methoduoethumbnailspositiontype tbody tr");
methoduoethumbnailspositiontyperows.each(function (index) {
    var methoduoethumbnailspositiontyperow = $(this);
 	var methoduoethumbnailspositiontypeobj = {};
	var vMethod = methoduoethumbnailspositiontyperow.find("[name=Method]").text();
			methoduoethumbnailspositiontypeobj['Method'] = vMethod;
			methoduoethumbnailspositiontypeobj['index'] = index;
var vParameters = methoduoethumbnailspositiontyperow.find("[name=Parameters]").text();
			methoduoethumbnailspositiontypeobj['Parameters'] = vParameters;
			methoduoethumbnailspositiontypeobj['index'] = index;
var vReturnType = methoduoethumbnailspositiontyperow.find("[name=ReturnType]").text();
			methoduoethumbnailspositiontypeobj['ReturnType'] = vReturnType;
			methoduoethumbnailspositiontypeobj['index'] = index;
var vDescription = methoduoethumbnailspositiontyperow.find("[name=Description]").text();
			methoduoethumbnailspositiontypeobj['Description'] = vDescription;
			methoduoethumbnailspositiontypeobj['index'] = index;

	methoduoethumbnailspositiontypedata.push(methoduoethumbnailspositiontypeobj);
});
return methoduoethumbnailspositiontypedata;
	}
function getRowstbluoethumbtypetype(){
	var tbluoethumbtypetypedata = [];
	tbluoethumbtypetyperows = $("#tbluoethumbtypetype tbody tr");
tbluoethumbtypetyperows.each(function (index) {
    var tbluoethumbtypetyperow = $(this);
 	var tbluoethumbtypetypeobj = {};
	var vProperty = tbluoethumbtypetyperow.find("[name=Property]").text();
			tbluoethumbtypetypeobj['Property'] = vProperty;
			tbluoethumbtypetypeobj['index'] = index;
var vType = tbluoethumbtypetyperow.find("[name=Type]").text();
			tbluoethumbtypetypeobj['Type'] = vType;
			tbluoethumbtypetypeobj['index'] = index;
var vDefaultValue = tbluoethumbtypetyperow.find("[name=DefaultValue]").text();
			tbluoethumbtypetypeobj['DefaultValue'] = vDefaultValue;
			tbluoethumbtypetypeobj['index'] = index;
var vDescription = tbluoethumbtypetyperow.find("[name=Description]").text();
			tbluoethumbtypetypeobj['Description'] = vDescription;
			tbluoethumbtypetypeobj['index'] = index;

	tbluoethumbtypetypedata.push(tbluoethumbtypetypeobj);
});
return tbluoethumbtypetypedata;
	}
function getRowsmethoduoethumbtypetype(){
	var methoduoethumbtypetypedata = [];
	methoduoethumbtypetyperows = $("#methoduoethumbtypetype tbody tr");
methoduoethumbtypetyperows.each(function (index) {
    var methoduoethumbtypetyperow = $(this);
 	var methoduoethumbtypetypeobj = {};
	var vMethod = methoduoethumbtypetyperow.find("[name=Method]").text();
			methoduoethumbtypetypeobj['Method'] = vMethod;
			methoduoethumbtypetypeobj['index'] = index;
var vParameters = methoduoethumbtypetyperow.find("[name=Parameters]").text();
			methoduoethumbtypetypeobj['Parameters'] = vParameters;
			methoduoethumbtypetypeobj['index'] = index;
var vReturnType = methoduoethumbtypetyperow.find("[name=ReturnType]").text();
			methoduoethumbtypetypeobj['ReturnType'] = vReturnType;
			methoduoethumbtypetypeobj['index'] = index;
var vDescription = methoduoethumbtypetyperow.find("[name=Description]").text();
			methoduoethumbtypetypeobj['Description'] = vDescription;
			methoduoethumbtypetypeobj['index'] = index;

	methoduoethumbtypetypedata.push(methoduoethumbtypetypeobj);
});
return methoduoethumbtypetypedata;
	}
function getRowstbluoetoast(){
	var tbluoetoastdata = [];
	tbluoetoastrows = $("#tbluoetoast tbody tr");
tbluoetoastrows.each(function (index) {
    var tbluoetoastrow = $(this);
 	var tbluoetoastobj = {};
	var vProperty = tbluoetoastrow.find("[name=Property]").text();
			tbluoetoastobj['Property'] = vProperty;
			tbluoetoastobj['index'] = index;
var vType = tbluoetoastrow.find("[name=Type]").text();
			tbluoetoastobj['Type'] = vType;
			tbluoetoastobj['index'] = index;
var vDefaultValue = tbluoetoastrow.find("[name=DefaultValue]").text();
			tbluoetoastobj['DefaultValue'] = vDefaultValue;
			tbluoetoastobj['index'] = index;
var vDescription = tbluoetoastrow.find("[name=Description]").text();
			tbluoetoastobj['Description'] = vDescription;
			tbluoetoastobj['index'] = index;

	tbluoetoastdata.push(tbluoetoastobj);
});
return tbluoetoastdata;
	}
function getRowsmethoduoetoast(){
	var methoduoetoastdata = [];
	methoduoetoastrows = $("#methoduoetoast tbody tr");
methoduoetoastrows.each(function (index) {
    var methoduoetoastrow = $(this);
 	var methoduoetoastobj = {};
	var vMethod = methoduoetoastrow.find("[name=Method]").text();
			methoduoetoastobj['Method'] = vMethod;
			methoduoetoastobj['index'] = index;
var vParameters = methoduoetoastrow.find("[name=Parameters]").text();
			methoduoetoastobj['Parameters'] = vParameters;
			methoduoetoastobj['index'] = index;
var vReturnType = methoduoetoastrow.find("[name=ReturnType]").text();
			methoduoetoastobj['ReturnType'] = vReturnType;
			methoduoetoastobj['index'] = index;
var vDescription = methoduoetoastrow.find("[name=Description]").text();
			methoduoetoastobj['Description'] = vDescription;
			methoduoetoastobj['index'] = index;

	methoduoetoastdata.push(methoduoetoastobj);
});
return methoduoetoastdata;
	}
function getRowstbluoetoc(){
	var tbluoetocdata = [];
	tbluoetocrows = $("#tbluoetoc tbody tr");
tbluoetocrows.each(function (index) {
    var tbluoetocrow = $(this);
 	var tbluoetocobj = {};
	var vProperty = tbluoetocrow.find("[name=Property]").text();
			tbluoetocobj['Property'] = vProperty;
			tbluoetocobj['index'] = index;
var vType = tbluoetocrow.find("[name=Type]").text();
			tbluoetocobj['Type'] = vType;
			tbluoetocobj['index'] = index;
var vDefaultValue = tbluoetocrow.find("[name=DefaultValue]").text();
			tbluoetocobj['DefaultValue'] = vDefaultValue;
			tbluoetocobj['index'] = index;
var vDescription = tbluoetocrow.find("[name=Description]").text();
			tbluoetocobj['Description'] = vDescription;
			tbluoetocobj['index'] = index;

	tbluoetocdata.push(tbluoetocobj);
});
return tbluoetocdata;
	}
function getRowsmethoduoetoc(){
	var methoduoetocdata = [];
	methoduoetocrows = $("#methoduoetoc tbody tr");
methoduoetocrows.each(function (index) {
    var methoduoetocrow = $(this);
 	var methoduoetocobj = {};
	var vMethod = methoduoetocrow.find("[name=Method]").text();
			methoduoetocobj['Method'] = vMethod;
			methoduoetocobj['index'] = index;
var vParameters = methoduoetocrow.find("[name=Parameters]").text();
			methoduoetocobj['Parameters'] = vParameters;
			methoduoetocobj['index'] = index;
var vReturnType = methoduoetocrow.find("[name=ReturnType]").text();
			methoduoetocobj['ReturnType'] = vReturnType;
			methoduoetocobj['index'] = index;
var vDescription = methoduoetocrow.find("[name=Description]").text();
			methoduoetocobj['Description'] = vDescription;
			methoduoetocobj['index'] = index;

	methoduoetocdata.push(methoduoetocobj);
});
return methoduoetocdata;
	}
function getRowstbluoetoolbar(){
	var tbluoetoolbardata = [];
	tbluoetoolbarrows = $("#tbluoetoolbar tbody tr");
tbluoetoolbarrows.each(function (index) {
    var tbluoetoolbarrow = $(this);
 	var tbluoetoolbarobj = {};
	var vProperty = tbluoetoolbarrow.find("[name=Property]").text();
			tbluoetoolbarobj['Property'] = vProperty;
			tbluoetoolbarobj['index'] = index;
var vType = tbluoetoolbarrow.find("[name=Type]").text();
			tbluoetoolbarobj['Type'] = vType;
			tbluoetoolbarobj['index'] = index;
var vDefaultValue = tbluoetoolbarrow.find("[name=DefaultValue]").text();
			tbluoetoolbarobj['DefaultValue'] = vDefaultValue;
			tbluoetoolbarobj['index'] = index;
var vDescription = tbluoetoolbarrow.find("[name=Description]").text();
			tbluoetoolbarobj['Description'] = vDescription;
			tbluoetoolbarobj['index'] = index;

	tbluoetoolbardata.push(tbluoetoolbarobj);
});
return tbluoetoolbardata;
	}
function getRowsmethoduoetoolbar(){
	var methoduoetoolbardata = [];
	methoduoetoolbarrows = $("#methoduoetoolbar tbody tr");
methoduoetoolbarrows.each(function (index) {
    var methoduoetoolbarrow = $(this);
 	var methoduoetoolbarobj = {};
	var vMethod = methoduoetoolbarrow.find("[name=Method]").text();
			methoduoetoolbarobj['Method'] = vMethod;
			methoduoetoolbarobj['index'] = index;
var vParameters = methoduoetoolbarrow.find("[name=Parameters]").text();
			methoduoetoolbarobj['Parameters'] = vParameters;
			methoduoetoolbarobj['index'] = index;
var vReturnType = methoduoetoolbarrow.find("[name=ReturnType]").text();
			methoduoetoolbarobj['ReturnType'] = vReturnType;
			methoduoetoolbarobj['index'] = index;
var vDescription = methoduoetoolbarrow.find("[name=Description]").text();
			methoduoetoolbarobj['Description'] = vDescription;
			methoduoetoolbarobj['index'] = index;

	methoduoetoolbardata.push(methoduoetoolbarobj);
});
return methoduoetoolbardata;
	}
function getRowstbluoetoolbaranimation(){
	var tbluoetoolbaranimationdata = [];
	tbluoetoolbaranimationrows = $("#tbluoetoolbaranimation tbody tr");
tbluoetoolbaranimationrows.each(function (index) {
    var tbluoetoolbaranimationrow = $(this);
 	var tbluoetoolbaranimationobj = {};
	var vProperty = tbluoetoolbaranimationrow.find("[name=Property]").text();
			tbluoetoolbaranimationobj['Property'] = vProperty;
			tbluoetoolbaranimationobj['index'] = index;
var vType = tbluoetoolbaranimationrow.find("[name=Type]").text();
			tbluoetoolbaranimationobj['Type'] = vType;
			tbluoetoolbaranimationobj['index'] = index;
var vDefaultValue = tbluoetoolbaranimationrow.find("[name=DefaultValue]").text();
			tbluoetoolbaranimationobj['DefaultValue'] = vDefaultValue;
			tbluoetoolbaranimationobj['index'] = index;
var vDescription = tbluoetoolbaranimationrow.find("[name=Description]").text();
			tbluoetoolbaranimationobj['Description'] = vDescription;
			tbluoetoolbaranimationobj['index'] = index;

	tbluoetoolbaranimationdata.push(tbluoetoolbaranimationobj);
});
return tbluoetoolbaranimationdata;
	}
function getRowsmethoduoetoolbaranimation(){
	var methoduoetoolbaranimationdata = [];
	methoduoetoolbaranimationrows = $("#methoduoetoolbaranimation tbody tr");
methoduoetoolbaranimationrows.each(function (index) {
    var methoduoetoolbaranimationrow = $(this);
 	var methoduoetoolbaranimationobj = {};
	var vMethod = methoduoetoolbaranimationrow.find("[name=Method]").text();
			methoduoetoolbaranimationobj['Method'] = vMethod;
			methoduoetoolbaranimationobj['index'] = index;
var vParameters = methoduoetoolbaranimationrow.find("[name=Parameters]").text();
			methoduoetoolbaranimationobj['Parameters'] = vParameters;
			methoduoetoolbaranimationobj['index'] = index;
var vReturnType = methoduoetoolbaranimationrow.find("[name=ReturnType]").text();
			methoduoetoolbaranimationobj['ReturnType'] = vReturnType;
			methoduoetoolbaranimationobj['index'] = index;
var vDescription = methoduoetoolbaranimationrow.find("[name=Description]").text();
			methoduoetoolbaranimationobj['Description'] = vDescription;
			methoduoetoolbaranimationobj['index'] = index;

	methoduoetoolbaranimationdata.push(methoduoetoolbaranimationobj);
});
return methoduoetoolbaranimationdata;
	}
function getRowstbluoetoolbarposition(){
	var tbluoetoolbarpositiondata = [];
	tbluoetoolbarpositionrows = $("#tbluoetoolbarposition tbody tr");
tbluoetoolbarpositionrows.each(function (index) {
    var tbluoetoolbarpositionrow = $(this);
 	var tbluoetoolbarpositionobj = {};
	var vProperty = tbluoetoolbarpositionrow.find("[name=Property]").text();
			tbluoetoolbarpositionobj['Property'] = vProperty;
			tbluoetoolbarpositionobj['index'] = index;
var vType = tbluoetoolbarpositionrow.find("[name=Type]").text();
			tbluoetoolbarpositionobj['Type'] = vType;
			tbluoetoolbarpositionobj['index'] = index;
var vDefaultValue = tbluoetoolbarpositionrow.find("[name=DefaultValue]").text();
			tbluoetoolbarpositionobj['DefaultValue'] = vDefaultValue;
			tbluoetoolbarpositionobj['index'] = index;
var vDescription = tbluoetoolbarpositionrow.find("[name=Description]").text();
			tbluoetoolbarpositionobj['Description'] = vDescription;
			tbluoetoolbarpositionobj['index'] = index;

	tbluoetoolbarpositiondata.push(tbluoetoolbarpositionobj);
});
return tbluoetoolbarpositiondata;
	}
function getRowsmethoduoetoolbarposition(){
	var methoduoetoolbarpositiondata = [];
	methoduoetoolbarpositionrows = $("#methoduoetoolbarposition tbody tr");
methoduoetoolbarpositionrows.each(function (index) {
    var methoduoetoolbarpositionrow = $(this);
 	var methoduoetoolbarpositionobj = {};
	var vMethod = methoduoetoolbarpositionrow.find("[name=Method]").text();
			methoduoetoolbarpositionobj['Method'] = vMethod;
			methoduoetoolbarpositionobj['index'] = index;
var vParameters = methoduoetoolbarpositionrow.find("[name=Parameters]").text();
			methoduoetoolbarpositionobj['Parameters'] = vParameters;
			methoduoetoolbarpositionobj['index'] = index;
var vReturnType = methoduoetoolbarpositionrow.find("[name=ReturnType]").text();
			methoduoetoolbarpositionobj['ReturnType'] = vReturnType;
			methoduoetoolbarpositionobj['index'] = index;
var vDescription = methoduoetoolbarpositionrow.find("[name=Description]").text();
			methoduoetoolbarpositionobj['Description'] = vDescription;
			methoduoetoolbarpositionobj['index'] = index;

	methoduoetoolbarpositiondata.push(methoduoetoolbarpositionobj);
});
return methoduoetoolbarpositiondata;
	}
function getRowstbluoetoolbartheme(){
	var tbluoetoolbarthemedata = [];
	tbluoetoolbarthemerows = $("#tbluoetoolbartheme tbody tr");
tbluoetoolbarthemerows.each(function (index) {
    var tbluoetoolbarthemerow = $(this);
 	var tbluoetoolbarthemeobj = {};
	var vProperty = tbluoetoolbarthemerow.find("[name=Property]").text();
			tbluoetoolbarthemeobj['Property'] = vProperty;
			tbluoetoolbarthemeobj['index'] = index;
var vType = tbluoetoolbarthemerow.find("[name=Type]").text();
			tbluoetoolbarthemeobj['Type'] = vType;
			tbluoetoolbarthemeobj['index'] = index;
var vDefaultValue = tbluoetoolbarthemerow.find("[name=DefaultValue]").text();
			tbluoetoolbarthemeobj['DefaultValue'] = vDefaultValue;
			tbluoetoolbarthemeobj['index'] = index;
var vDescription = tbluoetoolbarthemerow.find("[name=Description]").text();
			tbluoetoolbarthemeobj['Description'] = vDescription;
			tbluoetoolbarthemeobj['index'] = index;

	tbluoetoolbarthemedata.push(tbluoetoolbarthemeobj);
});
return tbluoetoolbarthemedata;
	}
function getRowsmethoduoetoolbartheme(){
	var methoduoetoolbarthemedata = [];
	methoduoetoolbarthemerows = $("#methoduoetoolbartheme tbody tr");
methoduoetoolbarthemerows.each(function (index) {
    var methoduoetoolbarthemerow = $(this);
 	var methoduoetoolbarthemeobj = {};
	var vMethod = methoduoetoolbarthemerow.find("[name=Method]").text();
			methoduoetoolbarthemeobj['Method'] = vMethod;
			methoduoetoolbarthemeobj['index'] = index;
var vParameters = methoduoetoolbarthemerow.find("[name=Parameters]").text();
			methoduoetoolbarthemeobj['Parameters'] = vParameters;
			methoduoetoolbarthemeobj['index'] = index;
var vReturnType = methoduoetoolbarthemerow.find("[name=ReturnType]").text();
			methoduoetoolbarthemeobj['ReturnType'] = vReturnType;
			methoduoetoolbarthemeobj['index'] = index;
var vDescription = methoduoetoolbarthemerow.find("[name=Description]").text();
			methoduoetoolbarthemeobj['Description'] = vDescription;
			methoduoetoolbarthemeobj['index'] = index;

	methoduoetoolbarthemedata.push(methoduoetoolbarthemeobj);
});
return methoduoetoolbarthemedata;
	}
function getRowstbluoetooltip(){
	var tbluoetooltipdata = [];
	tbluoetooltiprows = $("#tbluoetooltip tbody tr");
tbluoetooltiprows.each(function (index) {
    var tbluoetooltiprow = $(this);
 	var tbluoetooltipobj = {};
	var vProperty = tbluoetooltiprow.find("[name=Property]").text();
			tbluoetooltipobj['Property'] = vProperty;
			tbluoetooltipobj['index'] = index;
var vType = tbluoetooltiprow.find("[name=Type]").text();
			tbluoetooltipobj['Type'] = vType;
			tbluoetooltipobj['index'] = index;
var vDefaultValue = tbluoetooltiprow.find("[name=DefaultValue]").text();
			tbluoetooltipobj['DefaultValue'] = vDefaultValue;
			tbluoetooltipobj['index'] = index;
var vDescription = tbluoetooltiprow.find("[name=Description]").text();
			tbluoetooltipobj['Description'] = vDescription;
			tbluoetooltipobj['index'] = index;

	tbluoetooltipdata.push(tbluoetooltipobj);
});
return tbluoetooltipdata;
	}
function getRowsmethoduoetooltip(){
	var methoduoetooltipdata = [];
	methoduoetooltiprows = $("#methoduoetooltip tbody tr");
methoduoetooltiprows.each(function (index) {
    var methoduoetooltiprow = $(this);
 	var methoduoetooltipobj = {};
	var vMethod = methoduoetooltiprow.find("[name=Method]").text();
			methoduoetooltipobj['Method'] = vMethod;
			methoduoetooltipobj['index'] = index;
var vParameters = methoduoetooltiprow.find("[name=Parameters]").text();
			methoduoetooltipobj['Parameters'] = vParameters;
			methoduoetooltipobj['index'] = index;
var vReturnType = methoduoetooltiprow.find("[name=ReturnType]").text();
			methoduoetooltipobj['ReturnType'] = vReturnType;
			methoduoetooltipobj['index'] = index;
var vDescription = methoduoetooltiprow.find("[name=Description]").text();
			methoduoetooltipobj['Description'] = vDescription;
			methoduoetooltipobj['index'] = index;

	methoduoetooltipdata.push(methoduoetooltipobj);
});
return methoduoetooltipdata;
	}
function getRowstbluoetooltippos(){
	var tbluoetooltipposdata = [];
	tbluoetooltipposrows = $("#tbluoetooltippos tbody tr");
tbluoetooltipposrows.each(function (index) {
    var tbluoetooltipposrow = $(this);
 	var tbluoetooltipposobj = {};
	var vProperty = tbluoetooltipposrow.find("[name=Property]").text();
			tbluoetooltipposobj['Property'] = vProperty;
			tbluoetooltipposobj['index'] = index;
var vType = tbluoetooltipposrow.find("[name=Type]").text();
			tbluoetooltipposobj['Type'] = vType;
			tbluoetooltipposobj['index'] = index;
var vDefaultValue = tbluoetooltipposrow.find("[name=DefaultValue]").text();
			tbluoetooltipposobj['DefaultValue'] = vDefaultValue;
			tbluoetooltipposobj['index'] = index;
var vDescription = tbluoetooltipposrow.find("[name=Description]").text();
			tbluoetooltipposobj['Description'] = vDescription;
			tbluoetooltipposobj['index'] = index;

	tbluoetooltipposdata.push(tbluoetooltipposobj);
});
return tbluoetooltipposdata;
	}
function getRowsmethoduoetooltippos(){
	var methoduoetooltipposdata = [];
	methoduoetooltipposrows = $("#methoduoetooltippos tbody tr");
methoduoetooltipposrows.each(function (index) {
    var methoduoetooltipposrow = $(this);
 	var methoduoetooltipposobj = {};
	var vMethod = methoduoetooltipposrow.find("[name=Method]").text();
			methoduoetooltipposobj['Method'] = vMethod;
			methoduoetooltipposobj['index'] = index;
var vParameters = methoduoetooltipposrow.find("[name=Parameters]").text();
			methoduoetooltipposobj['Parameters'] = vParameters;
			methoduoetooltipposobj['index'] = index;
var vReturnType = methoduoetooltipposrow.find("[name=ReturnType]").text();
			methoduoetooltipposobj['ReturnType'] = vReturnType;
			methoduoetooltipposobj['index'] = index;
var vDescription = methoduoetooltipposrow.find("[name=Description]").text();
			methoduoetooltipposobj['Description'] = vDescription;
			methoduoetooltipposobj['index'] = index;

	methoduoetooltipposdata.push(methoduoetooltipposobj);
});
return methoduoetooltipposdata;
	}
function getRowstbluoetransition(){
	var tbluoetransitiondata = [];
	tbluoetransitionrows = $("#tbluoetransition tbody tr");
tbluoetransitionrows.each(function (index) {
    var tbluoetransitionrow = $(this);
 	var tbluoetransitionobj = {};
	var vProperty = tbluoetransitionrow.find("[name=Property]").text();
			tbluoetransitionobj['Property'] = vProperty;
			tbluoetransitionobj['index'] = index;
var vType = tbluoetransitionrow.find("[name=Type]").text();
			tbluoetransitionobj['Type'] = vType;
			tbluoetransitionobj['index'] = index;
var vDefaultValue = tbluoetransitionrow.find("[name=DefaultValue]").text();
			tbluoetransitionobj['DefaultValue'] = vDefaultValue;
			tbluoetransitionobj['index'] = index;
var vDescription = tbluoetransitionrow.find("[name=Description]").text();
			tbluoetransitionobj['Description'] = vDescription;
			tbluoetransitionobj['index'] = index;

	tbluoetransitiondata.push(tbluoetransitionobj);
});
return tbluoetransitiondata;
	}
function getRowsmethoduoetransition(){
	var methoduoetransitiondata = [];
	methoduoetransitionrows = $("#methoduoetransition tbody tr");
methoduoetransitionrows.each(function (index) {
    var methoduoetransitionrow = $(this);
 	var methoduoetransitionobj = {};
	var vMethod = methoduoetransitionrow.find("[name=Method]").text();
			methoduoetransitionobj['Method'] = vMethod;
			methoduoetransitionobj['index'] = index;
var vParameters = methoduoetransitionrow.find("[name=Parameters]").text();
			methoduoetransitionobj['Parameters'] = vParameters;
			methoduoetransitionobj['index'] = index;
var vReturnType = methoduoetransitionrow.find("[name=ReturnType]").text();
			methoduoetransitionobj['ReturnType'] = vReturnType;
			methoduoetransitionobj['index'] = index;
var vDescription = methoduoetransitionrow.find("[name=Description]").text();
			methoduoetransitionobj['Description'] = vDescription;
			methoduoetransitionobj['index'] = index;

	methoduoetransitiondata.push(methoduoetransitionobj);
});
return methoduoetransitiondata;
	}
function getRowstbluoevideo(){
	var tbluoevideodata = [];
	tbluoevideorows = $("#tbluoevideo tbody tr");
tbluoevideorows.each(function (index) {
    var tbluoevideorow = $(this);
 	var tbluoevideoobj = {};
	var vProperty = tbluoevideorow.find("[name=Property]").text();
			tbluoevideoobj['Property'] = vProperty;
			tbluoevideoobj['index'] = index;
var vType = tbluoevideorow.find("[name=Type]").text();
			tbluoevideoobj['Type'] = vType;
			tbluoevideoobj['index'] = index;
var vDefaultValue = tbluoevideorow.find("[name=DefaultValue]").text();
			tbluoevideoobj['DefaultValue'] = vDefaultValue;
			tbluoevideoobj['index'] = index;
var vDescription = tbluoevideorow.find("[name=Description]").text();
			tbluoevideoobj['Description'] = vDescription;
			tbluoevideoobj['index'] = index;

	tbluoevideodata.push(tbluoevideoobj);
});
return tbluoevideodata;
	}
function getRowsmethoduoevideo(){
	var methoduoevideodata = [];
	methoduoevideorows = $("#methoduoevideo tbody tr");
methoduoevideorows.each(function (index) {
    var methoduoevideorow = $(this);
 	var methoduoevideoobj = {};
	var vMethod = methoduoevideorow.find("[name=Method]").text();
			methoduoevideoobj['Method'] = vMethod;
			methoduoevideoobj['index'] = index;
var vParameters = methoduoevideorow.find("[name=Parameters]").text();
			methoduoevideoobj['Parameters'] = vParameters;
			methoduoevideoobj['index'] = index;
var vReturnType = methoduoevideorow.find("[name=ReturnType]").text();
			methoduoevideoobj['ReturnType'] = vReturnType;
			methoduoevideoobj['index'] = index;
var vDescription = methoduoevideorow.find("[name=Description]").text();
			methoduoevideoobj['Description'] = vDescription;
			methoduoevideoobj['index'] = index;

	methoduoevideodata.push(methoduoevideoobj);
});
return methoduoevideodata;
	}
function getRowstbluoevideotype(){
	var tbluoevideotypedata = [];
	tbluoevideotyperows = $("#tbluoevideotype tbody tr");
tbluoevideotyperows.each(function (index) {
    var tbluoevideotyperow = $(this);
 	var tbluoevideotypeobj = {};
	var vProperty = tbluoevideotyperow.find("[name=Property]").text();
			tbluoevideotypeobj['Property'] = vProperty;
			tbluoevideotypeobj['index'] = index;
var vType = tbluoevideotyperow.find("[name=Type]").text();
			tbluoevideotypeobj['Type'] = vType;
			tbluoevideotypeobj['index'] = index;
var vDefaultValue = tbluoevideotyperow.find("[name=DefaultValue]").text();
			tbluoevideotypeobj['DefaultValue'] = vDefaultValue;
			tbluoevideotypeobj['index'] = index;
var vDescription = tbluoevideotyperow.find("[name=Description]").text();
			tbluoevideotypeobj['Description'] = vDescription;
			tbluoevideotypeobj['index'] = index;

	tbluoevideotypedata.push(tbluoevideotypeobj);
});
return tbluoevideotypedata;
	}
function getRowsmethoduoevideotype(){
	var methoduoevideotypedata = [];
	methoduoevideotyperows = $("#methoduoevideotype tbody tr");
methoduoevideotyperows.each(function (index) {
    var methoduoevideotyperow = $(this);
 	var methoduoevideotypeobj = {};
	var vMethod = methoduoevideotyperow.find("[name=Method]").text();
			methoduoevideotypeobj['Method'] = vMethod;
			methoduoevideotypeobj['index'] = index;
var vParameters = methoduoevideotyperow.find("[name=Parameters]").text();
			methoduoevideotypeobj['Parameters'] = vParameters;
			methoduoevideotypeobj['index'] = index;
var vReturnType = methoduoevideotyperow.find("[name=ReturnType]").text();
			methoduoevideotypeobj['ReturnType'] = vReturnType;
			methoduoevideotypeobj['index'] = index;
var vDescription = methoduoevideotyperow.find("[name=Description]").text();
			methoduoevideotypeobj['Description'] = vDescription;
			methoduoevideotypeobj['index'] = index;

	methoduoevideotypedata.push(methoduoevideotypeobj);
});
return methoduoevideotypedata;
	}
function getRowstbluoevisibility(){
	var tbluoevisibilitydata = [];
	tbluoevisibilityrows = $("#tbluoevisibility tbody tr");
tbluoevisibilityrows.each(function (index) {
    var tbluoevisibilityrow = $(this);
 	var tbluoevisibilityobj = {};
	var vProperty = tbluoevisibilityrow.find("[name=Property]").text();
			tbluoevisibilityobj['Property'] = vProperty;
			tbluoevisibilityobj['index'] = index;
var vType = tbluoevisibilityrow.find("[name=Type]").text();
			tbluoevisibilityobj['Type'] = vType;
			tbluoevisibilityobj['index'] = index;
var vDefaultValue = tbluoevisibilityrow.find("[name=DefaultValue]").text();
			tbluoevisibilityobj['DefaultValue'] = vDefaultValue;
			tbluoevisibilityobj['index'] = index;
var vDescription = tbluoevisibilityrow.find("[name=Description]").text();
			tbluoevisibilityobj['Description'] = vDescription;
			tbluoevisibilityobj['index'] = index;

	tbluoevisibilitydata.push(tbluoevisibilityobj);
});
return tbluoevisibilitydata;
	}
function getRowsmethoduoevisibility(){
	var methoduoevisibilitydata = [];
	methoduoevisibilityrows = $("#methoduoevisibility tbody tr");
methoduoevisibilityrows.each(function (index) {
    var methoduoevisibilityrow = $(this);
 	var methoduoevisibilityobj = {};
	var vMethod = methoduoevisibilityrow.find("[name=Method]").text();
			methoduoevisibilityobj['Method'] = vMethod;
			methoduoevisibilityobj['index'] = index;
var vParameters = methoduoevisibilityrow.find("[name=Parameters]").text();
			methoduoevisibilityobj['Parameters'] = vParameters;
			methoduoevisibilityobj['index'] = index;
var vReturnType = methoduoevisibilityrow.find("[name=ReturnType]").text();
			methoduoevisibilityobj['ReturnType'] = vReturnType;
			methoduoevisibilityobj['index'] = index;
var vDescription = methoduoevisibilityrow.find("[name=Description]").text();
			methoduoevisibilityobj['Description'] = vDescription;
			methoduoevisibilityobj['index'] = index;

	methoduoevisibilitydata.push(methoduoevisibilityobj);
});
return methoduoevisibilitydata;
	}
function getRowstbluoewaterball(){
	var tbluoewaterballdata = [];
	tbluoewaterballrows = $("#tbluoewaterball tbody tr");
tbluoewaterballrows.each(function (index) {
    var tbluoewaterballrow = $(this);
 	var tbluoewaterballobj = {};
	var vProperty = tbluoewaterballrow.find("[name=Property]").text();
			tbluoewaterballobj['Property'] = vProperty;
			tbluoewaterballobj['index'] = index;
var vType = tbluoewaterballrow.find("[name=Type]").text();
			tbluoewaterballobj['Type'] = vType;
			tbluoewaterballobj['index'] = index;
var vDefaultValue = tbluoewaterballrow.find("[name=DefaultValue]").text();
			tbluoewaterballobj['DefaultValue'] = vDefaultValue;
			tbluoewaterballobj['index'] = index;
var vDescription = tbluoewaterballrow.find("[name=Description]").text();
			tbluoewaterballobj['Description'] = vDescription;
			tbluoewaterballobj['index'] = index;

	tbluoewaterballdata.push(tbluoewaterballobj);
});
return tbluoewaterballdata;
	}
function getRowsmethoduoewaterball(){
	var methoduoewaterballdata = [];
	methoduoewaterballrows = $("#methoduoewaterball tbody tr");
methoduoewaterballrows.each(function (index) {
    var methoduoewaterballrow = $(this);
 	var methoduoewaterballobj = {};
	var vMethod = methoduoewaterballrow.find("[name=Method]").text();
			methoduoewaterballobj['Method'] = vMethod;
			methoduoewaterballobj['index'] = index;
var vParameters = methoduoewaterballrow.find("[name=Parameters]").text();
			methoduoewaterballobj['Parameters'] = vParameters;
			methoduoewaterballobj['index'] = index;
var vReturnType = methoduoewaterballrow.find("[name=ReturnType]").text();
			methoduoewaterballobj['ReturnType'] = vReturnType;
			methoduoewaterballobj['index'] = index;
var vDescription = methoduoewaterballrow.find("[name=Description]").text();
			methoduoewaterballobj['Description'] = vDescription;
			methoduoewaterballobj['index'] = index;

	methoduoewaterballdata.push(methoduoewaterballobj);
});
return methoduoewaterballdata;
	}
function getRowstbluoewavestype(){
	var tbluoewavestypedata = [];
	tbluoewavestyperows = $("#tbluoewavestype tbody tr");
tbluoewavestyperows.each(function (index) {
    var tbluoewavestyperow = $(this);
 	var tbluoewavestypeobj = {};
	var vProperty = tbluoewavestyperow.find("[name=Property]").text();
			tbluoewavestypeobj['Property'] = vProperty;
			tbluoewavestypeobj['index'] = index;
var vType = tbluoewavestyperow.find("[name=Type]").text();
			tbluoewavestypeobj['Type'] = vType;
			tbluoewavestypeobj['index'] = index;
var vDefaultValue = tbluoewavestyperow.find("[name=DefaultValue]").text();
			tbluoewavestypeobj['DefaultValue'] = vDefaultValue;
			tbluoewavestypeobj['index'] = index;
var vDescription = tbluoewavestyperow.find("[name=Description]").text();
			tbluoewavestypeobj['Description'] = vDescription;
			tbluoewavestypeobj['index'] = index;

	tbluoewavestypedata.push(tbluoewavestypeobj);
});
return tbluoewavestypedata;
	}
function getRowsmethoduoewavestype(){
	var methoduoewavestypedata = [];
	methoduoewavestyperows = $("#methoduoewavestype tbody tr");
methoduoewavestyperows.each(function (index) {
    var methoduoewavestyperow = $(this);
 	var methoduoewavestypeobj = {};
	var vMethod = methoduoewavestyperow.find("[name=Method]").text();
			methoduoewavestypeobj['Method'] = vMethod;
			methoduoewavestypeobj['index'] = index;
var vParameters = methoduoewavestyperow.find("[name=Parameters]").text();
			methoduoewavestypeobj['Parameters'] = vParameters;
			methoduoewavestypeobj['index'] = index;
var vReturnType = methoduoewavestyperow.find("[name=ReturnType]").text();
			methoduoewavestypeobj['ReturnType'] = vReturnType;
			methoduoewavestypeobj['index'] = index;
var vDescription = methoduoewavestyperow.find("[name=Description]").text();
			methoduoewavestypeobj['Description'] = vDescription;
			methoduoewavestypeobj['index'] = index;

	methoduoewavestypedata.push(methoduoewavestypeobj);
});
return methoduoewavestypedata;
	}
function getRowstbluoewordcloud(){
	var tbluoewordclouddata = [];
	tbluoewordcloudrows = $("#tbluoewordcloud tbody tr");
tbluoewordcloudrows.each(function (index) {
    var tbluoewordcloudrow = $(this);
 	var tbluoewordcloudobj = {};
	var vProperty = tbluoewordcloudrow.find("[name=Property]").text();
			tbluoewordcloudobj['Property'] = vProperty;
			tbluoewordcloudobj['index'] = index;
var vType = tbluoewordcloudrow.find("[name=Type]").text();
			tbluoewordcloudobj['Type'] = vType;
			tbluoewordcloudobj['index'] = index;
var vDefaultValue = tbluoewordcloudrow.find("[name=DefaultValue]").text();
			tbluoewordcloudobj['DefaultValue'] = vDefaultValue;
			tbluoewordcloudobj['index'] = index;
var vDescription = tbluoewordcloudrow.find("[name=Description]").text();
			tbluoewordcloudobj['Description'] = vDescription;
			tbluoewordcloudobj['index'] = index;

	tbluoewordclouddata.push(tbluoewordcloudobj);
});
return tbluoewordclouddata;
	}
function getRowsmethoduoewordcloud(){
	var methoduoewordclouddata = [];
	methoduoewordcloudrows = $("#methoduoewordcloud tbody tr");
methoduoewordcloudrows.each(function (index) {
    var methoduoewordcloudrow = $(this);
 	var methoduoewordcloudobj = {};
	var vMethod = methoduoewordcloudrow.find("[name=Method]").text();
			methoduoewordcloudobj['Method'] = vMethod;
			methoduoewordcloudobj['index'] = index;
var vParameters = methoduoewordcloudrow.find("[name=Parameters]").text();
			methoduoewordcloudobj['Parameters'] = vParameters;
			methoduoewordcloudobj['index'] = index;
var vReturnType = methoduoewordcloudrow.find("[name=ReturnType]").text();
			methoduoewordcloudobj['ReturnType'] = vReturnType;
			methoduoewordcloudobj['index'] = index;
var vDescription = methoduoewordcloudrow.find("[name=Description]").text();
			methoduoewordcloudobj['Description'] = vDescription;
			methoduoewordcloudobj['index'] = index;

	methoduoewordclouddata.push(methoduoewordcloudobj);
});
return methoduoewordclouddata;
	}
function getRowstbluoezdepth(){
	var tbluoezdepthdata = [];
	tbluoezdepthrows = $("#tbluoezdepth tbody tr");
tbluoezdepthrows.each(function (index) {
    var tbluoezdepthrow = $(this);
 	var tbluoezdepthobj = {};
	var vProperty = tbluoezdepthrow.find("[name=Property]").text();
			tbluoezdepthobj['Property'] = vProperty;
			tbluoezdepthobj['index'] = index;
var vType = tbluoezdepthrow.find("[name=Type]").text();
			tbluoezdepthobj['Type'] = vType;
			tbluoezdepthobj['index'] = index;
var vDefaultValue = tbluoezdepthrow.find("[name=DefaultValue]").text();
			tbluoezdepthobj['DefaultValue'] = vDefaultValue;
			tbluoezdepthobj['index'] = index;
var vDescription = tbluoezdepthrow.find("[name=Description]").text();
			tbluoezdepthobj['Description'] = vDescription;
			tbluoezdepthobj['index'] = index;

	tbluoezdepthdata.push(tbluoezdepthobj);
});
return tbluoezdepthdata;
	}
function getRowsmethoduoezdepth(){
	var methoduoezdepthdata = [];
	methoduoezdepthrows = $("#methoduoezdepth tbody tr");
methoduoezdepthrows.each(function (index) {
    var methoduoezdepthrow = $(this);
 	var methoduoezdepthobj = {};
	var vMethod = methoduoezdepthrow.find("[name=Method]").text();
			methoduoezdepthobj['Method'] = vMethod;
			methoduoezdepthobj['index'] = index;
var vParameters = methoduoezdepthrow.find("[name=Parameters]").text();
			methoduoezdepthobj['Parameters'] = vParameters;
			methoduoezdepthobj['index'] = index;
var vReturnType = methoduoezdepthrow.find("[name=ReturnType]").text();
			methoduoezdepthobj['ReturnType'] = vReturnType;
			methoduoezdepthobj['index'] = index;
var vDescription = methoduoezdepthrow.find("[name=Description]").text();
			methoduoezdepthobj['Description'] = vDescription;
			methoduoezdepthobj['index'] = index;

	methoduoezdepthdata.push(methoduoezdepthobj);
});
return methoduoezdepthdata;
	}
var instfaqthem = document.getElementById('faqthem');
	var faqtheminst = M.Collapsible.getInstance(instfaqthem);
$('#faqthem').collapsible({
	accordion: true,
	onOpenStart: function(el) {
                   
               },
    onOpenEnd: function(el) {
                   
               },
	onCloseStart: function(el) {
                   
               },
	onCloseEnd: function(el) {
                   
               }
	});
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawercollapse').collapsible({
	accordion: true,
	onOpenStart: function(el) {
                   
               },
    onOpenEnd: function(el) {
                   
               },
	onCloseStart: function(el) {
                   
               },
	onCloseEnd: function(el) {
                   
               }
	});
$('#navbardrawer').sidenav({
	draggable:true,
	preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
});
