$('#fabdiv').floatingActionButton({hoverEnabled: true,
	direction:'top',
	toolbarEnabled: false});
var instfab = document.getElementById('fabdiv');
	var fabinst = M.FloatingActionButton.getInstance(instfab);
var instp1 = document.getElementById('p1');
	var p1inst = M.Parallax.getInstance(instp1);
$('#navbardrawer').sidenav({
	draggable:true,
	preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
});
