function getRowsinvoice(){
	var invoicedata = [];
	invoicerows = $("#invoice tbody tr");
invoicerows.each(function (index) {
    var invoicerow = $(this);
 	var invoiceobj = {};
	
	invoicedata.push(invoiceobj);
});
return invoicedata;
	}
var tblinvoice = document.getElementById('invoice');
	// Class applied to each export button element.
	$.fn.tableExport.defaultButton = "button-default white-text black";
	new TableExport(tblinvoice, {
        headers: true,
        footers: true,
        formats: ['xlsx', 'xls', 'csv', 'txt'], 
		filename: 'invoice',                        
        bootstrap: true,                       
        position: 'bottom',                       
        ignoreRows: null,                         
        ignoreCols: null,                         
        ignoreCSS: '.tableexport-ignore',           
		emptyCSS: '.tableexport-empty',            
        trimWhitespace: true,                     
        RTL: false,                              
        sheetname: 'invoice'                            
    });
var invblock = document.getElementById('invcode');
Prism.highlightElement(invblock);
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
$("#tbl tbody").on("click", "tr", function () {
    activerow = $(this).closest('tr').find('td').map(function () {
        return $(this).text();
    }).get().join();
	M.toast({html:activerow, displayLength:3000, classes:'rounded white-text green'});
});
function getRowstbl(){
	var tbldata = [];
	tblrows = $("#tbl tbody tr");
tblrows.each(function (index) {
    var tblrow = $(this);
 	var tblobj = {};
	var vitemname = tblrow.find("[name=itemname]").text();
			tblobj['itemname'] = vitemname;
			tblobj['index'] = index;
var vitemsurname = tblrow.find("[name=itemsurname]").text();
			tblobj['itemsurname'] = vitemsurname;
			tblobj['index'] = index;
var vitemprice = tblrow.find("[name=itemprice]").text();
			tblobj['itemprice'] = vitemprice;
			tblobj['index'] = index;

	tbldata.push(tblobj);
});
return tbldata;
	}
function getRowstb2(){
	var tb2data = [];
	tb2rows = $("#tb2 tbody tr");
tb2rows.each(function (index) {
    var tb2row = $(this);
 	var tb2obj = {};
	
	tb2data.push(tb2obj);
});
return tb2data;
	}
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
function getRowstb3(){
	var tb3data = [];
	tb3rows = $("#tb3 tbody tr");
tb3rows.each(function (index) {
    var tb3row = $(this);
 	var tb3obj = {};
	
	tb3data.push(tb3obj);
});
return tb3data;
	}
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
function getRowstb4(){
	var tb4data = [];
	tb4rows = $("#tb4 tbody tr");
tb4rows.each(function (index) {
    var tb4row = $(this);
 	var tb4obj = {};
	
	tb4data.push(tb4obj);
});
return tb4data;
	}
var cd5block = document.getElementById('cd5code');
Prism.highlightElement(cd5block);
function getRowstb4(){
	var tb4data = [];
	tb4rows = $("#tb4 tbody tr");
tb4rows.each(function (index) {
    var tb4row = $(this);
 	var tb4obj = {};
	
	tb4data.push(tb4obj);
});
return tb4data;
	}
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawercollapse').collapsible({
	accordion: true,
	onOpenStart: function(el) {
                   
               },
    onOpenEnd: function(el) {
                   
               },
	onCloseStart: function(el) {
                   
               },
	onCloseEnd: function(el) {
                   
               }
	});
$('#navbardrawer').sidenav({
	draggable:true,
	preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
$(document).on('click', '#btn2json', function(){
$("#tbl").tableHTMLExport({type:'json',filename:'tbl.json'});
});
$(document).on('click', '#btn2txt', function(){
$("#tbl").tableHTMLExport({type:'txt',filename:'tbl.txt'});
});
$(document).on('click', '#btn2csv', function(){
$("#tbl").tableHTMLExport({type:'csv',filename:'tbl.csv'});
});
$(document).on('click', '#btn2png', function(){
domtoimage.toPng(document.getElementById('tbl'))
    .then(function (dataUrl) {
        var link = document.createElement('a');
        link.download = 'tbl.png';
        link.href = dataUrl;
		link.target = "_blank";
        link.click();
    });

});
$(document).on('click', '#btnget', function(){
myData = getRowstbl();tblData = JSON.stringify(myData);
M.toast({html:tblData, displayLength:3000, classes:'rounded white-text green'});

});
$(document).on('click', '#btntoggle', function(){
var tbltbl = $("#tbl");
    var tblheadtbl = $("#tbl th");
	var colToHidetbl = tblheadtbl.filter(".itemsurname");
    var indextbl = colToHidetbl.index();
    tbltbl.find('tr :nth-child(' + (indextbl + 1) + ')').toggle();
});
$(document).on('click', '#btnclear', function(){
$('#tbl tbody tr').remove();
});
$(document).on('click', '#btnlastrow', function(){
var newRow = '<tr id="tbl_r1550174500992"><td id="tbl_r1550174500992_c0" name="itemname" class="itemname" style="text-align:left !important;">Anele</td><td id="tbl_r1550174500992_c1" name="itemsurname" class="itemsurname" style="text-align:center !important;">Mbangas</td><td id="tbl_r1550174500992_c2" name="itemprice" class="itemprice" style="text-align:right !important;">On Last Row</td></tr>';
		var tbl = $('#tbl');
		tbl.append(newRow);
});
$(document).on('click', '#btnfirst', function(){
var newRow = '<tr id="tbl_r1550174500997"><td id="tbl_r1550174500997_c0" name="itemname" class="itemname" style="text-align:left !important;">Mashy</td><td id="tbl_r1550174500997_c1" name="itemsurname" class="itemsurname" style="text-align:center !important;">Mabi</td><td id="tbl_r1550174500997_c2" name="itemprice" class="itemprice" style="text-align:right !important;">First Row</td></tr>';
		$('#tbl > tbody > tr').eq(1-1).before(newRow);
});
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
});
