var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
var mbill0chart;
function mbill0Chart(){
	mbill0chart = bb.generate({
	data: {x: "x",
  	columns: [["x", "2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "bar",
    types: {
data1:"bar",data2:"bar"},
    
	labels: true,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Horizontal Chart"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: true,
    x: {
	  type: "category",
		categories: ["2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
      label: {
	  	text: "Period",
	  	position: "outer-center"
	  },
	  tick: {
        rotate: 0,
        multiline: false,
        tooltip: true
      },
      height: 0,
    },
    y: {
      label: {
	  	text: "Percentage",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: true
    },
    y: {
      show: true
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#mbill0"
});
mbill0chart.flush(true);
	}
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var mbill1chart;
function mbill1Chart(){
	mbill1chart = bb.generate({
	data: {x: "x",
  	columns: [["x", "2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "bar",
    types: {
data1:"area",data2:"area-spline"},
    
	labels: true,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Area & Area-Spline"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  type: "category",
		categories: ["2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
      label: {
	  	text: "Period",
	  	position: "outer-center"
	  },
	  tick: {
        rotate: 90,
        multiline: false,
        tooltip: true
      },
      height: 100,
    },
    y: {
      label: {
	  	text: "Percentage",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: false,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#mbill1"
});
mbill1chart.flush(true);
	}
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
var mbill2chart;
function mbill2Chart(){
	mbill2chart = bb.generate({
	data: {x: "x",
  	columns: [["x", "2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "bar",
    types: {
data1:"bar",data2:"bar"},
    
	labels: true,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Bar Charts"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  type: "category",
		categories: ["2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
      label: {
	  	text: "Period",
	  	position: "outer-center"
	  },
	  tick: {
        rotate: 0,
        multiline: false,
        tooltip: true
      },
      height: 0,
    },
    y: {
      label: {
	  	text: "Percentage",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#mbill2"
});
mbill2chart.flush(true);
	}
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
var mbill3chart;
function mbill3Chart(){
	mbill3chart = bb.generate({
	data: {x: "x",
  	columns: [["x", "2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "bar",
    types: {
data1:"bar",data2:"bar"},
    groups: [
      [
        "data1","data2"
      ]
    ],
	labels: true,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Stacked Charts"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  type: "category",
		categories: ["2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
      label: {
	  	text: "Period",
	  	position: "outer-center"
	  },
	  tick: {
        rotate: 0,
        multiline: false,
        tooltip: true
      },
      height: 0,
    },
    y: {
      label: {
	  	text: "Percentage",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#mbill3"
});
mbill3chart.flush(true);
	}
var cd5block = document.getElementById('cd5code');
Prism.highlightElement(cd5block);
var mbillchart;
function mbillChart(){
	mbillchart = bb.generate({
	data: {x: "x",
  	columns: [["x", "2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "bar",
    types: {
data1:"bar",data2:"spline"},
    
	labels: true,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Combination Chart"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  type: "category",
		categories: ["2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
      label: {
	  	text: "",
	  	position: "outer-center"
	  },
	  tick: {
        rotate: 0,
        multiline: false,
        tooltip: true
      },
      height: 0,
    },
    y: {
      label: {
	  	text: "",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#mbill"
});
mbillchart.flush(true);
	}
var cd6block = document.getElementById('cd6code');
Prism.highlightElement(cd6block);
var mbilldchart;
function mbilldChart(){
	mbilldchart = bb.generate({
	data: {
  	columns: [
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "donut",
    types: {
data1:"donut",data2:"donut"},
    
	labels: false,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Donut"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  
      label: {
	  	text: "",
	  	position: "outer-center"
	  },
	  
    },
    y: {
      label: {
	  	text: "",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "Donut",
padAngle: 0.1,
label: {
show: true,
}
},
  bindto: "#mbilld"
});
mbilldchart.flush(true);
	}
var cd7block = document.getElementById('cd7code');
Prism.highlightElement(cd7block);
var mbillgchart;
function mbillgChart(){
	mbillgchart = bb.generate({
	data: {
  	columns: [
	["data1",60]
	],
	names: {data1:"% Progress"},
    color: {
    pattern: [
      "red","blue","orange","green"
    ],
    threshold: {
      values: [
        30,60,90,100
      ]
    }
  },
	
	type: "gauge",
    types: {
data1:"gauge"},
    
	labels: false,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Gauge"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  
      label: {
	  	text: "",
	  	position: "outer-center"
	  },
	  
    },
    y: {
      label: {
	  	text: "",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#mbillg"
});
mbillgchart.flush(true);
	}
var cd8block = document.getElementById('cd8code');
Prism.highlightElement(cd8block);
var mbillpchart;
function mbillpChart(){
	mbillpchart = bb.generate({
	data: {
  	columns: [
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "pie",
    types: {
data1:"pie",data2:"pie"},
    
	labels: false,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Pie"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  
  pie: {
  	innerRadius: 20,
	padAngle: 0.1,
	padding: 3,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  
      label: {
	  	text: "",
	  	position: "outer-center"
	  },
	  
    },
    y: {
      label: {
	  	text: "",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#mbillp"
});
mbillpchart.flush(true);
	}
var cd9block = document.getElementById('cd9code');
Prism.highlightElement(cd9block);
var mbillstepchart;
function mbillstepChart(){
	mbillstepchart = bb.generate({
	data: {x: "x",
  	columns: [["x", "2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "step",
    types: {
data1:"step",data2:"area-step"},
    
	labels: true,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Step"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  type: "category",
		categories: ["2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
      label: {
	  	text: "",
	  	position: "outer-center"
	  },
	  tick: {
        rotate: 0,
        multiline: false,
        tooltip: true
      },
      height: 0,
    },
    y: {
      label: {
	  	text: "",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#mbillstep"
});
mbillstepchart.flush(true);
	}
var cd10block = document.getElementById('cd10code');
Prism.highlightElement(cd10block);
var mbilllchart;
function mbilllChart(){
	mbilllchart = bb.generate({
	data: {x: "x",
  	columns: [["x", "2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "line",
    types: {
data1:"line",data2:"line"},
    
	labels: true,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Line"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  type: "category",
		categories: ["2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
      label: {
	  	text: "",
	  	position: "outer-center"
	  },
	  tick: {
        rotate: 0,
        multiline: false,
        tooltip: true
      },
      height: 0,
    },
    y: {
      label: {
	  	text: "",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#mbilll"
});
mbilllchart.flush(true);
	}
var cd11block = document.getElementById('cd11code');
Prism.highlightElement(cd11block);
var radar1chart;
function radar1Chart(){
	radar1chart = bb.generate({
	data: {x: "x",
  	columns: [["x", "2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "radar",
    types: {
data1:"radar",data2:"radar"},
    
	labels: true,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Radar1"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  type: "category",
		categories: ["2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
      label: {
	  	text: "",
	  	position: "outer-center"
	  },
	  tick: {
        rotate: 0,
        multiline: false,
        tooltip: true
      },
      height: 0,
    },
    y: {
      label: {
	  	text: "",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#radar1"
});
radar1chart.flush(true);
	}
var cd12block = document.getElementById('cd12code');
Prism.highlightElement(cd12block);
var scatterchart;
function scatterChart(){
	scatterchart = bb.generate({
	data: {x: "x",
  	columns: [["x", "2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "scatter",
    types: {
data1:"scatter",data2:"scatter"},
    
	labels: true,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Scatter"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  type: "category",
		categories: ["2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
      label: {
	  	text: "",
	  	position: "outer-center"
	  },
	  tick: {
        rotate: 0,
        multiline: false,
        tooltip: true
      },
      height: 0,
    },
    y: {
      label: {
	  	text: "",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: true
    },
    y: {
      show: true
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#scatter"
});
scatterchart.flush(true);
	}
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawercollapse').collapsible({
	accordion: true,
	onOpenStart: function(el) {
                   
               },
    onOpenEnd: function(el) {
                   
               },
	onCloseStart: function(el) {
                   
               },
	onCloseEnd: function(el) {
                   
               }
	});
$('#navbardrawer').sidenav({
	draggable:true,
	preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
mbill0Chart();
$(document).on('click', '#btnimage', function(){
domtoimage.toPng(document.getElementById('mbill0'))
    .then(function (dataUrl) {
        var link = document.createElement('a');
        link.download = 'mbill0.png';
        link.href = dataUrl;
		link.target = "_blank";
        link.click();
    });

});
$(document).on('click', '#btnprint', function(){
$('#mbill0').printThis();
});
mbill1Chart();
mbill2Chart();
mbill3Chart();
mbillChart();
mbilldChart();
mbillgChart();
mbillpChart();
mbillstepChart();
mbilllChart();
radar1Chart();
scatterChart();
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
});
