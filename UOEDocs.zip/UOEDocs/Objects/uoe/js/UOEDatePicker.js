var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
var instdp = document.getElementById('dp');
		var dpinst = M.Datepicker.getInstance(instdp);
var datedp = $('#dp').datepicker({
	showClearBtn:true,
	showDaysInNextAndPreviousMonths:true,
	showMonthAfterYear:true,
	yearRange:10,
	firstDay:0,
	disableWeekends:false,
	setDefaultDate:true,
	format:'yyyy-mm-dd',
	autoClose: false,
	i18n: {
		cancel: 'Cancel',
        clear: 'Clear',
		done: 'Ok',
		previousMonth: '<',
		nextMonth: '>'
      }
	});
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var instdp1 = document.getElementById('dp1');
		var dp1inst = M.Timepicker.getInstance(instdp1);
var timedp1 = $('#dp1').timepicker({
	showClearBtn:true,
	twelveHour:false,
	defaultTime:'now',
	format:'yyyy-mm-dd',
	vibrate: true,
	autoClose: false,
	i18n: {
		cancel: 'Cancel',
        clear: 'Clear',
		done: 'Ok'
	  }
	});
	timedp1.showView('hours');
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawercollapse').collapsible({
	accordion: true,
	onOpenStart: function(el) {
                   
               },
    onOpenEnd: function(el) {
                   
               },
	onCloseStart: function(el) {
                   
               },
	onCloseEnd: function(el) {
                   
               }
	});
$('#navbardrawer').sidenav({
	draggable:true,
	preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
});
