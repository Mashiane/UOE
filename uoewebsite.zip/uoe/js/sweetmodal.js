M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
$(document).on('click', '#btnalert', function(e){
	e.preventDefault();
$.sweetModal('Alert', 'This is an alert message!');
});
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
$(document).on('click', '#btnsuccess', function(e){
	e.preventDefault();
$.sweetModal({content: 'This is a success message!',title: 'Success',icon: $.sweetModal.ICON_SUCCESS});
});
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
$(document).on('click', '#btnwarning', function(e){
	e.preventDefault();
$.sweetModal({content: 'This is a warning message!',title: 'Warning',icon: $.sweetModal.ICON_WARNING});
});
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
$(document).on('click', '#btnerror', function(e){
	e.preventDefault();
$.sweetModal({content: 'This is an error message!',title: 'Error',icon: $.sweetModal.ICON_ERROR});
});
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
$(document).on('click', '#btnconfirm', function(e){
	e.preventDefault();
$.sweetModal.confirm('Confirm', 'Are you sure you want to do this?', function() {
	M.toast({html:'<div>OK</div>', displayLength:3000, classes:'rounded white-text  green'});
}, function() {
	M.toast({html:'<div>NO</div>', displayLength:3000, classes:'rounded white-text  red'});
});
});
var cd5block = document.getElementById('cd5code');
Prism.highlightElement(cd5block);
$(document).on('click', '#btnprompt', function(e){
	e.preventDefault();
$.sweetModal.prompt('Prompt', 'Please enter your name here.', 'Mashy', function(val) {
	M.toast({html:val, displayLength:3000, classes:'rounded white-text green'});
});
});
var cd6block = document.getElementById('cd6code');
Prism.highlightElement(cd6block);
$(document).on('click', '#btnyoutube', function(e){
	e.preventDefault();
$.sweetModal({
	title: 'Will YouTube Ever Run Out Of Video IDs?',
	content: 'https://www.youtube.com/watch?v=gocwRvLhDf8'
});
});
var cd7block = document.getElementById('cd7code');
Prism.highlightElement(cd7block);
function showmashy(){
	$.sweetModal({
	title: {
		tab1: {label: 'Name(s)', icon: ''},
tab2: {label: 'Contact Details', icon: ''}
		},
	content: {
		tab1: '<div id="tb1cont" data-sequence="500" data-appear-top-offset="-300" class="animatedParent animations"><div id="tb1contr1" style="margin-top:0px !important; margin-bottom:20px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="row"><div id="tb1contr1c1" style="margin-top:0px !important; margin-bottom:0px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="col s12 m12 l12 offset-s0 offset-m0 offset-l0"><div id="txtnamep" class="input-field col s12 m12 l12"><input id="txtname" type="text" data-length="-1" value="" class="validate"><label for="txtname" class="active">Name</label><span data-error="Error" data-success="Success" class="helper-text"></span></div></div></div><div id="tb1contr2" style="margin-top:0px !important; margin-bottom:20px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="row"><div id="tb1contr2c1" style="margin-top:0px !important; margin-bottom:0px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="col s12 m12 l12 offset-s0 offset-m0 offset-l0"><div id="txtsurnamep" class="input-field col s12 m12 l12"><input id="txtsurname" type="text" data-length="-1" value="" class="validate"><label for="txtsurname" class="active">Surname</label><span data-error="Error" data-success="Success" class="helper-text"></span></div></div></div><div id="tb1contr3" style="margin-top:0px !important; margin-bottom:20px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="row"><div id="tb1contr3c1" style="margin-top:0px !important; margin-bottom:0px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="col s12 m12 l12 offset-s0 offset-m0 offset-l0"></div></div><div id="tb1contr4" style="margin-top:0px !important; margin-bottom:20px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="row"><div id="tb1contr4c1" style="margin-top:0px !important; margin-bottom:0px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="col s12 m12 l12 offset-s0 offset-m0 offset-l0"></div></div><div id="tb1contr5" style="margin-top:0px !important; margin-bottom:20px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="row"><div id="tb1contr5c1" style="margin-top:0px !important; margin-bottom:0px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="col s12 m12 l12 offset-s0 offset-m0 offset-l0"></div></div></div>',
tab2: '<div id="tb2cont" data-sequence="500" data-appear-top-offset="-300" class="animatedParent animations"><div id="tb2contr1" style="margin-top:0px !important; margin-bottom:20px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="row"><div id="tb2contr1c1" style="margin-top:0px !important; margin-bottom:0px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="col s12 m12 l12 offset-s0 offset-m0 offset-l0"><div id="txtidp" class="input-field col s12 m12 l12"><input id="txtid" type="text" data-length="-1" value="" class="validate"><label for="txtid" class="active">ID #</label><span data-error="Error" data-success="Success" class="helper-text"></span></div></div></div><div id="tb2contr2" style="margin-top:0px !important; margin-bottom:20px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="row"><div id="tb2contr2c1" style="margin-top:0px !important; margin-bottom:0px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="col s12 m12 l12 offset-s0 offset-m0 offset-l0"><div id="txtemailp" class="input-field col s12 m12 l12"><input id="txtemail" type="text" data-length="-1" value="" class="validate"><label for="txtemail" class="active">Email Address</label><span data-error="Error" data-success="Success" class="helper-text"></span></div></div></div><div id="tb2contr3" style="margin-top:0px !important; margin-bottom:20px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="row"><div id="tb2contr3c1" style="margin-top:0px !important; margin-bottom:0px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="col s12 m12 l12 offset-s0 offset-m0 offset-l0"></div></div><div id="tb2contr4" style="margin-top:0px !important; margin-bottom:20px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="row"><div id="tb2contr4c1" style="margin-top:0px !important; margin-bottom:0px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="col s12 m12 l12 offset-s0 offset-m0 offset-l0"></div></div><div id="tb2contr5" style="margin-top:0px !important; margin-bottom:20px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="row"><div id="tb2contr5c1" style="margin-top:0px !important; margin-bottom:0px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="col s12 m12 l12 offset-s0 offset-m0 offset-l0"></div></div></div>'
		} ,
	icon: '',
	showCloseButton: true,
	blocking: true,	
	timeout: null,
	width: 'auto',
	buttons: {
		btnSaveModal: {
			label: 'Save',
			classes: 'greenB',
			action: function() {
				return M.toast({html:'<div>Save</div>', displayLength:3000, classes:'rounded white-text  green'});
			}
		}
		}
});
}
$(document).on('click', '#btnsm', function(e){
	e.preventDefault();
showmashy();
});
var cd8block = document.getElementById('cd8code');
Prism.highlightElement(cd8block);
var cd9block = document.getElementById('cd9code');
Prism.highlightElement(cd9block);
function showsm2(){
	$.sweetModal({
	title: 'Sign In',
	content: '<div id="tb3cont" data-sequence="500" data-appear-top-offset="-300" class="animatedParent animations"><div id="tb3contr1" style="margin-top:0px !important; margin-bottom:20px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="row"><div id="tb3contr1c1" style="margin-top:0px !important; margin-bottom:0px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="col s12 m12 l12 offset-s0 offset-m0 offset-l0"><div id="txtnamep" class="input-field col s12 m12 l12"><input id="txtname" type="text" data-length="-1" value="" class="validate"><label for="txtname" class="active">Name</label><span data-error="Error" data-success="Success" class="helper-text"></span></div></div></div><div id="tb3contr2" style="margin-top:0px !important; margin-bottom:20px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="row"><div id="tb3contr2c1" style="margin-top:0px !important; margin-bottom:0px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="col s12 m12 l12 offset-s0 offset-m0 offset-l0"><div id="txtsurnamep" class="input-field col s12 m12 l12"><input id="txtsurname" type="text" data-length="-1" value="" class="validate"><label for="txtsurname" class="active">Surname</label><span data-error="Error" data-success="Success" class="helper-text"></span></div></div></div><div id="tb3contr3" style="margin-top:0px !important; margin-bottom:20px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="row"><div id="tb3contr3c1" style="margin-top:0px !important; margin-bottom:0px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="col s12 m12 l12 offset-s0 offset-m0 offset-l0"><div id="txtidp" class="input-field col s12 m12 l12"><input id="txtid" type="text" data-length="-1" value="" class="validate"><label for="txtid" class="active">ID #</label><span data-error="Error" data-success="Success" class="helper-text"></span></div></div></div><div id="tb3contr4" style="margin-top:0px !important; margin-bottom:20px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="row"><div id="tb3contr4c1" style="margin-top:0px !important; margin-bottom:0px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="col s12 m12 l12 offset-s0 offset-m0 offset-l0"><div id="txtemailp" class="input-field col s12 m12 l12"><input id="txtemail" type="text" data-length="-1" value="" class="validate"><label for="txtemail" class="active">Email Address</label><span data-error="Error" data-success="Success" class="helper-text"></span></div></div></div><div id="tb3contr5" style="margin-top:0px !important; margin-bottom:20px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="row"><div id="tb3contr5c1" style="margin-top:0px !important; margin-bottom:0px !important; margin-left:0px !important; margin-right:0px !important; padding-top:0px !important; padding-bottom:0px !important; padding-left:0px !important; padding-right:0px !important;" class="col s12 m12 l12 offset-s0 offset-m0 offset-l0"></div></div></div>' ,
	icon: '',
	showCloseButton: true,
	blocking: false,	
	timeout: null,
	width: 'auto',
	buttons: {
		btnSaveDetails: {
			label: 'Save',
			classes: 'greenB',
			action: function() {
				return M.toast({html:'<div>Save</div>', displayLength:3000, classes:'rounded white-text  green'});
			}
		}
		}
});
}
$(document).on('click', '#btndetails', function(e){
	e.preventDefault();
showsm2();
});
var cd10block = document.getElementById('cd10code');
Prism.highlightElement(cd10block);
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){

});
