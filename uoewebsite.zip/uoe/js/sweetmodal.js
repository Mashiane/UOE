
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
$('#btnalert').on('click', function (e) {
$.sweetModal('Alert', 'This is an alert message!');});
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
$('#btnsuccess').on('click', function (e) {
$.sweetModal({content: 'This is a success message!',title: 'Success',icon: $.sweetModal.ICON_SUCCESS});});
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
$('#btnwarning').on('click', function (e) {
$.sweetModal({content: 'This is a warning message!',title: 'Warning',icon: $.sweetModal.ICON_WARNING});});
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
$('#btnerror').on('click', function (e) {
$.sweetModal({content: 'This is an error message!',title: 'Error',icon: $.sweetModal.ICON_ERROR});});
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
$('#btnconfirm').on('click', function (e) {
$.sweetModal.confirm('Confirm', 'Are you sure you want to do this?', function() {
	M.toast({html:'<div>OK</div>', displayLength:3000, classes:'rounded  green white-text '});
}, function() {
	M.toast({html:'<div>NO</div>', displayLength:3000, classes:'rounded  red white-text '});
});});
var cd5block = document.getElementById('cd5code');
Prism.highlightElement(cd5block);
$('#btnprompt').on('click', function (e) {
$.sweetModal.prompt('Prompt', 'Please enter your name here.', 'Mashy', function(val) {
	M.toast({html:val, displayLength:3000, classes:'rounded white-text green'});
});});
var cd6block = document.getElementById('cd6code');
Prism.highlightElement(cd6block);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
