$('#modalp').modal({
	startingTop:'4%',endingTop:'10%',dismissible: false,
	preventScrolling: true});
var instmodalp = document.getElementById('modalp');
	var modalpinst = M.Modal.getInstance(instmodalp);
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
$('#modalp1').modal({
	startingTop:'4%',endingTop:'10%',dismissible: false,
	preventScrolling: true});
var instmodalp1 = document.getElementById('modalp1');
	var modalp1inst = M.Modal.getInstance(instmodalp1);
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
$('#modalp2').modal({
	startingTop:'4%',endingTop:'10%',dismissible: false,
	preventScrolling: true});
var instmodalp2 = document.getElementById('modalp2');
	var modalp2inst = M.Modal.getInstance(instmodalp2);
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawercollapse').collapsible({
	accordion: true,
	onOpenStart: function(el) {
                   
               },
    onOpenEnd: function(el) {
                   
               },
	onCloseStart: function(el) {
                   
               },
	onCloseEnd: function(el) {
                   
               }
	});
$('#navbardrawer').sidenav({
	draggable:true,
	preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
$(document).on('click', '#btnagree', function(){
modalpinst.close();
});
$(document).on('click', '#btncancel', function(){
modalpinst.close();
});
$(document).on('click', '#btnopen', function(){
modalpinst.open();
});
$(document).on('click', '#btnagree', function(){
modalp1inst.close();
});
$(document).on('click', '#btncancel', function(){
modalp1inst.close();
});
$(document).on('click', '#btnopen1', function(){
modalp1inst.open();
});
$(document).on('click', '#btnagree', function(){
modalp2inst.close();
});
$(document).on('click', '#btncancel', function(){
modalp2inst.close();
});
$(document).on('click', '#btnopen2', function(){
modalp2inst.open();
});
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
});
