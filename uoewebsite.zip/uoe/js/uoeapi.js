var colors = HTMLColors();
var activerow;
function getRowstblanimation(){
	var tblanimationdata = [];
	tblanimationrows = $("#tblanimation tbody tr");
tblanimationrows.each(function (index) {
    var tblanimationrow = $(this);
 	var tblanimationobj = {};
	var vProperty = tblanimationrow.find("[name=Property]").text();
			tblanimationobj['Property'] = vProperty;
			tblanimationobj['index'] = index;
var vType = tblanimationrow.find("[name=Type]").text();
			tblanimationobj['Type'] = vType;
			tblanimationobj['index'] = index;
var vDefaultValue = tblanimationrow.find("[name=DefaultValue]").text();
			tblanimationobj['DefaultValue'] = vDefaultValue;
			tblanimationobj['index'] = index;
var vDescription = tblanimationrow.find("[name=Description]").text();
			tblanimationobj['Description'] = vDescription;
			tblanimationobj['index'] = index;

	tblanimationdata.push(tblanimationobj);
});
return tblanimationdata;
	}
function getRowsmethodanimation(){
	var methodanimationdata = [];
	methodanimationrows = $("#methodanimation tbody tr");
methodanimationrows.each(function (index) {
    var methodanimationrow = $(this);
 	var methodanimationobj = {};
	var vMethod = methodanimationrow.find("[name=Method]").text();
			methodanimationobj['Method'] = vMethod;
			methodanimationobj['index'] = index;
var vParameters = methodanimationrow.find("[name=Parameters]").text();
			methodanimationobj['Parameters'] = vParameters;
			methodanimationobj['index'] = index;
var vReturnType = methodanimationrow.find("[name=ReturnType]").text();
			methodanimationobj['ReturnType'] = vReturnType;
			methodanimationobj['index'] = index;
var vDescription = methodanimationrow.find("[name=Description]").text();
			methodanimationobj['Description'] = vDescription;
			methodanimationobj['index'] = index;

	methodanimationdata.push(methodanimationobj);
});
return methodanimationdata;
	}
function getRowstblclsalignment(){
	var tblclsalignmentdata = [];
	tblclsalignmentrows = $("#tblclsalignment tbody tr");
tblclsalignmentrows.each(function (index) {
    var tblclsalignmentrow = $(this);
 	var tblclsalignmentobj = {};
	var vProperty = tblclsalignmentrow.find("[name=Property]").text();
			tblclsalignmentobj['Property'] = vProperty;
			tblclsalignmentobj['index'] = index;
var vType = tblclsalignmentrow.find("[name=Type]").text();
			tblclsalignmentobj['Type'] = vType;
			tblclsalignmentobj['index'] = index;
var vDefaultValue = tblclsalignmentrow.find("[name=DefaultValue]").text();
			tblclsalignmentobj['DefaultValue'] = vDefaultValue;
			tblclsalignmentobj['index'] = index;
var vDescription = tblclsalignmentrow.find("[name=Description]").text();
			tblclsalignmentobj['Description'] = vDescription;
			tblclsalignmentobj['index'] = index;

	tblclsalignmentdata.push(tblclsalignmentobj);
});
return tblclsalignmentdata;
	}
function getRowsmethodclsalignment(){
	var methodclsalignmentdata = [];
	methodclsalignmentrows = $("#methodclsalignment tbody tr");
methodclsalignmentrows.each(function (index) {
    var methodclsalignmentrow = $(this);
 	var methodclsalignmentobj = {};
	var vMethod = methodclsalignmentrow.find("[name=Method]").text();
			methodclsalignmentobj['Method'] = vMethod;
			methodclsalignmentobj['index'] = index;
var vParameters = methodclsalignmentrow.find("[name=Parameters]").text();
			methodclsalignmentobj['Parameters'] = vParameters;
			methodclsalignmentobj['index'] = index;
var vReturnType = methodclsalignmentrow.find("[name=ReturnType]").text();
			methodclsalignmentobj['ReturnType'] = vReturnType;
			methodclsalignmentobj['index'] = index;
var vDescription = methodclsalignmentrow.find("[name=Description]").text();
			methodclsalignmentobj['Description'] = vDescription;
			methodclsalignmentobj['index'] = index;

	methodclsalignmentdata.push(methodclsalignmentobj);
});
return methodclsalignmentdata;
	}
function getRowstblclsanglearctype(){
	var tblclsanglearctypedata = [];
	tblclsanglearctyperows = $("#tblclsanglearctype tbody tr");
tblclsanglearctyperows.each(function (index) {
    var tblclsanglearctyperow = $(this);
 	var tblclsanglearctypeobj = {};
	var vProperty = tblclsanglearctyperow.find("[name=Property]").text();
			tblclsanglearctypeobj['Property'] = vProperty;
			tblclsanglearctypeobj['index'] = index;
var vType = tblclsanglearctyperow.find("[name=Type]").text();
			tblclsanglearctypeobj['Type'] = vType;
			tblclsanglearctypeobj['index'] = index;
var vDefaultValue = tblclsanglearctyperow.find("[name=DefaultValue]").text();
			tblclsanglearctypeobj['DefaultValue'] = vDefaultValue;
			tblclsanglearctypeobj['index'] = index;
var vDescription = tblclsanglearctyperow.find("[name=Description]").text();
			tblclsanglearctypeobj['Description'] = vDescription;
			tblclsanglearctypeobj['index'] = index;

	tblclsanglearctypedata.push(tblclsanglearctypeobj);
});
return tblclsanglearctypedata;
	}
function getRowsmethodclsanglearctype(){
	var methodclsanglearctypedata = [];
	methodclsanglearctyperows = $("#methodclsanglearctype tbody tr");
methodclsanglearctyperows.each(function (index) {
    var methodclsanglearctyperow = $(this);
 	var methodclsanglearctypeobj = {};
	var vMethod = methodclsanglearctyperow.find("[name=Method]").text();
			methodclsanglearctypeobj['Method'] = vMethod;
			methodclsanglearctypeobj['index'] = index;
var vParameters = methodclsanglearctyperow.find("[name=Parameters]").text();
			methodclsanglearctypeobj['Parameters'] = vParameters;
			methodclsanglearctypeobj['index'] = index;
var vReturnType = methodclsanglearctyperow.find("[name=ReturnType]").text();
			methodclsanglearctypeobj['ReturnType'] = vReturnType;
			methodclsanglearctypeobj['index'] = index;
var vDescription = methodclsanglearctyperow.find("[name=Description]").text();
			methodclsanglearctypeobj['Description'] = vDescription;
			methodclsanglearctypeobj['index'] = index;

	methodclsanglearctypedata.push(methodclsanglearctypeobj);
});
return methodclsanglearctypedata;
	}
function getRowstblclsangleoffsettype(){
	var tblclsangleoffsettypedata = [];
	tblclsangleoffsettyperows = $("#tblclsangleoffsettype tbody tr");
tblclsangleoffsettyperows.each(function (index) {
    var tblclsangleoffsettyperow = $(this);
 	var tblclsangleoffsettypeobj = {};
	var vProperty = tblclsangleoffsettyperow.find("[name=Property]").text();
			tblclsangleoffsettypeobj['Property'] = vProperty;
			tblclsangleoffsettypeobj['index'] = index;
var vType = tblclsangleoffsettyperow.find("[name=Type]").text();
			tblclsangleoffsettypeobj['Type'] = vType;
			tblclsangleoffsettypeobj['index'] = index;
var vDefaultValue = tblclsangleoffsettyperow.find("[name=DefaultValue]").text();
			tblclsangleoffsettypeobj['DefaultValue'] = vDefaultValue;
			tblclsangleoffsettypeobj['index'] = index;
var vDescription = tblclsangleoffsettyperow.find("[name=Description]").text();
			tblclsangleoffsettypeobj['Description'] = vDescription;
			tblclsangleoffsettypeobj['index'] = index;

	tblclsangleoffsettypedata.push(tblclsangleoffsettypeobj);
});
return tblclsangleoffsettypedata;
	}
function getRowsmethodclsangleoffsettype(){
	var methodclsangleoffsettypedata = [];
	methodclsangleoffsettyperows = $("#methodclsangleoffsettype tbody tr");
methodclsangleoffsettyperows.each(function (index) {
    var methodclsangleoffsettyperow = $(this);
 	var methodclsangleoffsettypeobj = {};
	var vMethod = methodclsangleoffsettyperow.find("[name=Method]").text();
			methodclsangleoffsettypeobj['Method'] = vMethod;
			methodclsangleoffsettypeobj['index'] = index;
var vParameters = methodclsangleoffsettyperow.find("[name=Parameters]").text();
			methodclsangleoffsettypeobj['Parameters'] = vParameters;
			methodclsangleoffsettypeobj['index'] = index;
var vReturnType = methodclsangleoffsettyperow.find("[name=ReturnType]").text();
			methodclsangleoffsettypeobj['ReturnType'] = vReturnType;
			methodclsangleoffsettypeobj['index'] = index;
var vDescription = methodclsangleoffsettyperow.find("[name=Description]").text();
			methodclsangleoffsettypeobj['Description'] = vDescription;
			methodclsangleoffsettypeobj['index'] = index;

	methodclsangleoffsettypedata.push(methodclsangleoffsettypeobj);
});
return methodclsangleoffsettypedata;
	}
function getRowstblclsanimation(){
	var tblclsanimationdata = [];
	tblclsanimationrows = $("#tblclsanimation tbody tr");
tblclsanimationrows.each(function (index) {
    var tblclsanimationrow = $(this);
 	var tblclsanimationobj = {};
	var vProperty = tblclsanimationrow.find("[name=Property]").text();
			tblclsanimationobj['Property'] = vProperty;
			tblclsanimationobj['index'] = index;
var vType = tblclsanimationrow.find("[name=Type]").text();
			tblclsanimationobj['Type'] = vType;
			tblclsanimationobj['index'] = index;
var vDefaultValue = tblclsanimationrow.find("[name=DefaultValue]").text();
			tblclsanimationobj['DefaultValue'] = vDefaultValue;
			tblclsanimationobj['index'] = index;
var vDescription = tblclsanimationrow.find("[name=Description]").text();
			tblclsanimationobj['Description'] = vDescription;
			tblclsanimationobj['index'] = index;

	tblclsanimationdata.push(tblclsanimationobj);
});
return tblclsanimationdata;
	}
function getRowsmethodclsanimation(){
	var methodclsanimationdata = [];
	methodclsanimationrows = $("#methodclsanimation tbody tr");
methodclsanimationrows.each(function (index) {
    var methodclsanimationrow = $(this);
 	var methodclsanimationobj = {};
	var vMethod = methodclsanimationrow.find("[name=Method]").text();
			methodclsanimationobj['Method'] = vMethod;
			methodclsanimationobj['index'] = index;
var vParameters = methodclsanimationrow.find("[name=Parameters]").text();
			methodclsanimationobj['Parameters'] = vParameters;
			methodclsanimationobj['index'] = index;
var vReturnType = methodclsanimationrow.find("[name=ReturnType]").text();
			methodclsanimationobj['ReturnType'] = vReturnType;
			methodclsanimationobj['index'] = index;
var vDescription = methodclsanimationrow.find("[name=Description]").text();
			methodclsanimationobj['Description'] = vDescription;
			methodclsanimationobj['index'] = index;

	methodclsanimationdata.push(methodclsanimationobj);
});
return methodclsanimationdata;
	}
function getRowstblclsbillboardcharttype(){
	var tblclsbillboardcharttypedata = [];
	tblclsbillboardcharttyperows = $("#tblclsbillboardcharttype tbody tr");
tblclsbillboardcharttyperows.each(function (index) {
    var tblclsbillboardcharttyperow = $(this);
 	var tblclsbillboardcharttypeobj = {};
	var vProperty = tblclsbillboardcharttyperow.find("[name=Property]").text();
			tblclsbillboardcharttypeobj['Property'] = vProperty;
			tblclsbillboardcharttypeobj['index'] = index;
var vType = tblclsbillboardcharttyperow.find("[name=Type]").text();
			tblclsbillboardcharttypeobj['Type'] = vType;
			tblclsbillboardcharttypeobj['index'] = index;
var vDefaultValue = tblclsbillboardcharttyperow.find("[name=DefaultValue]").text();
			tblclsbillboardcharttypeobj['DefaultValue'] = vDefaultValue;
			tblclsbillboardcharttypeobj['index'] = index;
var vDescription = tblclsbillboardcharttyperow.find("[name=Description]").text();
			tblclsbillboardcharttypeobj['Description'] = vDescription;
			tblclsbillboardcharttypeobj['index'] = index;

	tblclsbillboardcharttypedata.push(tblclsbillboardcharttypeobj);
});
return tblclsbillboardcharttypedata;
	}
function getRowsmethodclsbillboardcharttype(){
	var methodclsbillboardcharttypedata = [];
	methodclsbillboardcharttyperows = $("#methodclsbillboardcharttype tbody tr");
methodclsbillboardcharttyperows.each(function (index) {
    var methodclsbillboardcharttyperow = $(this);
 	var methodclsbillboardcharttypeobj = {};
	var vMethod = methodclsbillboardcharttyperow.find("[name=Method]").text();
			methodclsbillboardcharttypeobj['Method'] = vMethod;
			methodclsbillboardcharttypeobj['index'] = index;
var vParameters = methodclsbillboardcharttyperow.find("[name=Parameters]").text();
			methodclsbillboardcharttypeobj['Parameters'] = vParameters;
			methodclsbillboardcharttypeobj['index'] = index;
var vReturnType = methodclsbillboardcharttyperow.find("[name=ReturnType]").text();
			methodclsbillboardcharttypeobj['ReturnType'] = vReturnType;
			methodclsbillboardcharttypeobj['index'] = index;
var vDescription = methodclsbillboardcharttyperow.find("[name=Description]").text();
			methodclsbillboardcharttypeobj['Description'] = vDescription;
			methodclsbillboardcharttypeobj['index'] = index;

	methodclsbillboardcharttypedata.push(methodclsbillboardcharttypeobj);
});
return methodclsbillboardcharttypedata;
	}
function getRowstblclsbillboarddonuttype(){
	var tblclsbillboarddonuttypedata = [];
	tblclsbillboarddonuttyperows = $("#tblclsbillboarddonuttype tbody tr");
tblclsbillboarddonuttyperows.each(function (index) {
    var tblclsbillboarddonuttyperow = $(this);
 	var tblclsbillboarddonuttypeobj = {};
	var vProperty = tblclsbillboarddonuttyperow.find("[name=Property]").text();
			tblclsbillboarddonuttypeobj['Property'] = vProperty;
			tblclsbillboarddonuttypeobj['index'] = index;
var vType = tblclsbillboarddonuttyperow.find("[name=Type]").text();
			tblclsbillboarddonuttypeobj['Type'] = vType;
			tblclsbillboarddonuttypeobj['index'] = index;
var vDefaultValue = tblclsbillboarddonuttyperow.find("[name=DefaultValue]").text();
			tblclsbillboarddonuttypeobj['DefaultValue'] = vDefaultValue;
			tblclsbillboarddonuttypeobj['index'] = index;
var vDescription = tblclsbillboarddonuttyperow.find("[name=Description]").text();
			tblclsbillboarddonuttypeobj['Description'] = vDescription;
			tblclsbillboarddonuttypeobj['index'] = index;

	tblclsbillboarddonuttypedata.push(tblclsbillboarddonuttypeobj);
});
return tblclsbillboarddonuttypedata;
	}
function getRowsmethodclsbillboarddonuttype(){
	var methodclsbillboarddonuttypedata = [];
	methodclsbillboarddonuttyperows = $("#methodclsbillboarddonuttype tbody tr");
methodclsbillboarddonuttyperows.each(function (index) {
    var methodclsbillboarddonuttyperow = $(this);
 	var methodclsbillboarddonuttypeobj = {};
	var vMethod = methodclsbillboarddonuttyperow.find("[name=Method]").text();
			methodclsbillboarddonuttypeobj['Method'] = vMethod;
			methodclsbillboarddonuttypeobj['index'] = index;
var vParameters = methodclsbillboarddonuttyperow.find("[name=Parameters]").text();
			methodclsbillboarddonuttypeobj['Parameters'] = vParameters;
			methodclsbillboarddonuttypeobj['index'] = index;
var vReturnType = methodclsbillboarddonuttyperow.find("[name=ReturnType]").text();
			methodclsbillboarddonuttypeobj['ReturnType'] = vReturnType;
			methodclsbillboarddonuttypeobj['index'] = index;
var vDescription = methodclsbillboarddonuttyperow.find("[name=Description]").text();
			methodclsbillboarddonuttypeobj['Description'] = vDescription;
			methodclsbillboarddonuttypeobj['index'] = index;

	methodclsbillboarddonuttypedata.push(methodclsbillboarddonuttypeobj);
});
return methodclsbillboarddonuttypedata;
	}
function getRowstblclsbillboardgaugetype(){
	var tblclsbillboardgaugetypedata = [];
	tblclsbillboardgaugetyperows = $("#tblclsbillboardgaugetype tbody tr");
tblclsbillboardgaugetyperows.each(function (index) {
    var tblclsbillboardgaugetyperow = $(this);
 	var tblclsbillboardgaugetypeobj = {};
	var vProperty = tblclsbillboardgaugetyperow.find("[name=Property]").text();
			tblclsbillboardgaugetypeobj['Property'] = vProperty;
			tblclsbillboardgaugetypeobj['index'] = index;
var vType = tblclsbillboardgaugetyperow.find("[name=Type]").text();
			tblclsbillboardgaugetypeobj['Type'] = vType;
			tblclsbillboardgaugetypeobj['index'] = index;
var vDefaultValue = tblclsbillboardgaugetyperow.find("[name=DefaultValue]").text();
			tblclsbillboardgaugetypeobj['DefaultValue'] = vDefaultValue;
			tblclsbillboardgaugetypeobj['index'] = index;
var vDescription = tblclsbillboardgaugetyperow.find("[name=Description]").text();
			tblclsbillboardgaugetypeobj['Description'] = vDescription;
			tblclsbillboardgaugetypeobj['index'] = index;

	tblclsbillboardgaugetypedata.push(tblclsbillboardgaugetypeobj);
});
return tblclsbillboardgaugetypedata;
	}
function getRowsmethodclsbillboardgaugetype(){
	var methodclsbillboardgaugetypedata = [];
	methodclsbillboardgaugetyperows = $("#methodclsbillboardgaugetype tbody tr");
methodclsbillboardgaugetyperows.each(function (index) {
    var methodclsbillboardgaugetyperow = $(this);
 	var methodclsbillboardgaugetypeobj = {};
	var vMethod = methodclsbillboardgaugetyperow.find("[name=Method]").text();
			methodclsbillboardgaugetypeobj['Method'] = vMethod;
			methodclsbillboardgaugetypeobj['index'] = index;
var vParameters = methodclsbillboardgaugetyperow.find("[name=Parameters]").text();
			methodclsbillboardgaugetypeobj['Parameters'] = vParameters;
			methodclsbillboardgaugetypeobj['index'] = index;
var vReturnType = methodclsbillboardgaugetyperow.find("[name=ReturnType]").text();
			methodclsbillboardgaugetypeobj['ReturnType'] = vReturnType;
			methodclsbillboardgaugetypeobj['index'] = index;
var vDescription = methodclsbillboardgaugetyperow.find("[name=Description]").text();
			methodclsbillboardgaugetypeobj['Description'] = vDescription;
			methodclsbillboardgaugetypeobj['index'] = index;

	methodclsbillboardgaugetypedata.push(methodclsbillboardgaugetypeobj);
});
return methodclsbillboardgaugetypedata;
	}
function getRowstblclsbillboardlegendpositiontype(){
	var tblclsbillboardlegendpositiontypedata = [];
	tblclsbillboardlegendpositiontyperows = $("#tblclsbillboardlegendpositiontype tbody tr");
tblclsbillboardlegendpositiontyperows.each(function (index) {
    var tblclsbillboardlegendpositiontyperow = $(this);
 	var tblclsbillboardlegendpositiontypeobj = {};
	var vProperty = tblclsbillboardlegendpositiontyperow.find("[name=Property]").text();
			tblclsbillboardlegendpositiontypeobj['Property'] = vProperty;
			tblclsbillboardlegendpositiontypeobj['index'] = index;
var vType = tblclsbillboardlegendpositiontyperow.find("[name=Type]").text();
			tblclsbillboardlegendpositiontypeobj['Type'] = vType;
			tblclsbillboardlegendpositiontypeobj['index'] = index;
var vDefaultValue = tblclsbillboardlegendpositiontyperow.find("[name=DefaultValue]").text();
			tblclsbillboardlegendpositiontypeobj['DefaultValue'] = vDefaultValue;
			tblclsbillboardlegendpositiontypeobj['index'] = index;
var vDescription = tblclsbillboardlegendpositiontyperow.find("[name=Description]").text();
			tblclsbillboardlegendpositiontypeobj['Description'] = vDescription;
			tblclsbillboardlegendpositiontypeobj['index'] = index;

	tblclsbillboardlegendpositiontypedata.push(tblclsbillboardlegendpositiontypeobj);
});
return tblclsbillboardlegendpositiontypedata;
	}
function getRowsmethodclsbillboardlegendpositiontype(){
	var methodclsbillboardlegendpositiontypedata = [];
	methodclsbillboardlegendpositiontyperows = $("#methodclsbillboardlegendpositiontype tbody tr");
methodclsbillboardlegendpositiontyperows.each(function (index) {
    var methodclsbillboardlegendpositiontyperow = $(this);
 	var methodclsbillboardlegendpositiontypeobj = {};
	var vMethod = methodclsbillboardlegendpositiontyperow.find("[name=Method]").text();
			methodclsbillboardlegendpositiontypeobj['Method'] = vMethod;
			methodclsbillboardlegendpositiontypeobj['index'] = index;
var vParameters = methodclsbillboardlegendpositiontyperow.find("[name=Parameters]").text();
			methodclsbillboardlegendpositiontypeobj['Parameters'] = vParameters;
			methodclsbillboardlegendpositiontypeobj['index'] = index;
var vReturnType = methodclsbillboardlegendpositiontyperow.find("[name=ReturnType]").text();
			methodclsbillboardlegendpositiontypeobj['ReturnType'] = vReturnType;
			methodclsbillboardlegendpositiontypeobj['index'] = index;
var vDescription = methodclsbillboardlegendpositiontyperow.find("[name=Description]").text();
			methodclsbillboardlegendpositiontypeobj['Description'] = vDescription;
			methodclsbillboardlegendpositiontypeobj['index'] = index;

	methodclsbillboardlegendpositiontypedata.push(methodclsbillboardlegendpositiontypeobj);
});
return methodclsbillboardlegendpositiontypedata;
	}
function getRowstblclsbillboardlegendtype(){
	var tblclsbillboardlegendtypedata = [];
	tblclsbillboardlegendtyperows = $("#tblclsbillboardlegendtype tbody tr");
tblclsbillboardlegendtyperows.each(function (index) {
    var tblclsbillboardlegendtyperow = $(this);
 	var tblclsbillboardlegendtypeobj = {};
	var vProperty = tblclsbillboardlegendtyperow.find("[name=Property]").text();
			tblclsbillboardlegendtypeobj['Property'] = vProperty;
			tblclsbillboardlegendtypeobj['index'] = index;
var vType = tblclsbillboardlegendtyperow.find("[name=Type]").text();
			tblclsbillboardlegendtypeobj['Type'] = vType;
			tblclsbillboardlegendtypeobj['index'] = index;
var vDefaultValue = tblclsbillboardlegendtyperow.find("[name=DefaultValue]").text();
			tblclsbillboardlegendtypeobj['DefaultValue'] = vDefaultValue;
			tblclsbillboardlegendtypeobj['index'] = index;
var vDescription = tblclsbillboardlegendtyperow.find("[name=Description]").text();
			tblclsbillboardlegendtypeobj['Description'] = vDescription;
			tblclsbillboardlegendtypeobj['index'] = index;

	tblclsbillboardlegendtypedata.push(tblclsbillboardlegendtypeobj);
});
return tblclsbillboardlegendtypedata;
	}
function getRowsmethodclsbillboardlegendtype(){
	var methodclsbillboardlegendtypedata = [];
	methodclsbillboardlegendtyperows = $("#methodclsbillboardlegendtype tbody tr");
methodclsbillboardlegendtyperows.each(function (index) {
    var methodclsbillboardlegendtyperow = $(this);
 	var methodclsbillboardlegendtypeobj = {};
	var vMethod = methodclsbillboardlegendtyperow.find("[name=Method]").text();
			methodclsbillboardlegendtypeobj['Method'] = vMethod;
			methodclsbillboardlegendtypeobj['index'] = index;
var vParameters = methodclsbillboardlegendtyperow.find("[name=Parameters]").text();
			methodclsbillboardlegendtypeobj['Parameters'] = vParameters;
			methodclsbillboardlegendtypeobj['index'] = index;
var vReturnType = methodclsbillboardlegendtyperow.find("[name=ReturnType]").text();
			methodclsbillboardlegendtypeobj['ReturnType'] = vReturnType;
			methodclsbillboardlegendtypeobj['index'] = index;
var vDescription = methodclsbillboardlegendtyperow.find("[name=Description]").text();
			methodclsbillboardlegendtypeobj['Description'] = vDescription;
			methodclsbillboardlegendtypeobj['index'] = index;

	methodclsbillboardlegendtypedata.push(methodclsbillboardlegendtypeobj);
});
return methodclsbillboardlegendtypedata;
	}
function getRowstblclsbillboardpietype(){
	var tblclsbillboardpietypedata = [];
	tblclsbillboardpietyperows = $("#tblclsbillboardpietype tbody tr");
tblclsbillboardpietyperows.each(function (index) {
    var tblclsbillboardpietyperow = $(this);
 	var tblclsbillboardpietypeobj = {};
	var vProperty = tblclsbillboardpietyperow.find("[name=Property]").text();
			tblclsbillboardpietypeobj['Property'] = vProperty;
			tblclsbillboardpietypeobj['index'] = index;
var vType = tblclsbillboardpietyperow.find("[name=Type]").text();
			tblclsbillboardpietypeobj['Type'] = vType;
			tblclsbillboardpietypeobj['index'] = index;
var vDefaultValue = tblclsbillboardpietyperow.find("[name=DefaultValue]").text();
			tblclsbillboardpietypeobj['DefaultValue'] = vDefaultValue;
			tblclsbillboardpietypeobj['index'] = index;
var vDescription = tblclsbillboardpietyperow.find("[name=Description]").text();
			tblclsbillboardpietypeobj['Description'] = vDescription;
			tblclsbillboardpietypeobj['index'] = index;

	tblclsbillboardpietypedata.push(tblclsbillboardpietypeobj);
});
return tblclsbillboardpietypedata;
	}
function getRowsmethodclsbillboardpietype(){
	var methodclsbillboardpietypedata = [];
	methodclsbillboardpietyperows = $("#methodclsbillboardpietype tbody tr");
methodclsbillboardpietyperows.each(function (index) {
    var methodclsbillboardpietyperow = $(this);
 	var methodclsbillboardpietypeobj = {};
	var vMethod = methodclsbillboardpietyperow.find("[name=Method]").text();
			methodclsbillboardpietypeobj['Method'] = vMethod;
			methodclsbillboardpietypeobj['index'] = index;
var vParameters = methodclsbillboardpietyperow.find("[name=Parameters]").text();
			methodclsbillboardpietypeobj['Parameters'] = vParameters;
			methodclsbillboardpietypeobj['index'] = index;
var vReturnType = methodclsbillboardpietyperow.find("[name=ReturnType]").text();
			methodclsbillboardpietypeobj['ReturnType'] = vReturnType;
			methodclsbillboardpietypeobj['index'] = index;
var vDescription = methodclsbillboardpietyperow.find("[name=Description]").text();
			methodclsbillboardpietypeobj['Description'] = vDescription;
			methodclsbillboardpietypeobj['index'] = index;

	methodclsbillboardpietypedata.push(methodclsbillboardpietypeobj);
});
return methodclsbillboardpietypedata;
	}
function getRowstblclsbillboardradartype(){
	var tblclsbillboardradartypedata = [];
	tblclsbillboardradartyperows = $("#tblclsbillboardradartype tbody tr");
tblclsbillboardradartyperows.each(function (index) {
    var tblclsbillboardradartyperow = $(this);
 	var tblclsbillboardradartypeobj = {};
	var vProperty = tblclsbillboardradartyperow.find("[name=Property]").text();
			tblclsbillboardradartypeobj['Property'] = vProperty;
			tblclsbillboardradartypeobj['index'] = index;
var vType = tblclsbillboardradartyperow.find("[name=Type]").text();
			tblclsbillboardradartypeobj['Type'] = vType;
			tblclsbillboardradartypeobj['index'] = index;
var vDefaultValue = tblclsbillboardradartyperow.find("[name=DefaultValue]").text();
			tblclsbillboardradartypeobj['DefaultValue'] = vDefaultValue;
			tblclsbillboardradartypeobj['index'] = index;
var vDescription = tblclsbillboardradartyperow.find("[name=Description]").text();
			tblclsbillboardradartypeobj['Description'] = vDescription;
			tblclsbillboardradartypeobj['index'] = index;

	tblclsbillboardradartypedata.push(tblclsbillboardradartypeobj);
});
return tblclsbillboardradartypedata;
	}
function getRowsmethodclsbillboardradartype(){
	var methodclsbillboardradartypedata = [];
	methodclsbillboardradartyperows = $("#methodclsbillboardradartype tbody tr");
methodclsbillboardradartyperows.each(function (index) {
    var methodclsbillboardradartyperow = $(this);
 	var methodclsbillboardradartypeobj = {};
	var vMethod = methodclsbillboardradartyperow.find("[name=Method]").text();
			methodclsbillboardradartypeobj['Method'] = vMethod;
			methodclsbillboardradartypeobj['index'] = index;
var vParameters = methodclsbillboardradartyperow.find("[name=Parameters]").text();
			methodclsbillboardradartypeobj['Parameters'] = vParameters;
			methodclsbillboardradartypeobj['index'] = index;
var vReturnType = methodclsbillboardradartyperow.find("[name=ReturnType]").text();
			methodclsbillboardradartypeobj['ReturnType'] = vReturnType;
			methodclsbillboardradartypeobj['index'] = index;
var vDescription = methodclsbillboardradartyperow.find("[name=Description]").text();
			methodclsbillboardradartypeobj['Description'] = vDescription;
			methodclsbillboardradartypeobj['index'] = index;

	methodclsbillboardradartypedata.push(methodclsbillboardradartypeobj);
});
return methodclsbillboardradartypedata;
	}
function getRowstblclsbuttonsize(){
	var tblclsbuttonsizedata = [];
	tblclsbuttonsizerows = $("#tblclsbuttonsize tbody tr");
tblclsbuttonsizerows.each(function (index) {
    var tblclsbuttonsizerow = $(this);
 	var tblclsbuttonsizeobj = {};
	var vProperty = tblclsbuttonsizerow.find("[name=Property]").text();
			tblclsbuttonsizeobj['Property'] = vProperty;
			tblclsbuttonsizeobj['index'] = index;
var vType = tblclsbuttonsizerow.find("[name=Type]").text();
			tblclsbuttonsizeobj['Type'] = vType;
			tblclsbuttonsizeobj['index'] = index;
var vDefaultValue = tblclsbuttonsizerow.find("[name=DefaultValue]").text();
			tblclsbuttonsizeobj['DefaultValue'] = vDefaultValue;
			tblclsbuttonsizeobj['index'] = index;
var vDescription = tblclsbuttonsizerow.find("[name=Description]").text();
			tblclsbuttonsizeobj['Description'] = vDescription;
			tblclsbuttonsizeobj['index'] = index;

	tblclsbuttonsizedata.push(tblclsbuttonsizeobj);
});
return tblclsbuttonsizedata;
	}
function getRowsmethodclsbuttonsize(){
	var methodclsbuttonsizedata = [];
	methodclsbuttonsizerows = $("#methodclsbuttonsize tbody tr");
methodclsbuttonsizerows.each(function (index) {
    var methodclsbuttonsizerow = $(this);
 	var methodclsbuttonsizeobj = {};
	var vMethod = methodclsbuttonsizerow.find("[name=Method]").text();
			methodclsbuttonsizeobj['Method'] = vMethod;
			methodclsbuttonsizeobj['index'] = index;
var vParameters = methodclsbuttonsizerow.find("[name=Parameters]").text();
			methodclsbuttonsizeobj['Parameters'] = vParameters;
			methodclsbuttonsizeobj['index'] = index;
var vReturnType = methodclsbuttonsizerow.find("[name=ReturnType]").text();
			methodclsbuttonsizeobj['ReturnType'] = vReturnType;
			methodclsbuttonsizeobj['index'] = index;
var vDescription = methodclsbuttonsizerow.find("[name=Description]").text();
			methodclsbuttonsizeobj['Description'] = vDescription;
			methodclsbuttonsizeobj['index'] = index;

	methodclsbuttonsizedata.push(methodclsbuttonsizeobj);
});
return methodclsbuttonsizedata;
	}
function getRowstblclsbuttontype(){
	var tblclsbuttontypedata = [];
	tblclsbuttontyperows = $("#tblclsbuttontype tbody tr");
tblclsbuttontyperows.each(function (index) {
    var tblclsbuttontyperow = $(this);
 	var tblclsbuttontypeobj = {};
	var vProperty = tblclsbuttontyperow.find("[name=Property]").text();
			tblclsbuttontypeobj['Property'] = vProperty;
			tblclsbuttontypeobj['index'] = index;
var vType = tblclsbuttontyperow.find("[name=Type]").text();
			tblclsbuttontypeobj['Type'] = vType;
			tblclsbuttontypeobj['index'] = index;
var vDefaultValue = tblclsbuttontyperow.find("[name=DefaultValue]").text();
			tblclsbuttontypeobj['DefaultValue'] = vDefaultValue;
			tblclsbuttontypeobj['index'] = index;
var vDescription = tblclsbuttontyperow.find("[name=Description]").text();
			tblclsbuttontypeobj['Description'] = vDescription;
			tblclsbuttontypeobj['index'] = index;

	tblclsbuttontypedata.push(tblclsbuttontypeobj);
});
return tblclsbuttontypedata;
	}
function getRowsmethodclsbuttontype(){
	var methodclsbuttontypedata = [];
	methodclsbuttontyperows = $("#methodclsbuttontype tbody tr");
methodclsbuttontyperows.each(function (index) {
    var methodclsbuttontyperow = $(this);
 	var methodclsbuttontypeobj = {};
	var vMethod = methodclsbuttontyperow.find("[name=Method]").text();
			methodclsbuttontypeobj['Method'] = vMethod;
			methodclsbuttontypeobj['index'] = index;
var vParameters = methodclsbuttontyperow.find("[name=Parameters]").text();
			methodclsbuttontypeobj['Parameters'] = vParameters;
			methodclsbuttontypeobj['index'] = index;
var vReturnType = methodclsbuttontyperow.find("[name=ReturnType]").text();
			methodclsbuttontypeobj['ReturnType'] = vReturnType;
			methodclsbuttontypeobj['index'] = index;
var vDescription = methodclsbuttontyperow.find("[name=Description]").text();
			methodclsbuttontypeobj['Description'] = vDescription;
			methodclsbuttontypeobj['index'] = index;

	methodclsbuttontypedata.push(methodclsbuttontypeobj);
});
return methodclsbuttontypedata;
	}
function getRowstblclscardsize(){
	var tblclscardsizedata = [];
	tblclscardsizerows = $("#tblclscardsize tbody tr");
tblclscardsizerows.each(function (index) {
    var tblclscardsizerow = $(this);
 	var tblclscardsizeobj = {};
	var vProperty = tblclscardsizerow.find("[name=Property]").text();
			tblclscardsizeobj['Property'] = vProperty;
			tblclscardsizeobj['index'] = index;
var vType = tblclscardsizerow.find("[name=Type]").text();
			tblclscardsizeobj['Type'] = vType;
			tblclscardsizeobj['index'] = index;
var vDefaultValue = tblclscardsizerow.find("[name=DefaultValue]").text();
			tblclscardsizeobj['DefaultValue'] = vDefaultValue;
			tblclscardsizeobj['index'] = index;
var vDescription = tblclscardsizerow.find("[name=Description]").text();
			tblclscardsizeobj['Description'] = vDescription;
			tblclscardsizeobj['index'] = index;

	tblclscardsizedata.push(tblclscardsizeobj);
});
return tblclscardsizedata;
	}
function getRowsmethodclscardsize(){
	var methodclscardsizedata = [];
	methodclscardsizerows = $("#methodclscardsize tbody tr");
methodclscardsizerows.each(function (index) {
    var methodclscardsizerow = $(this);
 	var methodclscardsizeobj = {};
	var vMethod = methodclscardsizerow.find("[name=Method]").text();
			methodclscardsizeobj['Method'] = vMethod;
			methodclscardsizeobj['index'] = index;
var vParameters = methodclscardsizerow.find("[name=Parameters]").text();
			methodclscardsizeobj['Parameters'] = vParameters;
			methodclscardsizeobj['index'] = index;
var vReturnType = methodclscardsizerow.find("[name=ReturnType]").text();
			methodclscardsizeobj['ReturnType'] = vReturnType;
			methodclscardsizeobj['index'] = index;
var vDescription = methodclscardsizerow.find("[name=Description]").text();
			methodclscardsizeobj['Description'] = vDescription;
			methodclscardsizeobj['index'] = index;

	methodclscardsizedata.push(methodclscardsizeobj);
});
return methodclscardsizedata;
	}
function getRowstblclscardtype(){
	var tblclscardtypedata = [];
	tblclscardtyperows = $("#tblclscardtype tbody tr");
tblclscardtyperows.each(function (index) {
    var tblclscardtyperow = $(this);
 	var tblclscardtypeobj = {};
	var vProperty = tblclscardtyperow.find("[name=Property]").text();
			tblclscardtypeobj['Property'] = vProperty;
			tblclscardtypeobj['index'] = index;
var vType = tblclscardtyperow.find("[name=Type]").text();
			tblclscardtypeobj['Type'] = vType;
			tblclscardtypeobj['index'] = index;
var vDefaultValue = tblclscardtyperow.find("[name=DefaultValue]").text();
			tblclscardtypeobj['DefaultValue'] = vDefaultValue;
			tblclscardtypeobj['index'] = index;
var vDescription = tblclscardtyperow.find("[name=Description]").text();
			tblclscardtypeobj['Description'] = vDescription;
			tblclscardtypeobj['index'] = index;

	tblclscardtypedata.push(tblclscardtypeobj);
});
return tblclscardtypedata;
	}
function getRowsmethodclscardtype(){
	var methodclscardtypedata = [];
	methodclscardtyperows = $("#methodclscardtype tbody tr");
methodclscardtyperows.each(function (index) {
    var methodclscardtyperow = $(this);
 	var methodclscardtypeobj = {};
	var vMethod = methodclscardtyperow.find("[name=Method]").text();
			methodclscardtypeobj['Method'] = vMethod;
			methodclscardtypeobj['index'] = index;
var vParameters = methodclscardtyperow.find("[name=Parameters]").text();
			methodclscardtypeobj['Parameters'] = vParameters;
			methodclscardtypeobj['index'] = index;
var vReturnType = methodclscardtyperow.find("[name=ReturnType]").text();
			methodclscardtypeobj['ReturnType'] = vReturnType;
			methodclscardtypeobj['index'] = index;
var vDescription = methodclscardtyperow.find("[name=Description]").text();
			methodclscardtypeobj['Description'] = vDescription;
			methodclscardtypeobj['index'] = index;

	methodclscardtypedata.push(methodclscardtypeobj);
});
return methodclscardtypedata;
	}
function getRowstblclscollapsibletype(){
	var tblclscollapsibletypedata = [];
	tblclscollapsibletyperows = $("#tblclscollapsibletype tbody tr");
tblclscollapsibletyperows.each(function (index) {
    var tblclscollapsibletyperow = $(this);
 	var tblclscollapsibletypeobj = {};
	var vProperty = tblclscollapsibletyperow.find("[name=Property]").text();
			tblclscollapsibletypeobj['Property'] = vProperty;
			tblclscollapsibletypeobj['index'] = index;
var vType = tblclscollapsibletyperow.find("[name=Type]").text();
			tblclscollapsibletypeobj['Type'] = vType;
			tblclscollapsibletypeobj['index'] = index;
var vDefaultValue = tblclscollapsibletyperow.find("[name=DefaultValue]").text();
			tblclscollapsibletypeobj['DefaultValue'] = vDefaultValue;
			tblclscollapsibletypeobj['index'] = index;
var vDescription = tblclscollapsibletyperow.find("[name=Description]").text();
			tblclscollapsibletypeobj['Description'] = vDescription;
			tblclscollapsibletypeobj['index'] = index;

	tblclscollapsibletypedata.push(tblclscollapsibletypeobj);
});
return tblclscollapsibletypedata;
	}
function getRowsmethodclscollapsibletype(){
	var methodclscollapsibletypedata = [];
	methodclscollapsibletyperows = $("#methodclscollapsibletype tbody tr");
methodclscollapsibletyperows.each(function (index) {
    var methodclscollapsibletyperow = $(this);
 	var methodclscollapsibletypeobj = {};
	var vMethod = methodclscollapsibletyperow.find("[name=Method]").text();
			methodclscollapsibletypeobj['Method'] = vMethod;
			methodclscollapsibletypeobj['index'] = index;
var vParameters = methodclscollapsibletyperow.find("[name=Parameters]").text();
			methodclscollapsibletypeobj['Parameters'] = vParameters;
			methodclscollapsibletypeobj['index'] = index;
var vReturnType = methodclscollapsibletyperow.find("[name=ReturnType]").text();
			methodclscollapsibletypeobj['ReturnType'] = vReturnType;
			methodclscollapsibletypeobj['index'] = index;
var vDescription = methodclscollapsibletyperow.find("[name=Description]").text();
			methodclscollapsibletypeobj['Description'] = vDescription;
			methodclscollapsibletypeobj['index'] = index;

	methodclscollapsibletypedata.push(methodclscollapsibletypeobj);
});
return methodclscollapsibletypedata;
	}
function getRowstblclscolor(){
	var tblclscolordata = [];
	tblclscolorrows = $("#tblclscolor tbody tr");
tblclscolorrows.each(function (index) {
    var tblclscolorrow = $(this);
 	var tblclscolorobj = {};
	var vProperty = tblclscolorrow.find("[name=Property]").text();
			tblclscolorobj['Property'] = vProperty;
			tblclscolorobj['index'] = index;
var vType = tblclscolorrow.find("[name=Type]").text();
			tblclscolorobj['Type'] = vType;
			tblclscolorobj['index'] = index;
var vDefaultValue = tblclscolorrow.find("[name=DefaultValue]").text();
			tblclscolorobj['DefaultValue'] = vDefaultValue;
			tblclscolorobj['index'] = index;
var vDescription = tblclscolorrow.find("[name=Description]").text();
			tblclscolorobj['Description'] = vDescription;
			tblclscolorobj['index'] = index;

	tblclscolordata.push(tblclscolorobj);
});
return tblclscolordata;
	}
function getRowsmethodclscolor(){
	var methodclscolordata = [];
	methodclscolorrows = $("#methodclscolor tbody tr");
methodclscolorrows.each(function (index) {
    var methodclscolorrow = $(this);
 	var methodclscolorobj = {};
	var vMethod = methodclscolorrow.find("[name=Method]").text();
			methodclscolorobj['Method'] = vMethod;
			methodclscolorobj['index'] = index;
var vParameters = methodclscolorrow.find("[name=Parameters]").text();
			methodclscolorobj['Parameters'] = vParameters;
			methodclscolorobj['index'] = index;
var vReturnType = methodclscolorrow.find("[name=ReturnType]").text();
			methodclscolorobj['ReturnType'] = vReturnType;
			methodclscolorobj['index'] = index;
var vDescription = methodclscolorrow.find("[name=Description]").text();
			methodclscolorobj['Description'] = vDescription;
			methodclscolorobj['index'] = index;

	methodclscolordata.push(methodclscolorobj);
});
return methodclscolordata;
	}
function getRowstblclsdatetimetype(){
	var tblclsdatetimetypedata = [];
	tblclsdatetimetyperows = $("#tblclsdatetimetype tbody tr");
tblclsdatetimetyperows.each(function (index) {
    var tblclsdatetimetyperow = $(this);
 	var tblclsdatetimetypeobj = {};
	var vProperty = tblclsdatetimetyperow.find("[name=Property]").text();
			tblclsdatetimetypeobj['Property'] = vProperty;
			tblclsdatetimetypeobj['index'] = index;
var vType = tblclsdatetimetyperow.find("[name=Type]").text();
			tblclsdatetimetypeobj['Type'] = vType;
			tblclsdatetimetypeobj['index'] = index;
var vDefaultValue = tblclsdatetimetyperow.find("[name=DefaultValue]").text();
			tblclsdatetimetypeobj['DefaultValue'] = vDefaultValue;
			tblclsdatetimetypeobj['index'] = index;
var vDescription = tblclsdatetimetyperow.find("[name=Description]").text();
			tblclsdatetimetypeobj['Description'] = vDescription;
			tblclsdatetimetypeobj['index'] = index;

	tblclsdatetimetypedata.push(tblclsdatetimetypeobj);
});
return tblclsdatetimetypedata;
	}
function getRowsmethodclsdatetimetype(){
	var methodclsdatetimetypedata = [];
	methodclsdatetimetyperows = $("#methodclsdatetimetype tbody tr");
methodclsdatetimetyperows.each(function (index) {
    var methodclsdatetimetyperow = $(this);
 	var methodclsdatetimetypeobj = {};
	var vMethod = methodclsdatetimetyperow.find("[name=Method]").text();
			methodclsdatetimetypeobj['Method'] = vMethod;
			methodclsdatetimetypeobj['index'] = index;
var vParameters = methodclsdatetimetyperow.find("[name=Parameters]").text();
			methodclsdatetimetypeobj['Parameters'] = vParameters;
			methodclsdatetimetypeobj['index'] = index;
var vReturnType = methodclsdatetimetyperow.find("[name=ReturnType]").text();
			methodclsdatetimetypeobj['ReturnType'] = vReturnType;
			methodclsdatetimetypeobj['index'] = index;
var vDescription = methodclsdatetimetyperow.find("[name=Description]").text();
			methodclsdatetimetypeobj['Description'] = vDescription;
			methodclsdatetimetypeobj['index'] = index;

	methodclsdatetimetypedata.push(methodclsdatetimetypeobj);
});
return methodclsdatetimetypedata;
	}
function getRowstblclsdisplaytype(){
	var tblclsdisplaytypedata = [];
	tblclsdisplaytyperows = $("#tblclsdisplaytype tbody tr");
tblclsdisplaytyperows.each(function (index) {
    var tblclsdisplaytyperow = $(this);
 	var tblclsdisplaytypeobj = {};
	var vProperty = tblclsdisplaytyperow.find("[name=Property]").text();
			tblclsdisplaytypeobj['Property'] = vProperty;
			tblclsdisplaytypeobj['index'] = index;
var vType = tblclsdisplaytyperow.find("[name=Type]").text();
			tblclsdisplaytypeobj['Type'] = vType;
			tblclsdisplaytypeobj['index'] = index;
var vDefaultValue = tblclsdisplaytyperow.find("[name=DefaultValue]").text();
			tblclsdisplaytypeobj['DefaultValue'] = vDefaultValue;
			tblclsdisplaytypeobj['index'] = index;
var vDescription = tblclsdisplaytyperow.find("[name=Description]").text();
			tblclsdisplaytypeobj['Description'] = vDescription;
			tblclsdisplaytypeobj['index'] = index;

	tblclsdisplaytypedata.push(tblclsdisplaytypeobj);
});
return tblclsdisplaytypedata;
	}
function getRowsmethodclsdisplaytype(){
	var methodclsdisplaytypedata = [];
	methodclsdisplaytyperows = $("#methodclsdisplaytype tbody tr");
methodclsdisplaytyperows.each(function (index) {
    var methodclsdisplaytyperow = $(this);
 	var methodclsdisplaytypeobj = {};
	var vMethod = methodclsdisplaytyperow.find("[name=Method]").text();
			methodclsdisplaytypeobj['Method'] = vMethod;
			methodclsdisplaytypeobj['index'] = index;
var vParameters = methodclsdisplaytyperow.find("[name=Parameters]").text();
			methodclsdisplaytypeobj['Parameters'] = vParameters;
			methodclsdisplaytypeobj['index'] = index;
var vReturnType = methodclsdisplaytyperow.find("[name=ReturnType]").text();
			methodclsdisplaytypeobj['ReturnType'] = vReturnType;
			methodclsdisplaytypeobj['index'] = index;
var vDescription = methodclsdisplaytyperow.find("[name=Description]").text();
			methodclsdisplaytypeobj['Description'] = vDescription;
			methodclsdisplaytypeobj['index'] = index;

	methodclsdisplaytypedata.push(methodclsdisplaytypeobj);
});
return methodclsdisplaytypedata;
	}
function getRowstblclseasing(){
	var tblclseasingdata = [];
	tblclseasingrows = $("#tblclseasing tbody tr");
tblclseasingrows.each(function (index) {
    var tblclseasingrow = $(this);
 	var tblclseasingobj = {};
	var vProperty = tblclseasingrow.find("[name=Property]").text();
			tblclseasingobj['Property'] = vProperty;
			tblclseasingobj['index'] = index;
var vType = tblclseasingrow.find("[name=Type]").text();
			tblclseasingobj['Type'] = vType;
			tblclseasingobj['index'] = index;
var vDefaultValue = tblclseasingrow.find("[name=DefaultValue]").text();
			tblclseasingobj['DefaultValue'] = vDefaultValue;
			tblclseasingobj['index'] = index;
var vDescription = tblclseasingrow.find("[name=Description]").text();
			tblclseasingobj['Description'] = vDescription;
			tblclseasingobj['index'] = index;

	tblclseasingdata.push(tblclseasingobj);
});
return tblclseasingdata;
	}
function getRowsmethodclseasing(){
	var methodclseasingdata = [];
	methodclseasingrows = $("#methodclseasing tbody tr");
methodclseasingrows.each(function (index) {
    var methodclseasingrow = $(this);
 	var methodclseasingobj = {};
	var vMethod = methodclseasingrow.find("[name=Method]").text();
			methodclseasingobj['Method'] = vMethod;
			methodclseasingobj['index'] = index;
var vParameters = methodclseasingrow.find("[name=Parameters]").text();
			methodclseasingobj['Parameters'] = vParameters;
			methodclseasingobj['index'] = index;
var vReturnType = methodclseasingrow.find("[name=ReturnType]").text();
			methodclseasingobj['ReturnType'] = vReturnType;
			methodclseasingobj['index'] = index;
var vDescription = methodclseasingrow.find("[name=Description]").text();
			methodclseasingobj['Description'] = vDescription;
			methodclseasingobj['index'] = index;

	methodclseasingdata.push(methodclseasingobj);
});
return methodclseasingdata;
	}
function getRowstblclsevents(){
	var tblclseventsdata = [];
	tblclseventsrows = $("#tblclsevents tbody tr");
tblclseventsrows.each(function (index) {
    var tblclseventsrow = $(this);
 	var tblclseventsobj = {};
	var vProperty = tblclseventsrow.find("[name=Property]").text();
			tblclseventsobj['Property'] = vProperty;
			tblclseventsobj['index'] = index;
var vType = tblclseventsrow.find("[name=Type]").text();
			tblclseventsobj['Type'] = vType;
			tblclseventsobj['index'] = index;
var vDefaultValue = tblclseventsrow.find("[name=DefaultValue]").text();
			tblclseventsobj['DefaultValue'] = vDefaultValue;
			tblclseventsobj['index'] = index;
var vDescription = tblclseventsrow.find("[name=Description]").text();
			tblclseventsobj['Description'] = vDescription;
			tblclseventsobj['index'] = index;

	tblclseventsdata.push(tblclseventsobj);
});
return tblclseventsdata;
	}
function getRowsmethodclsevents(){
	var methodclseventsdata = [];
	methodclseventsrows = $("#methodclsevents tbody tr");
methodclseventsrows.each(function (index) {
    var methodclseventsrow = $(this);
 	var methodclseventsobj = {};
	var vMethod = methodclseventsrow.find("[name=Method]").text();
			methodclseventsobj['Method'] = vMethod;
			methodclseventsobj['index'] = index;
var vParameters = methodclseventsrow.find("[name=Parameters]").text();
			methodclseventsobj['Parameters'] = vParameters;
			methodclseventsobj['index'] = index;
var vReturnType = methodclseventsrow.find("[name=ReturnType]").text();
			methodclseventsobj['ReturnType'] = vReturnType;
			methodclseventsobj['index'] = index;
var vDescription = methodclseventsrow.find("[name=Description]").text();
			methodclseventsobj['Description'] = vDescription;
			methodclseventsobj['index'] = index;

	methodclseventsdata.push(methodclseventsobj);
});
return methodclseventsdata;
	}
function getRowstblclsfabdirection(){
	var tblclsfabdirectiondata = [];
	tblclsfabdirectionrows = $("#tblclsfabdirection tbody tr");
tblclsfabdirectionrows.each(function (index) {
    var tblclsfabdirectionrow = $(this);
 	var tblclsfabdirectionobj = {};
	var vProperty = tblclsfabdirectionrow.find("[name=Property]").text();
			tblclsfabdirectionobj['Property'] = vProperty;
			tblclsfabdirectionobj['index'] = index;
var vType = tblclsfabdirectionrow.find("[name=Type]").text();
			tblclsfabdirectionobj['Type'] = vType;
			tblclsfabdirectionobj['index'] = index;
var vDefaultValue = tblclsfabdirectionrow.find("[name=DefaultValue]").text();
			tblclsfabdirectionobj['DefaultValue'] = vDefaultValue;
			tblclsfabdirectionobj['index'] = index;
var vDescription = tblclsfabdirectionrow.find("[name=Description]").text();
			tblclsfabdirectionobj['Description'] = vDescription;
			tblclsfabdirectionobj['index'] = index;

	tblclsfabdirectiondata.push(tblclsfabdirectionobj);
});
return tblclsfabdirectiondata;
	}
function getRowsmethodclsfabdirection(){
	var methodclsfabdirectiondata = [];
	methodclsfabdirectionrows = $("#methodclsfabdirection tbody tr");
methodclsfabdirectionrows.each(function (index) {
    var methodclsfabdirectionrow = $(this);
 	var methodclsfabdirectionobj = {};
	var vMethod = methodclsfabdirectionrow.find("[name=Method]").text();
			methodclsfabdirectionobj['Method'] = vMethod;
			methodclsfabdirectionobj['index'] = index;
var vParameters = methodclsfabdirectionrow.find("[name=Parameters]").text();
			methodclsfabdirectionobj['Parameters'] = vParameters;
			methodclsfabdirectionobj['index'] = index;
var vReturnType = methodclsfabdirectionrow.find("[name=ReturnType]").text();
			methodclsfabdirectionobj['ReturnType'] = vReturnType;
			methodclsfabdirectionobj['index'] = index;
var vDescription = methodclsfabdirectionrow.find("[name=Description]").text();
			methodclsfabdirectionobj['Description'] = vDescription;
			methodclsfabdirectionobj['index'] = index;

	methodclsfabdirectiondata.push(methodclsfabdirectionobj);
});
return methodclsfabdirectiondata;
	}
function getRowstblclsfcoperation(){
	var tblclsfcoperationdata = [];
	tblclsfcoperationrows = $("#tblclsfcoperation tbody tr");
tblclsfcoperationrows.each(function (index) {
    var tblclsfcoperationrow = $(this);
 	var tblclsfcoperationobj = {};
	var vProperty = tblclsfcoperationrow.find("[name=Property]").text();
			tblclsfcoperationobj['Property'] = vProperty;
			tblclsfcoperationobj['index'] = index;
var vType = tblclsfcoperationrow.find("[name=Type]").text();
			tblclsfcoperationobj['Type'] = vType;
			tblclsfcoperationobj['index'] = index;
var vDefaultValue = tblclsfcoperationrow.find("[name=DefaultValue]").text();
			tblclsfcoperationobj['DefaultValue'] = vDefaultValue;
			tblclsfcoperationobj['index'] = index;
var vDescription = tblclsfcoperationrow.find("[name=Description]").text();
			tblclsfcoperationobj['Description'] = vDescription;
			tblclsfcoperationobj['index'] = index;

	tblclsfcoperationdata.push(tblclsfcoperationobj);
});
return tblclsfcoperationdata;
	}
function getRowsmethodclsfcoperation(){
	var methodclsfcoperationdata = [];
	methodclsfcoperationrows = $("#methodclsfcoperation tbody tr");
methodclsfcoperationrows.each(function (index) {
    var methodclsfcoperationrow = $(this);
 	var methodclsfcoperationobj = {};
	var vMethod = methodclsfcoperationrow.find("[name=Method]").text();
			methodclsfcoperationobj['Method'] = vMethod;
			methodclsfcoperationobj['index'] = index;
var vParameters = methodclsfcoperationrow.find("[name=Parameters]").text();
			methodclsfcoperationobj['Parameters'] = vParameters;
			methodclsfcoperationobj['index'] = index;
var vReturnType = methodclsfcoperationrow.find("[name=ReturnType]").text();
			methodclsfcoperationobj['ReturnType'] = vReturnType;
			methodclsfcoperationobj['index'] = index;
var vDescription = methodclsfcoperationrow.find("[name=Description]").text();
			methodclsfcoperationobj['Description'] = vDescription;
			methodclsfcoperationobj['index'] = index;

	methodclsfcoperationdata.push(methodclsfcoperationobj);
});
return methodclsfcoperationdata;
	}
function getRowstblclsfcpositiontype(){
	var tblclsfcpositiontypedata = [];
	tblclsfcpositiontyperows = $("#tblclsfcpositiontype tbody tr");
tblclsfcpositiontyperows.each(function (index) {
    var tblclsfcpositiontyperow = $(this);
 	var tblclsfcpositiontypeobj = {};
	var vProperty = tblclsfcpositiontyperow.find("[name=Property]").text();
			tblclsfcpositiontypeobj['Property'] = vProperty;
			tblclsfcpositiontypeobj['index'] = index;
var vType = tblclsfcpositiontyperow.find("[name=Type]").text();
			tblclsfcpositiontypeobj['Type'] = vType;
			tblclsfcpositiontypeobj['index'] = index;
var vDefaultValue = tblclsfcpositiontyperow.find("[name=DefaultValue]").text();
			tblclsfcpositiontypeobj['DefaultValue'] = vDefaultValue;
			tblclsfcpositiontypeobj['index'] = index;
var vDescription = tblclsfcpositiontyperow.find("[name=Description]").text();
			tblclsfcpositiontypeobj['Description'] = vDescription;
			tblclsfcpositiontypeobj['index'] = index;

	tblclsfcpositiontypedata.push(tblclsfcpositiontypeobj);
});
return tblclsfcpositiontypedata;
	}
function getRowsmethodclsfcpositiontype(){
	var methodclsfcpositiontypedata = [];
	methodclsfcpositiontyperows = $("#methodclsfcpositiontype tbody tr");
methodclsfcpositiontyperows.each(function (index) {
    var methodclsfcpositiontyperow = $(this);
 	var methodclsfcpositiontypeobj = {};
	var vMethod = methodclsfcpositiontyperow.find("[name=Method]").text();
			methodclsfcpositiontypeobj['Method'] = vMethod;
			methodclsfcpositiontypeobj['index'] = index;
var vParameters = methodclsfcpositiontyperow.find("[name=Parameters]").text();
			methodclsfcpositiontypeobj['Parameters'] = vParameters;
			methodclsfcpositiontypeobj['index'] = index;
var vReturnType = methodclsfcpositiontyperow.find("[name=ReturnType]").text();
			methodclsfcpositiontypeobj['ReturnType'] = vReturnType;
			methodclsfcpositiontypeobj['index'] = index;
var vDescription = methodclsfcpositiontyperow.find("[name=Description]").text();
			methodclsfcpositiontypeobj['Description'] = vDescription;
			methodclsfcpositiontypeobj['index'] = index;

	methodclsfcpositiontypedata.push(methodclsfcpositiontypeobj);
});
return methodclsfcpositiontypedata;
	}
function getRowstblclsfloattype(){
	var tblclsfloattypedata = [];
	tblclsfloattyperows = $("#tblclsfloattype tbody tr");
tblclsfloattyperows.each(function (index) {
    var tblclsfloattyperow = $(this);
 	var tblclsfloattypeobj = {};
	var vProperty = tblclsfloattyperow.find("[name=Property]").text();
			tblclsfloattypeobj['Property'] = vProperty;
			tblclsfloattypeobj['index'] = index;
var vType = tblclsfloattyperow.find("[name=Type]").text();
			tblclsfloattypeobj['Type'] = vType;
			tblclsfloattypeobj['index'] = index;
var vDefaultValue = tblclsfloattyperow.find("[name=DefaultValue]").text();
			tblclsfloattypeobj['DefaultValue'] = vDefaultValue;
			tblclsfloattypeobj['index'] = index;
var vDescription = tblclsfloattyperow.find("[name=Description]").text();
			tblclsfloattypeobj['Description'] = vDescription;
			tblclsfloattypeobj['index'] = index;

	tblclsfloattypedata.push(tblclsfloattypeobj);
});
return tblclsfloattypedata;
	}
function getRowsmethodclsfloattype(){
	var methodclsfloattypedata = [];
	methodclsfloattyperows = $("#methodclsfloattype tbody tr");
methodclsfloattyperows.each(function (index) {
    var methodclsfloattyperow = $(this);
 	var methodclsfloattypeobj = {};
	var vMethod = methodclsfloattyperow.find("[name=Method]").text();
			methodclsfloattypeobj['Method'] = vMethod;
			methodclsfloattypeobj['index'] = index;
var vParameters = methodclsfloattyperow.find("[name=Parameters]").text();
			methodclsfloattypeobj['Parameters'] = vParameters;
			methodclsfloattypeobj['index'] = index;
var vReturnType = methodclsfloattyperow.find("[name=ReturnType]").text();
			methodclsfloattypeobj['ReturnType'] = vReturnType;
			methodclsfloattypeobj['index'] = index;
var vDescription = methodclsfloattyperow.find("[name=Description]").text();
			methodclsfloattypeobj['Description'] = vDescription;
			methodclsfloattypeobj['index'] = index;

	methodclsfloattypedata.push(methodclsfloattypeobj);
});
return methodclsfloattypedata;
	}
function getRowstblclshexcolors(){
	var tblclshexcolorsdata = [];
	tblclshexcolorsrows = $("#tblclshexcolors tbody tr");
tblclshexcolorsrows.each(function (index) {
    var tblclshexcolorsrow = $(this);
 	var tblclshexcolorsobj = {};
	var vProperty = tblclshexcolorsrow.find("[name=Property]").text();
			tblclshexcolorsobj['Property'] = vProperty;
			tblclshexcolorsobj['index'] = index;
var vType = tblclshexcolorsrow.find("[name=Type]").text();
			tblclshexcolorsobj['Type'] = vType;
			tblclshexcolorsobj['index'] = index;
var vDefaultValue = tblclshexcolorsrow.find("[name=DefaultValue]").text();
			tblclshexcolorsobj['DefaultValue'] = vDefaultValue;
			tblclshexcolorsobj['index'] = index;
var vDescription = tblclshexcolorsrow.find("[name=Description]").text();
			tblclshexcolorsobj['Description'] = vDescription;
			tblclshexcolorsobj['index'] = index;

	tblclshexcolorsdata.push(tblclshexcolorsobj);
});
return tblclshexcolorsdata;
	}
function getRowsmethodclshexcolors(){
	var methodclshexcolorsdata = [];
	methodclshexcolorsrows = $("#methodclshexcolors tbody tr");
methodclshexcolorsrows.each(function (index) {
    var methodclshexcolorsrow = $(this);
 	var methodclshexcolorsobj = {};
	var vMethod = methodclshexcolorsrow.find("[name=Method]").text();
			methodclshexcolorsobj['Method'] = vMethod;
			methodclshexcolorsobj['index'] = index;
var vParameters = methodclshexcolorsrow.find("[name=Parameters]").text();
			methodclshexcolorsobj['Parameters'] = vParameters;
			methodclshexcolorsobj['index'] = index;
var vReturnType = methodclshexcolorsrow.find("[name=ReturnType]").text();
			methodclshexcolorsobj['ReturnType'] = vReturnType;
			methodclshexcolorsobj['index'] = index;
var vDescription = methodclshexcolorsrow.find("[name=Description]").text();
			methodclshexcolorsobj['Description'] = vDescription;
			methodclshexcolorsobj['index'] = index;

	methodclshexcolorsdata.push(methodclshexcolorsobj);
});
return methodclshexcolorsdata;
	}
function getRowstblclsiconsize(){
	var tblclsiconsizedata = [];
	tblclsiconsizerows = $("#tblclsiconsize tbody tr");
tblclsiconsizerows.each(function (index) {
    var tblclsiconsizerow = $(this);
 	var tblclsiconsizeobj = {};
	var vProperty = tblclsiconsizerow.find("[name=Property]").text();
			tblclsiconsizeobj['Property'] = vProperty;
			tblclsiconsizeobj['index'] = index;
var vType = tblclsiconsizerow.find("[name=Type]").text();
			tblclsiconsizeobj['Type'] = vType;
			tblclsiconsizeobj['index'] = index;
var vDefaultValue = tblclsiconsizerow.find("[name=DefaultValue]").text();
			tblclsiconsizeobj['DefaultValue'] = vDefaultValue;
			tblclsiconsizeobj['index'] = index;
var vDescription = tblclsiconsizerow.find("[name=Description]").text();
			tblclsiconsizeobj['Description'] = vDescription;
			tblclsiconsizeobj['index'] = index;

	tblclsiconsizedata.push(tblclsiconsizeobj);
});
return tblclsiconsizedata;
	}
function getRowsmethodclsiconsize(){
	var methodclsiconsizedata = [];
	methodclsiconsizerows = $("#methodclsiconsize tbody tr");
methodclsiconsizerows.each(function (index) {
    var methodclsiconsizerow = $(this);
 	var methodclsiconsizeobj = {};
	var vMethod = methodclsiconsizerow.find("[name=Method]").text();
			methodclsiconsizeobj['Method'] = vMethod;
			methodclsiconsizeobj['index'] = index;
var vParameters = methodclsiconsizerow.find("[name=Parameters]").text();
			methodclsiconsizeobj['Parameters'] = vParameters;
			methodclsiconsizeobj['index'] = index;
var vReturnType = methodclsiconsizerow.find("[name=ReturnType]").text();
			methodclsiconsizeobj['ReturnType'] = vReturnType;
			methodclsiconsizeobj['index'] = index;
var vDescription = methodclsiconsizerow.find("[name=Description]").text();
			methodclsiconsizeobj['Description'] = vDescription;
			methodclsiconsizeobj['index'] = index;

	methodclsiconsizedata.push(methodclsiconsizeobj);
});
return methodclsiconsizedata;
	}
function getRowstblclsinputtype(){
	var tblclsinputtypedata = [];
	tblclsinputtyperows = $("#tblclsinputtype tbody tr");
tblclsinputtyperows.each(function (index) {
    var tblclsinputtyperow = $(this);
 	var tblclsinputtypeobj = {};
	var vProperty = tblclsinputtyperow.find("[name=Property]").text();
			tblclsinputtypeobj['Property'] = vProperty;
			tblclsinputtypeobj['index'] = index;
var vType = tblclsinputtyperow.find("[name=Type]").text();
			tblclsinputtypeobj['Type'] = vType;
			tblclsinputtypeobj['index'] = index;
var vDefaultValue = tblclsinputtyperow.find("[name=DefaultValue]").text();
			tblclsinputtypeobj['DefaultValue'] = vDefaultValue;
			tblclsinputtypeobj['index'] = index;
var vDescription = tblclsinputtyperow.find("[name=Description]").text();
			tblclsinputtypeobj['Description'] = vDescription;
			tblclsinputtypeobj['index'] = index;

	tblclsinputtypedata.push(tblclsinputtypeobj);
});
return tblclsinputtypedata;
	}
function getRowsmethodclsinputtype(){
	var methodclsinputtypedata = [];
	methodclsinputtyperows = $("#methodclsinputtype tbody tr");
methodclsinputtyperows.each(function (index) {
    var methodclsinputtyperow = $(this);
 	var methodclsinputtypeobj = {};
	var vMethod = methodclsinputtyperow.find("[name=Method]").text();
			methodclsinputtypeobj['Method'] = vMethod;
			methodclsinputtypeobj['index'] = index;
var vParameters = methodclsinputtyperow.find("[name=Parameters]").text();
			methodclsinputtypeobj['Parameters'] = vParameters;
			methodclsinputtypeobj['index'] = index;
var vReturnType = methodclsinputtyperow.find("[name=ReturnType]").text();
			methodclsinputtypeobj['ReturnType'] = vReturnType;
			methodclsinputtypeobj['index'] = index;
var vDescription = methodclsinputtyperow.find("[name=Description]").text();
			methodclsinputtypeobj['Description'] = vDescription;
			methodclsinputtypeobj['index'] = index;

	methodclsinputtypedata.push(methodclsinputtypeobj);
});
return methodclsinputtypedata;
	}
function getRowstblclsintensity(){
	var tblclsintensitydata = [];
	tblclsintensityrows = $("#tblclsintensity tbody tr");
tblclsintensityrows.each(function (index) {
    var tblclsintensityrow = $(this);
 	var tblclsintensityobj = {};
	var vProperty = tblclsintensityrow.find("[name=Property]").text();
			tblclsintensityobj['Property'] = vProperty;
			tblclsintensityobj['index'] = index;
var vType = tblclsintensityrow.find("[name=Type]").text();
			tblclsintensityobj['Type'] = vType;
			tblclsintensityobj['index'] = index;
var vDefaultValue = tblclsintensityrow.find("[name=DefaultValue]").text();
			tblclsintensityobj['DefaultValue'] = vDefaultValue;
			tblclsintensityobj['index'] = index;
var vDescription = tblclsintensityrow.find("[name=Description]").text();
			tblclsintensityobj['Description'] = vDescription;
			tblclsintensityobj['index'] = index;

	tblclsintensitydata.push(tblclsintensityobj);
});
return tblclsintensitydata;
	}
function getRowsmethodclsintensity(){
	var methodclsintensitydata = [];
	methodclsintensityrows = $("#methodclsintensity tbody tr");
methodclsintensityrows.each(function (index) {
    var methodclsintensityrow = $(this);
 	var methodclsintensityobj = {};
	var vMethod = methodclsintensityrow.find("[name=Method]").text();
			methodclsintensityobj['Method'] = vMethod;
			methodclsintensityobj['index'] = index;
var vParameters = methodclsintensityrow.find("[name=Parameters]").text();
			methodclsintensityobj['Parameters'] = vParameters;
			methodclsintensityobj['index'] = index;
var vReturnType = methodclsintensityrow.find("[name=ReturnType]").text();
			methodclsintensityobj['ReturnType'] = vReturnType;
			methodclsintensityobj['index'] = index;
var vDescription = methodclsintensityrow.find("[name=Description]").text();
			methodclsintensityobj['Description'] = vDescription;
			methodclsintensityobj['index'] = index;

	methodclsintensitydata.push(methodclsintensityobj);
});
return methodclsintensitydata;
	}
function getRowstblclsintervaltype(){
	var tblclsintervaltypedata = [];
	tblclsintervaltyperows = $("#tblclsintervaltype tbody tr");
tblclsintervaltyperows.each(function (index) {
    var tblclsintervaltyperow = $(this);
 	var tblclsintervaltypeobj = {};
	var vProperty = tblclsintervaltyperow.find("[name=Property]").text();
			tblclsintervaltypeobj['Property'] = vProperty;
			tblclsintervaltypeobj['index'] = index;
var vType = tblclsintervaltyperow.find("[name=Type]").text();
			tblclsintervaltypeobj['Type'] = vType;
			tblclsintervaltypeobj['index'] = index;
var vDefaultValue = tblclsintervaltyperow.find("[name=DefaultValue]").text();
			tblclsintervaltypeobj['DefaultValue'] = vDefaultValue;
			tblclsintervaltypeobj['index'] = index;
var vDescription = tblclsintervaltyperow.find("[name=Description]").text();
			tblclsintervaltypeobj['Description'] = vDescription;
			tblclsintervaltypeobj['index'] = index;

	tblclsintervaltypedata.push(tblclsintervaltypeobj);
});
return tblclsintervaltypedata;
	}
function getRowsmethodclsintervaltype(){
	var methodclsintervaltypedata = [];
	methodclsintervaltyperows = $("#methodclsintervaltype tbody tr");
methodclsintervaltyperows.each(function (index) {
    var methodclsintervaltyperow = $(this);
 	var methodclsintervaltypeobj = {};
	var vMethod = methodclsintervaltyperow.find("[name=Method]").text();
			methodclsintervaltypeobj['Method'] = vMethod;
			methodclsintervaltypeobj['index'] = index;
var vParameters = methodclsintervaltyperow.find("[name=Parameters]").text();
			methodclsintervaltypeobj['Parameters'] = vParameters;
			methodclsintervaltypeobj['index'] = index;
var vReturnType = methodclsintervaltyperow.find("[name=ReturnType]").text();
			methodclsintervaltypeobj['ReturnType'] = vReturnType;
			methodclsintervaltypeobj['index'] = index;
var vDescription = methodclsintervaltyperow.find("[name=Description]").text();
			methodclsintervaltypeobj['Description'] = vDescription;
			methodclsintervaltypeobj['index'] = index;

	methodclsintervaltypedata.push(methodclsintervaltypeobj);
});
return methodclsintervaltypedata;
	}
function getRowstblclslabelsize(){
	var tblclslabelsizedata = [];
	tblclslabelsizerows = $("#tblclslabelsize tbody tr");
tblclslabelsizerows.each(function (index) {
    var tblclslabelsizerow = $(this);
 	var tblclslabelsizeobj = {};
	var vProperty = tblclslabelsizerow.find("[name=Property]").text();
			tblclslabelsizeobj['Property'] = vProperty;
			tblclslabelsizeobj['index'] = index;
var vType = tblclslabelsizerow.find("[name=Type]").text();
			tblclslabelsizeobj['Type'] = vType;
			tblclslabelsizeobj['index'] = index;
var vDefaultValue = tblclslabelsizerow.find("[name=DefaultValue]").text();
			tblclslabelsizeobj['DefaultValue'] = vDefaultValue;
			tblclslabelsizeobj['index'] = index;
var vDescription = tblclslabelsizerow.find("[name=Description]").text();
			tblclslabelsizeobj['Description'] = vDescription;
			tblclslabelsizeobj['index'] = index;

	tblclslabelsizedata.push(tblclslabelsizeobj);
});
return tblclslabelsizedata;
	}
function getRowsmethodclslabelsize(){
	var methodclslabelsizedata = [];
	methodclslabelsizerows = $("#methodclslabelsize tbody tr");
methodclslabelsizerows.each(function (index) {
    var methodclslabelsizerow = $(this);
 	var methodclslabelsizeobj = {};
	var vMethod = methodclslabelsizerow.find("[name=Method]").text();
			methodclslabelsizeobj['Method'] = vMethod;
			methodclslabelsizeobj['index'] = index;
var vParameters = methodclslabelsizerow.find("[name=Parameters]").text();
			methodclslabelsizeobj['Parameters'] = vParameters;
			methodclslabelsizeobj['index'] = index;
var vReturnType = methodclslabelsizerow.find("[name=ReturnType]").text();
			methodclslabelsizeobj['ReturnType'] = vReturnType;
			methodclslabelsizeobj['index'] = index;
var vDescription = methodclslabelsizerow.find("[name=Description]").text();
			methodclslabelsizeobj['Description'] = vDescription;
			methodclslabelsizeobj['index'] = index;

	methodclslabelsizedata.push(methodclslabelsizeobj);
});
return methodclslabelsizedata;
	}
function getRowstblclslatlng(){
	var tblclslatlngdata = [];
	tblclslatlngrows = $("#tblclslatlng tbody tr");
tblclslatlngrows.each(function (index) {
    var tblclslatlngrow = $(this);
 	var tblclslatlngobj = {};
	var vProperty = tblclslatlngrow.find("[name=Property]").text();
			tblclslatlngobj['Property'] = vProperty;
			tblclslatlngobj['index'] = index;
var vType = tblclslatlngrow.find("[name=Type]").text();
			tblclslatlngobj['Type'] = vType;
			tblclslatlngobj['index'] = index;
var vDefaultValue = tblclslatlngrow.find("[name=DefaultValue]").text();
			tblclslatlngobj['DefaultValue'] = vDefaultValue;
			tblclslatlngobj['index'] = index;
var vDescription = tblclslatlngrow.find("[name=Description]").text();
			tblclslatlngobj['Description'] = vDescription;
			tblclslatlngobj['index'] = index;

	tblclslatlngdata.push(tblclslatlngobj);
});
return tblclslatlngdata;
	}
function getRowsmethodclslatlng(){
	var methodclslatlngdata = [];
	methodclslatlngrows = $("#methodclslatlng tbody tr");
methodclslatlngrows.each(function (index) {
    var methodclslatlngrow = $(this);
 	var methodclslatlngobj = {};
	var vMethod = methodclslatlngrow.find("[name=Method]").text();
			methodclslatlngobj['Method'] = vMethod;
			methodclslatlngobj['index'] = index;
var vParameters = methodclslatlngrow.find("[name=Parameters]").text();
			methodclslatlngobj['Parameters'] = vParameters;
			methodclslatlngobj['index'] = index;
var vReturnType = methodclslatlngrow.find("[name=ReturnType]").text();
			methodclslatlngobj['ReturnType'] = vReturnType;
			methodclslatlngobj['index'] = index;
var vDescription = methodclslatlngrow.find("[name=Description]").text();
			methodclslatlngobj['Description'] = vDescription;
			methodclslatlngobj['index'] = index;

	methodclslatlngdata.push(methodclslatlngobj);
});
return methodclslatlngdata;
	}
function getRowstblclslinecapof(){
	var tblclslinecapofdata = [];
	tblclslinecapofrows = $("#tblclslinecapof tbody tr");
tblclslinecapofrows.each(function (index) {
    var tblclslinecapofrow = $(this);
 	var tblclslinecapofobj = {};
	var vProperty = tblclslinecapofrow.find("[name=Property]").text();
			tblclslinecapofobj['Property'] = vProperty;
			tblclslinecapofobj['index'] = index;
var vType = tblclslinecapofrow.find("[name=Type]").text();
			tblclslinecapofobj['Type'] = vType;
			tblclslinecapofobj['index'] = index;
var vDefaultValue = tblclslinecapofrow.find("[name=DefaultValue]").text();
			tblclslinecapofobj['DefaultValue'] = vDefaultValue;
			tblclslinecapofobj['index'] = index;
var vDescription = tblclslinecapofrow.find("[name=Description]").text();
			tblclslinecapofobj['Description'] = vDescription;
			tblclslinecapofobj['index'] = index;

	tblclslinecapofdata.push(tblclslinecapofobj);
});
return tblclslinecapofdata;
	}
function getRowsmethodclslinecapof(){
	var methodclslinecapofdata = [];
	methodclslinecapofrows = $("#methodclslinecapof tbody tr");
methodclslinecapofrows.each(function (index) {
    var methodclslinecapofrow = $(this);
 	var methodclslinecapofobj = {};
	var vMethod = methodclslinecapofrow.find("[name=Method]").text();
			methodclslinecapofobj['Method'] = vMethod;
			methodclslinecapofobj['index'] = index;
var vParameters = methodclslinecapofrow.find("[name=Parameters]").text();
			methodclslinecapofobj['Parameters'] = vParameters;
			methodclslinecapofobj['index'] = index;
var vReturnType = methodclslinecapofrow.find("[name=ReturnType]").text();
			methodclslinecapofobj['ReturnType'] = vReturnType;
			methodclslinecapofobj['index'] = index;
var vDescription = methodclslinecapofrow.find("[name=Description]").text();
			methodclslinecapofobj['Description'] = vDescription;
			methodclslinecapofobj['index'] = index;

	methodclslinecapofdata.push(methodclslinecapofobj);
});
return methodclslinecapofdata;
	}
function getRowstblclslogoposition(){
	var tblclslogopositiondata = [];
	tblclslogopositionrows = $("#tblclslogoposition tbody tr");
tblclslogopositionrows.each(function (index) {
    var tblclslogopositionrow = $(this);
 	var tblclslogopositionobj = {};
	var vProperty = tblclslogopositionrow.find("[name=Property]").text();
			tblclslogopositionobj['Property'] = vProperty;
			tblclslogopositionobj['index'] = index;
var vType = tblclslogopositionrow.find("[name=Type]").text();
			tblclslogopositionobj['Type'] = vType;
			tblclslogopositionobj['index'] = index;
var vDefaultValue = tblclslogopositionrow.find("[name=DefaultValue]").text();
			tblclslogopositionobj['DefaultValue'] = vDefaultValue;
			tblclslogopositionobj['index'] = index;
var vDescription = tblclslogopositionrow.find("[name=Description]").text();
			tblclslogopositionobj['Description'] = vDescription;
			tblclslogopositionobj['index'] = index;

	tblclslogopositiondata.push(tblclslogopositionobj);
});
return tblclslogopositiondata;
	}
function getRowsmethodclslogoposition(){
	var methodclslogopositiondata = [];
	methodclslogopositionrows = $("#methodclslogoposition tbody tr");
methodclslogopositionrows.each(function (index) {
    var methodclslogopositionrow = $(this);
 	var methodclslogopositionobj = {};
	var vMethod = methodclslogopositionrow.find("[name=Method]").text();
			methodclslogopositionobj['Method'] = vMethod;
			methodclslogopositionobj['index'] = index;
var vParameters = methodclslogopositionrow.find("[name=Parameters]").text();
			methodclslogopositionobj['Parameters'] = vParameters;
			methodclslogopositionobj['index'] = index;
var vReturnType = methodclslogopositionrow.find("[name=ReturnType]").text();
			methodclslogopositionobj['ReturnType'] = vReturnType;
			methodclslogopositionobj['index'] = index;
var vDescription = methodclslogopositionrow.find("[name=Description]").text();
			methodclslogopositionobj['Description'] = vDescription;
			methodclslogopositionobj['index'] = index;

	methodclslogopositiondata.push(methodclslogopositionobj);
});
return methodclslogopositiondata;
	}
function getRowstblclsmakiicons(){
	var tblclsmakiiconsdata = [];
	tblclsmakiiconsrows = $("#tblclsmakiicons tbody tr");
tblclsmakiiconsrows.each(function (index) {
    var tblclsmakiiconsrow = $(this);
 	var tblclsmakiiconsobj = {};
	var vProperty = tblclsmakiiconsrow.find("[name=Property]").text();
			tblclsmakiiconsobj['Property'] = vProperty;
			tblclsmakiiconsobj['index'] = index;
var vType = tblclsmakiiconsrow.find("[name=Type]").text();
			tblclsmakiiconsobj['Type'] = vType;
			tblclsmakiiconsobj['index'] = index;
var vDefaultValue = tblclsmakiiconsrow.find("[name=DefaultValue]").text();
			tblclsmakiiconsobj['DefaultValue'] = vDefaultValue;
			tblclsmakiiconsobj['index'] = index;
var vDescription = tblclsmakiiconsrow.find("[name=Description]").text();
			tblclsmakiiconsobj['Description'] = vDescription;
			tblclsmakiiconsobj['index'] = index;

	tblclsmakiiconsdata.push(tblclsmakiiconsobj);
});
return tblclsmakiiconsdata;
	}
function getRowsmethodclsmakiicons(){
	var methodclsmakiiconsdata = [];
	methodclsmakiiconsrows = $("#methodclsmakiicons tbody tr");
methodclsmakiiconsrows.each(function (index) {
    var methodclsmakiiconsrow = $(this);
 	var methodclsmakiiconsobj = {};
	var vMethod = methodclsmakiiconsrow.find("[name=Method]").text();
			methodclsmakiiconsobj['Method'] = vMethod;
			methodclsmakiiconsobj['index'] = index;
var vParameters = methodclsmakiiconsrow.find("[name=Parameters]").text();
			methodclsmakiiconsobj['Parameters'] = vParameters;
			methodclsmakiiconsobj['index'] = index;
var vReturnType = methodclsmakiiconsrow.find("[name=ReturnType]").text();
			methodclsmakiiconsobj['ReturnType'] = vReturnType;
			methodclsmakiiconsobj['index'] = index;
var vDescription = methodclsmakiiconsrow.find("[name=Description]").text();
			methodclsmakiiconsobj['Description'] = vDescription;
			methodclsmakiiconsobj['index'] = index;

	methodclsmakiiconsdata.push(methodclsmakiiconsobj);
});
return methodclsmakiiconsdata;
	}
function getRowstblclsmaptypeobj(){
	var tblclsmaptypeobjdata = [];
	tblclsmaptypeobjrows = $("#tblclsmaptypeobj tbody tr");
tblclsmaptypeobjrows.each(function (index) {
    var tblclsmaptypeobjrow = $(this);
 	var tblclsmaptypeobjobj = {};
	var vProperty = tblclsmaptypeobjrow.find("[name=Property]").text();
			tblclsmaptypeobjobj['Property'] = vProperty;
			tblclsmaptypeobjobj['index'] = index;
var vType = tblclsmaptypeobjrow.find("[name=Type]").text();
			tblclsmaptypeobjobj['Type'] = vType;
			tblclsmaptypeobjobj['index'] = index;
var vDefaultValue = tblclsmaptypeobjrow.find("[name=DefaultValue]").text();
			tblclsmaptypeobjobj['DefaultValue'] = vDefaultValue;
			tblclsmaptypeobjobj['index'] = index;
var vDescription = tblclsmaptypeobjrow.find("[name=Description]").text();
			tblclsmaptypeobjobj['Description'] = vDescription;
			tblclsmaptypeobjobj['index'] = index;

	tblclsmaptypeobjdata.push(tblclsmaptypeobjobj);
});
return tblclsmaptypeobjdata;
	}
function getRowsmethodclsmaptypeobj(){
	var methodclsmaptypeobjdata = [];
	methodclsmaptypeobjrows = $("#methodclsmaptypeobj tbody tr");
methodclsmaptypeobjrows.each(function (index) {
    var methodclsmaptypeobjrow = $(this);
 	var methodclsmaptypeobjobj = {};
	var vMethod = methodclsmaptypeobjrow.find("[name=Method]").text();
			methodclsmaptypeobjobj['Method'] = vMethod;
			methodclsmaptypeobjobj['index'] = index;
var vParameters = methodclsmaptypeobjrow.find("[name=Parameters]").text();
			methodclsmaptypeobjobj['Parameters'] = vParameters;
			methodclsmaptypeobjobj['index'] = index;
var vReturnType = methodclsmaptypeobjrow.find("[name=ReturnType]").text();
			methodclsmaptypeobjobj['ReturnType'] = vReturnType;
			methodclsmaptypeobjobj['index'] = index;
var vDescription = methodclsmaptypeobjrow.find("[name=Description]").text();
			methodclsmaptypeobjobj['Description'] = vDescription;
			methodclsmaptypeobjobj['index'] = index;

	methodclsmaptypeobjdata.push(methodclsmaptypeobjobj);
});
return methodclsmaptypeobjdata;
	}
function getRowstblclsmbcircle(){
	var tblclsmbcircledata = [];
	tblclsmbcirclerows = $("#tblclsmbcircle tbody tr");
tblclsmbcirclerows.each(function (index) {
    var tblclsmbcirclerow = $(this);
 	var tblclsmbcircleobj = {};
	var vProperty = tblclsmbcirclerow.find("[name=Property]").text();
			tblclsmbcircleobj['Property'] = vProperty;
			tblclsmbcircleobj['index'] = index;
var vType = tblclsmbcirclerow.find("[name=Type]").text();
			tblclsmbcircleobj['Type'] = vType;
			tblclsmbcircleobj['index'] = index;
var vDefaultValue = tblclsmbcirclerow.find("[name=DefaultValue]").text();
			tblclsmbcircleobj['DefaultValue'] = vDefaultValue;
			tblclsmbcircleobj['index'] = index;
var vDescription = tblclsmbcirclerow.find("[name=Description]").text();
			tblclsmbcircleobj['Description'] = vDescription;
			tblclsmbcircleobj['index'] = index;

	tblclsmbcircledata.push(tblclsmbcircleobj);
});
return tblclsmbcircledata;
	}
function getRowsmethodclsmbcircle(){
	var methodclsmbcircledata = [];
	methodclsmbcirclerows = $("#methodclsmbcircle tbody tr");
methodclsmbcirclerows.each(function (index) {
    var methodclsmbcirclerow = $(this);
 	var methodclsmbcircleobj = {};
	var vMethod = methodclsmbcirclerow.find("[name=Method]").text();
			methodclsmbcircleobj['Method'] = vMethod;
			methodclsmbcircleobj['index'] = index;
var vParameters = methodclsmbcirclerow.find("[name=Parameters]").text();
			methodclsmbcircleobj['Parameters'] = vParameters;
			methodclsmbcircleobj['index'] = index;
var vReturnType = methodclsmbcirclerow.find("[name=ReturnType]").text();
			methodclsmbcircleobj['ReturnType'] = vReturnType;
			methodclsmbcircleobj['index'] = index;
var vDescription = methodclsmbcirclerow.find("[name=Description]").text();
			methodclsmbcircleobj['Description'] = vDescription;
			methodclsmbcircleobj['index'] = index;

	methodclsmbcircledata.push(methodclsmbcircleobj);
});
return methodclsmbcircledata;
	}
function getRowstblclsmbiconsize(){
	var tblclsmbiconsizedata = [];
	tblclsmbiconsizerows = $("#tblclsmbiconsize tbody tr");
tblclsmbiconsizerows.each(function (index) {
    var tblclsmbiconsizerow = $(this);
 	var tblclsmbiconsizeobj = {};
	var vProperty = tblclsmbiconsizerow.find("[name=Property]").text();
			tblclsmbiconsizeobj['Property'] = vProperty;
			tblclsmbiconsizeobj['index'] = index;
var vType = tblclsmbiconsizerow.find("[name=Type]").text();
			tblclsmbiconsizeobj['Type'] = vType;
			tblclsmbiconsizeobj['index'] = index;
var vDefaultValue = tblclsmbiconsizerow.find("[name=DefaultValue]").text();
			tblclsmbiconsizeobj['DefaultValue'] = vDefaultValue;
			tblclsmbiconsizeobj['index'] = index;
var vDescription = tblclsmbiconsizerow.find("[name=Description]").text();
			tblclsmbiconsizeobj['Description'] = vDescription;
			tblclsmbiconsizeobj['index'] = index;

	tblclsmbiconsizedata.push(tblclsmbiconsizeobj);
});
return tblclsmbiconsizedata;
	}
function getRowsmethodclsmbiconsize(){
	var methodclsmbiconsizedata = [];
	methodclsmbiconsizerows = $("#methodclsmbiconsize tbody tr");
methodclsmbiconsizerows.each(function (index) {
    var methodclsmbiconsizerow = $(this);
 	var methodclsmbiconsizeobj = {};
	var vMethod = methodclsmbiconsizerow.find("[name=Method]").text();
			methodclsmbiconsizeobj['Method'] = vMethod;
			methodclsmbiconsizeobj['index'] = index;
var vParameters = methodclsmbiconsizerow.find("[name=Parameters]").text();
			methodclsmbiconsizeobj['Parameters'] = vParameters;
			methodclsmbiconsizeobj['index'] = index;
var vReturnType = methodclsmbiconsizerow.find("[name=ReturnType]").text();
			methodclsmbiconsizeobj['ReturnType'] = vReturnType;
			methodclsmbiconsizeobj['index'] = index;
var vDescription = methodclsmbiconsizerow.find("[name=Description]").text();
			methodclsmbiconsizeobj['Description'] = vDescription;
			methodclsmbiconsizeobj['index'] = index;

	methodclsmbiconsizedata.push(methodclsmbiconsizeobj);
});
return methodclsmbiconsizedata;
	}
function getRowstblclsmbmarkertype(){
	var tblclsmbmarkertypedata = [];
	tblclsmbmarkertyperows = $("#tblclsmbmarkertype tbody tr");
tblclsmbmarkertyperows.each(function (index) {
    var tblclsmbmarkertyperow = $(this);
 	var tblclsmbmarkertypeobj = {};
	var vProperty = tblclsmbmarkertyperow.find("[name=Property]").text();
			tblclsmbmarkertypeobj['Property'] = vProperty;
			tblclsmbmarkertypeobj['index'] = index;
var vType = tblclsmbmarkertyperow.find("[name=Type]").text();
			tblclsmbmarkertypeobj['Type'] = vType;
			tblclsmbmarkertypeobj['index'] = index;
var vDefaultValue = tblclsmbmarkertyperow.find("[name=DefaultValue]").text();
			tblclsmbmarkertypeobj['DefaultValue'] = vDefaultValue;
			tblclsmbmarkertypeobj['index'] = index;
var vDescription = tblclsmbmarkertyperow.find("[name=Description]").text();
			tblclsmbmarkertypeobj['Description'] = vDescription;
			tblclsmbmarkertypeobj['index'] = index;

	tblclsmbmarkertypedata.push(tblclsmbmarkertypeobj);
});
return tblclsmbmarkertypedata;
	}
function getRowsmethodclsmbmarkertype(){
	var methodclsmbmarkertypedata = [];
	methodclsmbmarkertyperows = $("#methodclsmbmarkertype tbody tr");
methodclsmbmarkertyperows.each(function (index) {
    var methodclsmbmarkertyperow = $(this);
 	var methodclsmbmarkertypeobj = {};
	var vMethod = methodclsmbmarkertyperow.find("[name=Method]").text();
			methodclsmbmarkertypeobj['Method'] = vMethod;
			methodclsmbmarkertypeobj['index'] = index;
var vParameters = methodclsmbmarkertyperow.find("[name=Parameters]").text();
			methodclsmbmarkertypeobj['Parameters'] = vParameters;
			methodclsmbmarkertypeobj['index'] = index;
var vReturnType = methodclsmbmarkertyperow.find("[name=ReturnType]").text();
			methodclsmbmarkertypeobj['ReturnType'] = vReturnType;
			methodclsmbmarkertypeobj['index'] = index;
var vDescription = methodclsmbmarkertyperow.find("[name=Description]").text();
			methodclsmbmarkertypeobj['Description'] = vDescription;
			methodclsmbmarkertypeobj['index'] = index;

	methodclsmbmarkertypedata.push(methodclsmbmarkertypeobj);
});
return methodclsmbmarkertypedata;
	}
function getRowstblclsmbpolyline(){
	var tblclsmbpolylinedata = [];
	tblclsmbpolylinerows = $("#tblclsmbpolyline tbody tr");
tblclsmbpolylinerows.each(function (index) {
    var tblclsmbpolylinerow = $(this);
 	var tblclsmbpolylineobj = {};
	var vProperty = tblclsmbpolylinerow.find("[name=Property]").text();
			tblclsmbpolylineobj['Property'] = vProperty;
			tblclsmbpolylineobj['index'] = index;
var vType = tblclsmbpolylinerow.find("[name=Type]").text();
			tblclsmbpolylineobj['Type'] = vType;
			tblclsmbpolylineobj['index'] = index;
var vDefaultValue = tblclsmbpolylinerow.find("[name=DefaultValue]").text();
			tblclsmbpolylineobj['DefaultValue'] = vDefaultValue;
			tblclsmbpolylineobj['index'] = index;
var vDescription = tblclsmbpolylinerow.find("[name=Description]").text();
			tblclsmbpolylineobj['Description'] = vDescription;
			tblclsmbpolylineobj['index'] = index;

	tblclsmbpolylinedata.push(tblclsmbpolylineobj);
});
return tblclsmbpolylinedata;
	}
function getRowsmethodclsmbpolyline(){
	var methodclsmbpolylinedata = [];
	methodclsmbpolylinerows = $("#methodclsmbpolyline tbody tr");
methodclsmbpolylinerows.each(function (index) {
    var methodclsmbpolylinerow = $(this);
 	var methodclsmbpolylineobj = {};
	var vMethod = methodclsmbpolylinerow.find("[name=Method]").text();
			methodclsmbpolylineobj['Method'] = vMethod;
			methodclsmbpolylineobj['index'] = index;
var vParameters = methodclsmbpolylinerow.find("[name=Parameters]").text();
			methodclsmbpolylineobj['Parameters'] = vParameters;
			methodclsmbpolylineobj['index'] = index;
var vReturnType = methodclsmbpolylinerow.find("[name=ReturnType]").text();
			methodclsmbpolylineobj['ReturnType'] = vReturnType;
			methodclsmbpolylineobj['index'] = index;
var vDescription = methodclsmbpolylinerow.find("[name=Description]").text();
			methodclsmbpolylineobj['Description'] = vDescription;
			methodclsmbpolylineobj['index'] = index;

	methodclsmbpolylinedata.push(methodclsmbpolylineobj);
});
return methodclsmbpolylinedata;
	}
function getRowstblclsmenupos(){
	var tblclsmenuposdata = [];
	tblclsmenuposrows = $("#tblclsmenupos tbody tr");
tblclsmenuposrows.each(function (index) {
    var tblclsmenuposrow = $(this);
 	var tblclsmenuposobj = {};
	var vProperty = tblclsmenuposrow.find("[name=Property]").text();
			tblclsmenuposobj['Property'] = vProperty;
			tblclsmenuposobj['index'] = index;
var vType = tblclsmenuposrow.find("[name=Type]").text();
			tblclsmenuposobj['Type'] = vType;
			tblclsmenuposobj['index'] = index;
var vDefaultValue = tblclsmenuposrow.find("[name=DefaultValue]").text();
			tblclsmenuposobj['DefaultValue'] = vDefaultValue;
			tblclsmenuposobj['index'] = index;
var vDescription = tblclsmenuposrow.find("[name=Description]").text();
			tblclsmenuposobj['Description'] = vDescription;
			tblclsmenuposobj['index'] = index;

	tblclsmenuposdata.push(tblclsmenuposobj);
});
return tblclsmenuposdata;
	}
function getRowsmethodclsmenupos(){
	var methodclsmenuposdata = [];
	methodclsmenuposrows = $("#methodclsmenupos tbody tr");
methodclsmenuposrows.each(function (index) {
    var methodclsmenuposrow = $(this);
 	var methodclsmenuposobj = {};
	var vMethod = methodclsmenuposrow.find("[name=Method]").text();
			methodclsmenuposobj['Method'] = vMethod;
			methodclsmenuposobj['index'] = index;
var vParameters = methodclsmenuposrow.find("[name=Parameters]").text();
			methodclsmenuposobj['Parameters'] = vParameters;
			methodclsmenuposobj['index'] = index;
var vReturnType = methodclsmenuposrow.find("[name=ReturnType]").text();
			methodclsmenuposobj['ReturnType'] = vReturnType;
			methodclsmenuposobj['index'] = index;
var vDescription = methodclsmenuposrow.find("[name=Description]").text();
			methodclsmenuposobj['Description'] = vDescription;
			methodclsmenuposobj['index'] = index;

	methodclsmenuposdata.push(methodclsmenuposobj);
});
return methodclsmenuposdata;
	}
function getRowstblclsmodetype(){
	var tblclsmodetypedata = [];
	tblclsmodetyperows = $("#tblclsmodetype tbody tr");
tblclsmodetyperows.each(function (index) {
    var tblclsmodetyperow = $(this);
 	var tblclsmodetypeobj = {};
	var vProperty = tblclsmodetyperow.find("[name=Property]").text();
			tblclsmodetypeobj['Property'] = vProperty;
			tblclsmodetypeobj['index'] = index;
var vType = tblclsmodetyperow.find("[name=Type]").text();
			tblclsmodetypeobj['Type'] = vType;
			tblclsmodetypeobj['index'] = index;
var vDefaultValue = tblclsmodetyperow.find("[name=DefaultValue]").text();
			tblclsmodetypeobj['DefaultValue'] = vDefaultValue;
			tblclsmodetypeobj['index'] = index;
var vDescription = tblclsmodetyperow.find("[name=Description]").text();
			tblclsmodetypeobj['Description'] = vDescription;
			tblclsmodetypeobj['index'] = index;

	tblclsmodetypedata.push(tblclsmodetypeobj);
});
return tblclsmodetypedata;
	}
function getRowsmethodclsmodetype(){
	var methodclsmodetypedata = [];
	methodclsmodetyperows = $("#methodclsmodetype tbody tr");
methodclsmodetyperows.each(function (index) {
    var methodclsmodetyperow = $(this);
 	var methodclsmodetypeobj = {};
	var vMethod = methodclsmodetyperow.find("[name=Method]").text();
			methodclsmodetypeobj['Method'] = vMethod;
			methodclsmodetypeobj['index'] = index;
var vParameters = methodclsmodetyperow.find("[name=Parameters]").text();
			methodclsmodetypeobj['Parameters'] = vParameters;
			methodclsmodetypeobj['index'] = index;
var vReturnType = methodclsmodetyperow.find("[name=ReturnType]").text();
			methodclsmodetypeobj['ReturnType'] = vReturnType;
			methodclsmodetypeobj['index'] = index;
var vDescription = methodclsmodetyperow.find("[name=Description]").text();
			methodclsmodetypeobj['Description'] = vDescription;
			methodclsmodetypeobj['index'] = index;

	methodclsmodetypedata.push(methodclsmodetypeobj);
});
return methodclsmodetypedata;
	}
function getRowstblclsorientation(){
	var tblclsorientationdata = [];
	tblclsorientationrows = $("#tblclsorientation tbody tr");
tblclsorientationrows.each(function (index) {
    var tblclsorientationrow = $(this);
 	var tblclsorientationobj = {};
	var vProperty = tblclsorientationrow.find("[name=Property]").text();
			tblclsorientationobj['Property'] = vProperty;
			tblclsorientationobj['index'] = index;
var vType = tblclsorientationrow.find("[name=Type]").text();
			tblclsorientationobj['Type'] = vType;
			tblclsorientationobj['index'] = index;
var vDefaultValue = tblclsorientationrow.find("[name=DefaultValue]").text();
			tblclsorientationobj['DefaultValue'] = vDefaultValue;
			tblclsorientationobj['index'] = index;
var vDescription = tblclsorientationrow.find("[name=Description]").text();
			tblclsorientationobj['Description'] = vDescription;
			tblclsorientationobj['index'] = index;

	tblclsorientationdata.push(tblclsorientationobj);
});
return tblclsorientationdata;
	}
function getRowsmethodclsorientation(){
	var methodclsorientationdata = [];
	methodclsorientationrows = $("#methodclsorientation tbody tr");
methodclsorientationrows.each(function (index) {
    var methodclsorientationrow = $(this);
 	var methodclsorientationobj = {};
	var vMethod = methodclsorientationrow.find("[name=Method]").text();
			methodclsorientationobj['Method'] = vMethod;
			methodclsorientationobj['index'] = index;
var vParameters = methodclsorientationrow.find("[name=Parameters]").text();
			methodclsorientationobj['Parameters'] = vParameters;
			methodclsorientationobj['index'] = index;
var vReturnType = methodclsorientationrow.find("[name=ReturnType]").text();
			methodclsorientationobj['ReturnType'] = vReturnType;
			methodclsorientationobj['index'] = index;
var vDescription = methodclsorientationrow.find("[name=Description]").text();
			methodclsorientationobj['Description'] = vDescription;
			methodclsorientationobj['index'] = index;

	methodclsorientationdata.push(methodclsorientationobj);
});
return methodclsorientationdata;
	}
function getRowstblclsscaletype(){
	var tblclsscaletypedata = [];
	tblclsscaletyperows = $("#tblclsscaletype tbody tr");
tblclsscaletyperows.each(function (index) {
    var tblclsscaletyperow = $(this);
 	var tblclsscaletypeobj = {};
	var vProperty = tblclsscaletyperow.find("[name=Property]").text();
			tblclsscaletypeobj['Property'] = vProperty;
			tblclsscaletypeobj['index'] = index;
var vType = tblclsscaletyperow.find("[name=Type]").text();
			tblclsscaletypeobj['Type'] = vType;
			tblclsscaletypeobj['index'] = index;
var vDefaultValue = tblclsscaletyperow.find("[name=DefaultValue]").text();
			tblclsscaletypeobj['DefaultValue'] = vDefaultValue;
			tblclsscaletypeobj['index'] = index;
var vDescription = tblclsscaletyperow.find("[name=Description]").text();
			tblclsscaletypeobj['Description'] = vDescription;
			tblclsscaletypeobj['index'] = index;

	tblclsscaletypedata.push(tblclsscaletypeobj);
});
return tblclsscaletypedata;
	}
function getRowsmethodclsscaletype(){
	var methodclsscaletypedata = [];
	methodclsscaletyperows = $("#methodclsscaletype tbody tr");
methodclsscaletyperows.each(function (index) {
    var methodclsscaletyperow = $(this);
 	var methodclsscaletypeobj = {};
	var vMethod = methodclsscaletyperow.find("[name=Method]").text();
			methodclsscaletypeobj['Method'] = vMethod;
			methodclsscaletypeobj['index'] = index;
var vParameters = methodclsscaletyperow.find("[name=Parameters]").text();
			methodclsscaletypeobj['Parameters'] = vParameters;
			methodclsscaletypeobj['index'] = index;
var vReturnType = methodclsscaletyperow.find("[name=ReturnType]").text();
			methodclsscaletypeobj['ReturnType'] = vReturnType;
			methodclsscaletypeobj['index'] = index;
var vDescription = methodclsscaletyperow.find("[name=Description]").text();
			methodclsscaletypeobj['Description'] = vDescription;
			methodclsscaletypeobj['index'] = index;

	methodclsscaletypedata.push(methodclsscaletypeobj);
});
return methodclsscaletypedata;
	}
function getRowstblclssliderorientation(){
	var tblclssliderorientationdata = [];
	tblclssliderorientationrows = $("#tblclssliderorientation tbody tr");
tblclssliderorientationrows.each(function (index) {
    var tblclssliderorientationrow = $(this);
 	var tblclssliderorientationobj = {};
	var vProperty = tblclssliderorientationrow.find("[name=Property]").text();
			tblclssliderorientationobj['Property'] = vProperty;
			tblclssliderorientationobj['index'] = index;
var vType = tblclssliderorientationrow.find("[name=Type]").text();
			tblclssliderorientationobj['Type'] = vType;
			tblclssliderorientationobj['index'] = index;
var vDefaultValue = tblclssliderorientationrow.find("[name=DefaultValue]").text();
			tblclssliderorientationobj['DefaultValue'] = vDefaultValue;
			tblclssliderorientationobj['index'] = index;
var vDescription = tblclssliderorientationrow.find("[name=Description]").text();
			tblclssliderorientationobj['Description'] = vDescription;
			tblclssliderorientationobj['index'] = index;

	tblclssliderorientationdata.push(tblclssliderorientationobj);
});
return tblclssliderorientationdata;
	}
function getRowsmethodclssliderorientation(){
	var methodclssliderorientationdata = [];
	methodclssliderorientationrows = $("#methodclssliderorientation tbody tr");
methodclssliderorientationrows.each(function (index) {
    var methodclssliderorientationrow = $(this);
 	var methodclssliderorientationobj = {};
	var vMethod = methodclssliderorientationrow.find("[name=Method]").text();
			methodclssliderorientationobj['Method'] = vMethod;
			methodclssliderorientationobj['index'] = index;
var vParameters = methodclssliderorientationrow.find("[name=Parameters]").text();
			methodclssliderorientationobj['Parameters'] = vParameters;
			methodclssliderorientationobj['index'] = index;
var vReturnType = methodclssliderorientationrow.find("[name=ReturnType]").text();
			methodclssliderorientationobj['ReturnType'] = vReturnType;
			methodclssliderorientationobj['index'] = index;
var vDescription = methodclssliderorientationrow.find("[name=Description]").text();
			methodclssliderorientationobj['Description'] = vDescription;
			methodclssliderorientationobj['index'] = index;

	methodclssliderorientationdata.push(methodclssliderorientationobj);
});
return methodclssliderorientationdata;
	}
function getRowstblclssocialshareplatform(){
	var tblclssocialshareplatformdata = [];
	tblclssocialshareplatformrows = $("#tblclssocialshareplatform tbody tr");
tblclssocialshareplatformrows.each(function (index) {
    var tblclssocialshareplatformrow = $(this);
 	var tblclssocialshareplatformobj = {};
	var vProperty = tblclssocialshareplatformrow.find("[name=Property]").text();
			tblclssocialshareplatformobj['Property'] = vProperty;
			tblclssocialshareplatformobj['index'] = index;
var vType = tblclssocialshareplatformrow.find("[name=Type]").text();
			tblclssocialshareplatformobj['Type'] = vType;
			tblclssocialshareplatformobj['index'] = index;
var vDefaultValue = tblclssocialshareplatformrow.find("[name=DefaultValue]").text();
			tblclssocialshareplatformobj['DefaultValue'] = vDefaultValue;
			tblclssocialshareplatformobj['index'] = index;
var vDescription = tblclssocialshareplatformrow.find("[name=Description]").text();
			tblclssocialshareplatformobj['Description'] = vDescription;
			tblclssocialshareplatformobj['index'] = index;

	tblclssocialshareplatformdata.push(tblclssocialshareplatformobj);
});
return tblclssocialshareplatformdata;
	}
function getRowsmethodclssocialshareplatform(){
	var methodclssocialshareplatformdata = [];
	methodclssocialshareplatformrows = $("#methodclssocialshareplatform tbody tr");
methodclssocialshareplatformrows.each(function (index) {
    var methodclssocialshareplatformrow = $(this);
 	var methodclssocialshareplatformobj = {};
	var vMethod = methodclssocialshareplatformrow.find("[name=Method]").text();
			methodclssocialshareplatformobj['Method'] = vMethod;
			methodclssocialshareplatformobj['index'] = index;
var vParameters = methodclssocialshareplatformrow.find("[name=Parameters]").text();
			methodclssocialshareplatformobj['Parameters'] = vParameters;
			methodclssocialshareplatformobj['index'] = index;
var vReturnType = methodclssocialshareplatformrow.find("[name=ReturnType]").text();
			methodclssocialshareplatformobj['ReturnType'] = vReturnType;
			methodclssocialshareplatformobj['index'] = index;
var vDescription = methodclssocialshareplatformrow.find("[name=Description]").text();
			methodclssocialshareplatformobj['Description'] = vDescription;
			methodclssocialshareplatformobj['index'] = index;

	methodclssocialshareplatformdata.push(methodclssocialshareplatformobj);
});
return methodclssocialshareplatformdata;
	}
function getRowstblclssocialsharetheme(){
	var tblclssocialsharethemedata = [];
	tblclssocialsharethemerows = $("#tblclssocialsharetheme tbody tr");
tblclssocialsharethemerows.each(function (index) {
    var tblclssocialsharethemerow = $(this);
 	var tblclssocialsharethemeobj = {};
	var vProperty = tblclssocialsharethemerow.find("[name=Property]").text();
			tblclssocialsharethemeobj['Property'] = vProperty;
			tblclssocialsharethemeobj['index'] = index;
var vType = tblclssocialsharethemerow.find("[name=Type]").text();
			tblclssocialsharethemeobj['Type'] = vType;
			tblclssocialsharethemeobj['index'] = index;
var vDefaultValue = tblclssocialsharethemerow.find("[name=DefaultValue]").text();
			tblclssocialsharethemeobj['DefaultValue'] = vDefaultValue;
			tblclssocialsharethemeobj['index'] = index;
var vDescription = tblclssocialsharethemerow.find("[name=Description]").text();
			tblclssocialsharethemeobj['Description'] = vDescription;
			tblclssocialsharethemeobj['index'] = index;

	tblclssocialsharethemedata.push(tblclssocialsharethemeobj);
});
return tblclssocialsharethemedata;
	}
function getRowsmethodclssocialsharetheme(){
	var methodclssocialsharethemedata = [];
	methodclssocialsharethemerows = $("#methodclssocialsharetheme tbody tr");
methodclssocialsharethemerows.each(function (index) {
    var methodclssocialsharethemerow = $(this);
 	var methodclssocialsharethemeobj = {};
	var vMethod = methodclssocialsharethemerow.find("[name=Method]").text();
			methodclssocialsharethemeobj['Method'] = vMethod;
			methodclssocialsharethemeobj['index'] = index;
var vParameters = methodclssocialsharethemerow.find("[name=Parameters]").text();
			methodclssocialsharethemeobj['Parameters'] = vParameters;
			methodclssocialsharethemeobj['index'] = index;
var vReturnType = methodclssocialsharethemerow.find("[name=ReturnType]").text();
			methodclssocialsharethemeobj['ReturnType'] = vReturnType;
			methodclssocialsharethemeobj['index'] = index;
var vDescription = methodclssocialsharethemerow.find("[name=Description]").text();
			methodclssocialsharethemeobj['Description'] = vDescription;
			methodclssocialsharethemeobj['index'] = index;

	methodclssocialsharethemedata.push(methodclssocialsharethemeobj);
});
return methodclssocialsharethemedata;
	}
function getRowstblclsstatstype(){
	var tblclsstatstypedata = [];
	tblclsstatstyperows = $("#tblclsstatstype tbody tr");
tblclsstatstyperows.each(function (index) {
    var tblclsstatstyperow = $(this);
 	var tblclsstatstypeobj = {};
	var vProperty = tblclsstatstyperow.find("[name=Property]").text();
			tblclsstatstypeobj['Property'] = vProperty;
			tblclsstatstypeobj['index'] = index;
var vType = tblclsstatstyperow.find("[name=Type]").text();
			tblclsstatstypeobj['Type'] = vType;
			tblclsstatstypeobj['index'] = index;
var vDefaultValue = tblclsstatstyperow.find("[name=DefaultValue]").text();
			tblclsstatstypeobj['DefaultValue'] = vDefaultValue;
			tblclsstatstypeobj['index'] = index;
var vDescription = tblclsstatstyperow.find("[name=Description]").text();
			tblclsstatstypeobj['Description'] = vDescription;
			tblclsstatstypeobj['index'] = index;

	tblclsstatstypedata.push(tblclsstatstypeobj);
});
return tblclsstatstypedata;
	}
function getRowsmethodclsstatstype(){
	var methodclsstatstypedata = [];
	methodclsstatstyperows = $("#methodclsstatstype tbody tr");
methodclsstatstyperows.each(function (index) {
    var methodclsstatstyperow = $(this);
 	var methodclsstatstypeobj = {};
	var vMethod = methodclsstatstyperow.find("[name=Method]").text();
			methodclsstatstypeobj['Method'] = vMethod;
			methodclsstatstypeobj['index'] = index;
var vParameters = methodclsstatstyperow.find("[name=Parameters]").text();
			methodclsstatstypeobj['Parameters'] = vParameters;
			methodclsstatstypeobj['index'] = index;
var vReturnType = methodclsstatstyperow.find("[name=ReturnType]").text();
			methodclsstatstypeobj['ReturnType'] = vReturnType;
			methodclsstatstypeobj['index'] = index;
var vDescription = methodclsstatstyperow.find("[name=Description]").text();
			methodclsstatstypeobj['Description'] = vDescription;
			methodclsstatstypeobj['index'] = index;

	methodclsstatstypedata.push(methodclsstatstypeobj);
});
return methodclsstatstypedata;
	}
function getRowstblclssubmarkerdirectiontype(){
	var tblclssubmarkerdirectiontypedata = [];
	tblclssubmarkerdirectiontyperows = $("#tblclssubmarkerdirectiontype tbody tr");
tblclssubmarkerdirectiontyperows.each(function (index) {
    var tblclssubmarkerdirectiontyperow = $(this);
 	var tblclssubmarkerdirectiontypeobj = {};
	var vProperty = tblclssubmarkerdirectiontyperow.find("[name=Property]").text();
			tblclssubmarkerdirectiontypeobj['Property'] = vProperty;
			tblclssubmarkerdirectiontypeobj['index'] = index;
var vType = tblclssubmarkerdirectiontyperow.find("[name=Type]").text();
			tblclssubmarkerdirectiontypeobj['Type'] = vType;
			tblclssubmarkerdirectiontypeobj['index'] = index;
var vDefaultValue = tblclssubmarkerdirectiontyperow.find("[name=DefaultValue]").text();
			tblclssubmarkerdirectiontypeobj['DefaultValue'] = vDefaultValue;
			tblclssubmarkerdirectiontypeobj['index'] = index;
var vDescription = tblclssubmarkerdirectiontyperow.find("[name=Description]").text();
			tblclssubmarkerdirectiontypeobj['Description'] = vDescription;
			tblclssubmarkerdirectiontypeobj['index'] = index;

	tblclssubmarkerdirectiontypedata.push(tblclssubmarkerdirectiontypeobj);
});
return tblclssubmarkerdirectiontypedata;
	}
function getRowsmethodclssubmarkerdirectiontype(){
	var methodclssubmarkerdirectiontypedata = [];
	methodclssubmarkerdirectiontyperows = $("#methodclssubmarkerdirectiontype tbody tr");
methodclssubmarkerdirectiontyperows.each(function (index) {
    var methodclssubmarkerdirectiontyperow = $(this);
 	var methodclssubmarkerdirectiontypeobj = {};
	var vMethod = methodclssubmarkerdirectiontyperow.find("[name=Method]").text();
			methodclssubmarkerdirectiontypeobj['Method'] = vMethod;
			methodclssubmarkerdirectiontypeobj['index'] = index;
var vParameters = methodclssubmarkerdirectiontyperow.find("[name=Parameters]").text();
			methodclssubmarkerdirectiontypeobj['Parameters'] = vParameters;
			methodclssubmarkerdirectiontypeobj['index'] = index;
var vReturnType = methodclssubmarkerdirectiontyperow.find("[name=ReturnType]").text();
			methodclssubmarkerdirectiontypeobj['ReturnType'] = vReturnType;
			methodclssubmarkerdirectiontypeobj['index'] = index;
var vDescription = methodclssubmarkerdirectiontyperow.find("[name=Description]").text();
			methodclssubmarkerdirectiontypeobj['Description'] = vDescription;
			methodclssubmarkerdirectiontypeobj['index'] = index;

	methodclssubmarkerdirectiontypedata.push(methodclssubmarkerdirectiontypeobj);
});
return methodclssubmarkerdirectiontypedata;
	}
function getRowstblclssubmarkerinfotype(){
	var tblclssubmarkerinfotypedata = [];
	tblclssubmarkerinfotyperows = $("#tblclssubmarkerinfotype tbody tr");
tblclssubmarkerinfotyperows.each(function (index) {
    var tblclssubmarkerinfotyperow = $(this);
 	var tblclssubmarkerinfotypeobj = {};
	var vProperty = tblclssubmarkerinfotyperow.find("[name=Property]").text();
			tblclssubmarkerinfotypeobj['Property'] = vProperty;
			tblclssubmarkerinfotypeobj['index'] = index;
var vType = tblclssubmarkerinfotyperow.find("[name=Type]").text();
			tblclssubmarkerinfotypeobj['Type'] = vType;
			tblclssubmarkerinfotypeobj['index'] = index;
var vDefaultValue = tblclssubmarkerinfotyperow.find("[name=DefaultValue]").text();
			tblclssubmarkerinfotypeobj['DefaultValue'] = vDefaultValue;
			tblclssubmarkerinfotypeobj['index'] = index;
var vDescription = tblclssubmarkerinfotyperow.find("[name=Description]").text();
			tblclssubmarkerinfotypeobj['Description'] = vDescription;
			tblclssubmarkerinfotypeobj['index'] = index;

	tblclssubmarkerinfotypedata.push(tblclssubmarkerinfotypeobj);
});
return tblclssubmarkerinfotypedata;
	}
function getRowsmethodclssubmarkerinfotype(){
	var methodclssubmarkerinfotypedata = [];
	methodclssubmarkerinfotyperows = $("#methodclssubmarkerinfotype tbody tr");
methodclssubmarkerinfotyperows.each(function (index) {
    var methodclssubmarkerinfotyperow = $(this);
 	var methodclssubmarkerinfotypeobj = {};
	var vMethod = methodclssubmarkerinfotyperow.find("[name=Method]").text();
			methodclssubmarkerinfotypeobj['Method'] = vMethod;
			methodclssubmarkerinfotypeobj['index'] = index;
var vParameters = methodclssubmarkerinfotyperow.find("[name=Parameters]").text();
			methodclssubmarkerinfotypeobj['Parameters'] = vParameters;
			methodclssubmarkerinfotypeobj['index'] = index;
var vReturnType = methodclssubmarkerinfotyperow.find("[name=ReturnType]").text();
			methodclssubmarkerinfotypeobj['ReturnType'] = vReturnType;
			methodclssubmarkerinfotypeobj['index'] = index;
var vDescription = methodclssubmarkerinfotyperow.find("[name=Description]").text();
			methodclssubmarkerinfotypeobj['Description'] = vDescription;
			methodclssubmarkerinfotypeobj['index'] = index;

	methodclssubmarkerinfotypedata.push(methodclssubmarkerinfotypeobj);
});
return methodclssubmarkerinfotypedata;
	}
function getRowstblclssubmarkerpostype(){
	var tblclssubmarkerpostypedata = [];
	tblclssubmarkerpostyperows = $("#tblclssubmarkerpostype tbody tr");
tblclssubmarkerpostyperows.each(function (index) {
    var tblclssubmarkerpostyperow = $(this);
 	var tblclssubmarkerpostypeobj = {};
	var vProperty = tblclssubmarkerpostyperow.find("[name=Property]").text();
			tblclssubmarkerpostypeobj['Property'] = vProperty;
			tblclssubmarkerpostypeobj['index'] = index;
var vType = tblclssubmarkerpostyperow.find("[name=Type]").text();
			tblclssubmarkerpostypeobj['Type'] = vType;
			tblclssubmarkerpostypeobj['index'] = index;
var vDefaultValue = tblclssubmarkerpostyperow.find("[name=DefaultValue]").text();
			tblclssubmarkerpostypeobj['DefaultValue'] = vDefaultValue;
			tblclssubmarkerpostypeobj['index'] = index;
var vDescription = tblclssubmarkerpostyperow.find("[name=Description]").text();
			tblclssubmarkerpostypeobj['Description'] = vDescription;
			tblclssubmarkerpostypeobj['index'] = index;

	tblclssubmarkerpostypedata.push(tblclssubmarkerpostypeobj);
});
return tblclssubmarkerpostypedata;
	}
function getRowsmethodclssubmarkerpostype(){
	var methodclssubmarkerpostypedata = [];
	methodclssubmarkerpostyperows = $("#methodclssubmarkerpostype tbody tr");
methodclssubmarkerpostyperows.each(function (index) {
    var methodclssubmarkerpostyperow = $(this);
 	var methodclssubmarkerpostypeobj = {};
	var vMethod = methodclssubmarkerpostyperow.find("[name=Method]").text();
			methodclssubmarkerpostypeobj['Method'] = vMethod;
			methodclssubmarkerpostypeobj['index'] = index;
var vParameters = methodclssubmarkerpostyperow.find("[name=Parameters]").text();
			methodclssubmarkerpostypeobj['Parameters'] = vParameters;
			methodclssubmarkerpostypeobj['index'] = index;
var vReturnType = methodclssubmarkerpostyperow.find("[name=ReturnType]").text();
			methodclssubmarkerpostypeobj['ReturnType'] = vReturnType;
			methodclssubmarkerpostypeobj['index'] = index;
var vDescription = methodclssubmarkerpostyperow.find("[name=Description]").text();
			methodclssubmarkerpostypeobj['Description'] = vDescription;
			methodclssubmarkerpostypeobj['index'] = index;

	methodclssubmarkerpostypedata.push(methodclssubmarkerpostypeobj);
});
return methodclssubmarkerpostypedata;
	}
function getRowstblclssubmarkertype(){
	var tblclssubmarkertypedata = [];
	tblclssubmarkertyperows = $("#tblclssubmarkertype tbody tr");
tblclssubmarkertyperows.each(function (index) {
    var tblclssubmarkertyperow = $(this);
 	var tblclssubmarkertypeobj = {};
	var vProperty = tblclssubmarkertyperow.find("[name=Property]").text();
			tblclssubmarkertypeobj['Property'] = vProperty;
			tblclssubmarkertypeobj['index'] = index;
var vType = tblclssubmarkertyperow.find("[name=Type]").text();
			tblclssubmarkertypeobj['Type'] = vType;
			tblclssubmarkertypeobj['index'] = index;
var vDefaultValue = tblclssubmarkertyperow.find("[name=DefaultValue]").text();
			tblclssubmarkertypeobj['DefaultValue'] = vDefaultValue;
			tblclssubmarkertypeobj['index'] = index;
var vDescription = tblclssubmarkertyperow.find("[name=Description]").text();
			tblclssubmarkertypeobj['Description'] = vDescription;
			tblclssubmarkertypeobj['index'] = index;

	tblclssubmarkertypedata.push(tblclssubmarkertypeobj);
});
return tblclssubmarkertypedata;
	}
function getRowsmethodclssubmarkertype(){
	var methodclssubmarkertypedata = [];
	methodclssubmarkertyperows = $("#methodclssubmarkertype tbody tr");
methodclssubmarkertyperows.each(function (index) {
    var methodclssubmarkertyperow = $(this);
 	var methodclssubmarkertypeobj = {};
	var vMethod = methodclssubmarkertyperow.find("[name=Method]").text();
			methodclssubmarkertypeobj['Method'] = vMethod;
			methodclssubmarkertypeobj['index'] = index;
var vParameters = methodclssubmarkertyperow.find("[name=Parameters]").text();
			methodclssubmarkertypeobj['Parameters'] = vParameters;
			methodclssubmarkertypeobj['index'] = index;
var vReturnType = methodclssubmarkertyperow.find("[name=ReturnType]").text();
			methodclssubmarkertypeobj['ReturnType'] = vReturnType;
			methodclssubmarkertypeobj['index'] = index;
var vDescription = methodclssubmarkertyperow.find("[name=Description]").text();
			methodclssubmarkertypeobj['Description'] = vDescription;
			methodclssubmarkertypeobj['index'] = index;

	methodclssubmarkertypedata.push(methodclssubmarkertypeobj);
});
return methodclssubmarkertypedata;
	}
function getRowstblclstarget(){
	var tblclstargetdata = [];
	tblclstargetrows = $("#tblclstarget tbody tr");
tblclstargetrows.each(function (index) {
    var tblclstargetrow = $(this);
 	var tblclstargetobj = {};
	var vProperty = tblclstargetrow.find("[name=Property]").text();
			tblclstargetobj['Property'] = vProperty;
			tblclstargetobj['index'] = index;
var vType = tblclstargetrow.find("[name=Type]").text();
			tblclstargetobj['Type'] = vType;
			tblclstargetobj['index'] = index;
var vDefaultValue = tblclstargetrow.find("[name=DefaultValue]").text();
			tblclstargetobj['DefaultValue'] = vDefaultValue;
			tblclstargetobj['index'] = index;
var vDescription = tblclstargetrow.find("[name=Description]").text();
			tblclstargetobj['Description'] = vDescription;
			tblclstargetobj['index'] = index;

	tblclstargetdata.push(tblclstargetobj);
});
return tblclstargetdata;
	}
function getRowsmethodclstarget(){
	var methodclstargetdata = [];
	methodclstargetrows = $("#methodclstarget tbody tr");
methodclstargetrows.each(function (index) {
    var methodclstargetrow = $(this);
 	var methodclstargetobj = {};
	var vMethod = methodclstargetrow.find("[name=Method]").text();
			methodclstargetobj['Method'] = vMethod;
			methodclstargetobj['index'] = index;
var vParameters = methodclstargetrow.find("[name=Parameters]").text();
			methodclstargetobj['Parameters'] = vParameters;
			methodclstargetobj['index'] = index;
var vReturnType = methodclstargetrow.find("[name=ReturnType]").text();
			methodclstargetobj['ReturnType'] = vReturnType;
			methodclstargetobj['index'] = index;
var vDescription = methodclstargetrow.find("[name=Description]").text();
			methodclstargetobj['Description'] = vDescription;
			methodclstargetobj['index'] = index;

	methodclstargetdata.push(methodclstargetobj);
});
return methodclstargetdata;
	}
function getRowstblclstextalignment(){
	var tblclstextalignmentdata = [];
	tblclstextalignmentrows = $("#tblclstextalignment tbody tr");
tblclstextalignmentrows.each(function (index) {
    var tblclstextalignmentrow = $(this);
 	var tblclstextalignmentobj = {};
	var vProperty = tblclstextalignmentrow.find("[name=Property]").text();
			tblclstextalignmentobj['Property'] = vProperty;
			tblclstextalignmentobj['index'] = index;
var vType = tblclstextalignmentrow.find("[name=Type]").text();
			tblclstextalignmentobj['Type'] = vType;
			tblclstextalignmentobj['index'] = index;
var vDefaultValue = tblclstextalignmentrow.find("[name=DefaultValue]").text();
			tblclstextalignmentobj['DefaultValue'] = vDefaultValue;
			tblclstextalignmentobj['index'] = index;
var vDescription = tblclstextalignmentrow.find("[name=Description]").text();
			tblclstextalignmentobj['Description'] = vDescription;
			tblclstextalignmentobj['index'] = index;

	tblclstextalignmentdata.push(tblclstextalignmentobj);
});
return tblclstextalignmentdata;
	}
function getRowsmethodclstextalignment(){
	var methodclstextalignmentdata = [];
	methodclstextalignmentrows = $("#methodclstextalignment tbody tr");
methodclstextalignmentrows.each(function (index) {
    var methodclstextalignmentrow = $(this);
 	var methodclstextalignmentobj = {};
	var vMethod = methodclstextalignmentrow.find("[name=Method]").text();
			methodclstextalignmentobj['Method'] = vMethod;
			methodclstextalignmentobj['index'] = index;
var vParameters = methodclstextalignmentrow.find("[name=Parameters]").text();
			methodclstextalignmentobj['Parameters'] = vParameters;
			methodclstextalignmentobj['index'] = index;
var vReturnType = methodclstextalignmentrow.find("[name=ReturnType]").text();
			methodclstextalignmentobj['ReturnType'] = vReturnType;
			methodclstextalignmentobj['index'] = index;
var vDescription = methodclstextalignmentrow.find("[name=Description]").text();
			methodclstextalignmentobj['Description'] = vDescription;
			methodclstextalignmentobj['index'] = index;

	methodclstextalignmentdata.push(methodclstextalignmentobj);
});
return methodclstextalignmentdata;
	}
function getRowstblclsthumbnailspositiontype(){
	var tblclsthumbnailspositiontypedata = [];
	tblclsthumbnailspositiontyperows = $("#tblclsthumbnailspositiontype tbody tr");
tblclsthumbnailspositiontyperows.each(function (index) {
    var tblclsthumbnailspositiontyperow = $(this);
 	var tblclsthumbnailspositiontypeobj = {};
	var vProperty = tblclsthumbnailspositiontyperow.find("[name=Property]").text();
			tblclsthumbnailspositiontypeobj['Property'] = vProperty;
			tblclsthumbnailspositiontypeobj['index'] = index;
var vType = tblclsthumbnailspositiontyperow.find("[name=Type]").text();
			tblclsthumbnailspositiontypeobj['Type'] = vType;
			tblclsthumbnailspositiontypeobj['index'] = index;
var vDefaultValue = tblclsthumbnailspositiontyperow.find("[name=DefaultValue]").text();
			tblclsthumbnailspositiontypeobj['DefaultValue'] = vDefaultValue;
			tblclsthumbnailspositiontypeobj['index'] = index;
var vDescription = tblclsthumbnailspositiontyperow.find("[name=Description]").text();
			tblclsthumbnailspositiontypeobj['Description'] = vDescription;
			tblclsthumbnailspositiontypeobj['index'] = index;

	tblclsthumbnailspositiontypedata.push(tblclsthumbnailspositiontypeobj);
});
return tblclsthumbnailspositiontypedata;
	}
function getRowsmethodclsthumbnailspositiontype(){
	var methodclsthumbnailspositiontypedata = [];
	methodclsthumbnailspositiontyperows = $("#methodclsthumbnailspositiontype tbody tr");
methodclsthumbnailspositiontyperows.each(function (index) {
    var methodclsthumbnailspositiontyperow = $(this);
 	var methodclsthumbnailspositiontypeobj = {};
	var vMethod = methodclsthumbnailspositiontyperow.find("[name=Method]").text();
			methodclsthumbnailspositiontypeobj['Method'] = vMethod;
			methodclsthumbnailspositiontypeobj['index'] = index;
var vParameters = methodclsthumbnailspositiontyperow.find("[name=Parameters]").text();
			methodclsthumbnailspositiontypeobj['Parameters'] = vParameters;
			methodclsthumbnailspositiontypeobj['index'] = index;
var vReturnType = methodclsthumbnailspositiontyperow.find("[name=ReturnType]").text();
			methodclsthumbnailspositiontypeobj['ReturnType'] = vReturnType;
			methodclsthumbnailspositiontypeobj['index'] = index;
var vDescription = methodclsthumbnailspositiontyperow.find("[name=Description]").text();
			methodclsthumbnailspositiontypeobj['Description'] = vDescription;
			methodclsthumbnailspositiontypeobj['index'] = index;

	methodclsthumbnailspositiontypedata.push(methodclsthumbnailspositiontypeobj);
});
return methodclsthumbnailspositiontypedata;
	}
function getRowstblclsthumbtypetype(){
	var tblclsthumbtypetypedata = [];
	tblclsthumbtypetyperows = $("#tblclsthumbtypetype tbody tr");
tblclsthumbtypetyperows.each(function (index) {
    var tblclsthumbtypetyperow = $(this);
 	var tblclsthumbtypetypeobj = {};
	var vProperty = tblclsthumbtypetyperow.find("[name=Property]").text();
			tblclsthumbtypetypeobj['Property'] = vProperty;
			tblclsthumbtypetypeobj['index'] = index;
var vType = tblclsthumbtypetyperow.find("[name=Type]").text();
			tblclsthumbtypetypeobj['Type'] = vType;
			tblclsthumbtypetypeobj['index'] = index;
var vDefaultValue = tblclsthumbtypetyperow.find("[name=DefaultValue]").text();
			tblclsthumbtypetypeobj['DefaultValue'] = vDefaultValue;
			tblclsthumbtypetypeobj['index'] = index;
var vDescription = tblclsthumbtypetyperow.find("[name=Description]").text();
			tblclsthumbtypetypeobj['Description'] = vDescription;
			tblclsthumbtypetypeobj['index'] = index;

	tblclsthumbtypetypedata.push(tblclsthumbtypetypeobj);
});
return tblclsthumbtypetypedata;
	}
function getRowsmethodclsthumbtypetype(){
	var methodclsthumbtypetypedata = [];
	methodclsthumbtypetyperows = $("#methodclsthumbtypetype tbody tr");
methodclsthumbtypetyperows.each(function (index) {
    var methodclsthumbtypetyperow = $(this);
 	var methodclsthumbtypetypeobj = {};
	var vMethod = methodclsthumbtypetyperow.find("[name=Method]").text();
			methodclsthumbtypetypeobj['Method'] = vMethod;
			methodclsthumbtypetypeobj['index'] = index;
var vParameters = methodclsthumbtypetyperow.find("[name=Parameters]").text();
			methodclsthumbtypetypeobj['Parameters'] = vParameters;
			methodclsthumbtypetypeobj['index'] = index;
var vReturnType = methodclsthumbtypetyperow.find("[name=ReturnType]").text();
			methodclsthumbtypetypeobj['ReturnType'] = vReturnType;
			methodclsthumbtypetypeobj['index'] = index;
var vDescription = methodclsthumbtypetyperow.find("[name=Description]").text();
			methodclsthumbtypetypeobj['Description'] = vDescription;
			methodclsthumbtypetypeobj['index'] = index;

	methodclsthumbtypetypedata.push(methodclsthumbtypetypeobj);
});
return methodclsthumbtypetypedata;
	}
function getRowstblclstooltippos(){
	var tblclstooltipposdata = [];
	tblclstooltipposrows = $("#tblclstooltippos tbody tr");
tblclstooltipposrows.each(function (index) {
    var tblclstooltipposrow = $(this);
 	var tblclstooltipposobj = {};
	var vProperty = tblclstooltipposrow.find("[name=Property]").text();
			tblclstooltipposobj['Property'] = vProperty;
			tblclstooltipposobj['index'] = index;
var vType = tblclstooltipposrow.find("[name=Type]").text();
			tblclstooltipposobj['Type'] = vType;
			tblclstooltipposobj['index'] = index;
var vDefaultValue = tblclstooltipposrow.find("[name=DefaultValue]").text();
			tblclstooltipposobj['DefaultValue'] = vDefaultValue;
			tblclstooltipposobj['index'] = index;
var vDescription = tblclstooltipposrow.find("[name=Description]").text();
			tblclstooltipposobj['Description'] = vDescription;
			tblclstooltipposobj['index'] = index;

	tblclstooltipposdata.push(tblclstooltipposobj);
});
return tblclstooltipposdata;
	}
function getRowsmethodclstooltippos(){
	var methodclstooltipposdata = [];
	methodclstooltipposrows = $("#methodclstooltippos tbody tr");
methodclstooltipposrows.each(function (index) {
    var methodclstooltipposrow = $(this);
 	var methodclstooltipposobj = {};
	var vMethod = methodclstooltipposrow.find("[name=Method]").text();
			methodclstooltipposobj['Method'] = vMethod;
			methodclstooltipposobj['index'] = index;
var vParameters = methodclstooltipposrow.find("[name=Parameters]").text();
			methodclstooltipposobj['Parameters'] = vParameters;
			methodclstooltipposobj['index'] = index;
var vReturnType = methodclstooltipposrow.find("[name=ReturnType]").text();
			methodclstooltipposobj['ReturnType'] = vReturnType;
			methodclstooltipposobj['index'] = index;
var vDescription = methodclstooltipposrow.find("[name=Description]").text();
			methodclstooltipposobj['Description'] = vDescription;
			methodclstooltipposobj['index'] = index;

	methodclstooltipposdata.push(methodclstooltipposobj);
});
return methodclstooltipposdata;
	}
function getRowstblclstransition(){
	var tblclstransitiondata = [];
	tblclstransitionrows = $("#tblclstransition tbody tr");
tblclstransitionrows.each(function (index) {
    var tblclstransitionrow = $(this);
 	var tblclstransitionobj = {};
	var vProperty = tblclstransitionrow.find("[name=Property]").text();
			tblclstransitionobj['Property'] = vProperty;
			tblclstransitionobj['index'] = index;
var vType = tblclstransitionrow.find("[name=Type]").text();
			tblclstransitionobj['Type'] = vType;
			tblclstransitionobj['index'] = index;
var vDefaultValue = tblclstransitionrow.find("[name=DefaultValue]").text();
			tblclstransitionobj['DefaultValue'] = vDefaultValue;
			tblclstransitionobj['index'] = index;
var vDescription = tblclstransitionrow.find("[name=Description]").text();
			tblclstransitionobj['Description'] = vDescription;
			tblclstransitionobj['index'] = index;

	tblclstransitiondata.push(tblclstransitionobj);
});
return tblclstransitiondata;
	}
function getRowsmethodclstransition(){
	var methodclstransitiondata = [];
	methodclstransitionrows = $("#methodclstransition tbody tr");
methodclstransitionrows.each(function (index) {
    var methodclstransitionrow = $(this);
 	var methodclstransitionobj = {};
	var vMethod = methodclstransitionrow.find("[name=Method]").text();
			methodclstransitionobj['Method'] = vMethod;
			methodclstransitionobj['index'] = index;
var vParameters = methodclstransitionrow.find("[name=Parameters]").text();
			methodclstransitionobj['Parameters'] = vParameters;
			methodclstransitionobj['index'] = index;
var vReturnType = methodclstransitionrow.find("[name=ReturnType]").text();
			methodclstransitionobj['ReturnType'] = vReturnType;
			methodclstransitionobj['index'] = index;
var vDescription = methodclstransitionrow.find("[name=Description]").text();
			methodclstransitionobj['Description'] = vDescription;
			methodclstransitionobj['index'] = index;

	methodclstransitiondata.push(methodclstransitionobj);
});
return methodclstransitiondata;
	}
function getRowstblclsvideotype(){
	var tblclsvideotypedata = [];
	tblclsvideotyperows = $("#tblclsvideotype tbody tr");
tblclsvideotyperows.each(function (index) {
    var tblclsvideotyperow = $(this);
 	var tblclsvideotypeobj = {};
	var vProperty = tblclsvideotyperow.find("[name=Property]").text();
			tblclsvideotypeobj['Property'] = vProperty;
			tblclsvideotypeobj['index'] = index;
var vType = tblclsvideotyperow.find("[name=Type]").text();
			tblclsvideotypeobj['Type'] = vType;
			tblclsvideotypeobj['index'] = index;
var vDefaultValue = tblclsvideotyperow.find("[name=DefaultValue]").text();
			tblclsvideotypeobj['DefaultValue'] = vDefaultValue;
			tblclsvideotypeobj['index'] = index;
var vDescription = tblclsvideotyperow.find("[name=Description]").text();
			tblclsvideotypeobj['Description'] = vDescription;
			tblclsvideotypeobj['index'] = index;

	tblclsvideotypedata.push(tblclsvideotypeobj);
});
return tblclsvideotypedata;
	}
function getRowsmethodclsvideotype(){
	var methodclsvideotypedata = [];
	methodclsvideotyperows = $("#methodclsvideotype tbody tr");
methodclsvideotyperows.each(function (index) {
    var methodclsvideotyperow = $(this);
 	var methodclsvideotypeobj = {};
	var vMethod = methodclsvideotyperow.find("[name=Method]").text();
			methodclsvideotypeobj['Method'] = vMethod;
			methodclsvideotypeobj['index'] = index;
var vParameters = methodclsvideotyperow.find("[name=Parameters]").text();
			methodclsvideotypeobj['Parameters'] = vParameters;
			methodclsvideotypeobj['index'] = index;
var vReturnType = methodclsvideotyperow.find("[name=ReturnType]").text();
			methodclsvideotypeobj['ReturnType'] = vReturnType;
			methodclsvideotypeobj['index'] = index;
var vDescription = methodclsvideotyperow.find("[name=Description]").text();
			methodclsvideotypeobj['Description'] = vDescription;
			methodclsvideotypeobj['index'] = index;

	methodclsvideotypedata.push(methodclsvideotypeobj);
});
return methodclsvideotypedata;
	}
function getRowstblclsvisibility(){
	var tblclsvisibilitydata = [];
	tblclsvisibilityrows = $("#tblclsvisibility tbody tr");
tblclsvisibilityrows.each(function (index) {
    var tblclsvisibilityrow = $(this);
 	var tblclsvisibilityobj = {};
	var vProperty = tblclsvisibilityrow.find("[name=Property]").text();
			tblclsvisibilityobj['Property'] = vProperty;
			tblclsvisibilityobj['index'] = index;
var vType = tblclsvisibilityrow.find("[name=Type]").text();
			tblclsvisibilityobj['Type'] = vType;
			tblclsvisibilityobj['index'] = index;
var vDefaultValue = tblclsvisibilityrow.find("[name=DefaultValue]").text();
			tblclsvisibilityobj['DefaultValue'] = vDefaultValue;
			tblclsvisibilityobj['index'] = index;
var vDescription = tblclsvisibilityrow.find("[name=Description]").text();
			tblclsvisibilityobj['Description'] = vDescription;
			tblclsvisibilityobj['index'] = index;

	tblclsvisibilitydata.push(tblclsvisibilityobj);
});
return tblclsvisibilitydata;
	}
function getRowsmethodclsvisibility(){
	var methodclsvisibilitydata = [];
	methodclsvisibilityrows = $("#methodclsvisibility tbody tr");
methodclsvisibilityrows.each(function (index) {
    var methodclsvisibilityrow = $(this);
 	var methodclsvisibilityobj = {};
	var vMethod = methodclsvisibilityrow.find("[name=Method]").text();
			methodclsvisibilityobj['Method'] = vMethod;
			methodclsvisibilityobj['index'] = index;
var vParameters = methodclsvisibilityrow.find("[name=Parameters]").text();
			methodclsvisibilityobj['Parameters'] = vParameters;
			methodclsvisibilityobj['index'] = index;
var vReturnType = methodclsvisibilityrow.find("[name=ReturnType]").text();
			methodclsvisibilityobj['ReturnType'] = vReturnType;
			methodclsvisibilityobj['index'] = index;
var vDescription = methodclsvisibilityrow.find("[name=Description]").text();
			methodclsvisibilityobj['Description'] = vDescription;
			methodclsvisibilityobj['index'] = index;

	methodclsvisibilitydata.push(methodclsvisibilityobj);
});
return methodclsvisibilitydata;
	}
function getRowstblclswavestype(){
	var tblclswavestypedata = [];
	tblclswavestyperows = $("#tblclswavestype tbody tr");
tblclswavestyperows.each(function (index) {
    var tblclswavestyperow = $(this);
 	var tblclswavestypeobj = {};
	var vProperty = tblclswavestyperow.find("[name=Property]").text();
			tblclswavestypeobj['Property'] = vProperty;
			tblclswavestypeobj['index'] = index;
var vType = tblclswavestyperow.find("[name=Type]").text();
			tblclswavestypeobj['Type'] = vType;
			tblclswavestypeobj['index'] = index;
var vDefaultValue = tblclswavestyperow.find("[name=DefaultValue]").text();
			tblclswavestypeobj['DefaultValue'] = vDefaultValue;
			tblclswavestypeobj['index'] = index;
var vDescription = tblclswavestyperow.find("[name=Description]").text();
			tblclswavestypeobj['Description'] = vDescription;
			tblclswavestypeobj['index'] = index;

	tblclswavestypedata.push(tblclswavestypeobj);
});
return tblclswavestypedata;
	}
function getRowsmethodclswavestype(){
	var methodclswavestypedata = [];
	methodclswavestyperows = $("#methodclswavestype tbody tr");
methodclswavestyperows.each(function (index) {
    var methodclswavestyperow = $(this);
 	var methodclswavestypeobj = {};
	var vMethod = methodclswavestyperow.find("[name=Method]").text();
			methodclswavestypeobj['Method'] = vMethod;
			methodclswavestypeobj['index'] = index;
var vParameters = methodclswavestyperow.find("[name=Parameters]").text();
			methodclswavestypeobj['Parameters'] = vParameters;
			methodclswavestypeobj['index'] = index;
var vReturnType = methodclswavestyperow.find("[name=ReturnType]").text();
			methodclswavestypeobj['ReturnType'] = vReturnType;
			methodclswavestypeobj['index'] = index;
var vDescription = methodclswavestyperow.find("[name=Description]").text();
			methodclswavestypeobj['Description'] = vDescription;
			methodclswavestypeobj['index'] = index;

	methodclswavestypedata.push(methodclswavestypeobj);
});
return methodclswavestypedata;
	}
function getRowstblclszdepth(){
	var tblclszdepthdata = [];
	tblclszdepthrows = $("#tblclszdepth tbody tr");
tblclszdepthrows.each(function (index) {
    var tblclszdepthrow = $(this);
 	var tblclszdepthobj = {};
	var vProperty = tblclszdepthrow.find("[name=Property]").text();
			tblclszdepthobj['Property'] = vProperty;
			tblclszdepthobj['index'] = index;
var vType = tblclszdepthrow.find("[name=Type]").text();
			tblclszdepthobj['Type'] = vType;
			tblclszdepthobj['index'] = index;
var vDefaultValue = tblclszdepthrow.find("[name=DefaultValue]").text();
			tblclszdepthobj['DefaultValue'] = vDefaultValue;
			tblclszdepthobj['index'] = index;
var vDescription = tblclszdepthrow.find("[name=Description]").text();
			tblclszdepthobj['Description'] = vDescription;
			tblclszdepthobj['index'] = index;

	tblclszdepthdata.push(tblclszdepthobj);
});
return tblclszdepthdata;
	}
function getRowsmethodclszdepth(){
	var methodclszdepthdata = [];
	methodclszdepthrows = $("#methodclszdepth tbody tr");
methodclszdepthrows.each(function (index) {
    var methodclszdepthrow = $(this);
 	var methodclszdepthobj = {};
	var vMethod = methodclszdepthrow.find("[name=Method]").text();
			methodclszdepthobj['Method'] = vMethod;
			methodclszdepthobj['index'] = index;
var vParameters = methodclszdepthrow.find("[name=Parameters]").text();
			methodclszdepthobj['Parameters'] = vParameters;
			methodclszdepthobj['index'] = index;
var vReturnType = methodclszdepthrow.find("[name=ReturnType]").text();
			methodclszdepthobj['ReturnType'] = vReturnType;
			methodclszdepthobj['index'] = index;
var vDescription = methodclszdepthrow.find("[name=Description]").text();
			methodclszdepthobj['Description'] = vDescription;
			methodclszdepthobj['index'] = index;

	methodclszdepthdata.push(methodclszdepthobj);
});
return methodclszdepthdata;
	}
function getRowstblcssanimation(){
	var tblcssanimationdata = [];
	tblcssanimationrows = $("#tblcssanimation tbody tr");
tblcssanimationrows.each(function (index) {
    var tblcssanimationrow = $(this);
 	var tblcssanimationobj = {};
	var vProperty = tblcssanimationrow.find("[name=Property]").text();
			tblcssanimationobj['Property'] = vProperty;
			tblcssanimationobj['index'] = index;
var vType = tblcssanimationrow.find("[name=Type]").text();
			tblcssanimationobj['Type'] = vType;
			tblcssanimationobj['index'] = index;
var vDefaultValue = tblcssanimationrow.find("[name=DefaultValue]").text();
			tblcssanimationobj['DefaultValue'] = vDefaultValue;
			tblcssanimationobj['index'] = index;
var vDescription = tblcssanimationrow.find("[name=Description]").text();
			tblcssanimationobj['Description'] = vDescription;
			tblcssanimationobj['index'] = index;

	tblcssanimationdata.push(tblcssanimationobj);
});
return tblcssanimationdata;
	}
function getRowsmethodcssanimation(){
	var methodcssanimationdata = [];
	methodcssanimationrows = $("#methodcssanimation tbody tr");
methodcssanimationrows.each(function (index) {
    var methodcssanimationrow = $(this);
 	var methodcssanimationobj = {};
	var vMethod = methodcssanimationrow.find("[name=Method]").text();
			methodcssanimationobj['Method'] = vMethod;
			methodcssanimationobj['index'] = index;
var vParameters = methodcssanimationrow.find("[name=Parameters]").text();
			methodcssanimationobj['Parameters'] = vParameters;
			methodcssanimationobj['index'] = index;
var vReturnType = methodcssanimationrow.find("[name=ReturnType]").text();
			methodcssanimationobj['ReturnType'] = vReturnType;
			methodcssanimationobj['index'] = index;
var vDescription = methodcssanimationrow.find("[name=Description]").text();
			methodcssanimationobj['Description'] = vDescription;
			methodcssanimationobj['index'] = index;

	methodcssanimationdata.push(methodcssanimationobj);
});
return methodcssanimationdata;
	}
function getRowstblcssbackground(){
	var tblcssbackgrounddata = [];
	tblcssbackgroundrows = $("#tblcssbackground tbody tr");
tblcssbackgroundrows.each(function (index) {
    var tblcssbackgroundrow = $(this);
 	var tblcssbackgroundobj = {};
	var vProperty = tblcssbackgroundrow.find("[name=Property]").text();
			tblcssbackgroundobj['Property'] = vProperty;
			tblcssbackgroundobj['index'] = index;
var vType = tblcssbackgroundrow.find("[name=Type]").text();
			tblcssbackgroundobj['Type'] = vType;
			tblcssbackgroundobj['index'] = index;
var vDefaultValue = tblcssbackgroundrow.find("[name=DefaultValue]").text();
			tblcssbackgroundobj['DefaultValue'] = vDefaultValue;
			tblcssbackgroundobj['index'] = index;
var vDescription = tblcssbackgroundrow.find("[name=Description]").text();
			tblcssbackgroundobj['Description'] = vDescription;
			tblcssbackgroundobj['index'] = index;

	tblcssbackgrounddata.push(tblcssbackgroundobj);
});
return tblcssbackgrounddata;
	}
function getRowsmethodcssbackground(){
	var methodcssbackgrounddata = [];
	methodcssbackgroundrows = $("#methodcssbackground tbody tr");
methodcssbackgroundrows.each(function (index) {
    var methodcssbackgroundrow = $(this);
 	var methodcssbackgroundobj = {};
	var vMethod = methodcssbackgroundrow.find("[name=Method]").text();
			methodcssbackgroundobj['Method'] = vMethod;
			methodcssbackgroundobj['index'] = index;
var vParameters = methodcssbackgroundrow.find("[name=Parameters]").text();
			methodcssbackgroundobj['Parameters'] = vParameters;
			methodcssbackgroundobj['index'] = index;
var vReturnType = methodcssbackgroundrow.find("[name=ReturnType]").text();
			methodcssbackgroundobj['ReturnType'] = vReturnType;
			methodcssbackgroundobj['index'] = index;
var vDescription = methodcssbackgroundrow.find("[name=Description]").text();
			methodcssbackgroundobj['Description'] = vDescription;
			methodcssbackgroundobj['index'] = index;

	methodcssbackgrounddata.push(methodcssbackgroundobj);
});
return methodcssbackgrounddata;
	}
function getRowstblcssborder(){
	var tblcssborderdata = [];
	tblcssborderrows = $("#tblcssborder tbody tr");
tblcssborderrows.each(function (index) {
    var tblcssborderrow = $(this);
 	var tblcssborderobj = {};
	var vProperty = tblcssborderrow.find("[name=Property]").text();
			tblcssborderobj['Property'] = vProperty;
			tblcssborderobj['index'] = index;
var vType = tblcssborderrow.find("[name=Type]").text();
			tblcssborderobj['Type'] = vType;
			tblcssborderobj['index'] = index;
var vDefaultValue = tblcssborderrow.find("[name=DefaultValue]").text();
			tblcssborderobj['DefaultValue'] = vDefaultValue;
			tblcssborderobj['index'] = index;
var vDescription = tblcssborderrow.find("[name=Description]").text();
			tblcssborderobj['Description'] = vDescription;
			tblcssborderobj['index'] = index;

	tblcssborderdata.push(tblcssborderobj);
});
return tblcssborderdata;
	}
function getRowsmethodcssborder(){
	var methodcssborderdata = [];
	methodcssborderrows = $("#methodcssborder tbody tr");
methodcssborderrows.each(function (index) {
    var methodcssborderrow = $(this);
 	var methodcssborderobj = {};
	var vMethod = methodcssborderrow.find("[name=Method]").text();
			methodcssborderobj['Method'] = vMethod;
			methodcssborderobj['index'] = index;
var vParameters = methodcssborderrow.find("[name=Parameters]").text();
			methodcssborderobj['Parameters'] = vParameters;
			methodcssborderobj['index'] = index;
var vReturnType = methodcssborderrow.find("[name=ReturnType]").text();
			methodcssborderobj['ReturnType'] = vReturnType;
			methodcssborderobj['index'] = index;
var vDescription = methodcssborderrow.find("[name=Description]").text();
			methodcssborderobj['Description'] = vDescription;
			methodcssborderobj['index'] = index;

	methodcssborderdata.push(methodcssborderobj);
});
return methodcssborderdata;
	}
function getRowstblcssborderimage(){
	var tblcssborderimagedata = [];
	tblcssborderimagerows = $("#tblcssborderimage tbody tr");
tblcssborderimagerows.each(function (index) {
    var tblcssborderimagerow = $(this);
 	var tblcssborderimageobj = {};
	var vProperty = tblcssborderimagerow.find("[name=Property]").text();
			tblcssborderimageobj['Property'] = vProperty;
			tblcssborderimageobj['index'] = index;
var vType = tblcssborderimagerow.find("[name=Type]").text();
			tblcssborderimageobj['Type'] = vType;
			tblcssborderimageobj['index'] = index;
var vDefaultValue = tblcssborderimagerow.find("[name=DefaultValue]").text();
			tblcssborderimageobj['DefaultValue'] = vDefaultValue;
			tblcssborderimageobj['index'] = index;
var vDescription = tblcssborderimagerow.find("[name=Description]").text();
			tblcssborderimageobj['Description'] = vDescription;
			tblcssborderimageobj['index'] = index;

	tblcssborderimagedata.push(tblcssborderimageobj);
});
return tblcssborderimagedata;
	}
function getRowsmethodcssborderimage(){
	var methodcssborderimagedata = [];
	methodcssborderimagerows = $("#methodcssborderimage tbody tr");
methodcssborderimagerows.each(function (index) {
    var methodcssborderimagerow = $(this);
 	var methodcssborderimageobj = {};
	var vMethod = methodcssborderimagerow.find("[name=Method]").text();
			methodcssborderimageobj['Method'] = vMethod;
			methodcssborderimageobj['index'] = index;
var vParameters = methodcssborderimagerow.find("[name=Parameters]").text();
			methodcssborderimageobj['Parameters'] = vParameters;
			methodcssborderimageobj['index'] = index;
var vReturnType = methodcssborderimagerow.find("[name=ReturnType]").text();
			methodcssborderimageobj['ReturnType'] = vReturnType;
			methodcssborderimageobj['index'] = index;
var vDescription = methodcssborderimagerow.find("[name=Description]").text();
			methodcssborderimageobj['Description'] = vDescription;
			methodcssborderimageobj['index'] = index;

	methodcssborderimagedata.push(methodcssborderimageobj);
});
return methodcssborderimagedata;
	}
function getRowstblcssfilter(){
	var tblcssfilterdata = [];
	tblcssfilterrows = $("#tblcssfilter tbody tr");
tblcssfilterrows.each(function (index) {
    var tblcssfilterrow = $(this);
 	var tblcssfilterobj = {};
	var vProperty = tblcssfilterrow.find("[name=Property]").text();
			tblcssfilterobj['Property'] = vProperty;
			tblcssfilterobj['index'] = index;
var vType = tblcssfilterrow.find("[name=Type]").text();
			tblcssfilterobj['Type'] = vType;
			tblcssfilterobj['index'] = index;
var vDefaultValue = tblcssfilterrow.find("[name=DefaultValue]").text();
			tblcssfilterobj['DefaultValue'] = vDefaultValue;
			tblcssfilterobj['index'] = index;
var vDescription = tblcssfilterrow.find("[name=Description]").text();
			tblcssfilterobj['Description'] = vDescription;
			tblcssfilterobj['index'] = index;

	tblcssfilterdata.push(tblcssfilterobj);
});
return tblcssfilterdata;
	}
function getRowsmethodcssfilter(){
	var methodcssfilterdata = [];
	methodcssfilterrows = $("#methodcssfilter tbody tr");
methodcssfilterrows.each(function (index) {
    var methodcssfilterrow = $(this);
 	var methodcssfilterobj = {};
	var vMethod = methodcssfilterrow.find("[name=Method]").text();
			methodcssfilterobj['Method'] = vMethod;
			methodcssfilterobj['index'] = index;
var vParameters = methodcssfilterrow.find("[name=Parameters]").text();
			methodcssfilterobj['Parameters'] = vParameters;
			methodcssfilterobj['index'] = index;
var vReturnType = methodcssfilterrow.find("[name=ReturnType]").text();
			methodcssfilterobj['ReturnType'] = vReturnType;
			methodcssfilterobj['index'] = index;
var vDescription = methodcssfilterrow.find("[name=Description]").text();
			methodcssfilterobj['Description'] = vDescription;
			methodcssfilterobj['index'] = index;

	methodcssfilterdata.push(methodcssfilterobj);
});
return methodcssfilterdata;
	}
function getRowstblcssfont(){
	var tblcssfontdata = [];
	tblcssfontrows = $("#tblcssfont tbody tr");
tblcssfontrows.each(function (index) {
    var tblcssfontrow = $(this);
 	var tblcssfontobj = {};
	var vProperty = tblcssfontrow.find("[name=Property]").text();
			tblcssfontobj['Property'] = vProperty;
			tblcssfontobj['index'] = index;
var vType = tblcssfontrow.find("[name=Type]").text();
			tblcssfontobj['Type'] = vType;
			tblcssfontobj['index'] = index;
var vDefaultValue = tblcssfontrow.find("[name=DefaultValue]").text();
			tblcssfontobj['DefaultValue'] = vDefaultValue;
			tblcssfontobj['index'] = index;
var vDescription = tblcssfontrow.find("[name=Description]").text();
			tblcssfontobj['Description'] = vDescription;
			tblcssfontobj['index'] = index;

	tblcssfontdata.push(tblcssfontobj);
});
return tblcssfontdata;
	}
function getRowsmethodcssfont(){
	var methodcssfontdata = [];
	methodcssfontrows = $("#methodcssfont tbody tr");
methodcssfontrows.each(function (index) {
    var methodcssfontrow = $(this);
 	var methodcssfontobj = {};
	var vMethod = methodcssfontrow.find("[name=Method]").text();
			methodcssfontobj['Method'] = vMethod;
			methodcssfontobj['index'] = index;
var vParameters = methodcssfontrow.find("[name=Parameters]").text();
			methodcssfontobj['Parameters'] = vParameters;
			methodcssfontobj['index'] = index;
var vReturnType = methodcssfontrow.find("[name=ReturnType]").text();
			methodcssfontobj['ReturnType'] = vReturnType;
			methodcssfontobj['index'] = index;
var vDescription = methodcssfontrow.find("[name=Description]").text();
			methodcssfontobj['Description'] = vDescription;
			methodcssfontobj['index'] = index;

	methodcssfontdata.push(methodcssfontobj);
});
return methodcssfontdata;
	}
function getRowstblcssimage(){
	var tblcssimagedata = [];
	tblcssimagerows = $("#tblcssimage tbody tr");
tblcssimagerows.each(function (index) {
    var tblcssimagerow = $(this);
 	var tblcssimageobj = {};
	var vProperty = tblcssimagerow.find("[name=Property]").text();
			tblcssimageobj['Property'] = vProperty;
			tblcssimageobj['index'] = index;
var vType = tblcssimagerow.find("[name=Type]").text();
			tblcssimageobj['Type'] = vType;
			tblcssimageobj['index'] = index;
var vDefaultValue = tblcssimagerow.find("[name=DefaultValue]").text();
			tblcssimageobj['DefaultValue'] = vDefaultValue;
			tblcssimageobj['index'] = index;
var vDescription = tblcssimagerow.find("[name=Description]").text();
			tblcssimageobj['Description'] = vDescription;
			tblcssimageobj['index'] = index;

	tblcssimagedata.push(tblcssimageobj);
});
return tblcssimagedata;
	}
function getRowsmethodcssimage(){
	var methodcssimagedata = [];
	methodcssimagerows = $("#methodcssimage tbody tr");
methodcssimagerows.each(function (index) {
    var methodcssimagerow = $(this);
 	var methodcssimageobj = {};
	var vMethod = methodcssimagerow.find("[name=Method]").text();
			methodcssimageobj['Method'] = vMethod;
			methodcssimageobj['index'] = index;
var vParameters = methodcssimagerow.find("[name=Parameters]").text();
			methodcssimageobj['Parameters'] = vParameters;
			methodcssimageobj['index'] = index;
var vReturnType = methodcssimagerow.find("[name=ReturnType]").text();
			methodcssimageobj['ReturnType'] = vReturnType;
			methodcssimageobj['index'] = index;
var vDescription = methodcssimagerow.find("[name=Description]").text();
			methodcssimageobj['Description'] = vDescription;
			methodcssimageobj['index'] = index;

	methodcssimagedata.push(methodcssimageobj);
});
return methodcssimagedata;
	}
function getRowstblcsslist(){
	var tblcsslistdata = [];
	tblcsslistrows = $("#tblcsslist tbody tr");
tblcsslistrows.each(function (index) {
    var tblcsslistrow = $(this);
 	var tblcsslistobj = {};
	var vProperty = tblcsslistrow.find("[name=Property]").text();
			tblcsslistobj['Property'] = vProperty;
			tblcsslistobj['index'] = index;
var vType = tblcsslistrow.find("[name=Type]").text();
			tblcsslistobj['Type'] = vType;
			tblcsslistobj['index'] = index;
var vDefaultValue = tblcsslistrow.find("[name=DefaultValue]").text();
			tblcsslistobj['DefaultValue'] = vDefaultValue;
			tblcsslistobj['index'] = index;
var vDescription = tblcsslistrow.find("[name=Description]").text();
			tblcsslistobj['Description'] = vDescription;
			tblcsslistobj['index'] = index;

	tblcsslistdata.push(tblcsslistobj);
});
return tblcsslistdata;
	}
function getRowsmethodcsslist(){
	var methodcsslistdata = [];
	methodcsslistrows = $("#methodcsslist tbody tr");
methodcsslistrows.each(function (index) {
    var methodcsslistrow = $(this);
 	var methodcsslistobj = {};
	var vMethod = methodcsslistrow.find("[name=Method]").text();
			methodcsslistobj['Method'] = vMethod;
			methodcsslistobj['index'] = index;
var vParameters = methodcsslistrow.find("[name=Parameters]").text();
			methodcsslistobj['Parameters'] = vParameters;
			methodcsslistobj['index'] = index;
var vReturnType = methodcsslistrow.find("[name=ReturnType]").text();
			methodcsslistobj['ReturnType'] = vReturnType;
			methodcsslistobj['index'] = index;
var vDescription = methodcsslistrow.find("[name=Description]").text();
			methodcsslistobj['Description'] = vDescription;
			methodcsslistobj['index'] = index;

	methodcsslistdata.push(methodcsslistobj);
});
return methodcsslistdata;
	}
function getRowstblcssoutline(){
	var tblcssoutlinedata = [];
	tblcssoutlinerows = $("#tblcssoutline tbody tr");
tblcssoutlinerows.each(function (index) {
    var tblcssoutlinerow = $(this);
 	var tblcssoutlineobj = {};
	var vProperty = tblcssoutlinerow.find("[name=Property]").text();
			tblcssoutlineobj['Property'] = vProperty;
			tblcssoutlineobj['index'] = index;
var vType = tblcssoutlinerow.find("[name=Type]").text();
			tblcssoutlineobj['Type'] = vType;
			tblcssoutlineobj['index'] = index;
var vDefaultValue = tblcssoutlinerow.find("[name=DefaultValue]").text();
			tblcssoutlineobj['DefaultValue'] = vDefaultValue;
			tblcssoutlineobj['index'] = index;
var vDescription = tblcssoutlinerow.find("[name=Description]").text();
			tblcssoutlineobj['Description'] = vDescription;
			tblcssoutlineobj['index'] = index;

	tblcssoutlinedata.push(tblcssoutlineobj);
});
return tblcssoutlinedata;
	}
function getRowsmethodcssoutline(){
	var methodcssoutlinedata = [];
	methodcssoutlinerows = $("#methodcssoutline tbody tr");
methodcssoutlinerows.each(function (index) {
    var methodcssoutlinerow = $(this);
 	var methodcssoutlineobj = {};
	var vMethod = methodcssoutlinerow.find("[name=Method]").text();
			methodcssoutlineobj['Method'] = vMethod;
			methodcssoutlineobj['index'] = index;
var vParameters = methodcssoutlinerow.find("[name=Parameters]").text();
			methodcssoutlineobj['Parameters'] = vParameters;
			methodcssoutlineobj['index'] = index;
var vReturnType = methodcssoutlinerow.find("[name=ReturnType]").text();
			methodcssoutlineobj['ReturnType'] = vReturnType;
			methodcssoutlineobj['index'] = index;
var vDescription = methodcssoutlinerow.find("[name=Description]").text();
			methodcssoutlineobj['Description'] = vDescription;
			methodcssoutlineobj['index'] = index;

	methodcssoutlinedata.push(methodcssoutlineobj);
});
return methodcssoutlinedata;
	}
function getRowstblcssoverflow(){
	var tblcssoverflowdata = [];
	tblcssoverflowrows = $("#tblcssoverflow tbody tr");
tblcssoverflowrows.each(function (index) {
    var tblcssoverflowrow = $(this);
 	var tblcssoverflowobj = {};
	var vProperty = tblcssoverflowrow.find("[name=Property]").text();
			tblcssoverflowobj['Property'] = vProperty;
			tblcssoverflowobj['index'] = index;
var vType = tblcssoverflowrow.find("[name=Type]").text();
			tblcssoverflowobj['Type'] = vType;
			tblcssoverflowobj['index'] = index;
var vDefaultValue = tblcssoverflowrow.find("[name=DefaultValue]").text();
			tblcssoverflowobj['DefaultValue'] = vDefaultValue;
			tblcssoverflowobj['index'] = index;
var vDescription = tblcssoverflowrow.find("[name=Description]").text();
			tblcssoverflowobj['Description'] = vDescription;
			tblcssoverflowobj['index'] = index;

	tblcssoverflowdata.push(tblcssoverflowobj);
});
return tblcssoverflowdata;
	}
function getRowsmethodcssoverflow(){
	var methodcssoverflowdata = [];
	methodcssoverflowrows = $("#methodcssoverflow tbody tr");
methodcssoverflowrows.each(function (index) {
    var methodcssoverflowrow = $(this);
 	var methodcssoverflowobj = {};
	var vMethod = methodcssoverflowrow.find("[name=Method]").text();
			methodcssoverflowobj['Method'] = vMethod;
			methodcssoverflowobj['index'] = index;
var vParameters = methodcssoverflowrow.find("[name=Parameters]").text();
			methodcssoverflowobj['Parameters'] = vParameters;
			methodcssoverflowobj['index'] = index;
var vReturnType = methodcssoverflowrow.find("[name=ReturnType]").text();
			methodcssoverflowobj['ReturnType'] = vReturnType;
			methodcssoverflowobj['index'] = index;
var vDescription = methodcssoverflowrow.find("[name=Description]").text();
			methodcssoverflowobj['Description'] = vDescription;
			methodcssoverflowobj['index'] = index;

	methodcssoverflowdata.push(methodcssoverflowobj);
});
return methodcssoverflowdata;
	}
function getRowstblcsspositions(){
	var tblcsspositionsdata = [];
	tblcsspositionsrows = $("#tblcsspositions tbody tr");
tblcsspositionsrows.each(function (index) {
    var tblcsspositionsrow = $(this);
 	var tblcsspositionsobj = {};
	var vProperty = tblcsspositionsrow.find("[name=Property]").text();
			tblcsspositionsobj['Property'] = vProperty;
			tblcsspositionsobj['index'] = index;
var vType = tblcsspositionsrow.find("[name=Type]").text();
			tblcsspositionsobj['Type'] = vType;
			tblcsspositionsobj['index'] = index;
var vDefaultValue = tblcsspositionsrow.find("[name=DefaultValue]").text();
			tblcsspositionsobj['DefaultValue'] = vDefaultValue;
			tblcsspositionsobj['index'] = index;
var vDescription = tblcsspositionsrow.find("[name=Description]").text();
			tblcsspositionsobj['Description'] = vDescription;
			tblcsspositionsobj['index'] = index;

	tblcsspositionsdata.push(tblcsspositionsobj);
});
return tblcsspositionsdata;
	}
function getRowsmethodcsspositions(){
	var methodcsspositionsdata = [];
	methodcsspositionsrows = $("#methodcsspositions tbody tr");
methodcsspositionsrows.each(function (index) {
    var methodcsspositionsrow = $(this);
 	var methodcsspositionsobj = {};
	var vMethod = methodcsspositionsrow.find("[name=Method]").text();
			methodcsspositionsobj['Method'] = vMethod;
			methodcsspositionsobj['index'] = index;
var vParameters = methodcsspositionsrow.find("[name=Parameters]").text();
			methodcsspositionsobj['Parameters'] = vParameters;
			methodcsspositionsobj['index'] = index;
var vReturnType = methodcsspositionsrow.find("[name=ReturnType]").text();
			methodcsspositionsobj['ReturnType'] = vReturnType;
			methodcsspositionsobj['index'] = index;
var vDescription = methodcsspositionsrow.find("[name=Description]").text();
			methodcsspositionsobj['Description'] = vDescription;
			methodcsspositionsobj['index'] = index;

	methodcsspositionsdata.push(methodcsspositionsobj);
});
return methodcsspositionsdata;
	}
function getRowstblcsssize(){
	var tblcsssizedata = [];
	tblcsssizerows = $("#tblcsssize tbody tr");
tblcsssizerows.each(function (index) {
    var tblcsssizerow = $(this);
 	var tblcsssizeobj = {};
	var vProperty = tblcsssizerow.find("[name=Property]").text();
			tblcsssizeobj['Property'] = vProperty;
			tblcsssizeobj['index'] = index;
var vType = tblcsssizerow.find("[name=Type]").text();
			tblcsssizeobj['Type'] = vType;
			tblcsssizeobj['index'] = index;
var vDefaultValue = tblcsssizerow.find("[name=DefaultValue]").text();
			tblcsssizeobj['DefaultValue'] = vDefaultValue;
			tblcsssizeobj['index'] = index;
var vDescription = tblcsssizerow.find("[name=Description]").text();
			tblcsssizeobj['Description'] = vDescription;
			tblcsssizeobj['index'] = index;

	tblcsssizedata.push(tblcsssizeobj);
});
return tblcsssizedata;
	}
function getRowsmethodcsssize(){
	var methodcsssizedata = [];
	methodcsssizerows = $("#methodcsssize tbody tr");
methodcsssizerows.each(function (index) {
    var methodcsssizerow = $(this);
 	var methodcsssizeobj = {};
	var vMethod = methodcsssizerow.find("[name=Method]").text();
			methodcsssizeobj['Method'] = vMethod;
			methodcsssizeobj['index'] = index;
var vParameters = methodcsssizerow.find("[name=Parameters]").text();
			methodcsssizeobj['Parameters'] = vParameters;
			methodcsssizeobj['index'] = index;
var vReturnType = methodcsssizerow.find("[name=ReturnType]").text();
			methodcsssizeobj['ReturnType'] = vReturnType;
			methodcsssizeobj['index'] = index;
var vDescription = methodcsssizerow.find("[name=Description]").text();
			methodcsssizeobj['Description'] = vDescription;
			methodcsssizeobj['index'] = index;

	methodcsssizedata.push(methodcsssizeobj);
});
return methodcsssizedata;
	}
function getRowstblcsstext(){
	var tblcsstextdata = [];
	tblcsstextrows = $("#tblcsstext tbody tr");
tblcsstextrows.each(function (index) {
    var tblcsstextrow = $(this);
 	var tblcsstextobj = {};
	var vProperty = tblcsstextrow.find("[name=Property]").text();
			tblcsstextobj['Property'] = vProperty;
			tblcsstextobj['index'] = index;
var vType = tblcsstextrow.find("[name=Type]").text();
			tblcsstextobj['Type'] = vType;
			tblcsstextobj['index'] = index;
var vDefaultValue = tblcsstextrow.find("[name=DefaultValue]").text();
			tblcsstextobj['DefaultValue'] = vDefaultValue;
			tblcsstextobj['index'] = index;
var vDescription = tblcsstextrow.find("[name=Description]").text();
			tblcsstextobj['Description'] = vDescription;
			tblcsstextobj['index'] = index;

	tblcsstextdata.push(tblcsstextobj);
});
return tblcsstextdata;
	}
function getRowsmethodcsstext(){
	var methodcsstextdata = [];
	methodcsstextrows = $("#methodcsstext tbody tr");
methodcsstextrows.each(function (index) {
    var methodcsstextrow = $(this);
 	var methodcsstextobj = {};
	var vMethod = methodcsstextrow.find("[name=Method]").text();
			methodcsstextobj['Method'] = vMethod;
			methodcsstextobj['index'] = index;
var vParameters = methodcsstextrow.find("[name=Parameters]").text();
			methodcsstextobj['Parameters'] = vParameters;
			methodcsstextobj['index'] = index;
var vReturnType = methodcsstextrow.find("[name=ReturnType]").text();
			methodcsstextobj['ReturnType'] = vReturnType;
			methodcsstextobj['index'] = index;
var vDescription = methodcsstextrow.find("[name=Description]").text();
			methodcsstextobj['Description'] = vDescription;
			methodcsstextobj['index'] = index;

	methodcsstextdata.push(methodcsstextobj);
});
return methodcsstextdata;
	}
function getRowstblcsstransform(){
	var tblcsstransformdata = [];
	tblcsstransformrows = $("#tblcsstransform tbody tr");
tblcsstransformrows.each(function (index) {
    var tblcsstransformrow = $(this);
 	var tblcsstransformobj = {};
	var vProperty = tblcsstransformrow.find("[name=Property]").text();
			tblcsstransformobj['Property'] = vProperty;
			tblcsstransformobj['index'] = index;
var vType = tblcsstransformrow.find("[name=Type]").text();
			tblcsstransformobj['Type'] = vType;
			tblcsstransformobj['index'] = index;
var vDefaultValue = tblcsstransformrow.find("[name=DefaultValue]").text();
			tblcsstransformobj['DefaultValue'] = vDefaultValue;
			tblcsstransformobj['index'] = index;
var vDescription = tblcsstransformrow.find("[name=Description]").text();
			tblcsstransformobj['Description'] = vDescription;
			tblcsstransformobj['index'] = index;

	tblcsstransformdata.push(tblcsstransformobj);
});
return tblcsstransformdata;
	}
function getRowsmethodcsstransform(){
	var methodcsstransformdata = [];
	methodcsstransformrows = $("#methodcsstransform tbody tr");
methodcsstransformrows.each(function (index) {
    var methodcsstransformrow = $(this);
 	var methodcsstransformobj = {};
	var vMethod = methodcsstransformrow.find("[name=Method]").text();
			methodcsstransformobj['Method'] = vMethod;
			methodcsstransformobj['index'] = index;
var vParameters = methodcsstransformrow.find("[name=Parameters]").text();
			methodcsstransformobj['Parameters'] = vParameters;
			methodcsstransformobj['index'] = index;
var vReturnType = methodcsstransformrow.find("[name=ReturnType]").text();
			methodcsstransformobj['ReturnType'] = vReturnType;
			methodcsstransformobj['index'] = index;
var vDescription = methodcsstransformrow.find("[name=Description]").text();
			methodcsstransformobj['Description'] = vDescription;
			methodcsstransformobj['index'] = index;

	methodcsstransformdata.push(methodcsstransformobj);
});
return methodcsstransformdata;
	}
function getRowstblcsstransition(){
	var tblcsstransitiondata = [];
	tblcsstransitionrows = $("#tblcsstransition tbody tr");
tblcsstransitionrows.each(function (index) {
    var tblcsstransitionrow = $(this);
 	var tblcsstransitionobj = {};
	var vProperty = tblcsstransitionrow.find("[name=Property]").text();
			tblcsstransitionobj['Property'] = vProperty;
			tblcsstransitionobj['index'] = index;
var vType = tblcsstransitionrow.find("[name=Type]").text();
			tblcsstransitionobj['Type'] = vType;
			tblcsstransitionobj['index'] = index;
var vDefaultValue = tblcsstransitionrow.find("[name=DefaultValue]").text();
			tblcsstransitionobj['DefaultValue'] = vDefaultValue;
			tblcsstransitionobj['index'] = index;
var vDescription = tblcsstransitionrow.find("[name=Description]").text();
			tblcsstransitionobj['Description'] = vDescription;
			tblcsstransitionobj['index'] = index;

	tblcsstransitiondata.push(tblcsstransitionobj);
});
return tblcsstransitiondata;
	}
function getRowsmethodcsstransition(){
	var methodcsstransitiondata = [];
	methodcsstransitionrows = $("#methodcsstransition tbody tr");
methodcsstransitionrows.each(function (index) {
    var methodcsstransitionrow = $(this);
 	var methodcsstransitionobj = {};
	var vMethod = methodcsstransitionrow.find("[name=Method]").text();
			methodcsstransitionobj['Method'] = vMethod;
			methodcsstransitionobj['index'] = index;
var vParameters = methodcsstransitionrow.find("[name=Parameters]").text();
			methodcsstransitionobj['Parameters'] = vParameters;
			methodcsstransitionobj['index'] = index;
var vReturnType = methodcsstransitionrow.find("[name=ReturnType]").text();
			methodcsstransitionobj['ReturnType'] = vReturnType;
			methodcsstransitionobj['index'] = index;
var vDescription = methodcsstransitionrow.find("[name=Description]").text();
			methodcsstransitionobj['Description'] = vDescription;
			methodcsstransitionobj['index'] = index;

	methodcsstransitiondata.push(methodcsstransitionobj);
});
return methodcsstransitiondata;
	}
function getRowstblgmapcircle(){
	var tblgmapcircledata = [];
	tblgmapcirclerows = $("#tblgmapcircle tbody tr");
tblgmapcirclerows.each(function (index) {
    var tblgmapcirclerow = $(this);
 	var tblgmapcircleobj = {};
	var vProperty = tblgmapcirclerow.find("[name=Property]").text();
			tblgmapcircleobj['Property'] = vProperty;
			tblgmapcircleobj['index'] = index;
var vType = tblgmapcirclerow.find("[name=Type]").text();
			tblgmapcircleobj['Type'] = vType;
			tblgmapcircleobj['index'] = index;
var vDefaultValue = tblgmapcirclerow.find("[name=DefaultValue]").text();
			tblgmapcircleobj['DefaultValue'] = vDefaultValue;
			tblgmapcircleobj['index'] = index;
var vDescription = tblgmapcirclerow.find("[name=Description]").text();
			tblgmapcircleobj['Description'] = vDescription;
			tblgmapcircleobj['index'] = index;

	tblgmapcircledata.push(tblgmapcircleobj);
});
return tblgmapcircledata;
	}
function getRowsmethodgmapcircle(){
	var methodgmapcircledata = [];
	methodgmapcirclerows = $("#methodgmapcircle tbody tr");
methodgmapcirclerows.each(function (index) {
    var methodgmapcirclerow = $(this);
 	var methodgmapcircleobj = {};
	var vMethod = methodgmapcirclerow.find("[name=Method]").text();
			methodgmapcircleobj['Method'] = vMethod;
			methodgmapcircleobj['index'] = index;
var vParameters = methodgmapcirclerow.find("[name=Parameters]").text();
			methodgmapcircleobj['Parameters'] = vParameters;
			methodgmapcircleobj['index'] = index;
var vReturnType = methodgmapcirclerow.find("[name=ReturnType]").text();
			methodgmapcircleobj['ReturnType'] = vReturnType;
			methodgmapcircleobj['index'] = index;
var vDescription = methodgmapcirclerow.find("[name=Description]").text();
			methodgmapcircleobj['Description'] = vDescription;
			methodgmapcircleobj['index'] = index;

	methodgmapcircledata.push(methodgmapcircleobj);
});
return methodgmapcircledata;
	}
function getRowstblgmapmarker(){
	var tblgmapmarkerdata = [];
	tblgmapmarkerrows = $("#tblgmapmarker tbody tr");
tblgmapmarkerrows.each(function (index) {
    var tblgmapmarkerrow = $(this);
 	var tblgmapmarkerobj = {};
	var vProperty = tblgmapmarkerrow.find("[name=Property]").text();
			tblgmapmarkerobj['Property'] = vProperty;
			tblgmapmarkerobj['index'] = index;
var vType = tblgmapmarkerrow.find("[name=Type]").text();
			tblgmapmarkerobj['Type'] = vType;
			tblgmapmarkerobj['index'] = index;
var vDefaultValue = tblgmapmarkerrow.find("[name=DefaultValue]").text();
			tblgmapmarkerobj['DefaultValue'] = vDefaultValue;
			tblgmapmarkerobj['index'] = index;
var vDescription = tblgmapmarkerrow.find("[name=Description]").text();
			tblgmapmarkerobj['Description'] = vDescription;
			tblgmapmarkerobj['index'] = index;

	tblgmapmarkerdata.push(tblgmapmarkerobj);
});
return tblgmapmarkerdata;
	}
function getRowsmethodgmapmarker(){
	var methodgmapmarkerdata = [];
	methodgmapmarkerrows = $("#methodgmapmarker tbody tr");
methodgmapmarkerrows.each(function (index) {
    var methodgmapmarkerrow = $(this);
 	var methodgmapmarkerobj = {};
	var vMethod = methodgmapmarkerrow.find("[name=Method]").text();
			methodgmapmarkerobj['Method'] = vMethod;
			methodgmapmarkerobj['index'] = index;
var vParameters = methodgmapmarkerrow.find("[name=Parameters]").text();
			methodgmapmarkerobj['Parameters'] = vParameters;
			methodgmapmarkerobj['index'] = index;
var vReturnType = methodgmapmarkerrow.find("[name=ReturnType]").text();
			methodgmapmarkerobj['ReturnType'] = vReturnType;
			methodgmapmarkerobj['index'] = index;
var vDescription = methodgmapmarkerrow.find("[name=Description]").text();
			methodgmapmarkerobj['Description'] = vDescription;
			methodgmapmarkerobj['index'] = index;

	methodgmapmarkerdata.push(methodgmapmarkerobj);
});
return methodgmapmarkerdata;
	}
function getRowstblgmappolygon(){
	var tblgmappolygondata = [];
	tblgmappolygonrows = $("#tblgmappolygon tbody tr");
tblgmappolygonrows.each(function (index) {
    var tblgmappolygonrow = $(this);
 	var tblgmappolygonobj = {};
	var vProperty = tblgmappolygonrow.find("[name=Property]").text();
			tblgmappolygonobj['Property'] = vProperty;
			tblgmappolygonobj['index'] = index;
var vType = tblgmappolygonrow.find("[name=Type]").text();
			tblgmappolygonobj['Type'] = vType;
			tblgmappolygonobj['index'] = index;
var vDefaultValue = tblgmappolygonrow.find("[name=DefaultValue]").text();
			tblgmappolygonobj['DefaultValue'] = vDefaultValue;
			tblgmappolygonobj['index'] = index;
var vDescription = tblgmappolygonrow.find("[name=Description]").text();
			tblgmappolygonobj['Description'] = vDescription;
			tblgmappolygonobj['index'] = index;

	tblgmappolygondata.push(tblgmappolygonobj);
});
return tblgmappolygondata;
	}
function getRowsmethodgmappolygon(){
	var methodgmappolygondata = [];
	methodgmappolygonrows = $("#methodgmappolygon tbody tr");
methodgmappolygonrows.each(function (index) {
    var methodgmappolygonrow = $(this);
 	var methodgmappolygonobj = {};
	var vMethod = methodgmappolygonrow.find("[name=Method]").text();
			methodgmappolygonobj['Method'] = vMethod;
			methodgmappolygonobj['index'] = index;
var vParameters = methodgmappolygonrow.find("[name=Parameters]").text();
			methodgmappolygonobj['Parameters'] = vParameters;
			methodgmappolygonobj['index'] = index;
var vReturnType = methodgmappolygonrow.find("[name=ReturnType]").text();
			methodgmappolygonobj['ReturnType'] = vReturnType;
			methodgmappolygonobj['index'] = index;
var vDescription = methodgmappolygonrow.find("[name=Description]").text();
			methodgmappolygonobj['Description'] = vDescription;
			methodgmappolygonobj['index'] = index;

	methodgmappolygondata.push(methodgmappolygonobj);
});
return methodgmappolygondata;
	}
function getRowstblgmappolyline(){
	var tblgmappolylinedata = [];
	tblgmappolylinerows = $("#tblgmappolyline tbody tr");
tblgmappolylinerows.each(function (index) {
    var tblgmappolylinerow = $(this);
 	var tblgmappolylineobj = {};
	var vProperty = tblgmappolylinerow.find("[name=Property]").text();
			tblgmappolylineobj['Property'] = vProperty;
			tblgmappolylineobj['index'] = index;
var vType = tblgmappolylinerow.find("[name=Type]").text();
			tblgmappolylineobj['Type'] = vType;
			tblgmappolylineobj['index'] = index;
var vDefaultValue = tblgmappolylinerow.find("[name=DefaultValue]").text();
			tblgmappolylineobj['DefaultValue'] = vDefaultValue;
			tblgmappolylineobj['index'] = index;
var vDescription = tblgmappolylinerow.find("[name=Description]").text();
			tblgmappolylineobj['Description'] = vDescription;
			tblgmappolylineobj['index'] = index;

	tblgmappolylinedata.push(tblgmappolylineobj);
});
return tblgmappolylinedata;
	}
function getRowsmethodgmappolyline(){
	var methodgmappolylinedata = [];
	methodgmappolylinerows = $("#methodgmappolyline tbody tr");
methodgmappolylinerows.each(function (index) {
    var methodgmappolylinerow = $(this);
 	var methodgmappolylineobj = {};
	var vMethod = methodgmappolylinerow.find("[name=Method]").text();
			methodgmappolylineobj['Method'] = vMethod;
			methodgmappolylineobj['index'] = index;
var vParameters = methodgmappolylinerow.find("[name=Parameters]").text();
			methodgmappolylineobj['Parameters'] = vParameters;
			methodgmappolylineobj['index'] = index;
var vReturnType = methodgmappolylinerow.find("[name=ReturnType]").text();
			methodgmappolylineobj['ReturnType'] = vReturnType;
			methodgmappolylineobj['index'] = index;
var vDescription = methodgmappolylinerow.find("[name=Description]").text();
			methodgmappolylineobj['Description'] = vDescription;
			methodgmappolylineobj['index'] = index;

	methodgmappolylinedata.push(methodgmappolylineobj);
});
return methodgmappolylinedata;
	}
function getRowstblhtmlelement(){
	var tblhtmlelementdata = [];
	tblhtmlelementrows = $("#tblhtmlelement tbody tr");
tblhtmlelementrows.each(function (index) {
    var tblhtmlelementrow = $(this);
 	var tblhtmlelementobj = {};
	var vProperty = tblhtmlelementrow.find("[name=Property]").text();
			tblhtmlelementobj['Property'] = vProperty;
			tblhtmlelementobj['index'] = index;
var vType = tblhtmlelementrow.find("[name=Type]").text();
			tblhtmlelementobj['Type'] = vType;
			tblhtmlelementobj['index'] = index;
var vDefaultValue = tblhtmlelementrow.find("[name=DefaultValue]").text();
			tblhtmlelementobj['DefaultValue'] = vDefaultValue;
			tblhtmlelementobj['index'] = index;
var vDescription = tblhtmlelementrow.find("[name=Description]").text();
			tblhtmlelementobj['Description'] = vDescription;
			tblhtmlelementobj['index'] = index;

	tblhtmlelementdata.push(tblhtmlelementobj);
});
return tblhtmlelementdata;
	}
function getRowsmethodhtmlelement(){
	var methodhtmlelementdata = [];
	methodhtmlelementrows = $("#methodhtmlelement tbody tr");
methodhtmlelementrows.each(function (index) {
    var methodhtmlelementrow = $(this);
 	var methodhtmlelementobj = {};
	var vMethod = methodhtmlelementrow.find("[name=Method]").text();
			methodhtmlelementobj['Method'] = vMethod;
			methodhtmlelementobj['index'] = index;
var vParameters = methodhtmlelementrow.find("[name=Parameters]").text();
			methodhtmlelementobj['Parameters'] = vParameters;
			methodhtmlelementobj['index'] = index;
var vReturnType = methodhtmlelementrow.find("[name=ReturnType]").text();
			methodhtmlelementobj['ReturnType'] = vReturnType;
			methodhtmlelementobj['index'] = index;
var vDescription = methodhtmlelementrow.find("[name=Description]").text();
			methodhtmlelementobj['Description'] = vDescription;
			methodhtmlelementobj['index'] = index;

	methodhtmlelementdata.push(methodhtmlelementobj);
});
return methodhtmlelementdata;
	}
function getRowstblmdicons(){
	var tblmdiconsdata = [];
	tblmdiconsrows = $("#tblmdicons tbody tr");
tblmdiconsrows.each(function (index) {
    var tblmdiconsrow = $(this);
 	var tblmdiconsobj = {};
	var vProperty = tblmdiconsrow.find("[name=Property]").text();
			tblmdiconsobj['Property'] = vProperty;
			tblmdiconsobj['index'] = index;
var vType = tblmdiconsrow.find("[name=Type]").text();
			tblmdiconsobj['Type'] = vType;
			tblmdiconsobj['index'] = index;
var vDefaultValue = tblmdiconsrow.find("[name=DefaultValue]").text();
			tblmdiconsobj['DefaultValue'] = vDefaultValue;
			tblmdiconsobj['index'] = index;
var vDescription = tblmdiconsrow.find("[name=Description]").text();
			tblmdiconsobj['Description'] = vDescription;
			tblmdiconsobj['index'] = index;

	tblmdiconsdata.push(tblmdiconsobj);
});
return tblmdiconsdata;
	}
function getRowsmethodmdicons(){
	var methodmdiconsdata = [];
	methodmdiconsrows = $("#methodmdicons tbody tr");
methodmdiconsrows.each(function (index) {
    var methodmdiconsrow = $(this);
 	var methodmdiconsobj = {};
	var vMethod = methodmdiconsrow.find("[name=Method]").text();
			methodmdiconsobj['Method'] = vMethod;
			methodmdiconsobj['index'] = index;
var vParameters = methodmdiconsrow.find("[name=Parameters]").text();
			methodmdiconsobj['Parameters'] = vParameters;
			methodmdiconsobj['index'] = index;
var vReturnType = methodmdiconsrow.find("[name=ReturnType]").text();
			methodmdiconsobj['ReturnType'] = vReturnType;
			methodmdiconsobj['index'] = index;
var vDescription = methodmdiconsrow.find("[name=Description]").text();
			methodmdiconsobj['Description'] = vDescription;
			methodmdiconsobj['index'] = index;

	methodmdiconsdata.push(methodmdiconsobj);
});
return methodmdiconsdata;
	}
function getRowstbluoealert(){
	var tbluoealertdata = [];
	tbluoealertrows = $("#tbluoealert tbody tr");
tbluoealertrows.each(function (index) {
    var tbluoealertrow = $(this);
 	var tbluoealertobj = {};
	var vProperty = tbluoealertrow.find("[name=Property]").text();
			tbluoealertobj['Property'] = vProperty;
			tbluoealertobj['index'] = index;
var vType = tbluoealertrow.find("[name=Type]").text();
			tbluoealertobj['Type'] = vType;
			tbluoealertobj['index'] = index;
var vDefaultValue = tbluoealertrow.find("[name=DefaultValue]").text();
			tbluoealertobj['DefaultValue'] = vDefaultValue;
			tbluoealertobj['index'] = index;
var vDescription = tbluoealertrow.find("[name=Description]").text();
			tbluoealertobj['Description'] = vDescription;
			tbluoealertobj['index'] = index;

	tbluoealertdata.push(tbluoealertobj);
});
return tbluoealertdata;
	}
function getRowsmethoduoealert(){
	var methoduoealertdata = [];
	methoduoealertrows = $("#methoduoealert tbody tr");
methoduoealertrows.each(function (index) {
    var methoduoealertrow = $(this);
 	var methoduoealertobj = {};
	var vMethod = methoduoealertrow.find("[name=Method]").text();
			methoduoealertobj['Method'] = vMethod;
			methoduoealertobj['index'] = index;
var vParameters = methoduoealertrow.find("[name=Parameters]").text();
			methoduoealertobj['Parameters'] = vParameters;
			methoduoealertobj['index'] = index;
var vReturnType = methoduoealertrow.find("[name=ReturnType]").text();
			methoduoealertobj['ReturnType'] = vReturnType;
			methoduoealertobj['index'] = index;
var vDescription = methoduoealertrow.find("[name=Description]").text();
			methoduoealertobj['Description'] = vDescription;
			methoduoealertobj['index'] = index;

	methoduoealertdata.push(methoduoealertobj);
});
return methoduoealertdata;
	}
function getRowstbluoeanchor(){
	var tbluoeanchordata = [];
	tbluoeanchorrows = $("#tbluoeanchor tbody tr");
tbluoeanchorrows.each(function (index) {
    var tbluoeanchorrow = $(this);
 	var tbluoeanchorobj = {};
	var vProperty = tbluoeanchorrow.find("[name=Property]").text();
			tbluoeanchorobj['Property'] = vProperty;
			tbluoeanchorobj['index'] = index;
var vType = tbluoeanchorrow.find("[name=Type]").text();
			tbluoeanchorobj['Type'] = vType;
			tbluoeanchorobj['index'] = index;
var vDefaultValue = tbluoeanchorrow.find("[name=DefaultValue]").text();
			tbluoeanchorobj['DefaultValue'] = vDefaultValue;
			tbluoeanchorobj['index'] = index;
var vDescription = tbluoeanchorrow.find("[name=Description]").text();
			tbluoeanchorobj['Description'] = vDescription;
			tbluoeanchorobj['index'] = index;

	tbluoeanchordata.push(tbluoeanchorobj);
});
return tbluoeanchordata;
	}
function getRowsmethoduoeanchor(){
	var methoduoeanchordata = [];
	methoduoeanchorrows = $("#methoduoeanchor tbody tr");
methoduoeanchorrows.each(function (index) {
    var methoduoeanchorrow = $(this);
 	var methoduoeanchorobj = {};
	var vMethod = methoduoeanchorrow.find("[name=Method]").text();
			methoduoeanchorobj['Method'] = vMethod;
			methoduoeanchorobj['index'] = index;
var vParameters = methoduoeanchorrow.find("[name=Parameters]").text();
			methoduoeanchorobj['Parameters'] = vParameters;
			methoduoeanchorobj['index'] = index;
var vReturnType = methoduoeanchorrow.find("[name=ReturnType]").text();
			methoduoeanchorobj['ReturnType'] = vReturnType;
			methoduoeanchorobj['index'] = index;
var vDescription = methoduoeanchorrow.find("[name=Description]").text();
			methoduoeanchorobj['Description'] = vDescription;
			methoduoeanchorobj['index'] = index;

	methoduoeanchordata.push(methoduoeanchorobj);
});
return methoduoeanchordata;
	}
function getRowstbluoeanchoricon(){
	var tbluoeanchoricondata = [];
	tbluoeanchoriconrows = $("#tbluoeanchoricon tbody tr");
tbluoeanchoriconrows.each(function (index) {
    var tbluoeanchoriconrow = $(this);
 	var tbluoeanchoriconobj = {};
	var vProperty = tbluoeanchoriconrow.find("[name=Property]").text();
			tbluoeanchoriconobj['Property'] = vProperty;
			tbluoeanchoriconobj['index'] = index;
var vType = tbluoeanchoriconrow.find("[name=Type]").text();
			tbluoeanchoriconobj['Type'] = vType;
			tbluoeanchoriconobj['index'] = index;
var vDefaultValue = tbluoeanchoriconrow.find("[name=DefaultValue]").text();
			tbluoeanchoriconobj['DefaultValue'] = vDefaultValue;
			tbluoeanchoriconobj['index'] = index;
var vDescription = tbluoeanchoriconrow.find("[name=Description]").text();
			tbluoeanchoriconobj['Description'] = vDescription;
			tbluoeanchoriconobj['index'] = index;

	tbluoeanchoricondata.push(tbluoeanchoriconobj);
});
return tbluoeanchoricondata;
	}
function getRowsmethoduoeanchoricon(){
	var methoduoeanchoricondata = [];
	methoduoeanchoriconrows = $("#methoduoeanchoricon tbody tr");
methoduoeanchoriconrows.each(function (index) {
    var methoduoeanchoriconrow = $(this);
 	var methoduoeanchoriconobj = {};
	var vMethod = methoduoeanchoriconrow.find("[name=Method]").text();
			methoduoeanchoriconobj['Method'] = vMethod;
			methoduoeanchoriconobj['index'] = index;
var vParameters = methoduoeanchoriconrow.find("[name=Parameters]").text();
			methoduoeanchoriconobj['Parameters'] = vParameters;
			methoduoeanchoriconobj['index'] = index;
var vReturnType = methoduoeanchoriconrow.find("[name=ReturnType]").text();
			methoduoeanchoriconobj['ReturnType'] = vReturnType;
			methoduoeanchoriconobj['index'] = index;
var vDescription = methoduoeanchoriconrow.find("[name=Description]").text();
			methoduoeanchoriconobj['Description'] = vDescription;
			methoduoeanchoriconobj['index'] = index;

	methoduoeanchoricondata.push(methoduoeanchoriconobj);
});
return methoduoeanchoricondata;
	}
function getRowstbluoeapp(){
	var tbluoeappdata = [];
	tbluoeapprows = $("#tbluoeapp tbody tr");
tbluoeapprows.each(function (index) {
    var tbluoeapprow = $(this);
 	var tbluoeappobj = {};
	var vProperty = tbluoeapprow.find("[name=Property]").text();
			tbluoeappobj['Property'] = vProperty;
			tbluoeappobj['index'] = index;
var vType = tbluoeapprow.find("[name=Type]").text();
			tbluoeappobj['Type'] = vType;
			tbluoeappobj['index'] = index;
var vDefaultValue = tbluoeapprow.find("[name=DefaultValue]").text();
			tbluoeappobj['DefaultValue'] = vDefaultValue;
			tbluoeappobj['index'] = index;
var vDescription = tbluoeapprow.find("[name=Description]").text();
			tbluoeappobj['Description'] = vDescription;
			tbluoeappobj['index'] = index;

	tbluoeappdata.push(tbluoeappobj);
});
return tbluoeappdata;
	}
function getRowsmethoduoeapp(){
	var methoduoeappdata = [];
	methoduoeapprows = $("#methoduoeapp tbody tr");
methoduoeapprows.each(function (index) {
    var methoduoeapprow = $(this);
 	var methoduoeappobj = {};
	var vMethod = methoduoeapprow.find("[name=Method]").text();
			methoduoeappobj['Method'] = vMethod;
			methoduoeappobj['index'] = index;
var vParameters = methoduoeapprow.find("[name=Parameters]").text();
			methoduoeappobj['Parameters'] = vParameters;
			methoduoeappobj['index'] = index;
var vReturnType = methoduoeapprow.find("[name=ReturnType]").text();
			methoduoeappobj['ReturnType'] = vReturnType;
			methoduoeappobj['index'] = index;
var vDescription = methoduoeapprow.find("[name=Description]").text();
			methoduoeappobj['Description'] = vDescription;
			methoduoeappobj['index'] = index;

	methoduoeappdata.push(methoduoeappobj);
});
return methoduoeappdata;
	}
function getRowstbluoeaxios(){
	var tbluoeaxiosdata = [];
	tbluoeaxiosrows = $("#tbluoeaxios tbody tr");
tbluoeaxiosrows.each(function (index) {
    var tbluoeaxiosrow = $(this);
 	var tbluoeaxiosobj = {};
	var vProperty = tbluoeaxiosrow.find("[name=Property]").text();
			tbluoeaxiosobj['Property'] = vProperty;
			tbluoeaxiosobj['index'] = index;
var vType = tbluoeaxiosrow.find("[name=Type]").text();
			tbluoeaxiosobj['Type'] = vType;
			tbluoeaxiosobj['index'] = index;
var vDefaultValue = tbluoeaxiosrow.find("[name=DefaultValue]").text();
			tbluoeaxiosobj['DefaultValue'] = vDefaultValue;
			tbluoeaxiosobj['index'] = index;
var vDescription = tbluoeaxiosrow.find("[name=Description]").text();
			tbluoeaxiosobj['Description'] = vDescription;
			tbluoeaxiosobj['index'] = index;

	tbluoeaxiosdata.push(tbluoeaxiosobj);
});
return tbluoeaxiosdata;
	}
function getRowsmethoduoeaxios(){
	var methoduoeaxiosdata = [];
	methoduoeaxiosrows = $("#methoduoeaxios tbody tr");
methoduoeaxiosrows.each(function (index) {
    var methoduoeaxiosrow = $(this);
 	var methoduoeaxiosobj = {};
	var vMethod = methoduoeaxiosrow.find("[name=Method]").text();
			methoduoeaxiosobj['Method'] = vMethod;
			methoduoeaxiosobj['index'] = index;
var vParameters = methoduoeaxiosrow.find("[name=Parameters]").text();
			methoduoeaxiosobj['Parameters'] = vParameters;
			methoduoeaxiosobj['index'] = index;
var vReturnType = methoduoeaxiosrow.find("[name=ReturnType]").text();
			methoduoeaxiosobj['ReturnType'] = vReturnType;
			methoduoeaxiosobj['index'] = index;
var vDescription = methoduoeaxiosrow.find("[name=Description]").text();
			methoduoeaxiosobj['Description'] = vDescription;
			methoduoeaxiosobj['index'] = index;

	methoduoeaxiosdata.push(methoduoeaxiosobj);
});
return methoduoeaxiosdata;
	}
function getRowstbluoebackgroundvideo(){
	var tbluoebackgroundvideodata = [];
	tbluoebackgroundvideorows = $("#tbluoebackgroundvideo tbody tr");
tbluoebackgroundvideorows.each(function (index) {
    var tbluoebackgroundvideorow = $(this);
 	var tbluoebackgroundvideoobj = {};
	var vProperty = tbluoebackgroundvideorow.find("[name=Property]").text();
			tbluoebackgroundvideoobj['Property'] = vProperty;
			tbluoebackgroundvideoobj['index'] = index;
var vType = tbluoebackgroundvideorow.find("[name=Type]").text();
			tbluoebackgroundvideoobj['Type'] = vType;
			tbluoebackgroundvideoobj['index'] = index;
var vDefaultValue = tbluoebackgroundvideorow.find("[name=DefaultValue]").text();
			tbluoebackgroundvideoobj['DefaultValue'] = vDefaultValue;
			tbluoebackgroundvideoobj['index'] = index;
var vDescription = tbluoebackgroundvideorow.find("[name=Description]").text();
			tbluoebackgroundvideoobj['Description'] = vDescription;
			tbluoebackgroundvideoobj['index'] = index;

	tbluoebackgroundvideodata.push(tbluoebackgroundvideoobj);
});
return tbluoebackgroundvideodata;
	}
function getRowsmethoduoebackgroundvideo(){
	var methoduoebackgroundvideodata = [];
	methoduoebackgroundvideorows = $("#methoduoebackgroundvideo tbody tr");
methoduoebackgroundvideorows.each(function (index) {
    var methoduoebackgroundvideorow = $(this);
 	var methoduoebackgroundvideoobj = {};
	var vMethod = methoduoebackgroundvideorow.find("[name=Method]").text();
			methoduoebackgroundvideoobj['Method'] = vMethod;
			methoduoebackgroundvideoobj['index'] = index;
var vParameters = methoduoebackgroundvideorow.find("[name=Parameters]").text();
			methoduoebackgroundvideoobj['Parameters'] = vParameters;
			methoduoebackgroundvideoobj['index'] = index;
var vReturnType = methoduoebackgroundvideorow.find("[name=ReturnType]").text();
			methoduoebackgroundvideoobj['ReturnType'] = vReturnType;
			methoduoebackgroundvideoobj['index'] = index;
var vDescription = methoduoebackgroundvideorow.find("[name=Description]").text();
			methoduoebackgroundvideoobj['Description'] = vDescription;
			methoduoebackgroundvideoobj['index'] = index;

	methoduoebackgroundvideodata.push(methoduoebackgroundvideoobj);
});
return methoduoebackgroundvideodata;
	}
function getRowstbluoebadge(){
	var tbluoebadgedata = [];
	tbluoebadgerows = $("#tbluoebadge tbody tr");
tbluoebadgerows.each(function (index) {
    var tbluoebadgerow = $(this);
 	var tbluoebadgeobj = {};
	var vProperty = tbluoebadgerow.find("[name=Property]").text();
			tbluoebadgeobj['Property'] = vProperty;
			tbluoebadgeobj['index'] = index;
var vType = tbluoebadgerow.find("[name=Type]").text();
			tbluoebadgeobj['Type'] = vType;
			tbluoebadgeobj['index'] = index;
var vDefaultValue = tbluoebadgerow.find("[name=DefaultValue]").text();
			tbluoebadgeobj['DefaultValue'] = vDefaultValue;
			tbluoebadgeobj['index'] = index;
var vDescription = tbluoebadgerow.find("[name=Description]").text();
			tbluoebadgeobj['Description'] = vDescription;
			tbluoebadgeobj['index'] = index;

	tbluoebadgedata.push(tbluoebadgeobj);
});
return tbluoebadgedata;
	}
function getRowsmethoduoebadge(){
	var methoduoebadgedata = [];
	methoduoebadgerows = $("#methoduoebadge tbody tr");
methoduoebadgerows.each(function (index) {
    var methoduoebadgerow = $(this);
 	var methoduoebadgeobj = {};
	var vMethod = methoduoebadgerow.find("[name=Method]").text();
			methoduoebadgeobj['Method'] = vMethod;
			methoduoebadgeobj['index'] = index;
var vParameters = methoduoebadgerow.find("[name=Parameters]").text();
			methoduoebadgeobj['Parameters'] = vParameters;
			methoduoebadgeobj['index'] = index;
var vReturnType = methoduoebadgerow.find("[name=ReturnType]").text();
			methoduoebadgeobj['ReturnType'] = vReturnType;
			methoduoebadgeobj['index'] = index;
var vDescription = methoduoebadgerow.find("[name=Description]").text();
			methoduoebadgeobj['Description'] = vDescription;
			methoduoebadgeobj['index'] = index;

	methoduoebadgedata.push(methoduoebadgeobj);
});
return methoduoebadgedata;
	}
function getRowstbluoebreadcrumbs(){
	var tbluoebreadcrumbsdata = [];
	tbluoebreadcrumbsrows = $("#tbluoebreadcrumbs tbody tr");
tbluoebreadcrumbsrows.each(function (index) {
    var tbluoebreadcrumbsrow = $(this);
 	var tbluoebreadcrumbsobj = {};
	var vProperty = tbluoebreadcrumbsrow.find("[name=Property]").text();
			tbluoebreadcrumbsobj['Property'] = vProperty;
			tbluoebreadcrumbsobj['index'] = index;
var vType = tbluoebreadcrumbsrow.find("[name=Type]").text();
			tbluoebreadcrumbsobj['Type'] = vType;
			tbluoebreadcrumbsobj['index'] = index;
var vDefaultValue = tbluoebreadcrumbsrow.find("[name=DefaultValue]").text();
			tbluoebreadcrumbsobj['DefaultValue'] = vDefaultValue;
			tbluoebreadcrumbsobj['index'] = index;
var vDescription = tbluoebreadcrumbsrow.find("[name=Description]").text();
			tbluoebreadcrumbsobj['Description'] = vDescription;
			tbluoebreadcrumbsobj['index'] = index;

	tbluoebreadcrumbsdata.push(tbluoebreadcrumbsobj);
});
return tbluoebreadcrumbsdata;
	}
function getRowsmethoduoebreadcrumbs(){
	var methoduoebreadcrumbsdata = [];
	methoduoebreadcrumbsrows = $("#methoduoebreadcrumbs tbody tr");
methoduoebreadcrumbsrows.each(function (index) {
    var methoduoebreadcrumbsrow = $(this);
 	var methoduoebreadcrumbsobj = {};
	var vMethod = methoduoebreadcrumbsrow.find("[name=Method]").text();
			methoduoebreadcrumbsobj['Method'] = vMethod;
			methoduoebreadcrumbsobj['index'] = index;
var vParameters = methoduoebreadcrumbsrow.find("[name=Parameters]").text();
			methoduoebreadcrumbsobj['Parameters'] = vParameters;
			methoduoebreadcrumbsobj['index'] = index;
var vReturnType = methoduoebreadcrumbsrow.find("[name=ReturnType]").text();
			methoduoebreadcrumbsobj['ReturnType'] = vReturnType;
			methoduoebreadcrumbsobj['index'] = index;
var vDescription = methoduoebreadcrumbsrow.find("[name=Description]").text();
			methoduoebreadcrumbsobj['Description'] = vDescription;
			methoduoebreadcrumbsobj['index'] = index;

	methoduoebreadcrumbsdata.push(methoduoebreadcrumbsobj);
});
return methoduoebreadcrumbsdata;
	}
function getRowstbluoebutton(){
	var tbluoebuttondata = [];
	tbluoebuttonrows = $("#tbluoebutton tbody tr");
tbluoebuttonrows.each(function (index) {
    var tbluoebuttonrow = $(this);
 	var tbluoebuttonobj = {};
	var vProperty = tbluoebuttonrow.find("[name=Property]").text();
			tbluoebuttonobj['Property'] = vProperty;
			tbluoebuttonobj['index'] = index;
var vType = tbluoebuttonrow.find("[name=Type]").text();
			tbluoebuttonobj['Type'] = vType;
			tbluoebuttonobj['index'] = index;
var vDefaultValue = tbluoebuttonrow.find("[name=DefaultValue]").text();
			tbluoebuttonobj['DefaultValue'] = vDefaultValue;
			tbluoebuttonobj['index'] = index;
var vDescription = tbluoebuttonrow.find("[name=Description]").text();
			tbluoebuttonobj['Description'] = vDescription;
			tbluoebuttonobj['index'] = index;

	tbluoebuttondata.push(tbluoebuttonobj);
});
return tbluoebuttondata;
	}
function getRowsmethoduoebutton(){
	var methoduoebuttondata = [];
	methoduoebuttonrows = $("#methoduoebutton tbody tr");
methoduoebuttonrows.each(function (index) {
    var methoduoebuttonrow = $(this);
 	var methoduoebuttonobj = {};
	var vMethod = methoduoebuttonrow.find("[name=Method]").text();
			methoduoebuttonobj['Method'] = vMethod;
			methoduoebuttonobj['index'] = index;
var vParameters = methoduoebuttonrow.find("[name=Parameters]").text();
			methoduoebuttonobj['Parameters'] = vParameters;
			methoduoebuttonobj['index'] = index;
var vReturnType = methoduoebuttonrow.find("[name=ReturnType]").text();
			methoduoebuttonobj['ReturnType'] = vReturnType;
			methoduoebuttonobj['index'] = index;
var vDescription = methoduoebuttonrow.find("[name=Description]").text();
			methoduoebuttonobj['Description'] = vDescription;
			methoduoebuttonobj['index'] = index;

	methoduoebuttondata.push(methoduoebuttonobj);
});
return methoduoebuttondata;
	}
function getRowstbluoecard(){
	var tbluoecarddata = [];
	tbluoecardrows = $("#tbluoecard tbody tr");
tbluoecardrows.each(function (index) {
    var tbluoecardrow = $(this);
 	var tbluoecardobj = {};
	var vProperty = tbluoecardrow.find("[name=Property]").text();
			tbluoecardobj['Property'] = vProperty;
			tbluoecardobj['index'] = index;
var vType = tbluoecardrow.find("[name=Type]").text();
			tbluoecardobj['Type'] = vType;
			tbluoecardobj['index'] = index;
var vDefaultValue = tbluoecardrow.find("[name=DefaultValue]").text();
			tbluoecardobj['DefaultValue'] = vDefaultValue;
			tbluoecardobj['index'] = index;
var vDescription = tbluoecardrow.find("[name=Description]").text();
			tbluoecardobj['Description'] = vDescription;
			tbluoecardobj['index'] = index;

	tbluoecarddata.push(tbluoecardobj);
});
return tbluoecarddata;
	}
function getRowsmethoduoecard(){
	var methoduoecarddata = [];
	methoduoecardrows = $("#methoduoecard tbody tr");
methoduoecardrows.each(function (index) {
    var methoduoecardrow = $(this);
 	var methoduoecardobj = {};
	var vMethod = methoduoecardrow.find("[name=Method]").text();
			methoduoecardobj['Method'] = vMethod;
			methoduoecardobj['index'] = index;
var vParameters = methoduoecardrow.find("[name=Parameters]").text();
			methoduoecardobj['Parameters'] = vParameters;
			methoduoecardobj['index'] = index;
var vReturnType = methoduoecardrow.find("[name=ReturnType]").text();
			methoduoecardobj['ReturnType'] = vReturnType;
			methoduoecardobj['index'] = index;
var vDescription = methoduoecardrow.find("[name=Description]").text();
			methoduoecardobj['Description'] = vDescription;
			methoduoecardobj['index'] = index;

	methoduoecarddata.push(methoduoecardobj);
});
return methoduoecarddata;
	}
function getRowstbluoecarousel(){
	var tbluoecarouseldata = [];
	tbluoecarouselrows = $("#tbluoecarousel tbody tr");
tbluoecarouselrows.each(function (index) {
    var tbluoecarouselrow = $(this);
 	var tbluoecarouselobj = {};
	var vProperty = tbluoecarouselrow.find("[name=Property]").text();
			tbluoecarouselobj['Property'] = vProperty;
			tbluoecarouselobj['index'] = index;
var vType = tbluoecarouselrow.find("[name=Type]").text();
			tbluoecarouselobj['Type'] = vType;
			tbluoecarouselobj['index'] = index;
var vDefaultValue = tbluoecarouselrow.find("[name=DefaultValue]").text();
			tbluoecarouselobj['DefaultValue'] = vDefaultValue;
			tbluoecarouselobj['index'] = index;
var vDescription = tbluoecarouselrow.find("[name=Description]").text();
			tbluoecarouselobj['Description'] = vDescription;
			tbluoecarouselobj['index'] = index;

	tbluoecarouseldata.push(tbluoecarouselobj);
});
return tbluoecarouseldata;
	}
function getRowsmethoduoecarousel(){
	var methoduoecarouseldata = [];
	methoduoecarouselrows = $("#methoduoecarousel tbody tr");
methoduoecarouselrows.each(function (index) {
    var methoduoecarouselrow = $(this);
 	var methoduoecarouselobj = {};
	var vMethod = methoduoecarouselrow.find("[name=Method]").text();
			methoduoecarouselobj['Method'] = vMethod;
			methoduoecarouselobj['index'] = index;
var vParameters = methoduoecarouselrow.find("[name=Parameters]").text();
			methoduoecarouselobj['Parameters'] = vParameters;
			methoduoecarouselobj['index'] = index;
var vReturnType = methoduoecarouselrow.find("[name=ReturnType]").text();
			methoduoecarouselobj['ReturnType'] = vReturnType;
			methoduoecarouselobj['index'] = index;
var vDescription = methoduoecarouselrow.find("[name=Description]").text();
			methoduoecarouselobj['Description'] = vDescription;
			methoduoecarouselobj['index'] = index;

	methoduoecarouseldata.push(methoduoecarouselobj);
});
return methoduoecarouseldata;
	}
function getRowstbluoecharts(){
	var tbluoechartsdata = [];
	tbluoechartsrows = $("#tbluoecharts tbody tr");
tbluoechartsrows.each(function (index) {
    var tbluoechartsrow = $(this);
 	var tbluoechartsobj = {};
	var vProperty = tbluoechartsrow.find("[name=Property]").text();
			tbluoechartsobj['Property'] = vProperty;
			tbluoechartsobj['index'] = index;
var vType = tbluoechartsrow.find("[name=Type]").text();
			tbluoechartsobj['Type'] = vType;
			tbluoechartsobj['index'] = index;
var vDefaultValue = tbluoechartsrow.find("[name=DefaultValue]").text();
			tbluoechartsobj['DefaultValue'] = vDefaultValue;
			tbluoechartsobj['index'] = index;
var vDescription = tbluoechartsrow.find("[name=Description]").text();
			tbluoechartsobj['Description'] = vDescription;
			tbluoechartsobj['index'] = index;

	tbluoechartsdata.push(tbluoechartsobj);
});
return tbluoechartsdata;
	}
function getRowsmethoduoecharts(){
	var methoduoechartsdata = [];
	methoduoechartsrows = $("#methoduoecharts tbody tr");
methoduoechartsrows.each(function (index) {
    var methoduoechartsrow = $(this);
 	var methoduoechartsobj = {};
	var vMethod = methoduoechartsrow.find("[name=Method]").text();
			methoduoechartsobj['Method'] = vMethod;
			methoduoechartsobj['index'] = index;
var vParameters = methoduoechartsrow.find("[name=Parameters]").text();
			methoduoechartsobj['Parameters'] = vParameters;
			methoduoechartsobj['index'] = index;
var vReturnType = methoduoechartsrow.find("[name=ReturnType]").text();
			methoduoechartsobj['ReturnType'] = vReturnType;
			methoduoechartsobj['index'] = index;
var vDescription = methoduoechartsrow.find("[name=Description]").text();
			methoduoechartsobj['Description'] = vDescription;
			methoduoechartsobj['index'] = index;

	methoduoechartsdata.push(methoduoechartsobj);
});
return methoduoechartsdata;
	}
function getRowstbluoecheckbox(){
	var tbluoecheckboxdata = [];
	tbluoecheckboxrows = $("#tbluoecheckbox tbody tr");
tbluoecheckboxrows.each(function (index) {
    var tbluoecheckboxrow = $(this);
 	var tbluoecheckboxobj = {};
	var vProperty = tbluoecheckboxrow.find("[name=Property]").text();
			tbluoecheckboxobj['Property'] = vProperty;
			tbluoecheckboxobj['index'] = index;
var vType = tbluoecheckboxrow.find("[name=Type]").text();
			tbluoecheckboxobj['Type'] = vType;
			tbluoecheckboxobj['index'] = index;
var vDefaultValue = tbluoecheckboxrow.find("[name=DefaultValue]").text();
			tbluoecheckboxobj['DefaultValue'] = vDefaultValue;
			tbluoecheckboxobj['index'] = index;
var vDescription = tbluoecheckboxrow.find("[name=Description]").text();
			tbluoecheckboxobj['Description'] = vDescription;
			tbluoecheckboxobj['index'] = index;

	tbluoecheckboxdata.push(tbluoecheckboxobj);
});
return tbluoecheckboxdata;
	}
function getRowsmethoduoecheckbox(){
	var methoduoecheckboxdata = [];
	methoduoecheckboxrows = $("#methoduoecheckbox tbody tr");
methoduoecheckboxrows.each(function (index) {
    var methoduoecheckboxrow = $(this);
 	var methoduoecheckboxobj = {};
	var vMethod = methoduoecheckboxrow.find("[name=Method]").text();
			methoduoecheckboxobj['Method'] = vMethod;
			methoduoecheckboxobj['index'] = index;
var vParameters = methoduoecheckboxrow.find("[name=Parameters]").text();
			methoduoecheckboxobj['Parameters'] = vParameters;
			methoduoecheckboxobj['index'] = index;
var vReturnType = methoduoecheckboxrow.find("[name=ReturnType]").text();
			methoduoecheckboxobj['ReturnType'] = vReturnType;
			methoduoecheckboxobj['index'] = index;
var vDescription = methoduoecheckboxrow.find("[name=Description]").text();
			methoduoecheckboxobj['Description'] = vDescription;
			methoduoecheckboxobj['index'] = index;

	methoduoecheckboxdata.push(methoduoecheckboxobj);
});
return methoduoecheckboxdata;
	}
function getRowstbluoecheckgroup(){
	var tbluoecheckgroupdata = [];
	tbluoecheckgrouprows = $("#tbluoecheckgroup tbody tr");
tbluoecheckgrouprows.each(function (index) {
    var tbluoecheckgrouprow = $(this);
 	var tbluoecheckgroupobj = {};
	var vProperty = tbluoecheckgrouprow.find("[name=Property]").text();
			tbluoecheckgroupobj['Property'] = vProperty;
			tbluoecheckgroupobj['index'] = index;
var vType = tbluoecheckgrouprow.find("[name=Type]").text();
			tbluoecheckgroupobj['Type'] = vType;
			tbluoecheckgroupobj['index'] = index;
var vDefaultValue = tbluoecheckgrouprow.find("[name=DefaultValue]").text();
			tbluoecheckgroupobj['DefaultValue'] = vDefaultValue;
			tbluoecheckgroupobj['index'] = index;
var vDescription = tbluoecheckgrouprow.find("[name=Description]").text();
			tbluoecheckgroupobj['Description'] = vDescription;
			tbluoecheckgroupobj['index'] = index;

	tbluoecheckgroupdata.push(tbluoecheckgroupobj);
});
return tbluoecheckgroupdata;
	}
function getRowsmethoduoecheckgroup(){
	var methoduoecheckgroupdata = [];
	methoduoecheckgrouprows = $("#methoduoecheckgroup tbody tr");
methoduoecheckgrouprows.each(function (index) {
    var methoduoecheckgrouprow = $(this);
 	var methoduoecheckgroupobj = {};
	var vMethod = methoduoecheckgrouprow.find("[name=Method]").text();
			methoduoecheckgroupobj['Method'] = vMethod;
			methoduoecheckgroupobj['index'] = index;
var vParameters = methoduoecheckgrouprow.find("[name=Parameters]").text();
			methoduoecheckgroupobj['Parameters'] = vParameters;
			methoduoecheckgroupobj['index'] = index;
var vReturnType = methoduoecheckgrouprow.find("[name=ReturnType]").text();
			methoduoecheckgroupobj['ReturnType'] = vReturnType;
			methoduoecheckgroupobj['index'] = index;
var vDescription = methoduoecheckgrouprow.find("[name=Description]").text();
			methoduoecheckgroupobj['Description'] = vDescription;
			methoduoecheckgroupobj['index'] = index;

	methoduoecheckgroupdata.push(methoduoecheckgroupobj);
});
return methoduoecheckgroupdata;
	}
function getRowstbluoechip(){
	var tbluoechipdata = [];
	tbluoechiprows = $("#tbluoechip tbody tr");
tbluoechiprows.each(function (index) {
    var tbluoechiprow = $(this);
 	var tbluoechipobj = {};
	var vProperty = tbluoechiprow.find("[name=Property]").text();
			tbluoechipobj['Property'] = vProperty;
			tbluoechipobj['index'] = index;
var vType = tbluoechiprow.find("[name=Type]").text();
			tbluoechipobj['Type'] = vType;
			tbluoechipobj['index'] = index;
var vDefaultValue = tbluoechiprow.find("[name=DefaultValue]").text();
			tbluoechipobj['DefaultValue'] = vDefaultValue;
			tbluoechipobj['index'] = index;
var vDescription = tbluoechiprow.find("[name=Description]").text();
			tbluoechipobj['Description'] = vDescription;
			tbluoechipobj['index'] = index;

	tbluoechipdata.push(tbluoechipobj);
});
return tbluoechipdata;
	}
function getRowsmethoduoechip(){
	var methoduoechipdata = [];
	methoduoechiprows = $("#methoduoechip tbody tr");
methoduoechiprows.each(function (index) {
    var methoduoechiprow = $(this);
 	var methoduoechipobj = {};
	var vMethod = methoduoechiprow.find("[name=Method]").text();
			methoduoechipobj['Method'] = vMethod;
			methoduoechipobj['index'] = index;
var vParameters = methoduoechiprow.find("[name=Parameters]").text();
			methoduoechipobj['Parameters'] = vParameters;
			methoduoechipobj['index'] = index;
var vReturnType = methoduoechiprow.find("[name=ReturnType]").text();
			methoduoechipobj['ReturnType'] = vReturnType;
			methoduoechipobj['index'] = index;
var vDescription = methoduoechiprow.find("[name=Description]").text();
			methoduoechipobj['Description'] = vDescription;
			methoduoechipobj['index'] = index;

	methoduoechipdata.push(methoduoechipobj);
});
return methoduoechipdata;
	}
function getRowstbluoechips(){
	var tbluoechipsdata = [];
	tbluoechipsrows = $("#tbluoechips tbody tr");
tbluoechipsrows.each(function (index) {
    var tbluoechipsrow = $(this);
 	var tbluoechipsobj = {};
	var vProperty = tbluoechipsrow.find("[name=Property]").text();
			tbluoechipsobj['Property'] = vProperty;
			tbluoechipsobj['index'] = index;
var vType = tbluoechipsrow.find("[name=Type]").text();
			tbluoechipsobj['Type'] = vType;
			tbluoechipsobj['index'] = index;
var vDefaultValue = tbluoechipsrow.find("[name=DefaultValue]").text();
			tbluoechipsobj['DefaultValue'] = vDefaultValue;
			tbluoechipsobj['index'] = index;
var vDescription = tbluoechipsrow.find("[name=Description]").text();
			tbluoechipsobj['Description'] = vDescription;
			tbluoechipsobj['index'] = index;

	tbluoechipsdata.push(tbluoechipsobj);
});
return tbluoechipsdata;
	}
function getRowsmethoduoechips(){
	var methoduoechipsdata = [];
	methoduoechipsrows = $("#methoduoechips tbody tr");
methoduoechipsrows.each(function (index) {
    var methoduoechipsrow = $(this);
 	var methoduoechipsobj = {};
	var vMethod = methoduoechipsrow.find("[name=Method]").text();
			methoduoechipsobj['Method'] = vMethod;
			methoduoechipsobj['index'] = index;
var vParameters = methoduoechipsrow.find("[name=Parameters]").text();
			methoduoechipsobj['Parameters'] = vParameters;
			methoduoechipsobj['index'] = index;
var vReturnType = methoduoechipsrow.find("[name=ReturnType]").text();
			methoduoechipsobj['ReturnType'] = vReturnType;
			methoduoechipsobj['index'] = index;
var vDescription = methoduoechipsrow.find("[name=Description]").text();
			methoduoechipsobj['Description'] = vDescription;
			methoduoechipsobj['index'] = index;

	methoduoechipsdata.push(methoduoechipsobj);
});
return methoduoechipsdata;
	}
function getRowstbluoecollapsible(){
	var tbluoecollapsibledata = [];
	tbluoecollapsiblerows = $("#tbluoecollapsible tbody tr");
tbluoecollapsiblerows.each(function (index) {
    var tbluoecollapsiblerow = $(this);
 	var tbluoecollapsibleobj = {};
	var vProperty = tbluoecollapsiblerow.find("[name=Property]").text();
			tbluoecollapsibleobj['Property'] = vProperty;
			tbluoecollapsibleobj['index'] = index;
var vType = tbluoecollapsiblerow.find("[name=Type]").text();
			tbluoecollapsibleobj['Type'] = vType;
			tbluoecollapsibleobj['index'] = index;
var vDefaultValue = tbluoecollapsiblerow.find("[name=DefaultValue]").text();
			tbluoecollapsibleobj['DefaultValue'] = vDefaultValue;
			tbluoecollapsibleobj['index'] = index;
var vDescription = tbluoecollapsiblerow.find("[name=Description]").text();
			tbluoecollapsibleobj['Description'] = vDescription;
			tbluoecollapsibleobj['index'] = index;

	tbluoecollapsibledata.push(tbluoecollapsibleobj);
});
return tbluoecollapsibledata;
	}
function getRowsmethoduoecollapsible(){
	var methoduoecollapsibledata = [];
	methoduoecollapsiblerows = $("#methoduoecollapsible tbody tr");
methoduoecollapsiblerows.each(function (index) {
    var methoduoecollapsiblerow = $(this);
 	var methoduoecollapsibleobj = {};
	var vMethod = methoduoecollapsiblerow.find("[name=Method]").text();
			methoduoecollapsibleobj['Method'] = vMethod;
			methoduoecollapsibleobj['index'] = index;
var vParameters = methoduoecollapsiblerow.find("[name=Parameters]").text();
			methoduoecollapsibleobj['Parameters'] = vParameters;
			methoduoecollapsibleobj['index'] = index;
var vReturnType = methoduoecollapsiblerow.find("[name=ReturnType]").text();
			methoduoecollapsibleobj['ReturnType'] = vReturnType;
			methoduoecollapsibleobj['index'] = index;
var vDescription = methoduoecollapsiblerow.find("[name=Description]").text();
			methoduoecollapsibleobj['Description'] = vDescription;
			methoduoecollapsibleobj['index'] = index;

	methoduoecollapsibledata.push(methoduoecollapsibleobj);
});
return methoduoecollapsibledata;
	}
function getRowstbluoecollections(){
	var tbluoecollectionsdata = [];
	tbluoecollectionsrows = $("#tbluoecollections tbody tr");
tbluoecollectionsrows.each(function (index) {
    var tbluoecollectionsrow = $(this);
 	var tbluoecollectionsobj = {};
	var vProperty = tbluoecollectionsrow.find("[name=Property]").text();
			tbluoecollectionsobj['Property'] = vProperty;
			tbluoecollectionsobj['index'] = index;
var vType = tbluoecollectionsrow.find("[name=Type]").text();
			tbluoecollectionsobj['Type'] = vType;
			tbluoecollectionsobj['index'] = index;
var vDefaultValue = tbluoecollectionsrow.find("[name=DefaultValue]").text();
			tbluoecollectionsobj['DefaultValue'] = vDefaultValue;
			tbluoecollectionsobj['index'] = index;
var vDescription = tbluoecollectionsrow.find("[name=Description]").text();
			tbluoecollectionsobj['Description'] = vDescription;
			tbluoecollectionsobj['index'] = index;

	tbluoecollectionsdata.push(tbluoecollectionsobj);
});
return tbluoecollectionsdata;
	}
function getRowsmethoduoecollections(){
	var methoduoecollectionsdata = [];
	methoduoecollectionsrows = $("#methoduoecollections tbody tr");
methoduoecollectionsrows.each(function (index) {
    var methoduoecollectionsrow = $(this);
 	var methoduoecollectionsobj = {};
	var vMethod = methoduoecollectionsrow.find("[name=Method]").text();
			methoduoecollectionsobj['Method'] = vMethod;
			methoduoecollectionsobj['index'] = index;
var vParameters = methoduoecollectionsrow.find("[name=Parameters]").text();
			methoduoecollectionsobj['Parameters'] = vParameters;
			methoduoecollectionsobj['index'] = index;
var vReturnType = methoduoecollectionsrow.find("[name=ReturnType]").text();
			methoduoecollectionsobj['ReturnType'] = vReturnType;
			methoduoecollectionsobj['index'] = index;
var vDescription = methoduoecollectionsrow.find("[name=Description]").text();
			methoduoecollectionsobj['Description'] = vDescription;
			methoduoecollectionsobj['index'] = index;

	methoduoecollectionsdata.push(methoduoecollectionsobj);
});
return methoduoecollectionsdata;
	}
function getRowstbluoecolumn(){
	var tbluoecolumndata = [];
	tbluoecolumnrows = $("#tbluoecolumn tbody tr");
tbluoecolumnrows.each(function (index) {
    var tbluoecolumnrow = $(this);
 	var tbluoecolumnobj = {};
	var vProperty = tbluoecolumnrow.find("[name=Property]").text();
			tbluoecolumnobj['Property'] = vProperty;
			tbluoecolumnobj['index'] = index;
var vType = tbluoecolumnrow.find("[name=Type]").text();
			tbluoecolumnobj['Type'] = vType;
			tbluoecolumnobj['index'] = index;
var vDefaultValue = tbluoecolumnrow.find("[name=DefaultValue]").text();
			tbluoecolumnobj['DefaultValue'] = vDefaultValue;
			tbluoecolumnobj['index'] = index;
var vDescription = tbluoecolumnrow.find("[name=Description]").text();
			tbluoecolumnobj['Description'] = vDescription;
			tbluoecolumnobj['index'] = index;

	tbluoecolumndata.push(tbluoecolumnobj);
});
return tbluoecolumndata;
	}
function getRowsmethoduoecolumn(){
	var methoduoecolumndata = [];
	methoduoecolumnrows = $("#methoduoecolumn tbody tr");
methoduoecolumnrows.each(function (index) {
    var methoduoecolumnrow = $(this);
 	var methoduoecolumnobj = {};
	var vMethod = methoduoecolumnrow.find("[name=Method]").text();
			methoduoecolumnobj['Method'] = vMethod;
			methoduoecolumnobj['index'] = index;
var vParameters = methoduoecolumnrow.find("[name=Parameters]").text();
			methoduoecolumnobj['Parameters'] = vParameters;
			methoduoecolumnobj['index'] = index;
var vReturnType = methoduoecolumnrow.find("[name=ReturnType]").text();
			methoduoecolumnobj['ReturnType'] = vReturnType;
			methoduoecolumnobj['index'] = index;
var vDescription = methoduoecolumnrow.find("[name=Description]").text();
			methoduoecolumnobj['Description'] = vDescription;
			methoduoecolumnobj['index'] = index;

	methoduoecolumndata.push(methoduoecolumnobj);
});
return methoduoecolumndata;
	}
function getRowstbluoecontainer(){
	var tbluoecontainerdata = [];
	tbluoecontainerrows = $("#tbluoecontainer tbody tr");
tbluoecontainerrows.each(function (index) {
    var tbluoecontainerrow = $(this);
 	var tbluoecontainerobj = {};
	var vProperty = tbluoecontainerrow.find("[name=Property]").text();
			tbluoecontainerobj['Property'] = vProperty;
			tbluoecontainerobj['index'] = index;
var vType = tbluoecontainerrow.find("[name=Type]").text();
			tbluoecontainerobj['Type'] = vType;
			tbluoecontainerobj['index'] = index;
var vDefaultValue = tbluoecontainerrow.find("[name=DefaultValue]").text();
			tbluoecontainerobj['DefaultValue'] = vDefaultValue;
			tbluoecontainerobj['index'] = index;
var vDescription = tbluoecontainerrow.find("[name=Description]").text();
			tbluoecontainerobj['Description'] = vDescription;
			tbluoecontainerobj['index'] = index;

	tbluoecontainerdata.push(tbluoecontainerobj);
});
return tbluoecontainerdata;
	}
function getRowsmethoduoecontainer(){
	var methoduoecontainerdata = [];
	methoduoecontainerrows = $("#methoduoecontainer tbody tr");
methoduoecontainerrows.each(function (index) {
    var methoduoecontainerrow = $(this);
 	var methoduoecontainerobj = {};
	var vMethod = methoduoecontainerrow.find("[name=Method]").text();
			methoduoecontainerobj['Method'] = vMethod;
			methoduoecontainerobj['index'] = index;
var vParameters = methoduoecontainerrow.find("[name=Parameters]").text();
			methoduoecontainerobj['Parameters'] = vParameters;
			methoduoecontainerobj['index'] = index;
var vReturnType = methoduoecontainerrow.find("[name=ReturnType]").text();
			methoduoecontainerobj['ReturnType'] = vReturnType;
			methoduoecontainerobj['index'] = index;
var vDescription = methoduoecontainerrow.find("[name=Description]").text();
			methoduoecontainerobj['Description'] = vDescription;
			methoduoecontainerobj['index'] = index;

	methoduoecontainerdata.push(methoduoecontainerobj);
});
return methoduoecontainerdata;
	}
function getRowstbluoecopyrights(){
	var tbluoecopyrightsdata = [];
	tbluoecopyrightsrows = $("#tbluoecopyrights tbody tr");
tbluoecopyrightsrows.each(function (index) {
    var tbluoecopyrightsrow = $(this);
 	var tbluoecopyrightsobj = {};
	var vProperty = tbluoecopyrightsrow.find("[name=Property]").text();
			tbluoecopyrightsobj['Property'] = vProperty;
			tbluoecopyrightsobj['index'] = index;
var vType = tbluoecopyrightsrow.find("[name=Type]").text();
			tbluoecopyrightsobj['Type'] = vType;
			tbluoecopyrightsobj['index'] = index;
var vDefaultValue = tbluoecopyrightsrow.find("[name=DefaultValue]").text();
			tbluoecopyrightsobj['DefaultValue'] = vDefaultValue;
			tbluoecopyrightsobj['index'] = index;
var vDescription = tbluoecopyrightsrow.find("[name=Description]").text();
			tbluoecopyrightsobj['Description'] = vDescription;
			tbluoecopyrightsobj['index'] = index;

	tbluoecopyrightsdata.push(tbluoecopyrightsobj);
});
return tbluoecopyrightsdata;
	}
function getRowsmethoduoecopyrights(){
	var methoduoecopyrightsdata = [];
	methoduoecopyrightsrows = $("#methoduoecopyrights tbody tr");
methoduoecopyrightsrows.each(function (index) {
    var methoduoecopyrightsrow = $(this);
 	var methoduoecopyrightsobj = {};
	var vMethod = methoduoecopyrightsrow.find("[name=Method]").text();
			methoduoecopyrightsobj['Method'] = vMethod;
			methoduoecopyrightsobj['index'] = index;
var vParameters = methoduoecopyrightsrow.find("[name=Parameters]").text();
			methoduoecopyrightsobj['Parameters'] = vParameters;
			methoduoecopyrightsobj['index'] = index;
var vReturnType = methoduoecopyrightsrow.find("[name=ReturnType]").text();
			methoduoecopyrightsobj['ReturnType'] = vReturnType;
			methoduoecopyrightsobj['index'] = index;
var vDescription = methoduoecopyrightsrow.find("[name=Description]").text();
			methoduoecopyrightsobj['Description'] = vDescription;
			methoduoecopyrightsobj['index'] = index;

	methoduoecopyrightsdata.push(methoduoecopyrightsobj);
});
return methoduoecopyrightsdata;
	}
function getRowstbluoecss(){
	var tbluoecssdata = [];
	tbluoecssrows = $("#tbluoecss tbody tr");
tbluoecssrows.each(function (index) {
    var tbluoecssrow = $(this);
 	var tbluoecssobj = {};
	var vProperty = tbluoecssrow.find("[name=Property]").text();
			tbluoecssobj['Property'] = vProperty;
			tbluoecssobj['index'] = index;
var vType = tbluoecssrow.find("[name=Type]").text();
			tbluoecssobj['Type'] = vType;
			tbluoecssobj['index'] = index;
var vDefaultValue = tbluoecssrow.find("[name=DefaultValue]").text();
			tbluoecssobj['DefaultValue'] = vDefaultValue;
			tbluoecssobj['index'] = index;
var vDescription = tbluoecssrow.find("[name=Description]").text();
			tbluoecssobj['Description'] = vDescription;
			tbluoecssobj['index'] = index;

	tbluoecssdata.push(tbluoecssobj);
});
return tbluoecssdata;
	}
function getRowsmethoduoecss(){
	var methoduoecssdata = [];
	methoduoecssrows = $("#methoduoecss tbody tr");
methoduoecssrows.each(function (index) {
    var methoduoecssrow = $(this);
 	var methoduoecssobj = {};
	var vMethod = methoduoecssrow.find("[name=Method]").text();
			methoduoecssobj['Method'] = vMethod;
			methoduoecssobj['index'] = index;
var vParameters = methoduoecssrow.find("[name=Parameters]").text();
			methoduoecssobj['Parameters'] = vParameters;
			methoduoecssobj['index'] = index;
var vReturnType = methoduoecssrow.find("[name=ReturnType]").text();
			methoduoecssobj['ReturnType'] = vReturnType;
			methoduoecssobj['index'] = index;
var vDescription = methoduoecssrow.find("[name=Description]").text();
			methoduoecssobj['Description'] = vDescription;
			methoduoecssobj['index'] = index;

	methoduoecssdata.push(methoduoecssobj);
});
return methoduoecssdata;
	}
function getRowstbluoedatepicker(){
	var tbluoedatepickerdata = [];
	tbluoedatepickerrows = $("#tbluoedatepicker tbody tr");
tbluoedatepickerrows.each(function (index) {
    var tbluoedatepickerrow = $(this);
 	var tbluoedatepickerobj = {};
	var vProperty = tbluoedatepickerrow.find("[name=Property]").text();
			tbluoedatepickerobj['Property'] = vProperty;
			tbluoedatepickerobj['index'] = index;
var vType = tbluoedatepickerrow.find("[name=Type]").text();
			tbluoedatepickerobj['Type'] = vType;
			tbluoedatepickerobj['index'] = index;
var vDefaultValue = tbluoedatepickerrow.find("[name=DefaultValue]").text();
			tbluoedatepickerobj['DefaultValue'] = vDefaultValue;
			tbluoedatepickerobj['index'] = index;
var vDescription = tbluoedatepickerrow.find("[name=Description]").text();
			tbluoedatepickerobj['Description'] = vDescription;
			tbluoedatepickerobj['index'] = index;

	tbluoedatepickerdata.push(tbluoedatepickerobj);
});
return tbluoedatepickerdata;
	}
function getRowsmethoduoedatepicker(){
	var methoduoedatepickerdata = [];
	methoduoedatepickerrows = $("#methoduoedatepicker tbody tr");
methoduoedatepickerrows.each(function (index) {
    var methoduoedatepickerrow = $(this);
 	var methoduoedatepickerobj = {};
	var vMethod = methoduoedatepickerrow.find("[name=Method]").text();
			methoduoedatepickerobj['Method'] = vMethod;
			methoduoedatepickerobj['index'] = index;
var vParameters = methoduoedatepickerrow.find("[name=Parameters]").text();
			methoduoedatepickerobj['Parameters'] = vParameters;
			methoduoedatepickerobj['index'] = index;
var vReturnType = methoduoedatepickerrow.find("[name=ReturnType]").text();
			methoduoedatepickerobj['ReturnType'] = vReturnType;
			methoduoedatepickerobj['index'] = index;
var vDescription = methoduoedatepickerrow.find("[name=Description]").text();
			methoduoedatepickerobj['Description'] = vDescription;
			methoduoedatepickerobj['index'] = index;

	methoduoedatepickerdata.push(methoduoedatepickerobj);
});
return methoduoedatepickerdata;
	}
function getRowstbluoedial(){
	var tbluoedialdata = [];
	tbluoedialrows = $("#tbluoedial tbody tr");
tbluoedialrows.each(function (index) {
    var tbluoedialrow = $(this);
 	var tbluoedialobj = {};
	var vProperty = tbluoedialrow.find("[name=Property]").text();
			tbluoedialobj['Property'] = vProperty;
			tbluoedialobj['index'] = index;
var vType = tbluoedialrow.find("[name=Type]").text();
			tbluoedialobj['Type'] = vType;
			tbluoedialobj['index'] = index;
var vDefaultValue = tbluoedialrow.find("[name=DefaultValue]").text();
			tbluoedialobj['DefaultValue'] = vDefaultValue;
			tbluoedialobj['index'] = index;
var vDescription = tbluoedialrow.find("[name=Description]").text();
			tbluoedialobj['Description'] = vDescription;
			tbluoedialobj['index'] = index;

	tbluoedialdata.push(tbluoedialobj);
});
return tbluoedialdata;
	}
function getRowsmethoduoedial(){
	var methoduoedialdata = [];
	methoduoedialrows = $("#methoduoedial tbody tr");
methoduoedialrows.each(function (index) {
    var methoduoedialrow = $(this);
 	var methoduoedialobj = {};
	var vMethod = methoduoedialrow.find("[name=Method]").text();
			methoduoedialobj['Method'] = vMethod;
			methoduoedialobj['index'] = index;
var vParameters = methoduoedialrow.find("[name=Parameters]").text();
			methoduoedialobj['Parameters'] = vParameters;
			methoduoedialobj['index'] = index;
var vReturnType = methoduoedialrow.find("[name=ReturnType]").text();
			methoduoedialobj['ReturnType'] = vReturnType;
			methoduoedialobj['index'] = index;
var vDescription = methoduoedialrow.find("[name=Description]").text();
			methoduoedialobj['Description'] = vDescription;
			methoduoedialobj['index'] = index;

	methoduoedialdata.push(methoduoedialobj);
});
return methoduoedialdata;
	}
function getRowstbluoedivider(){
	var tbluoedividerdata = [];
	tbluoedividerrows = $("#tbluoedivider tbody tr");
tbluoedividerrows.each(function (index) {
    var tbluoedividerrow = $(this);
 	var tbluoedividerobj = {};
	var vProperty = tbluoedividerrow.find("[name=Property]").text();
			tbluoedividerobj['Property'] = vProperty;
			tbluoedividerobj['index'] = index;
var vType = tbluoedividerrow.find("[name=Type]").text();
			tbluoedividerobj['Type'] = vType;
			tbluoedividerobj['index'] = index;
var vDefaultValue = tbluoedividerrow.find("[name=DefaultValue]").text();
			tbluoedividerobj['DefaultValue'] = vDefaultValue;
			tbluoedividerobj['index'] = index;
var vDescription = tbluoedividerrow.find("[name=Description]").text();
			tbluoedividerobj['Description'] = vDescription;
			tbluoedividerobj['index'] = index;

	tbluoedividerdata.push(tbluoedividerobj);
});
return tbluoedividerdata;
	}
function getRowsmethoduoedivider(){
	var methoduoedividerdata = [];
	methoduoedividerrows = $("#methoduoedivider tbody tr");
methoduoedividerrows.each(function (index) {
    var methoduoedividerrow = $(this);
 	var methoduoedividerobj = {};
	var vMethod = methoduoedividerrow.find("[name=Method]").text();
			methoduoedividerobj['Method'] = vMethod;
			methoduoedividerobj['index'] = index;
var vParameters = methoduoedividerrow.find("[name=Parameters]").text();
			methoduoedividerobj['Parameters'] = vParameters;
			methoduoedividerobj['index'] = index;
var vReturnType = methoduoedividerrow.find("[name=ReturnType]").text();
			methoduoedividerobj['ReturnType'] = vReturnType;
			methoduoedividerobj['index'] = index;
var vDescription = methoduoedividerrow.find("[name=Description]").text();
			methoduoedividerobj['Description'] = vDescription;
			methoduoedividerobj['index'] = index;

	methoduoedividerdata.push(methoduoedividerobj);
});
return methoduoedividerdata;
	}
function getRowstbluoedropdown(){
	var tbluoedropdowndata = [];
	tbluoedropdownrows = $("#tbluoedropdown tbody tr");
tbluoedropdownrows.each(function (index) {
    var tbluoedropdownrow = $(this);
 	var tbluoedropdownobj = {};
	var vProperty = tbluoedropdownrow.find("[name=Property]").text();
			tbluoedropdownobj['Property'] = vProperty;
			tbluoedropdownobj['index'] = index;
var vType = tbluoedropdownrow.find("[name=Type]").text();
			tbluoedropdownobj['Type'] = vType;
			tbluoedropdownobj['index'] = index;
var vDefaultValue = tbluoedropdownrow.find("[name=DefaultValue]").text();
			tbluoedropdownobj['DefaultValue'] = vDefaultValue;
			tbluoedropdownobj['index'] = index;
var vDescription = tbluoedropdownrow.find("[name=Description]").text();
			tbluoedropdownobj['Description'] = vDescription;
			tbluoedropdownobj['index'] = index;

	tbluoedropdowndata.push(tbluoedropdownobj);
});
return tbluoedropdowndata;
	}
function getRowsmethoduoedropdown(){
	var methoduoedropdowndata = [];
	methoduoedropdownrows = $("#methoduoedropdown tbody tr");
methoduoedropdownrows.each(function (index) {
    var methoduoedropdownrow = $(this);
 	var methoduoedropdownobj = {};
	var vMethod = methoduoedropdownrow.find("[name=Method]").text();
			methoduoedropdownobj['Method'] = vMethod;
			methoduoedropdownobj['index'] = index;
var vParameters = methoduoedropdownrow.find("[name=Parameters]").text();
			methoduoedropdownobj['Parameters'] = vParameters;
			methoduoedropdownobj['index'] = index;
var vReturnType = methoduoedropdownrow.find("[name=ReturnType]").text();
			methoduoedropdownobj['ReturnType'] = vReturnType;
			methoduoedropdownobj['index'] = index;
var vDescription = methoduoedropdownrow.find("[name=Description]").text();
			methoduoedropdownobj['Description'] = vDescription;
			methoduoedropdownobj['index'] = index;

	methoduoedropdowndata.push(methoduoedropdownobj);
});
return methoduoedropdowndata;
	}
function getRowstbluoedropdownitem(){
	var tbluoedropdownitemdata = [];
	tbluoedropdownitemrows = $("#tbluoedropdownitem tbody tr");
tbluoedropdownitemrows.each(function (index) {
    var tbluoedropdownitemrow = $(this);
 	var tbluoedropdownitemobj = {};
	var vProperty = tbluoedropdownitemrow.find("[name=Property]").text();
			tbluoedropdownitemobj['Property'] = vProperty;
			tbluoedropdownitemobj['index'] = index;
var vType = tbluoedropdownitemrow.find("[name=Type]").text();
			tbluoedropdownitemobj['Type'] = vType;
			tbluoedropdownitemobj['index'] = index;
var vDefaultValue = tbluoedropdownitemrow.find("[name=DefaultValue]").text();
			tbluoedropdownitemobj['DefaultValue'] = vDefaultValue;
			tbluoedropdownitemobj['index'] = index;
var vDescription = tbluoedropdownitemrow.find("[name=Description]").text();
			tbluoedropdownitemobj['Description'] = vDescription;
			tbluoedropdownitemobj['index'] = index;

	tbluoedropdownitemdata.push(tbluoedropdownitemobj);
});
return tbluoedropdownitemdata;
	}
function getRowsmethoduoedropdownitem(){
	var methoduoedropdownitemdata = [];
	methoduoedropdownitemrows = $("#methoduoedropdownitem tbody tr");
methoduoedropdownitemrows.each(function (index) {
    var methoduoedropdownitemrow = $(this);
 	var methoduoedropdownitemobj = {};
	var vMethod = methoduoedropdownitemrow.find("[name=Method]").text();
			methoduoedropdownitemobj['Method'] = vMethod;
			methoduoedropdownitemobj['index'] = index;
var vParameters = methoduoedropdownitemrow.find("[name=Parameters]").text();
			methoduoedropdownitemobj['Parameters'] = vParameters;
			methoduoedropdownitemobj['index'] = index;
var vReturnType = methoduoedropdownitemrow.find("[name=ReturnType]").text();
			methoduoedropdownitemobj['ReturnType'] = vReturnType;
			methoduoedropdownitemobj['index'] = index;
var vDescription = methoduoedropdownitemrow.find("[name=Description]").text();
			methoduoedropdownitemobj['Description'] = vDescription;
			methoduoedropdownitemobj['index'] = index;

	methoduoedropdownitemdata.push(methoduoedropdownitemobj);
});
return methoduoedropdownitemdata;
	}
function getRowstbluoeeasyticker(){
	var tbluoeeasytickerdata = [];
	tbluoeeasytickerrows = $("#tbluoeeasyticker tbody tr");
tbluoeeasytickerrows.each(function (index) {
    var tbluoeeasytickerrow = $(this);
 	var tbluoeeasytickerobj = {};
	var vProperty = tbluoeeasytickerrow.find("[name=Property]").text();
			tbluoeeasytickerobj['Property'] = vProperty;
			tbluoeeasytickerobj['index'] = index;
var vType = tbluoeeasytickerrow.find("[name=Type]").text();
			tbluoeeasytickerobj['Type'] = vType;
			tbluoeeasytickerobj['index'] = index;
var vDefaultValue = tbluoeeasytickerrow.find("[name=DefaultValue]").text();
			tbluoeeasytickerobj['DefaultValue'] = vDefaultValue;
			tbluoeeasytickerobj['index'] = index;
var vDescription = tbluoeeasytickerrow.find("[name=Description]").text();
			tbluoeeasytickerobj['Description'] = vDescription;
			tbluoeeasytickerobj['index'] = index;

	tbluoeeasytickerdata.push(tbluoeeasytickerobj);
});
return tbluoeeasytickerdata;
	}
function getRowsmethoduoeeasyticker(){
	var methoduoeeasytickerdata = [];
	methoduoeeasytickerrows = $("#methoduoeeasyticker tbody tr");
methoduoeeasytickerrows.each(function (index) {
    var methoduoeeasytickerrow = $(this);
 	var methoduoeeasytickerobj = {};
	var vMethod = methoduoeeasytickerrow.find("[name=Method]").text();
			methoduoeeasytickerobj['Method'] = vMethod;
			methoduoeeasytickerobj['index'] = index;
var vParameters = methoduoeeasytickerrow.find("[name=Parameters]").text();
			methoduoeeasytickerobj['Parameters'] = vParameters;
			methoduoeeasytickerobj['index'] = index;
var vReturnType = methoduoeeasytickerrow.find("[name=ReturnType]").text();
			methoduoeeasytickerobj['ReturnType'] = vReturnType;
			methoduoeeasytickerobj['index'] = index;
var vDescription = methoduoeeasytickerrow.find("[name=Description]").text();
			methoduoeeasytickerobj['Description'] = vDescription;
			methoduoeeasytickerobj['index'] = index;

	methoduoeeasytickerdata.push(methoduoeeasytickerobj);
});
return methoduoeeasytickerdata;
	}
function getRowstbluoeeditor(){
	var tbluoeeditordata = [];
	tbluoeeditorrows = $("#tbluoeeditor tbody tr");
tbluoeeditorrows.each(function (index) {
    var tbluoeeditorrow = $(this);
 	var tbluoeeditorobj = {};
	var vProperty = tbluoeeditorrow.find("[name=Property]").text();
			tbluoeeditorobj['Property'] = vProperty;
			tbluoeeditorobj['index'] = index;
var vType = tbluoeeditorrow.find("[name=Type]").text();
			tbluoeeditorobj['Type'] = vType;
			tbluoeeditorobj['index'] = index;
var vDefaultValue = tbluoeeditorrow.find("[name=DefaultValue]").text();
			tbluoeeditorobj['DefaultValue'] = vDefaultValue;
			tbluoeeditorobj['index'] = index;
var vDescription = tbluoeeditorrow.find("[name=Description]").text();
			tbluoeeditorobj['Description'] = vDescription;
			tbluoeeditorobj['index'] = index;

	tbluoeeditordata.push(tbluoeeditorobj);
});
return tbluoeeditordata;
	}
function getRowsmethoduoeeditor(){
	var methoduoeeditordata = [];
	methoduoeeditorrows = $("#methoduoeeditor tbody tr");
methoduoeeditorrows.each(function (index) {
    var methoduoeeditorrow = $(this);
 	var methoduoeeditorobj = {};
	var vMethod = methoduoeeditorrow.find("[name=Method]").text();
			methoduoeeditorobj['Method'] = vMethod;
			methoduoeeditorobj['index'] = index;
var vParameters = methoduoeeditorrow.find("[name=Parameters]").text();
			methoduoeeditorobj['Parameters'] = vParameters;
			methoduoeeditorobj['index'] = index;
var vReturnType = methoduoeeditorrow.find("[name=ReturnType]").text();
			methoduoeeditorobj['ReturnType'] = vReturnType;
			methoduoeeditorobj['index'] = index;
var vDescription = methoduoeeditorrow.find("[name=Description]").text();
			methoduoeeditorobj['Description'] = vDescription;
			methoduoeeditorobj['index'] = index;

	methoduoeeditordata.push(methoduoeeditorobj);
});
return methoduoeeditordata;
	}
function getRowstbluoefab(){
	var tbluoefabdata = [];
	tbluoefabrows = $("#tbluoefab tbody tr");
tbluoefabrows.each(function (index) {
    var tbluoefabrow = $(this);
 	var tbluoefabobj = {};
	var vProperty = tbluoefabrow.find("[name=Property]").text();
			tbluoefabobj['Property'] = vProperty;
			tbluoefabobj['index'] = index;
var vType = tbluoefabrow.find("[name=Type]").text();
			tbluoefabobj['Type'] = vType;
			tbluoefabobj['index'] = index;
var vDefaultValue = tbluoefabrow.find("[name=DefaultValue]").text();
			tbluoefabobj['DefaultValue'] = vDefaultValue;
			tbluoefabobj['index'] = index;
var vDescription = tbluoefabrow.find("[name=Description]").text();
			tbluoefabobj['Description'] = vDescription;
			tbluoefabobj['index'] = index;

	tbluoefabdata.push(tbluoefabobj);
});
return tbluoefabdata;
	}
function getRowsmethoduoefab(){
	var methoduoefabdata = [];
	methoduoefabrows = $("#methoduoefab tbody tr");
methoduoefabrows.each(function (index) {
    var methoduoefabrow = $(this);
 	var methoduoefabobj = {};
	var vMethod = methoduoefabrow.find("[name=Method]").text();
			methoduoefabobj['Method'] = vMethod;
			methoduoefabobj['index'] = index;
var vParameters = methoduoefabrow.find("[name=Parameters]").text();
			methoduoefabobj['Parameters'] = vParameters;
			methoduoefabobj['index'] = index;
var vReturnType = methoduoefabrow.find("[name=ReturnType]").text();
			methoduoefabobj['ReturnType'] = vReturnType;
			methoduoefabobj['index'] = index;
var vDescription = methoduoefabrow.find("[name=Description]").text();
			methoduoefabobj['Description'] = vDescription;
			methoduoefabobj['index'] = index;

	methoduoefabdata.push(methoduoefabobj);
});
return methoduoefabdata;
	}
function getRowstbluoefeature(){
	var tbluoefeaturedata = [];
	tbluoefeaturerows = $("#tbluoefeature tbody tr");
tbluoefeaturerows.each(function (index) {
    var tbluoefeaturerow = $(this);
 	var tbluoefeatureobj = {};
	var vProperty = tbluoefeaturerow.find("[name=Property]").text();
			tbluoefeatureobj['Property'] = vProperty;
			tbluoefeatureobj['index'] = index;
var vType = tbluoefeaturerow.find("[name=Type]").text();
			tbluoefeatureobj['Type'] = vType;
			tbluoefeatureobj['index'] = index;
var vDefaultValue = tbluoefeaturerow.find("[name=DefaultValue]").text();
			tbluoefeatureobj['DefaultValue'] = vDefaultValue;
			tbluoefeatureobj['index'] = index;
var vDescription = tbluoefeaturerow.find("[name=Description]").text();
			tbluoefeatureobj['Description'] = vDescription;
			tbluoefeatureobj['index'] = index;

	tbluoefeaturedata.push(tbluoefeatureobj);
});
return tbluoefeaturedata;
	}
function getRowsmethoduoefeature(){
	var methoduoefeaturedata = [];
	methoduoefeaturerows = $("#methoduoefeature tbody tr");
methoduoefeaturerows.each(function (index) {
    var methoduoefeaturerow = $(this);
 	var methoduoefeatureobj = {};
	var vMethod = methoduoefeaturerow.find("[name=Method]").text();
			methoduoefeatureobj['Method'] = vMethod;
			methoduoefeatureobj['index'] = index;
var vParameters = methoduoefeaturerow.find("[name=Parameters]").text();
			methoduoefeatureobj['Parameters'] = vParameters;
			methoduoefeatureobj['index'] = index;
var vReturnType = methoduoefeaturerow.find("[name=ReturnType]").text();
			methoduoefeatureobj['ReturnType'] = vReturnType;
			methoduoefeatureobj['index'] = index;
var vDescription = methoduoefeaturerow.find("[name=Description]").text();
			methoduoefeatureobj['Description'] = vDescription;
			methoduoefeatureobj['index'] = index;

	methoduoefeaturedata.push(methoduoefeatureobj);
});
return methoduoefeaturedata;
	}
function getRowstbluoefile(){
	var tbluoefiledata = [];
	tbluoefilerows = $("#tbluoefile tbody tr");
tbluoefilerows.each(function (index) {
    var tbluoefilerow = $(this);
 	var tbluoefileobj = {};
	var vProperty = tbluoefilerow.find("[name=Property]").text();
			tbluoefileobj['Property'] = vProperty;
			tbluoefileobj['index'] = index;
var vType = tbluoefilerow.find("[name=Type]").text();
			tbluoefileobj['Type'] = vType;
			tbluoefileobj['index'] = index;
var vDefaultValue = tbluoefilerow.find("[name=DefaultValue]").text();
			tbluoefileobj['DefaultValue'] = vDefaultValue;
			tbluoefileobj['index'] = index;
var vDescription = tbluoefilerow.find("[name=Description]").text();
			tbluoefileobj['Description'] = vDescription;
			tbluoefileobj['index'] = index;

	tbluoefiledata.push(tbluoefileobj);
});
return tbluoefiledata;
	}
function getRowsmethoduoefile(){
	var methoduoefiledata = [];
	methoduoefilerows = $("#methoduoefile tbody tr");
methoduoefilerows.each(function (index) {
    var methoduoefilerow = $(this);
 	var methoduoefileobj = {};
	var vMethod = methoduoefilerow.find("[name=Method]").text();
			methoduoefileobj['Method'] = vMethod;
			methoduoefileobj['index'] = index;
var vParameters = methoduoefilerow.find("[name=Parameters]").text();
			methoduoefileobj['Parameters'] = vParameters;
			methoduoefileobj['index'] = index;
var vReturnType = methoduoefilerow.find("[name=ReturnType]").text();
			methoduoefileobj['ReturnType'] = vReturnType;
			methoduoefileobj['index'] = index;
var vDescription = methoduoefilerow.find("[name=Description]").text();
			methoduoefileobj['Description'] = vDescription;
			methoduoefileobj['index'] = index;

	methoduoefiledata.push(methoduoefileobj);
});
return methoduoefiledata;
	}
function getRowstbluoefirebase(){
	var tbluoefirebasedata = [];
	tbluoefirebaserows = $("#tbluoefirebase tbody tr");
tbluoefirebaserows.each(function (index) {
    var tbluoefirebaserow = $(this);
 	var tbluoefirebaseobj = {};
	var vProperty = tbluoefirebaserow.find("[name=Property]").text();
			tbluoefirebaseobj['Property'] = vProperty;
			tbluoefirebaseobj['index'] = index;
var vType = tbluoefirebaserow.find("[name=Type]").text();
			tbluoefirebaseobj['Type'] = vType;
			tbluoefirebaseobj['index'] = index;
var vDefaultValue = tbluoefirebaserow.find("[name=DefaultValue]").text();
			tbluoefirebaseobj['DefaultValue'] = vDefaultValue;
			tbluoefirebaseobj['index'] = index;
var vDescription = tbluoefirebaserow.find("[name=Description]").text();
			tbluoefirebaseobj['Description'] = vDescription;
			tbluoefirebaseobj['index'] = index;

	tbluoefirebasedata.push(tbluoefirebaseobj);
});
return tbluoefirebasedata;
	}
function getRowsmethoduoefirebase(){
	var methoduoefirebasedata = [];
	methoduoefirebaserows = $("#methoduoefirebase tbody tr");
methoduoefirebaserows.each(function (index) {
    var methoduoefirebaserow = $(this);
 	var methoduoefirebaseobj = {};
	var vMethod = methoduoefirebaserow.find("[name=Method]").text();
			methoduoefirebaseobj['Method'] = vMethod;
			methoduoefirebaseobj['index'] = index;
var vParameters = methoduoefirebaserow.find("[name=Parameters]").text();
			methoduoefirebaseobj['Parameters'] = vParameters;
			methoduoefirebaseobj['index'] = index;
var vReturnType = methoduoefirebaserow.find("[name=ReturnType]").text();
			methoduoefirebaseobj['ReturnType'] = vReturnType;
			methoduoefirebaseobj['index'] = index;
var vDescription = methoduoefirebaserow.find("[name=Description]").text();
			methoduoefirebaseobj['Description'] = vDescription;
			methoduoefirebaseobj['index'] = index;

	methoduoefirebasedata.push(methoduoefirebaseobj);
});
return methoduoefirebasedata;
	}
function getRowstbluoeflowchart(){
	var tbluoeflowchartdata = [];
	tbluoeflowchartrows = $("#tbluoeflowchart tbody tr");
tbluoeflowchartrows.each(function (index) {
    var tbluoeflowchartrow = $(this);
 	var tbluoeflowchartobj = {};
	var vProperty = tbluoeflowchartrow.find("[name=Property]").text();
			tbluoeflowchartobj['Property'] = vProperty;
			tbluoeflowchartobj['index'] = index;
var vType = tbluoeflowchartrow.find("[name=Type]").text();
			tbluoeflowchartobj['Type'] = vType;
			tbluoeflowchartobj['index'] = index;
var vDefaultValue = tbluoeflowchartrow.find("[name=DefaultValue]").text();
			tbluoeflowchartobj['DefaultValue'] = vDefaultValue;
			tbluoeflowchartobj['index'] = index;
var vDescription = tbluoeflowchartrow.find("[name=Description]").text();
			tbluoeflowchartobj['Description'] = vDescription;
			tbluoeflowchartobj['index'] = index;

	tbluoeflowchartdata.push(tbluoeflowchartobj);
});
return tbluoeflowchartdata;
	}
function getRowsmethoduoeflowchart(){
	var methoduoeflowchartdata = [];
	methoduoeflowchartrows = $("#methoduoeflowchart tbody tr");
methoduoeflowchartrows.each(function (index) {
    var methoduoeflowchartrow = $(this);
 	var methoduoeflowchartobj = {};
	var vMethod = methoduoeflowchartrow.find("[name=Method]").text();
			methoduoeflowchartobj['Method'] = vMethod;
			methoduoeflowchartobj['index'] = index;
var vParameters = methoduoeflowchartrow.find("[name=Parameters]").text();
			methoduoeflowchartobj['Parameters'] = vParameters;
			methoduoeflowchartobj['index'] = index;
var vReturnType = methoduoeflowchartrow.find("[name=ReturnType]").text();
			methoduoeflowchartobj['ReturnType'] = vReturnType;
			methoduoeflowchartobj['index'] = index;
var vDescription = methoduoeflowchartrow.find("[name=Description]").text();
			methoduoeflowchartobj['Description'] = vDescription;
			methoduoeflowchartobj['index'] = index;

	methoduoeflowchartdata.push(methoduoeflowchartobj);
});
return methoduoeflowchartdata;
	}
function getRowstbluoegallery(){
	var tbluoegallerydata = [];
	tbluoegalleryrows = $("#tbluoegallery tbody tr");
tbluoegalleryrows.each(function (index) {
    var tbluoegalleryrow = $(this);
 	var tbluoegalleryobj = {};
	var vProperty = tbluoegalleryrow.find("[name=Property]").text();
			tbluoegalleryobj['Property'] = vProperty;
			tbluoegalleryobj['index'] = index;
var vType = tbluoegalleryrow.find("[name=Type]").text();
			tbluoegalleryobj['Type'] = vType;
			tbluoegalleryobj['index'] = index;
var vDefaultValue = tbluoegalleryrow.find("[name=DefaultValue]").text();
			tbluoegalleryobj['DefaultValue'] = vDefaultValue;
			tbluoegalleryobj['index'] = index;
var vDescription = tbluoegalleryrow.find("[name=Description]").text();
			tbluoegalleryobj['Description'] = vDescription;
			tbluoegalleryobj['index'] = index;

	tbluoegallerydata.push(tbluoegalleryobj);
});
return tbluoegallerydata;
	}
function getRowsmethoduoegallery(){
	var methoduoegallerydata = [];
	methoduoegalleryrows = $("#methoduoegallery tbody tr");
methoduoegalleryrows.each(function (index) {
    var methoduoegalleryrow = $(this);
 	var methoduoegalleryobj = {};
	var vMethod = methoduoegalleryrow.find("[name=Method]").text();
			methoduoegalleryobj['Method'] = vMethod;
			methoduoegalleryobj['index'] = index;
var vParameters = methoduoegalleryrow.find("[name=Parameters]").text();
			methoduoegalleryobj['Parameters'] = vParameters;
			methoduoegalleryobj['index'] = index;
var vReturnType = methoduoegalleryrow.find("[name=ReturnType]").text();
			methoduoegalleryobj['ReturnType'] = vReturnType;
			methoduoegalleryobj['index'] = index;
var vDescription = methoduoegalleryrow.find("[name=Description]").text();
			methoduoegalleryobj['Description'] = vDescription;
			methoduoegalleryobj['index'] = index;

	methoduoegallerydata.push(methoduoegalleryobj);
});
return methoduoegallerydata;
	}
function getRowstbluoegmaps(){
	var tbluoegmapsdata = [];
	tbluoegmapsrows = $("#tbluoegmaps tbody tr");
tbluoegmapsrows.each(function (index) {
    var tbluoegmapsrow = $(this);
 	var tbluoegmapsobj = {};
	var vProperty = tbluoegmapsrow.find("[name=Property]").text();
			tbluoegmapsobj['Property'] = vProperty;
			tbluoegmapsobj['index'] = index;
var vType = tbluoegmapsrow.find("[name=Type]").text();
			tbluoegmapsobj['Type'] = vType;
			tbluoegmapsobj['index'] = index;
var vDefaultValue = tbluoegmapsrow.find("[name=DefaultValue]").text();
			tbluoegmapsobj['DefaultValue'] = vDefaultValue;
			tbluoegmapsobj['index'] = index;
var vDescription = tbluoegmapsrow.find("[name=Description]").text();
			tbluoegmapsobj['Description'] = vDescription;
			tbluoegmapsobj['index'] = index;

	tbluoegmapsdata.push(tbluoegmapsobj);
});
return tbluoegmapsdata;
	}
function getRowsmethoduoegmaps(){
	var methoduoegmapsdata = [];
	methoduoegmapsrows = $("#methoduoegmaps tbody tr");
methoduoegmapsrows.each(function (index) {
    var methoduoegmapsrow = $(this);
 	var methoduoegmapsobj = {};
	var vMethod = methoduoegmapsrow.find("[name=Method]").text();
			methoduoegmapsobj['Method'] = vMethod;
			methoduoegmapsobj['index'] = index;
var vParameters = methoduoegmapsrow.find("[name=Parameters]").text();
			methoduoegmapsobj['Parameters'] = vParameters;
			methoduoegmapsobj['index'] = index;
var vReturnType = methoduoegmapsrow.find("[name=ReturnType]").text();
			methoduoegmapsobj['ReturnType'] = vReturnType;
			methoduoegmapsobj['index'] = index;
var vDescription = methoduoegmapsrow.find("[name=Description]").text();
			methoduoegmapsobj['Description'] = vDescription;
			methoduoegmapsobj['index'] = index;

	methoduoegmapsdata.push(methoduoegmapsobj);
});
return methoduoegmapsdata;
	}
function getRowstbluoegrid(){
	var tbluoegriddata = [];
	tbluoegridrows = $("#tbluoegrid tbody tr");
tbluoegridrows.each(function (index) {
    var tbluoegridrow = $(this);
 	var tbluoegridobj = {};
	var vProperty = tbluoegridrow.find("[name=Property]").text();
			tbluoegridobj['Property'] = vProperty;
			tbluoegridobj['index'] = index;
var vType = tbluoegridrow.find("[name=Type]").text();
			tbluoegridobj['Type'] = vType;
			tbluoegridobj['index'] = index;
var vDefaultValue = tbluoegridrow.find("[name=DefaultValue]").text();
			tbluoegridobj['DefaultValue'] = vDefaultValue;
			tbluoegridobj['index'] = index;
var vDescription = tbluoegridrow.find("[name=Description]").text();
			tbluoegridobj['Description'] = vDescription;
			tbluoegridobj['index'] = index;

	tbluoegriddata.push(tbluoegridobj);
});
return tbluoegriddata;
	}
function getRowsmethoduoegrid(){
	var methoduoegriddata = [];
	methoduoegridrows = $("#methoduoegrid tbody tr");
methoduoegridrows.each(function (index) {
    var methoduoegridrow = $(this);
 	var methoduoegridobj = {};
	var vMethod = methoduoegridrow.find("[name=Method]").text();
			methoduoegridobj['Method'] = vMethod;
			methoduoegridobj['index'] = index;
var vParameters = methoduoegridrow.find("[name=Parameters]").text();
			methoduoegridobj['Parameters'] = vParameters;
			methoduoegridobj['index'] = index;
var vReturnType = methoduoegridrow.find("[name=ReturnType]").text();
			methoduoegridobj['ReturnType'] = vReturnType;
			methoduoegridobj['index'] = index;
var vDescription = methoduoegridrow.find("[name=Description]").text();
			methoduoegridobj['Description'] = vDescription;
			methoduoegridobj['index'] = index;

	methoduoegriddata.push(methoduoegridobj);
});
return methoduoegriddata;
	}
function getRowstbluoehtml5video(){
	var tbluoehtml5videodata = [];
	tbluoehtml5videorows = $("#tbluoehtml5video tbody tr");
tbluoehtml5videorows.each(function (index) {
    var tbluoehtml5videorow = $(this);
 	var tbluoehtml5videoobj = {};
	var vProperty = tbluoehtml5videorow.find("[name=Property]").text();
			tbluoehtml5videoobj['Property'] = vProperty;
			tbluoehtml5videoobj['index'] = index;
var vType = tbluoehtml5videorow.find("[name=Type]").text();
			tbluoehtml5videoobj['Type'] = vType;
			tbluoehtml5videoobj['index'] = index;
var vDefaultValue = tbluoehtml5videorow.find("[name=DefaultValue]").text();
			tbluoehtml5videoobj['DefaultValue'] = vDefaultValue;
			tbluoehtml5videoobj['index'] = index;
var vDescription = tbluoehtml5videorow.find("[name=Description]").text();
			tbluoehtml5videoobj['Description'] = vDescription;
			tbluoehtml5videoobj['index'] = index;

	tbluoehtml5videodata.push(tbluoehtml5videoobj);
});
return tbluoehtml5videodata;
	}
function getRowsmethoduoehtml5video(){
	var methoduoehtml5videodata = [];
	methoduoehtml5videorows = $("#methoduoehtml5video tbody tr");
methoduoehtml5videorows.each(function (index) {
    var methoduoehtml5videorow = $(this);
 	var methoduoehtml5videoobj = {};
	var vMethod = methoduoehtml5videorow.find("[name=Method]").text();
			methoduoehtml5videoobj['Method'] = vMethod;
			methoduoehtml5videoobj['index'] = index;
var vParameters = methoduoehtml5videorow.find("[name=Parameters]").text();
			methoduoehtml5videoobj['Parameters'] = vParameters;
			methoduoehtml5videoobj['index'] = index;
var vReturnType = methoduoehtml5videorow.find("[name=ReturnType]").text();
			methoduoehtml5videoobj['ReturnType'] = vReturnType;
			methoduoehtml5videoobj['index'] = index;
var vDescription = methoduoehtml5videorow.find("[name=Description]").text();
			methoduoehtml5videoobj['Description'] = vDescription;
			methoduoehtml5videoobj['index'] = index;

	methoduoehtml5videodata.push(methoduoehtml5videoobj);
});
return methoduoehtml5videodata;
	}
function getRowstbluoeicon(){
	var tbluoeicondata = [];
	tbluoeiconrows = $("#tbluoeicon tbody tr");
tbluoeiconrows.each(function (index) {
    var tbluoeiconrow = $(this);
 	var tbluoeiconobj = {};
	var vProperty = tbluoeiconrow.find("[name=Property]").text();
			tbluoeiconobj['Property'] = vProperty;
			tbluoeiconobj['index'] = index;
var vType = tbluoeiconrow.find("[name=Type]").text();
			tbluoeiconobj['Type'] = vType;
			tbluoeiconobj['index'] = index;
var vDefaultValue = tbluoeiconrow.find("[name=DefaultValue]").text();
			tbluoeiconobj['DefaultValue'] = vDefaultValue;
			tbluoeiconobj['index'] = index;
var vDescription = tbluoeiconrow.find("[name=Description]").text();
			tbluoeiconobj['Description'] = vDescription;
			tbluoeiconobj['index'] = index;

	tbluoeicondata.push(tbluoeiconobj);
});
return tbluoeicondata;
	}
function getRowsmethoduoeicon(){
	var methoduoeicondata = [];
	methoduoeiconrows = $("#methoduoeicon tbody tr");
methoduoeiconrows.each(function (index) {
    var methoduoeiconrow = $(this);
 	var methoduoeiconobj = {};
	var vMethod = methoduoeiconrow.find("[name=Method]").text();
			methoduoeiconobj['Method'] = vMethod;
			methoduoeiconobj['index'] = index;
var vParameters = methoduoeiconrow.find("[name=Parameters]").text();
			methoduoeiconobj['Parameters'] = vParameters;
			methoduoeiconobj['index'] = index;
var vReturnType = methoduoeiconrow.find("[name=ReturnType]").text();
			methoduoeiconobj['ReturnType'] = vReturnType;
			methoduoeiconobj['index'] = index;
var vDescription = methoduoeiconrow.find("[name=Description]").text();
			methoduoeiconobj['Description'] = vDescription;
			methoduoeiconobj['index'] = index;

	methoduoeicondata.push(methoduoeiconobj);
});
return methoduoeicondata;
	}
function getRowstbluoeimage(){
	var tbluoeimagedata = [];
	tbluoeimagerows = $("#tbluoeimage tbody tr");
tbluoeimagerows.each(function (index) {
    var tbluoeimagerow = $(this);
 	var tbluoeimageobj = {};
	var vProperty = tbluoeimagerow.find("[name=Property]").text();
			tbluoeimageobj['Property'] = vProperty;
			tbluoeimageobj['index'] = index;
var vType = tbluoeimagerow.find("[name=Type]").text();
			tbluoeimageobj['Type'] = vType;
			tbluoeimageobj['index'] = index;
var vDefaultValue = tbluoeimagerow.find("[name=DefaultValue]").text();
			tbluoeimageobj['DefaultValue'] = vDefaultValue;
			tbluoeimageobj['index'] = index;
var vDescription = tbluoeimagerow.find("[name=Description]").text();
			tbluoeimageobj['Description'] = vDescription;
			tbluoeimageobj['index'] = index;

	tbluoeimagedata.push(tbluoeimageobj);
});
return tbluoeimagedata;
	}
function getRowsmethoduoeimage(){
	var methoduoeimagedata = [];
	methoduoeimagerows = $("#methoduoeimage tbody tr");
methoduoeimagerows.each(function (index) {
    var methoduoeimagerow = $(this);
 	var methoduoeimageobj = {};
	var vMethod = methoduoeimagerow.find("[name=Method]").text();
			methoduoeimageobj['Method'] = vMethod;
			methoduoeimageobj['index'] = index;
var vParameters = methoduoeimagerow.find("[name=Parameters]").text();
			methoduoeimageobj['Parameters'] = vParameters;
			methoduoeimageobj['index'] = index;
var vReturnType = methoduoeimagerow.find("[name=ReturnType]").text();
			methoduoeimageobj['ReturnType'] = vReturnType;
			methoduoeimageobj['index'] = index;
var vDescription = methoduoeimagerow.find("[name=Description]").text();
			methoduoeimageobj['Description'] = vDescription;
			methoduoeimageobj['index'] = index;

	methoduoeimagedata.push(methoduoeimageobj);
});
return methoduoeimagedata;
	}
function getRowstbluoeinfobox(){
	var tbluoeinfoboxdata = [];
	tbluoeinfoboxrows = $("#tbluoeinfobox tbody tr");
tbluoeinfoboxrows.each(function (index) {
    var tbluoeinfoboxrow = $(this);
 	var tbluoeinfoboxobj = {};
	var vProperty = tbluoeinfoboxrow.find("[name=Property]").text();
			tbluoeinfoboxobj['Property'] = vProperty;
			tbluoeinfoboxobj['index'] = index;
var vType = tbluoeinfoboxrow.find("[name=Type]").text();
			tbluoeinfoboxobj['Type'] = vType;
			tbluoeinfoboxobj['index'] = index;
var vDefaultValue = tbluoeinfoboxrow.find("[name=DefaultValue]").text();
			tbluoeinfoboxobj['DefaultValue'] = vDefaultValue;
			tbluoeinfoboxobj['index'] = index;
var vDescription = tbluoeinfoboxrow.find("[name=Description]").text();
			tbluoeinfoboxobj['Description'] = vDescription;
			tbluoeinfoboxobj['index'] = index;

	tbluoeinfoboxdata.push(tbluoeinfoboxobj);
});
return tbluoeinfoboxdata;
	}
function getRowsmethoduoeinfobox(){
	var methoduoeinfoboxdata = [];
	methoduoeinfoboxrows = $("#methoduoeinfobox tbody tr");
methoduoeinfoboxrows.each(function (index) {
    var methoduoeinfoboxrow = $(this);
 	var methoduoeinfoboxobj = {};
	var vMethod = methoduoeinfoboxrow.find("[name=Method]").text();
			methoduoeinfoboxobj['Method'] = vMethod;
			methoduoeinfoboxobj['index'] = index;
var vParameters = methoduoeinfoboxrow.find("[name=Parameters]").text();
			methoduoeinfoboxobj['Parameters'] = vParameters;
			methoduoeinfoboxobj['index'] = index;
var vReturnType = methoduoeinfoboxrow.find("[name=ReturnType]").text();
			methoduoeinfoboxobj['ReturnType'] = vReturnType;
			methoduoeinfoboxobj['index'] = index;
var vDescription = methoduoeinfoboxrow.find("[name=Description]").text();
			methoduoeinfoboxobj['Description'] = vDescription;
			methoduoeinfoboxobj['index'] = index;

	methoduoeinfoboxdata.push(methoduoeinfoboxobj);
});
return methoduoeinfoboxdata;
	}
function getRowstbluoeinput(){
	var tbluoeinputdata = [];
	tbluoeinputrows = $("#tbluoeinput tbody tr");
tbluoeinputrows.each(function (index) {
    var tbluoeinputrow = $(this);
 	var tbluoeinputobj = {};
	var vProperty = tbluoeinputrow.find("[name=Property]").text();
			tbluoeinputobj['Property'] = vProperty;
			tbluoeinputobj['index'] = index;
var vType = tbluoeinputrow.find("[name=Type]").text();
			tbluoeinputobj['Type'] = vType;
			tbluoeinputobj['index'] = index;
var vDefaultValue = tbluoeinputrow.find("[name=DefaultValue]").text();
			tbluoeinputobj['DefaultValue'] = vDefaultValue;
			tbluoeinputobj['index'] = index;
var vDescription = tbluoeinputrow.find("[name=Description]").text();
			tbluoeinputobj['Description'] = vDescription;
			tbluoeinputobj['index'] = index;

	tbluoeinputdata.push(tbluoeinputobj);
});
return tbluoeinputdata;
	}
function getRowsmethoduoeinput(){
	var methoduoeinputdata = [];
	methoduoeinputrows = $("#methoduoeinput tbody tr");
methoduoeinputrows.each(function (index) {
    var methoduoeinputrow = $(this);
 	var methoduoeinputobj = {};
	var vMethod = methoduoeinputrow.find("[name=Method]").text();
			methoduoeinputobj['Method'] = vMethod;
			methoduoeinputobj['index'] = index;
var vParameters = methoduoeinputrow.find("[name=Parameters]").text();
			methoduoeinputobj['Parameters'] = vParameters;
			methoduoeinputobj['index'] = index;
var vReturnType = methoduoeinputrow.find("[name=ReturnType]").text();
			methoduoeinputobj['ReturnType'] = vReturnType;
			methoduoeinputobj['index'] = index;
var vDescription = methoduoeinputrow.find("[name=Description]").text();
			methoduoeinputobj['Description'] = vDescription;
			methoduoeinputobj['index'] = index;

	methoduoeinputdata.push(methoduoeinputobj);
});
return methoduoeinputdata;
	}
function getRowstbluoejs(){
	var tbluoejsdata = [];
	tbluoejsrows = $("#tbluoejs tbody tr");
tbluoejsrows.each(function (index) {
    var tbluoejsrow = $(this);
 	var tbluoejsobj = {};
	var vProperty = tbluoejsrow.find("[name=Property]").text();
			tbluoejsobj['Property'] = vProperty;
			tbluoejsobj['index'] = index;
var vType = tbluoejsrow.find("[name=Type]").text();
			tbluoejsobj['Type'] = vType;
			tbluoejsobj['index'] = index;
var vDefaultValue = tbluoejsrow.find("[name=DefaultValue]").text();
			tbluoejsobj['DefaultValue'] = vDefaultValue;
			tbluoejsobj['index'] = index;
var vDescription = tbluoejsrow.find("[name=Description]").text();
			tbluoejsobj['Description'] = vDescription;
			tbluoejsobj['index'] = index;

	tbluoejsdata.push(tbluoejsobj);
});
return tbluoejsdata;
	}
function getRowsmethoduoejs(){
	var methoduoejsdata = [];
	methoduoejsrows = $("#methoduoejs tbody tr");
methoduoejsrows.each(function (index) {
    var methoduoejsrow = $(this);
 	var methoduoejsobj = {};
	var vMethod = methoduoejsrow.find("[name=Method]").text();
			methoduoejsobj['Method'] = vMethod;
			methoduoejsobj['index'] = index;
var vParameters = methoduoejsrow.find("[name=Parameters]").text();
			methoduoejsobj['Parameters'] = vParameters;
			methoduoejsobj['index'] = index;
var vReturnType = methoduoejsrow.find("[name=ReturnType]").text();
			methoduoejsobj['ReturnType'] = vReturnType;
			methoduoejsobj['index'] = index;
var vDescription = methoduoejsrow.find("[name=Description]").text();
			methoduoejsobj['Description'] = vDescription;
			methoduoejsobj['index'] = index;

	methoduoejsdata.push(methoduoejsobj);
});
return methoduoejsdata;
	}
function getRowstbluoelabel(){
	var tbluoelabeldata = [];
	tbluoelabelrows = $("#tbluoelabel tbody tr");
tbluoelabelrows.each(function (index) {
    var tbluoelabelrow = $(this);
 	var tbluoelabelobj = {};
	var vProperty = tbluoelabelrow.find("[name=Property]").text();
			tbluoelabelobj['Property'] = vProperty;
			tbluoelabelobj['index'] = index;
var vType = tbluoelabelrow.find("[name=Type]").text();
			tbluoelabelobj['Type'] = vType;
			tbluoelabelobj['index'] = index;
var vDefaultValue = tbluoelabelrow.find("[name=DefaultValue]").text();
			tbluoelabelobj['DefaultValue'] = vDefaultValue;
			tbluoelabelobj['index'] = index;
var vDescription = tbluoelabelrow.find("[name=Description]").text();
			tbluoelabelobj['Description'] = vDescription;
			tbluoelabelobj['index'] = index;

	tbluoelabeldata.push(tbluoelabelobj);
});
return tbluoelabeldata;
	}
function getRowsmethoduoelabel(){
	var methoduoelabeldata = [];
	methoduoelabelrows = $("#methoduoelabel tbody tr");
methoduoelabelrows.each(function (index) {
    var methoduoelabelrow = $(this);
 	var methoduoelabelobj = {};
	var vMethod = methoduoelabelrow.find("[name=Method]").text();
			methoduoelabelobj['Method'] = vMethod;
			methoduoelabelobj['index'] = index;
var vParameters = methoduoelabelrow.find("[name=Parameters]").text();
			methoduoelabelobj['Parameters'] = vParameters;
			methoduoelabelobj['index'] = index;
var vReturnType = methoduoelabelrow.find("[name=ReturnType]").text();
			methoduoelabelobj['ReturnType'] = vReturnType;
			methoduoelabelobj['index'] = index;
var vDescription = methoduoelabelrow.find("[name=Description]").text();
			methoduoelabelobj['Description'] = vDescription;
			methoduoelabelobj['index'] = index;

	methoduoelabeldata.push(methoduoelabelobj);
});
return methoduoelabeldata;
	}
function getRowstbluoeleaflet(){
	var tbluoeleafletdata = [];
	tbluoeleafletrows = $("#tbluoeleaflet tbody tr");
tbluoeleafletrows.each(function (index) {
    var tbluoeleafletrow = $(this);
 	var tbluoeleafletobj = {};
	var vProperty = tbluoeleafletrow.find("[name=Property]").text();
			tbluoeleafletobj['Property'] = vProperty;
			tbluoeleafletobj['index'] = index;
var vType = tbluoeleafletrow.find("[name=Type]").text();
			tbluoeleafletobj['Type'] = vType;
			tbluoeleafletobj['index'] = index;
var vDefaultValue = tbluoeleafletrow.find("[name=DefaultValue]").text();
			tbluoeleafletobj['DefaultValue'] = vDefaultValue;
			tbluoeleafletobj['index'] = index;
var vDescription = tbluoeleafletrow.find("[name=Description]").text();
			tbluoeleafletobj['Description'] = vDescription;
			tbluoeleafletobj['index'] = index;

	tbluoeleafletdata.push(tbluoeleafletobj);
});
return tbluoeleafletdata;
	}
function getRowsmethoduoeleaflet(){
	var methoduoeleafletdata = [];
	methoduoeleafletrows = $("#methoduoeleaflet tbody tr");
methoduoeleafletrows.each(function (index) {
    var methoduoeleafletrow = $(this);
 	var methoduoeleafletobj = {};
	var vMethod = methoduoeleafletrow.find("[name=Method]").text();
			methoduoeleafletobj['Method'] = vMethod;
			methoduoeleafletobj['index'] = index;
var vParameters = methoduoeleafletrow.find("[name=Parameters]").text();
			methoduoeleafletobj['Parameters'] = vParameters;
			methoduoeleafletobj['index'] = index;
var vReturnType = methoduoeleafletrow.find("[name=ReturnType]").text();
			methoduoeleafletobj['ReturnType'] = vReturnType;
			methoduoeleafletobj['index'] = index;
var vDescription = methoduoeleafletrow.find("[name=Description]").text();
			methoduoeleafletobj['Description'] = vDescription;
			methoduoeleafletobj['index'] = index;

	methoduoeleafletdata.push(methoduoeleafletobj);
});
return methoduoeleafletdata;
	}
function getRowstbluoelist(){
	var tbluoelistdata = [];
	tbluoelistrows = $("#tbluoelist tbody tr");
tbluoelistrows.each(function (index) {
    var tbluoelistrow = $(this);
 	var tbluoelistobj = {};
	var vProperty = tbluoelistrow.find("[name=Property]").text();
			tbluoelistobj['Property'] = vProperty;
			tbluoelistobj['index'] = index;
var vType = tbluoelistrow.find("[name=Type]").text();
			tbluoelistobj['Type'] = vType;
			tbluoelistobj['index'] = index;
var vDefaultValue = tbluoelistrow.find("[name=DefaultValue]").text();
			tbluoelistobj['DefaultValue'] = vDefaultValue;
			tbluoelistobj['index'] = index;
var vDescription = tbluoelistrow.find("[name=Description]").text();
			tbluoelistobj['Description'] = vDescription;
			tbluoelistobj['index'] = index;

	tbluoelistdata.push(tbluoelistobj);
});
return tbluoelistdata;
	}
function getRowsmethoduoelist(){
	var methoduoelistdata = [];
	methoduoelistrows = $("#methoduoelist tbody tr");
methoduoelistrows.each(function (index) {
    var methoduoelistrow = $(this);
 	var methoduoelistobj = {};
	var vMethod = methoduoelistrow.find("[name=Method]").text();
			methoduoelistobj['Method'] = vMethod;
			methoduoelistobj['index'] = index;
var vParameters = methoduoelistrow.find("[name=Parameters]").text();
			methoduoelistobj['Parameters'] = vParameters;
			methoduoelistobj['index'] = index;
var vReturnType = methoduoelistrow.find("[name=ReturnType]").text();
			methoduoelistobj['ReturnType'] = vReturnType;
			methoduoelistobj['index'] = index;
var vDescription = methoduoelistrow.find("[name=Description]").text();
			methoduoelistobj['Description'] = vDescription;
			methoduoelistobj['index'] = index;

	methoduoelistdata.push(methoduoelistobj);
});
return methoduoelistdata;
	}
function getRowstbluoelistview(){
	var tbluoelistviewdata = [];
	tbluoelistviewrows = $("#tbluoelistview tbody tr");
tbluoelistviewrows.each(function (index) {
    var tbluoelistviewrow = $(this);
 	var tbluoelistviewobj = {};
	var vProperty = tbluoelistviewrow.find("[name=Property]").text();
			tbluoelistviewobj['Property'] = vProperty;
			tbluoelistviewobj['index'] = index;
var vType = tbluoelistviewrow.find("[name=Type]").text();
			tbluoelistviewobj['Type'] = vType;
			tbluoelistviewobj['index'] = index;
var vDefaultValue = tbluoelistviewrow.find("[name=DefaultValue]").text();
			tbluoelistviewobj['DefaultValue'] = vDefaultValue;
			tbluoelistviewobj['index'] = index;
var vDescription = tbluoelistviewrow.find("[name=Description]").text();
			tbluoelistviewobj['Description'] = vDescription;
			tbluoelistviewobj['index'] = index;

	tbluoelistviewdata.push(tbluoelistviewobj);
});
return tbluoelistviewdata;
	}
function getRowsmethoduoelistview(){
	var methoduoelistviewdata = [];
	methoduoelistviewrows = $("#methoduoelistview tbody tr");
methoduoelistviewrows.each(function (index) {
    var methoduoelistviewrow = $(this);
 	var methoduoelistviewobj = {};
	var vMethod = methoduoelistviewrow.find("[name=Method]").text();
			methoduoelistviewobj['Method'] = vMethod;
			methoduoelistviewobj['index'] = index;
var vParameters = methoduoelistviewrow.find("[name=Parameters]").text();
			methoduoelistviewobj['Parameters'] = vParameters;
			methoduoelistviewobj['index'] = index;
var vReturnType = methoduoelistviewrow.find("[name=ReturnType]").text();
			methoduoelistviewobj['ReturnType'] = vReturnType;
			methoduoelistviewobj['index'] = index;
var vDescription = methoduoelistviewrow.find("[name=Description]").text();
			methoduoelistviewobj['Description'] = vDescription;
			methoduoelistviewobj['index'] = index;

	methoduoelistviewdata.push(methoduoelistviewobj);
});
return methoduoelistviewdata;
	}
function getRowstbluoemermaid(){
	var tbluoemermaiddata = [];
	tbluoemermaidrows = $("#tbluoemermaid tbody tr");
tbluoemermaidrows.each(function (index) {
    var tbluoemermaidrow = $(this);
 	var tbluoemermaidobj = {};
	var vProperty = tbluoemermaidrow.find("[name=Property]").text();
			tbluoemermaidobj['Property'] = vProperty;
			tbluoemermaidobj['index'] = index;
var vType = tbluoemermaidrow.find("[name=Type]").text();
			tbluoemermaidobj['Type'] = vType;
			tbluoemermaidobj['index'] = index;
var vDefaultValue = tbluoemermaidrow.find("[name=DefaultValue]").text();
			tbluoemermaidobj['DefaultValue'] = vDefaultValue;
			tbluoemermaidobj['index'] = index;
var vDescription = tbluoemermaidrow.find("[name=Description]").text();
			tbluoemermaidobj['Description'] = vDescription;
			tbluoemermaidobj['index'] = index;

	tbluoemermaiddata.push(tbluoemermaidobj);
});
return tbluoemermaiddata;
	}
function getRowsmethoduoemermaid(){
	var methoduoemermaiddata = [];
	methoduoemermaidrows = $("#methoduoemermaid tbody tr");
methoduoemermaidrows.each(function (index) {
    var methoduoemermaidrow = $(this);
 	var methoduoemermaidobj = {};
	var vMethod = methoduoemermaidrow.find("[name=Method]").text();
			methoduoemermaidobj['Method'] = vMethod;
			methoduoemermaidobj['index'] = index;
var vParameters = methoduoemermaidrow.find("[name=Parameters]").text();
			methoduoemermaidobj['Parameters'] = vParameters;
			methoduoemermaidobj['index'] = index;
var vReturnType = methoduoemermaidrow.find("[name=ReturnType]").text();
			methoduoemermaidobj['ReturnType'] = vReturnType;
			methoduoemermaidobj['index'] = index;
var vDescription = methoduoemermaidrow.find("[name=Description]").text();
			methoduoemermaidobj['Description'] = vDescription;
			methoduoemermaidobj['index'] = index;

	methoduoemermaiddata.push(methoduoemermaidobj);
});
return methoduoemermaiddata;
	}
function getRowstbluoemodal(){
	var tbluoemodaldata = [];
	tbluoemodalrows = $("#tbluoemodal tbody tr");
tbluoemodalrows.each(function (index) {
    var tbluoemodalrow = $(this);
 	var tbluoemodalobj = {};
	var vProperty = tbluoemodalrow.find("[name=Property]").text();
			tbluoemodalobj['Property'] = vProperty;
			tbluoemodalobj['index'] = index;
var vType = tbluoemodalrow.find("[name=Type]").text();
			tbluoemodalobj['Type'] = vType;
			tbluoemodalobj['index'] = index;
var vDefaultValue = tbluoemodalrow.find("[name=DefaultValue]").text();
			tbluoemodalobj['DefaultValue'] = vDefaultValue;
			tbluoemodalobj['index'] = index;
var vDescription = tbluoemodalrow.find("[name=Description]").text();
			tbluoemodalobj['Description'] = vDescription;
			tbluoemodalobj['index'] = index;

	tbluoemodaldata.push(tbluoemodalobj);
});
return tbluoemodaldata;
	}
function getRowsmethoduoemodal(){
	var methoduoemodaldata = [];
	methoduoemodalrows = $("#methoduoemodal tbody tr");
methoduoemodalrows.each(function (index) {
    var methoduoemodalrow = $(this);
 	var methoduoemodalobj = {};
	var vMethod = methoduoemodalrow.find("[name=Method]").text();
			methoduoemodalobj['Method'] = vMethod;
			methoduoemodalobj['index'] = index;
var vParameters = methoduoemodalrow.find("[name=Parameters]").text();
			methoduoemodalobj['Parameters'] = vParameters;
			methoduoemodalobj['index'] = index;
var vReturnType = methoduoemodalrow.find("[name=ReturnType]").text();
			methoduoemodalobj['ReturnType'] = vReturnType;
			methoduoemodalobj['index'] = index;
var vDescription = methoduoemodalrow.find("[name=Description]").text();
			methoduoemodalobj['Description'] = vDescription;
			methoduoemodalobj['index'] = index;

	methoduoemodaldata.push(methoduoemodalobj);
});
return methoduoemodaldata;
	}
function getRowstbluoenav(){
	var tbluoenavdata = [];
	tbluoenavrows = $("#tbluoenav tbody tr");
tbluoenavrows.each(function (index) {
    var tbluoenavrow = $(this);
 	var tbluoenavobj = {};
	var vProperty = tbluoenavrow.find("[name=Property]").text();
			tbluoenavobj['Property'] = vProperty;
			tbluoenavobj['index'] = index;
var vType = tbluoenavrow.find("[name=Type]").text();
			tbluoenavobj['Type'] = vType;
			tbluoenavobj['index'] = index;
var vDefaultValue = tbluoenavrow.find("[name=DefaultValue]").text();
			tbluoenavobj['DefaultValue'] = vDefaultValue;
			tbluoenavobj['index'] = index;
var vDescription = tbluoenavrow.find("[name=Description]").text();
			tbluoenavobj['Description'] = vDescription;
			tbluoenavobj['index'] = index;

	tbluoenavdata.push(tbluoenavobj);
});
return tbluoenavdata;
	}
function getRowsmethoduoenav(){
	var methoduoenavdata = [];
	methoduoenavrows = $("#methoduoenav tbody tr");
methoduoenavrows.each(function (index) {
    var methoduoenavrow = $(this);
 	var methoduoenavobj = {};
	var vMethod = methoduoenavrow.find("[name=Method]").text();
			methoduoenavobj['Method'] = vMethod;
			methoduoenavobj['index'] = index;
var vParameters = methoduoenavrow.find("[name=Parameters]").text();
			methoduoenavobj['Parameters'] = vParameters;
			methoduoenavobj['index'] = index;
var vReturnType = methoduoenavrow.find("[name=ReturnType]").text();
			methoduoenavobj['ReturnType'] = vReturnType;
			methoduoenavobj['index'] = index;
var vDescription = methoduoenavrow.find("[name=Description]").text();
			methoduoenavobj['Description'] = vDescription;
			methoduoenavobj['index'] = index;

	methoduoenavdata.push(methoduoenavobj);
});
return methoduoenavdata;
	}
function getRowstbluoepage(){
	var tbluoepagedata = [];
	tbluoepagerows = $("#tbluoepage tbody tr");
tbluoepagerows.each(function (index) {
    var tbluoepagerow = $(this);
 	var tbluoepageobj = {};
	var vProperty = tbluoepagerow.find("[name=Property]").text();
			tbluoepageobj['Property'] = vProperty;
			tbluoepageobj['index'] = index;
var vType = tbluoepagerow.find("[name=Type]").text();
			tbluoepageobj['Type'] = vType;
			tbluoepageobj['index'] = index;
var vDefaultValue = tbluoepagerow.find("[name=DefaultValue]").text();
			tbluoepageobj['DefaultValue'] = vDefaultValue;
			tbluoepageobj['index'] = index;
var vDescription = tbluoepagerow.find("[name=Description]").text();
			tbluoepageobj['Description'] = vDescription;
			tbluoepageobj['index'] = index;

	tbluoepagedata.push(tbluoepageobj);
});
return tbluoepagedata;
	}
function getRowsmethoduoepage(){
	var methoduoepagedata = [];
	methoduoepagerows = $("#methoduoepage tbody tr");
methoduoepagerows.each(function (index) {
    var methoduoepagerow = $(this);
 	var methoduoepageobj = {};
	var vMethod = methoduoepagerow.find("[name=Method]").text();
			methoduoepageobj['Method'] = vMethod;
			methoduoepageobj['index'] = index;
var vParameters = methoduoepagerow.find("[name=Parameters]").text();
			methoduoepageobj['Parameters'] = vParameters;
			methoduoepageobj['index'] = index;
var vReturnType = methoduoepagerow.find("[name=ReturnType]").text();
			methoduoepageobj['ReturnType'] = vReturnType;
			methoduoepageobj['index'] = index;
var vDescription = methoduoepagerow.find("[name=Description]").text();
			methoduoepageobj['Description'] = vDescription;
			methoduoepageobj['index'] = index;

	methoduoepagedata.push(methoduoepageobj);
});
return methoduoepagedata;
	}
function getRowstbluoepagination(){
	var tbluoepaginationdata = [];
	tbluoepaginationrows = $("#tbluoepagination tbody tr");
tbluoepaginationrows.each(function (index) {
    var tbluoepaginationrow = $(this);
 	var tbluoepaginationobj = {};
	var vProperty = tbluoepaginationrow.find("[name=Property]").text();
			tbluoepaginationobj['Property'] = vProperty;
			tbluoepaginationobj['index'] = index;
var vType = tbluoepaginationrow.find("[name=Type]").text();
			tbluoepaginationobj['Type'] = vType;
			tbluoepaginationobj['index'] = index;
var vDefaultValue = tbluoepaginationrow.find("[name=DefaultValue]").text();
			tbluoepaginationobj['DefaultValue'] = vDefaultValue;
			tbluoepaginationobj['index'] = index;
var vDescription = tbluoepaginationrow.find("[name=Description]").text();
			tbluoepaginationobj['Description'] = vDescription;
			tbluoepaginationobj['index'] = index;

	tbluoepaginationdata.push(tbluoepaginationobj);
});
return tbluoepaginationdata;
	}
function getRowsmethoduoepagination(){
	var methoduoepaginationdata = [];
	methoduoepaginationrows = $("#methoduoepagination tbody tr");
methoduoepaginationrows.each(function (index) {
    var methoduoepaginationrow = $(this);
 	var methoduoepaginationobj = {};
	var vMethod = methoduoepaginationrow.find("[name=Method]").text();
			methoduoepaginationobj['Method'] = vMethod;
			methoduoepaginationobj['index'] = index;
var vParameters = methoduoepaginationrow.find("[name=Parameters]").text();
			methoduoepaginationobj['Parameters'] = vParameters;
			methoduoepaginationobj['index'] = index;
var vReturnType = methoduoepaginationrow.find("[name=ReturnType]").text();
			methoduoepaginationobj['ReturnType'] = vReturnType;
			methoduoepaginationobj['index'] = index;
var vDescription = methoduoepaginationrow.find("[name=Description]").text();
			methoduoepaginationobj['Description'] = vDescription;
			methoduoepaginationobj['index'] = index;

	methoduoepaginationdata.push(methoduoepaginationobj);
});
return methoduoepaginationdata;
	}
function getRowstbluoeparallax(){
	var tbluoeparallaxdata = [];
	tbluoeparallaxrows = $("#tbluoeparallax tbody tr");
tbluoeparallaxrows.each(function (index) {
    var tbluoeparallaxrow = $(this);
 	var tbluoeparallaxobj = {};
	var vProperty = tbluoeparallaxrow.find("[name=Property]").text();
			tbluoeparallaxobj['Property'] = vProperty;
			tbluoeparallaxobj['index'] = index;
var vType = tbluoeparallaxrow.find("[name=Type]").text();
			tbluoeparallaxobj['Type'] = vType;
			tbluoeparallaxobj['index'] = index;
var vDefaultValue = tbluoeparallaxrow.find("[name=DefaultValue]").text();
			tbluoeparallaxobj['DefaultValue'] = vDefaultValue;
			tbluoeparallaxobj['index'] = index;
var vDescription = tbluoeparallaxrow.find("[name=Description]").text();
			tbluoeparallaxobj['Description'] = vDescription;
			tbluoeparallaxobj['index'] = index;

	tbluoeparallaxdata.push(tbluoeparallaxobj);
});
return tbluoeparallaxdata;
	}
function getRowsmethoduoeparallax(){
	var methoduoeparallaxdata = [];
	methoduoeparallaxrows = $("#methoduoeparallax tbody tr");
methoduoeparallaxrows.each(function (index) {
    var methoduoeparallaxrow = $(this);
 	var methoduoeparallaxobj = {};
	var vMethod = methoduoeparallaxrow.find("[name=Method]").text();
			methoduoeparallaxobj['Method'] = vMethod;
			methoduoeparallaxobj['index'] = index;
var vParameters = methoduoeparallaxrow.find("[name=Parameters]").text();
			methoduoeparallaxobj['Parameters'] = vParameters;
			methoduoeparallaxobj['index'] = index;
var vReturnType = methoduoeparallaxrow.find("[name=ReturnType]").text();
			methoduoeparallaxobj['ReturnType'] = vReturnType;
			methoduoeparallaxobj['index'] = index;
var vDescription = methoduoeparallaxrow.find("[name=Description]").text();
			methoduoeparallaxobj['Description'] = vDescription;
			methoduoeparallaxobj['index'] = index;

	methoduoeparallaxdata.push(methoduoeparallaxobj);
});
return methoduoeparallaxdata;
	}
function getRowstbluoepreloader(){
	var tbluoepreloaderdata = [];
	tbluoepreloaderrows = $("#tbluoepreloader tbody tr");
tbluoepreloaderrows.each(function (index) {
    var tbluoepreloaderrow = $(this);
 	var tbluoepreloaderobj = {};
	var vProperty = tbluoepreloaderrow.find("[name=Property]").text();
			tbluoepreloaderobj['Property'] = vProperty;
			tbluoepreloaderobj['index'] = index;
var vType = tbluoepreloaderrow.find("[name=Type]").text();
			tbluoepreloaderobj['Type'] = vType;
			tbluoepreloaderobj['index'] = index;
var vDefaultValue = tbluoepreloaderrow.find("[name=DefaultValue]").text();
			tbluoepreloaderobj['DefaultValue'] = vDefaultValue;
			tbluoepreloaderobj['index'] = index;
var vDescription = tbluoepreloaderrow.find("[name=Description]").text();
			tbluoepreloaderobj['Description'] = vDescription;
			tbluoepreloaderobj['index'] = index;

	tbluoepreloaderdata.push(tbluoepreloaderobj);
});
return tbluoepreloaderdata;
	}
function getRowsmethoduoepreloader(){
	var methoduoepreloaderdata = [];
	methoduoepreloaderrows = $("#methoduoepreloader tbody tr");
methoduoepreloaderrows.each(function (index) {
    var methoduoepreloaderrow = $(this);
 	var methoduoepreloaderobj = {};
	var vMethod = methoduoepreloaderrow.find("[name=Method]").text();
			methoduoepreloaderobj['Method'] = vMethod;
			methoduoepreloaderobj['index'] = index;
var vParameters = methoduoepreloaderrow.find("[name=Parameters]").text();
			methoduoepreloaderobj['Parameters'] = vParameters;
			methoduoepreloaderobj['index'] = index;
var vReturnType = methoduoepreloaderrow.find("[name=ReturnType]").text();
			methoduoepreloaderobj['ReturnType'] = vReturnType;
			methoduoepreloaderobj['index'] = index;
var vDescription = methoduoepreloaderrow.find("[name=Description]").text();
			methoduoepreloaderobj['Description'] = vDescription;
			methoduoepreloaderobj['index'] = index;

	methoduoepreloaderdata.push(methoduoepreloaderobj);
});
return methoduoepreloaderdata;
	}
function getRowstbluoeprism(){
	var tbluoeprismdata = [];
	tbluoeprismrows = $("#tbluoeprism tbody tr");
tbluoeprismrows.each(function (index) {
    var tbluoeprismrow = $(this);
 	var tbluoeprismobj = {};
	var vProperty = tbluoeprismrow.find("[name=Property]").text();
			tbluoeprismobj['Property'] = vProperty;
			tbluoeprismobj['index'] = index;
var vType = tbluoeprismrow.find("[name=Type]").text();
			tbluoeprismobj['Type'] = vType;
			tbluoeprismobj['index'] = index;
var vDefaultValue = tbluoeprismrow.find("[name=DefaultValue]").text();
			tbluoeprismobj['DefaultValue'] = vDefaultValue;
			tbluoeprismobj['index'] = index;
var vDescription = tbluoeprismrow.find("[name=Description]").text();
			tbluoeprismobj['Description'] = vDescription;
			tbluoeprismobj['index'] = index;

	tbluoeprismdata.push(tbluoeprismobj);
});
return tbluoeprismdata;
	}
function getRowsmethoduoeprism(){
	var methoduoeprismdata = [];
	methoduoeprismrows = $("#methoduoeprism tbody tr");
methoduoeprismrows.each(function (index) {
    var methoduoeprismrow = $(this);
 	var methoduoeprismobj = {};
	var vMethod = methoduoeprismrow.find("[name=Method]").text();
			methoduoeprismobj['Method'] = vMethod;
			methoduoeprismobj['index'] = index;
var vParameters = methoduoeprismrow.find("[name=Parameters]").text();
			methoduoeprismobj['Parameters'] = vParameters;
			methoduoeprismobj['index'] = index;
var vReturnType = methoduoeprismrow.find("[name=ReturnType]").text();
			methoduoeprismobj['ReturnType'] = vReturnType;
			methoduoeprismobj['index'] = index;
var vDescription = methoduoeprismrow.find("[name=Description]").text();
			methoduoeprismobj['Description'] = vDescription;
			methoduoeprismobj['index'] = index;

	methoduoeprismdata.push(methoduoeprismobj);
});
return methoduoeprismdata;
	}
function getRowstbluoeprogress(){
	var tbluoeprogressdata = [];
	tbluoeprogressrows = $("#tbluoeprogress tbody tr");
tbluoeprogressrows.each(function (index) {
    var tbluoeprogressrow = $(this);
 	var tbluoeprogressobj = {};
	var vProperty = tbluoeprogressrow.find("[name=Property]").text();
			tbluoeprogressobj['Property'] = vProperty;
			tbluoeprogressobj['index'] = index;
var vType = tbluoeprogressrow.find("[name=Type]").text();
			tbluoeprogressobj['Type'] = vType;
			tbluoeprogressobj['index'] = index;
var vDefaultValue = tbluoeprogressrow.find("[name=DefaultValue]").text();
			tbluoeprogressobj['DefaultValue'] = vDefaultValue;
			tbluoeprogressobj['index'] = index;
var vDescription = tbluoeprogressrow.find("[name=Description]").text();
			tbluoeprogressobj['Description'] = vDescription;
			tbluoeprogressobj['index'] = index;

	tbluoeprogressdata.push(tbluoeprogressobj);
});
return tbluoeprogressdata;
	}
function getRowsmethoduoeprogress(){
	var methoduoeprogressdata = [];
	methoduoeprogressrows = $("#methoduoeprogress tbody tr");
methoduoeprogressrows.each(function (index) {
    var methoduoeprogressrow = $(this);
 	var methoduoeprogressobj = {};
	var vMethod = methoduoeprogressrow.find("[name=Method]").text();
			methoduoeprogressobj['Method'] = vMethod;
			methoduoeprogressobj['index'] = index;
var vParameters = methoduoeprogressrow.find("[name=Parameters]").text();
			methoduoeprogressobj['Parameters'] = vParameters;
			methoduoeprogressobj['index'] = index;
var vReturnType = methoduoeprogressrow.find("[name=ReturnType]").text();
			methoduoeprogressobj['ReturnType'] = vReturnType;
			methoduoeprogressobj['index'] = index;
var vDescription = methoduoeprogressrow.find("[name=Description]").text();
			methoduoeprogressobj['Description'] = vDescription;
			methoduoeprogressobj['index'] = index;

	methoduoeprogressdata.push(methoduoeprogressobj);
});
return methoduoeprogressdata;
	}
function getRowstbluoequill(){
	var tbluoequilldata = [];
	tbluoequillrows = $("#tbluoequill tbody tr");
tbluoequillrows.each(function (index) {
    var tbluoequillrow = $(this);
 	var tbluoequillobj = {};
	var vProperty = tbluoequillrow.find("[name=Property]").text();
			tbluoequillobj['Property'] = vProperty;
			tbluoequillobj['index'] = index;
var vType = tbluoequillrow.find("[name=Type]").text();
			tbluoequillobj['Type'] = vType;
			tbluoequillobj['index'] = index;
var vDefaultValue = tbluoequillrow.find("[name=DefaultValue]").text();
			tbluoequillobj['DefaultValue'] = vDefaultValue;
			tbluoequillobj['index'] = index;
var vDescription = tbluoequillrow.find("[name=Description]").text();
			tbluoequillobj['Description'] = vDescription;
			tbluoequillobj['index'] = index;

	tbluoequilldata.push(tbluoequillobj);
});
return tbluoequilldata;
	}
function getRowsmethoduoequill(){
	var methoduoequilldata = [];
	methoduoequillrows = $("#methoduoequill tbody tr");
methoduoequillrows.each(function (index) {
    var methoduoequillrow = $(this);
 	var methoduoequillobj = {};
	var vMethod = methoduoequillrow.find("[name=Method]").text();
			methoduoequillobj['Method'] = vMethod;
			methoduoequillobj['index'] = index;
var vParameters = methoduoequillrow.find("[name=Parameters]").text();
			methoduoequillobj['Parameters'] = vParameters;
			methoduoequillobj['index'] = index;
var vReturnType = methoduoequillrow.find("[name=ReturnType]").text();
			methoduoequillobj['ReturnType'] = vReturnType;
			methoduoequillobj['index'] = index;
var vDescription = methoduoequillrow.find("[name=Description]").text();
			methoduoequillobj['Description'] = vDescription;
			methoduoequillobj['index'] = index;

	methoduoequilldata.push(methoduoequillobj);
});
return methoduoequilldata;
	}
function getRowstbluoeradio(){
	var tbluoeradiodata = [];
	tbluoeradiorows = $("#tbluoeradio tbody tr");
tbluoeradiorows.each(function (index) {
    var tbluoeradiorow = $(this);
 	var tbluoeradioobj = {};
	var vProperty = tbluoeradiorow.find("[name=Property]").text();
			tbluoeradioobj['Property'] = vProperty;
			tbluoeradioobj['index'] = index;
var vType = tbluoeradiorow.find("[name=Type]").text();
			tbluoeradioobj['Type'] = vType;
			tbluoeradioobj['index'] = index;
var vDefaultValue = tbluoeradiorow.find("[name=DefaultValue]").text();
			tbluoeradioobj['DefaultValue'] = vDefaultValue;
			tbluoeradioobj['index'] = index;
var vDescription = tbluoeradiorow.find("[name=Description]").text();
			tbluoeradioobj['Description'] = vDescription;
			tbluoeradioobj['index'] = index;

	tbluoeradiodata.push(tbluoeradioobj);
});
return tbluoeradiodata;
	}
function getRowsmethoduoeradio(){
	var methoduoeradiodata = [];
	methoduoeradiorows = $("#methoduoeradio tbody tr");
methoduoeradiorows.each(function (index) {
    var methoduoeradiorow = $(this);
 	var methoduoeradioobj = {};
	var vMethod = methoduoeradiorow.find("[name=Method]").text();
			methoduoeradioobj['Method'] = vMethod;
			methoduoeradioobj['index'] = index;
var vParameters = methoduoeradiorow.find("[name=Parameters]").text();
			methoduoeradioobj['Parameters'] = vParameters;
			methoduoeradioobj['index'] = index;
var vReturnType = methoduoeradiorow.find("[name=ReturnType]").text();
			methoduoeradioobj['ReturnType'] = vReturnType;
			methoduoeradioobj['index'] = index;
var vDescription = methoduoeradiorow.find("[name=Description]").text();
			methoduoeradioobj['Description'] = vDescription;
			methoduoeradioobj['index'] = index;

	methoduoeradiodata.push(methoduoeradioobj);
});
return methoduoeradiodata;
	}
function getRowstbluoeradiogroup(){
	var tbluoeradiogroupdata = [];
	tbluoeradiogrouprows = $("#tbluoeradiogroup tbody tr");
tbluoeradiogrouprows.each(function (index) {
    var tbluoeradiogrouprow = $(this);
 	var tbluoeradiogroupobj = {};
	var vProperty = tbluoeradiogrouprow.find("[name=Property]").text();
			tbluoeradiogroupobj['Property'] = vProperty;
			tbluoeradiogroupobj['index'] = index;
var vType = tbluoeradiogrouprow.find("[name=Type]").text();
			tbluoeradiogroupobj['Type'] = vType;
			tbluoeradiogroupobj['index'] = index;
var vDefaultValue = tbluoeradiogrouprow.find("[name=DefaultValue]").text();
			tbluoeradiogroupobj['DefaultValue'] = vDefaultValue;
			tbluoeradiogroupobj['index'] = index;
var vDescription = tbluoeradiogrouprow.find("[name=Description]").text();
			tbluoeradiogroupobj['Description'] = vDescription;
			tbluoeradiogroupobj['index'] = index;

	tbluoeradiogroupdata.push(tbluoeradiogroupobj);
});
return tbluoeradiogroupdata;
	}
function getRowsmethoduoeradiogroup(){
	var methoduoeradiogroupdata = [];
	methoduoeradiogrouprows = $("#methoduoeradiogroup tbody tr");
methoduoeradiogrouprows.each(function (index) {
    var methoduoeradiogrouprow = $(this);
 	var methoduoeradiogroupobj = {};
	var vMethod = methoduoeradiogrouprow.find("[name=Method]").text();
			methoduoeradiogroupobj['Method'] = vMethod;
			methoduoeradiogroupobj['index'] = index;
var vParameters = methoduoeradiogrouprow.find("[name=Parameters]").text();
			methoduoeradiogroupobj['Parameters'] = vParameters;
			methoduoeradiogroupobj['index'] = index;
var vReturnType = methoduoeradiogrouprow.find("[name=ReturnType]").text();
			methoduoeradiogroupobj['ReturnType'] = vReturnType;
			methoduoeradiogroupobj['index'] = index;
var vDescription = methoduoeradiogrouprow.find("[name=Description]").text();
			methoduoeradiogroupobj['Description'] = vDescription;
			methoduoeradiogroupobj['index'] = index;

	methoduoeradiogroupdata.push(methoduoeradiogroupobj);
});
return methoduoeradiogroupdata;
	}
function getRowstbluoerange(){
	var tbluoerangedata = [];
	tbluoerangerows = $("#tbluoerange tbody tr");
tbluoerangerows.each(function (index) {
    var tbluoerangerow = $(this);
 	var tbluoerangeobj = {};
	var vProperty = tbluoerangerow.find("[name=Property]").text();
			tbluoerangeobj['Property'] = vProperty;
			tbluoerangeobj['index'] = index;
var vType = tbluoerangerow.find("[name=Type]").text();
			tbluoerangeobj['Type'] = vType;
			tbluoerangeobj['index'] = index;
var vDefaultValue = tbluoerangerow.find("[name=DefaultValue]").text();
			tbluoerangeobj['DefaultValue'] = vDefaultValue;
			tbluoerangeobj['index'] = index;
var vDescription = tbluoerangerow.find("[name=Description]").text();
			tbluoerangeobj['Description'] = vDescription;
			tbluoerangeobj['index'] = index;

	tbluoerangedata.push(tbluoerangeobj);
});
return tbluoerangedata;
	}
function getRowsmethoduoerange(){
	var methoduoerangedata = [];
	methoduoerangerows = $("#methoduoerange tbody tr");
methoduoerangerows.each(function (index) {
    var methoduoerangerow = $(this);
 	var methoduoerangeobj = {};
	var vMethod = methoduoerangerow.find("[name=Method]").text();
			methoduoerangeobj['Method'] = vMethod;
			methoduoerangeobj['index'] = index;
var vParameters = methoduoerangerow.find("[name=Parameters]").text();
			methoduoerangeobj['Parameters'] = vParameters;
			methoduoerangeobj['index'] = index;
var vReturnType = methoduoerangerow.find("[name=ReturnType]").text();
			methoduoerangeobj['ReturnType'] = vReturnType;
			methoduoerangeobj['index'] = index;
var vDescription = methoduoerangerow.find("[name=Description]").text();
			methoduoerangeobj['Description'] = vDescription;
			methoduoerangeobj['index'] = index;

	methoduoerangedata.push(methoduoerangeobj);
});
return methoduoerangedata;
	}
function getRowstbluoerangeslider(){
	var tbluoerangesliderdata = [];
	tbluoerangesliderrows = $("#tbluoerangeslider tbody tr");
tbluoerangesliderrows.each(function (index) {
    var tbluoerangesliderrow = $(this);
 	var tbluoerangesliderobj = {};
	var vProperty = tbluoerangesliderrow.find("[name=Property]").text();
			tbluoerangesliderobj['Property'] = vProperty;
			tbluoerangesliderobj['index'] = index;
var vType = tbluoerangesliderrow.find("[name=Type]").text();
			tbluoerangesliderobj['Type'] = vType;
			tbluoerangesliderobj['index'] = index;
var vDefaultValue = tbluoerangesliderrow.find("[name=DefaultValue]").text();
			tbluoerangesliderobj['DefaultValue'] = vDefaultValue;
			tbluoerangesliderobj['index'] = index;
var vDescription = tbluoerangesliderrow.find("[name=Description]").text();
			tbluoerangesliderobj['Description'] = vDescription;
			tbluoerangesliderobj['index'] = index;

	tbluoerangesliderdata.push(tbluoerangesliderobj);
});
return tbluoerangesliderdata;
	}
function getRowsmethoduoerangeslider(){
	var methoduoerangesliderdata = [];
	methoduoerangesliderrows = $("#methoduoerangeslider tbody tr");
methoduoerangesliderrows.each(function (index) {
    var methoduoerangesliderrow = $(this);
 	var methoduoerangesliderobj = {};
	var vMethod = methoduoerangesliderrow.find("[name=Method]").text();
			methoduoerangesliderobj['Method'] = vMethod;
			methoduoerangesliderobj['index'] = index;
var vParameters = methoduoerangesliderrow.find("[name=Parameters]").text();
			methoduoerangesliderobj['Parameters'] = vParameters;
			methoduoerangesliderobj['index'] = index;
var vReturnType = methoduoerangesliderrow.find("[name=ReturnType]").text();
			methoduoerangesliderobj['ReturnType'] = vReturnType;
			methoduoerangesliderobj['index'] = index;
var vDescription = methoduoerangesliderrow.find("[name=Description]").text();
			methoduoerangesliderobj['Description'] = vDescription;
			methoduoerangesliderobj['index'] = index;

	methoduoerangesliderdata.push(methoduoerangesliderobj);
});
return methoduoerangesliderdata;
	}
function getRowstbluoeribbon(){
	var tbluoeribbondata = [];
	tbluoeribbonrows = $("#tbluoeribbon tbody tr");
tbluoeribbonrows.each(function (index) {
    var tbluoeribbonrow = $(this);
 	var tbluoeribbonobj = {};
	var vProperty = tbluoeribbonrow.find("[name=Property]").text();
			tbluoeribbonobj['Property'] = vProperty;
			tbluoeribbonobj['index'] = index;
var vType = tbluoeribbonrow.find("[name=Type]").text();
			tbluoeribbonobj['Type'] = vType;
			tbluoeribbonobj['index'] = index;
var vDefaultValue = tbluoeribbonrow.find("[name=DefaultValue]").text();
			tbluoeribbonobj['DefaultValue'] = vDefaultValue;
			tbluoeribbonobj['index'] = index;
var vDescription = tbluoeribbonrow.find("[name=Description]").text();
			tbluoeribbonobj['Description'] = vDescription;
			tbluoeribbonobj['index'] = index;

	tbluoeribbondata.push(tbluoeribbonobj);
});
return tbluoeribbondata;
	}
function getRowsmethoduoeribbon(){
	var methoduoeribbondata = [];
	methoduoeribbonrows = $("#methoduoeribbon tbody tr");
methoduoeribbonrows.each(function (index) {
    var methoduoeribbonrow = $(this);
 	var methoduoeribbonobj = {};
	var vMethod = methoduoeribbonrow.find("[name=Method]").text();
			methoduoeribbonobj['Method'] = vMethod;
			methoduoeribbonobj['index'] = index;
var vParameters = methoduoeribbonrow.find("[name=Parameters]").text();
			methoduoeribbonobj['Parameters'] = vParameters;
			methoduoeribbonobj['index'] = index;
var vReturnType = methoduoeribbonrow.find("[name=ReturnType]").text();
			methoduoeribbonobj['ReturnType'] = vReturnType;
			methoduoeribbonobj['index'] = index;
var vDescription = methoduoeribbonrow.find("[name=Description]").text();
			methoduoeribbonobj['Description'] = vDescription;
			methoduoeribbonobj['index'] = index;

	methoduoeribbondata.push(methoduoeribbonobj);
});
return methoduoeribbondata;
	}
function getRowstbluoerow(){
	var tbluoerowdata = [];
	tbluoerowrows = $("#tbluoerow tbody tr");
tbluoerowrows.each(function (index) {
    var tbluoerowrow = $(this);
 	var tbluoerowobj = {};
	var vProperty = tbluoerowrow.find("[name=Property]").text();
			tbluoerowobj['Property'] = vProperty;
			tbluoerowobj['index'] = index;
var vType = tbluoerowrow.find("[name=Type]").text();
			tbluoerowobj['Type'] = vType;
			tbluoerowobj['index'] = index;
var vDefaultValue = tbluoerowrow.find("[name=DefaultValue]").text();
			tbluoerowobj['DefaultValue'] = vDefaultValue;
			tbluoerowobj['index'] = index;
var vDescription = tbluoerowrow.find("[name=Description]").text();
			tbluoerowobj['Description'] = vDescription;
			tbluoerowobj['index'] = index;

	tbluoerowdata.push(tbluoerowobj);
});
return tbluoerowdata;
	}
function getRowsmethoduoerow(){
	var methoduoerowdata = [];
	methoduoerowrows = $("#methoduoerow tbody tr");
methoduoerowrows.each(function (index) {
    var methoduoerowrow = $(this);
 	var methoduoerowobj = {};
	var vMethod = methoduoerowrow.find("[name=Method]").text();
			methoduoerowobj['Method'] = vMethod;
			methoduoerowobj['index'] = index;
var vParameters = methoduoerowrow.find("[name=Parameters]").text();
			methoduoerowobj['Parameters'] = vParameters;
			methoduoerowobj['index'] = index;
var vReturnType = methoduoerowrow.find("[name=ReturnType]").text();
			methoduoerowobj['ReturnType'] = vReturnType;
			methoduoerowobj['index'] = index;
var vDescription = methoduoerowrow.find("[name=Description]").text();
			methoduoerowobj['Description'] = vDescription;
			methoduoerowobj['index'] = index;

	methoduoerowdata.push(methoduoerowobj);
});
return methoduoerowdata;
	}
function getRowstbluoesection(){
	var tbluoesectiondata = [];
	tbluoesectionrows = $("#tbluoesection tbody tr");
tbluoesectionrows.each(function (index) {
    var tbluoesectionrow = $(this);
 	var tbluoesectionobj = {};
	var vProperty = tbluoesectionrow.find("[name=Property]").text();
			tbluoesectionobj['Property'] = vProperty;
			tbluoesectionobj['index'] = index;
var vType = tbluoesectionrow.find("[name=Type]").text();
			tbluoesectionobj['Type'] = vType;
			tbluoesectionobj['index'] = index;
var vDefaultValue = tbluoesectionrow.find("[name=DefaultValue]").text();
			tbluoesectionobj['DefaultValue'] = vDefaultValue;
			tbluoesectionobj['index'] = index;
var vDescription = tbluoesectionrow.find("[name=Description]").text();
			tbluoesectionobj['Description'] = vDescription;
			tbluoesectionobj['index'] = index;

	tbluoesectiondata.push(tbluoesectionobj);
});
return tbluoesectiondata;
	}
function getRowsmethoduoesection(){
	var methoduoesectiondata = [];
	methoduoesectionrows = $("#methoduoesection tbody tr");
methoduoesectionrows.each(function (index) {
    var methoduoesectionrow = $(this);
 	var methoduoesectionobj = {};
	var vMethod = methoduoesectionrow.find("[name=Method]").text();
			methoduoesectionobj['Method'] = vMethod;
			methoduoesectionobj['index'] = index;
var vParameters = methoduoesectionrow.find("[name=Parameters]").text();
			methoduoesectionobj['Parameters'] = vParameters;
			methoduoesectionobj['index'] = index;
var vReturnType = methoduoesectionrow.find("[name=ReturnType]").text();
			methoduoesectionobj['ReturnType'] = vReturnType;
			methoduoesectionobj['index'] = index;
var vDescription = methoduoesectionrow.find("[name=Description]").text();
			methoduoesectionobj['Description'] = vDescription;
			methoduoesectionobj['index'] = index;

	methoduoesectiondata.push(methoduoesectionobj);
});
return methoduoesectiondata;
	}
function getRowstbluoeselect(){
	var tbluoeselectdata = [];
	tbluoeselectrows = $("#tbluoeselect tbody tr");
tbluoeselectrows.each(function (index) {
    var tbluoeselectrow = $(this);
 	var tbluoeselectobj = {};
	var vProperty = tbluoeselectrow.find("[name=Property]").text();
			tbluoeselectobj['Property'] = vProperty;
			tbluoeselectobj['index'] = index;
var vType = tbluoeselectrow.find("[name=Type]").text();
			tbluoeselectobj['Type'] = vType;
			tbluoeselectobj['index'] = index;
var vDefaultValue = tbluoeselectrow.find("[name=DefaultValue]").text();
			tbluoeselectobj['DefaultValue'] = vDefaultValue;
			tbluoeselectobj['index'] = index;
var vDescription = tbluoeselectrow.find("[name=Description]").text();
			tbluoeselectobj['Description'] = vDescription;
			tbluoeselectobj['index'] = index;

	tbluoeselectdata.push(tbluoeselectobj);
});
return tbluoeselectdata;
	}
function getRowsmethoduoeselect(){
	var methoduoeselectdata = [];
	methoduoeselectrows = $("#methoduoeselect tbody tr");
methoduoeselectrows.each(function (index) {
    var methoduoeselectrow = $(this);
 	var methoduoeselectobj = {};
	var vMethod = methoduoeselectrow.find("[name=Method]").text();
			methoduoeselectobj['Method'] = vMethod;
			methoduoeselectobj['index'] = index;
var vParameters = methoduoeselectrow.find("[name=Parameters]").text();
			methoduoeselectobj['Parameters'] = vParameters;
			methoduoeselectobj['index'] = index;
var vReturnType = methoduoeselectrow.find("[name=ReturnType]").text();
			methoduoeselectobj['ReturnType'] = vReturnType;
			methoduoeselectobj['index'] = index;
var vDescription = methoduoeselectrow.find("[name=Description]").text();
			methoduoeselectobj['Description'] = vDescription;
			methoduoeselectobj['index'] = index;

	methoduoeselectdata.push(methoduoeselectobj);
});
return methoduoeselectdata;
	}
function getRowstbluoesidebar(){
	var tbluoesidebardata = [];
	tbluoesidebarrows = $("#tbluoesidebar tbody tr");
tbluoesidebarrows.each(function (index) {
    var tbluoesidebarrow = $(this);
 	var tbluoesidebarobj = {};
	var vProperty = tbluoesidebarrow.find("[name=Property]").text();
			tbluoesidebarobj['Property'] = vProperty;
			tbluoesidebarobj['index'] = index;
var vType = tbluoesidebarrow.find("[name=Type]").text();
			tbluoesidebarobj['Type'] = vType;
			tbluoesidebarobj['index'] = index;
var vDefaultValue = tbluoesidebarrow.find("[name=DefaultValue]").text();
			tbluoesidebarobj['DefaultValue'] = vDefaultValue;
			tbluoesidebarobj['index'] = index;
var vDescription = tbluoesidebarrow.find("[name=Description]").text();
			tbluoesidebarobj['Description'] = vDescription;
			tbluoesidebarobj['index'] = index;

	tbluoesidebardata.push(tbluoesidebarobj);
});
return tbluoesidebardata;
	}
function getRowsmethoduoesidebar(){
	var methoduoesidebardata = [];
	methoduoesidebarrows = $("#methoduoesidebar tbody tr");
methoduoesidebarrows.each(function (index) {
    var methoduoesidebarrow = $(this);
 	var methoduoesidebarobj = {};
	var vMethod = methoduoesidebarrow.find("[name=Method]").text();
			methoduoesidebarobj['Method'] = vMethod;
			methoduoesidebarobj['index'] = index;
var vParameters = methoduoesidebarrow.find("[name=Parameters]").text();
			methoduoesidebarobj['Parameters'] = vParameters;
			methoduoesidebarobj['index'] = index;
var vReturnType = methoduoesidebarrow.find("[name=ReturnType]").text();
			methoduoesidebarobj['ReturnType'] = vReturnType;
			methoduoesidebarobj['index'] = index;
var vDescription = methoduoesidebarrow.find("[name=Description]").text();
			methoduoesidebarobj['Description'] = vDescription;
			methoduoesidebarobj['index'] = index;

	methoduoesidebardata.push(methoduoesidebarobj);
});
return methoduoesidebardata;
	}
function getRowstbluoeslider(){
	var tbluoesliderdata = [];
	tbluoesliderrows = $("#tbluoeslider tbody tr");
tbluoesliderrows.each(function (index) {
    var tbluoesliderrow = $(this);
 	var tbluoesliderobj = {};
	var vProperty = tbluoesliderrow.find("[name=Property]").text();
			tbluoesliderobj['Property'] = vProperty;
			tbluoesliderobj['index'] = index;
var vType = tbluoesliderrow.find("[name=Type]").text();
			tbluoesliderobj['Type'] = vType;
			tbluoesliderobj['index'] = index;
var vDefaultValue = tbluoesliderrow.find("[name=DefaultValue]").text();
			tbluoesliderobj['DefaultValue'] = vDefaultValue;
			tbluoesliderobj['index'] = index;
var vDescription = tbluoesliderrow.find("[name=Description]").text();
			tbluoesliderobj['Description'] = vDescription;
			tbluoesliderobj['index'] = index;

	tbluoesliderdata.push(tbluoesliderobj);
});
return tbluoesliderdata;
	}
function getRowsmethoduoeslider(){
	var methoduoesliderdata = [];
	methoduoesliderrows = $("#methoduoeslider tbody tr");
methoduoesliderrows.each(function (index) {
    var methoduoesliderrow = $(this);
 	var methoduoesliderobj = {};
	var vMethod = methoduoesliderrow.find("[name=Method]").text();
			methoduoesliderobj['Method'] = vMethod;
			methoduoesliderobj['index'] = index;
var vParameters = methoduoesliderrow.find("[name=Parameters]").text();
			methoduoesliderobj['Parameters'] = vParameters;
			methoduoesliderobj['index'] = index;
var vReturnType = methoduoesliderrow.find("[name=ReturnType]").text();
			methoduoesliderobj['ReturnType'] = vReturnType;
			methoduoesliderobj['index'] = index;
var vDescription = methoduoesliderrow.find("[name=Description]").text();
			methoduoesliderobj['Description'] = vDescription;
			methoduoesliderobj['index'] = index;

	methoduoesliderdata.push(methoduoesliderobj);
});
return methoduoesliderdata;
	}
function getRowstbluoesocialshare(){
	var tbluoesocialsharedata = [];
	tbluoesocialsharerows = $("#tbluoesocialshare tbody tr");
tbluoesocialsharerows.each(function (index) {
    var tbluoesocialsharerow = $(this);
 	var tbluoesocialshareobj = {};
	var vProperty = tbluoesocialsharerow.find("[name=Property]").text();
			tbluoesocialshareobj['Property'] = vProperty;
			tbluoesocialshareobj['index'] = index;
var vType = tbluoesocialsharerow.find("[name=Type]").text();
			tbluoesocialshareobj['Type'] = vType;
			tbluoesocialshareobj['index'] = index;
var vDefaultValue = tbluoesocialsharerow.find("[name=DefaultValue]").text();
			tbluoesocialshareobj['DefaultValue'] = vDefaultValue;
			tbluoesocialshareobj['index'] = index;
var vDescription = tbluoesocialsharerow.find("[name=Description]").text();
			tbluoesocialshareobj['Description'] = vDescription;
			tbluoesocialshareobj['index'] = index;

	tbluoesocialsharedata.push(tbluoesocialshareobj);
});
return tbluoesocialsharedata;
	}
function getRowsmethoduoesocialshare(){
	var methoduoesocialsharedata = [];
	methoduoesocialsharerows = $("#methoduoesocialshare tbody tr");
methoduoesocialsharerows.each(function (index) {
    var methoduoesocialsharerow = $(this);
 	var methoduoesocialshareobj = {};
	var vMethod = methoduoesocialsharerow.find("[name=Method]").text();
			methoduoesocialshareobj['Method'] = vMethod;
			methoduoesocialshareobj['index'] = index;
var vParameters = methoduoesocialsharerow.find("[name=Parameters]").text();
			methoduoesocialshareobj['Parameters'] = vParameters;
			methoduoesocialshareobj['index'] = index;
var vReturnType = methoduoesocialsharerow.find("[name=ReturnType]").text();
			methoduoesocialshareobj['ReturnType'] = vReturnType;
			methoduoesocialshareobj['index'] = index;
var vDescription = methoduoesocialsharerow.find("[name=Description]").text();
			methoduoesocialshareobj['Description'] = vDescription;
			methoduoesocialshareobj['index'] = index;

	methoduoesocialsharedata.push(methoduoesocialshareobj);
});
return methoduoesocialsharedata;
	}
function getRowstbluoespan(){
	var tbluoespandata = [];
	tbluoespanrows = $("#tbluoespan tbody tr");
tbluoespanrows.each(function (index) {
    var tbluoespanrow = $(this);
 	var tbluoespanobj = {};
	var vProperty = tbluoespanrow.find("[name=Property]").text();
			tbluoespanobj['Property'] = vProperty;
			tbluoespanobj['index'] = index;
var vType = tbluoespanrow.find("[name=Type]").text();
			tbluoespanobj['Type'] = vType;
			tbluoespanobj['index'] = index;
var vDefaultValue = tbluoespanrow.find("[name=DefaultValue]").text();
			tbluoespanobj['DefaultValue'] = vDefaultValue;
			tbluoespanobj['index'] = index;
var vDescription = tbluoespanrow.find("[name=Description]").text();
			tbluoespanobj['Description'] = vDescription;
			tbluoespanobj['index'] = index;

	tbluoespandata.push(tbluoespanobj);
});
return tbluoespandata;
	}
function getRowsmethoduoespan(){
	var methoduoespandata = [];
	methoduoespanrows = $("#methoduoespan tbody tr");
methoduoespanrows.each(function (index) {
    var methoduoespanrow = $(this);
 	var methoduoespanobj = {};
	var vMethod = methoduoespanrow.find("[name=Method]").text();
			methoduoespanobj['Method'] = vMethod;
			methoduoespanobj['index'] = index;
var vParameters = methoduoespanrow.find("[name=Parameters]").text();
			methoduoespanobj['Parameters'] = vParameters;
			methoduoespanobj['index'] = index;
var vReturnType = methoduoespanrow.find("[name=ReturnType]").text();
			methoduoespanobj['ReturnType'] = vReturnType;
			methoduoespanobj['index'] = index;
var vDescription = methoduoespanrow.find("[name=Description]").text();
			methoduoespanobj['Description'] = vDescription;
			methoduoespanobj['index'] = index;

	methoduoespandata.push(methoduoespanobj);
});
return methoduoespandata;
	}
function getRowstbluoesplitflap(){
	var tbluoesplitflapdata = [];
	tbluoesplitflaprows = $("#tbluoesplitflap tbody tr");
tbluoesplitflaprows.each(function (index) {
    var tbluoesplitflaprow = $(this);
 	var tbluoesplitflapobj = {};
	var vProperty = tbluoesplitflaprow.find("[name=Property]").text();
			tbluoesplitflapobj['Property'] = vProperty;
			tbluoesplitflapobj['index'] = index;
var vType = tbluoesplitflaprow.find("[name=Type]").text();
			tbluoesplitflapobj['Type'] = vType;
			tbluoesplitflapobj['index'] = index;
var vDefaultValue = tbluoesplitflaprow.find("[name=DefaultValue]").text();
			tbluoesplitflapobj['DefaultValue'] = vDefaultValue;
			tbluoesplitflapobj['index'] = index;
var vDescription = tbluoesplitflaprow.find("[name=Description]").text();
			tbluoesplitflapobj['Description'] = vDescription;
			tbluoesplitflapobj['index'] = index;

	tbluoesplitflapdata.push(tbluoesplitflapobj);
});
return tbluoesplitflapdata;
	}
function getRowsmethoduoesplitflap(){
	var methoduoesplitflapdata = [];
	methoduoesplitflaprows = $("#methoduoesplitflap tbody tr");
methoduoesplitflaprows.each(function (index) {
    var methoduoesplitflaprow = $(this);
 	var methoduoesplitflapobj = {};
	var vMethod = methoduoesplitflaprow.find("[name=Method]").text();
			methoduoesplitflapobj['Method'] = vMethod;
			methoduoesplitflapobj['index'] = index;
var vParameters = methoduoesplitflaprow.find("[name=Parameters]").text();
			methoduoesplitflapobj['Parameters'] = vParameters;
			methoduoesplitflapobj['index'] = index;
var vReturnType = methoduoesplitflaprow.find("[name=ReturnType]").text();
			methoduoesplitflapobj['ReturnType'] = vReturnType;
			methoduoesplitflapobj['index'] = index;
var vDescription = methoduoesplitflaprow.find("[name=Description]").text();
			methoduoesplitflapobj['Description'] = vDescription;
			methoduoesplitflapobj['index'] = index;

	methoduoesplitflapdata.push(methoduoesplitflapobj);
});
return methoduoesplitflapdata;
	}
function getRowstbluoesquire(){
	var tbluoesquiredata = [];
	tbluoesquirerows = $("#tbluoesquire tbody tr");
tbluoesquirerows.each(function (index) {
    var tbluoesquirerow = $(this);
 	var tbluoesquireobj = {};
	var vProperty = tbluoesquirerow.find("[name=Property]").text();
			tbluoesquireobj['Property'] = vProperty;
			tbluoesquireobj['index'] = index;
var vType = tbluoesquirerow.find("[name=Type]").text();
			tbluoesquireobj['Type'] = vType;
			tbluoesquireobj['index'] = index;
var vDefaultValue = tbluoesquirerow.find("[name=DefaultValue]").text();
			tbluoesquireobj['DefaultValue'] = vDefaultValue;
			tbluoesquireobj['index'] = index;
var vDescription = tbluoesquirerow.find("[name=Description]").text();
			tbluoesquireobj['Description'] = vDescription;
			tbluoesquireobj['index'] = index;

	tbluoesquiredata.push(tbluoesquireobj);
});
return tbluoesquiredata;
	}
function getRowsmethoduoesquire(){
	var methoduoesquiredata = [];
	methoduoesquirerows = $("#methoduoesquire tbody tr");
methoduoesquirerows.each(function (index) {
    var methoduoesquirerow = $(this);
 	var methoduoesquireobj = {};
	var vMethod = methoduoesquirerow.find("[name=Method]").text();
			methoduoesquireobj['Method'] = vMethod;
			methoduoesquireobj['index'] = index;
var vParameters = methoduoesquirerow.find("[name=Parameters]").text();
			methoduoesquireobj['Parameters'] = vParameters;
			methoduoesquireobj['index'] = index;
var vReturnType = methoduoesquirerow.find("[name=ReturnType]").text();
			methoduoesquireobj['ReturnType'] = vReturnType;
			methoduoesquireobj['index'] = index;
var vDescription = methoduoesquirerow.find("[name=Description]").text();
			methoduoesquireobj['Description'] = vDescription;
			methoduoesquireobj['index'] = index;

	methoduoesquiredata.push(methoduoesquireobj);
});
return methoduoesquiredata;
	}
function getRowstbluoesubway(){
	var tbluoesubwaydata = [];
	tbluoesubwayrows = $("#tbluoesubway tbody tr");
tbluoesubwayrows.each(function (index) {
    var tbluoesubwayrow = $(this);
 	var tbluoesubwayobj = {};
	var vProperty = tbluoesubwayrow.find("[name=Property]").text();
			tbluoesubwayobj['Property'] = vProperty;
			tbluoesubwayobj['index'] = index;
var vType = tbluoesubwayrow.find("[name=Type]").text();
			tbluoesubwayobj['Type'] = vType;
			tbluoesubwayobj['index'] = index;
var vDefaultValue = tbluoesubwayrow.find("[name=DefaultValue]").text();
			tbluoesubwayobj['DefaultValue'] = vDefaultValue;
			tbluoesubwayobj['index'] = index;
var vDescription = tbluoesubwayrow.find("[name=Description]").text();
			tbluoesubwayobj['Description'] = vDescription;
			tbluoesubwayobj['index'] = index;

	tbluoesubwaydata.push(tbluoesubwayobj);
});
return tbluoesubwaydata;
	}
function getRowsmethoduoesubway(){
	var methoduoesubwaydata = [];
	methoduoesubwayrows = $("#methoduoesubway tbody tr");
methoduoesubwayrows.each(function (index) {
    var methoduoesubwayrow = $(this);
 	var methoduoesubwayobj = {};
	var vMethod = methoduoesubwayrow.find("[name=Method]").text();
			methoduoesubwayobj['Method'] = vMethod;
			methoduoesubwayobj['index'] = index;
var vParameters = methoduoesubwayrow.find("[name=Parameters]").text();
			methoduoesubwayobj['Parameters'] = vParameters;
			methoduoesubwayobj['index'] = index;
var vReturnType = methoduoesubwayrow.find("[name=ReturnType]").text();
			methoduoesubwayobj['ReturnType'] = vReturnType;
			methoduoesubwayobj['index'] = index;
var vDescription = methoduoesubwayrow.find("[name=Description]").text();
			methoduoesubwayobj['Description'] = vDescription;
			methoduoesubwayobj['index'] = index;

	methoduoesubwaydata.push(methoduoesubwayobj);
});
return methoduoesubwaydata;
	}
function getRowstbluoesubwayitem(){
	var tbluoesubwayitemdata = [];
	tbluoesubwayitemrows = $("#tbluoesubwayitem tbody tr");
tbluoesubwayitemrows.each(function (index) {
    var tbluoesubwayitemrow = $(this);
 	var tbluoesubwayitemobj = {};
	var vProperty = tbluoesubwayitemrow.find("[name=Property]").text();
			tbluoesubwayitemobj['Property'] = vProperty;
			tbluoesubwayitemobj['index'] = index;
var vType = tbluoesubwayitemrow.find("[name=Type]").text();
			tbluoesubwayitemobj['Type'] = vType;
			tbluoesubwayitemobj['index'] = index;
var vDefaultValue = tbluoesubwayitemrow.find("[name=DefaultValue]").text();
			tbluoesubwayitemobj['DefaultValue'] = vDefaultValue;
			tbluoesubwayitemobj['index'] = index;
var vDescription = tbluoesubwayitemrow.find("[name=Description]").text();
			tbluoesubwayitemobj['Description'] = vDescription;
			tbluoesubwayitemobj['index'] = index;

	tbluoesubwayitemdata.push(tbluoesubwayitemobj);
});
return tbluoesubwayitemdata;
	}
function getRowsmethoduoesubwayitem(){
	var methoduoesubwayitemdata = [];
	methoduoesubwayitemrows = $("#methoduoesubwayitem tbody tr");
methoduoesubwayitemrows.each(function (index) {
    var methoduoesubwayitemrow = $(this);
 	var methoduoesubwayitemobj = {};
	var vMethod = methoduoesubwayitemrow.find("[name=Method]").text();
			methoduoesubwayitemobj['Method'] = vMethod;
			methoduoesubwayitemobj['index'] = index;
var vParameters = methoduoesubwayitemrow.find("[name=Parameters]").text();
			methoduoesubwayitemobj['Parameters'] = vParameters;
			methoduoesubwayitemobj['index'] = index;
var vReturnType = methoduoesubwayitemrow.find("[name=ReturnType]").text();
			methoduoesubwayitemobj['ReturnType'] = vReturnType;
			methoduoesubwayitemobj['index'] = index;
var vDescription = methoduoesubwayitemrow.find("[name=Description]").text();
			methoduoesubwayitemobj['Description'] = vDescription;
			methoduoesubwayitemobj['index'] = index;

	methoduoesubwayitemdata.push(methoduoesubwayitemobj);
});
return methoduoesubwayitemdata;
	}
function getRowstbluoesweetmodal(){
	var tbluoesweetmodaldata = [];
	tbluoesweetmodalrows = $("#tbluoesweetmodal tbody tr");
tbluoesweetmodalrows.each(function (index) {
    var tbluoesweetmodalrow = $(this);
 	var tbluoesweetmodalobj = {};
	var vProperty = tbluoesweetmodalrow.find("[name=Property]").text();
			tbluoesweetmodalobj['Property'] = vProperty;
			tbluoesweetmodalobj['index'] = index;
var vType = tbluoesweetmodalrow.find("[name=Type]").text();
			tbluoesweetmodalobj['Type'] = vType;
			tbluoesweetmodalobj['index'] = index;
var vDefaultValue = tbluoesweetmodalrow.find("[name=DefaultValue]").text();
			tbluoesweetmodalobj['DefaultValue'] = vDefaultValue;
			tbluoesweetmodalobj['index'] = index;
var vDescription = tbluoesweetmodalrow.find("[name=Description]").text();
			tbluoesweetmodalobj['Description'] = vDescription;
			tbluoesweetmodalobj['index'] = index;

	tbluoesweetmodaldata.push(tbluoesweetmodalobj);
});
return tbluoesweetmodaldata;
	}
function getRowsmethoduoesweetmodal(){
	var methoduoesweetmodaldata = [];
	methoduoesweetmodalrows = $("#methoduoesweetmodal tbody tr");
methoduoesweetmodalrows.each(function (index) {
    var methoduoesweetmodalrow = $(this);
 	var methoduoesweetmodalobj = {};
	var vMethod = methoduoesweetmodalrow.find("[name=Method]").text();
			methoduoesweetmodalobj['Method'] = vMethod;
			methoduoesweetmodalobj['index'] = index;
var vParameters = methoduoesweetmodalrow.find("[name=Parameters]").text();
			methoduoesweetmodalobj['Parameters'] = vParameters;
			methoduoesweetmodalobj['index'] = index;
var vReturnType = methoduoesweetmodalrow.find("[name=ReturnType]").text();
			methoduoesweetmodalobj['ReturnType'] = vReturnType;
			methoduoesweetmodalobj['index'] = index;
var vDescription = methoduoesweetmodalrow.find("[name=Description]").text();
			methoduoesweetmodalobj['Description'] = vDescription;
			methoduoesweetmodalobj['index'] = index;

	methoduoesweetmodaldata.push(methoduoesweetmodalobj);
});
return methoduoesweetmodaldata;
	}
function getRowstbluoeswitch(){
	var tbluoeswitchdata = [];
	tbluoeswitchrows = $("#tbluoeswitch tbody tr");
tbluoeswitchrows.each(function (index) {
    var tbluoeswitchrow = $(this);
 	var tbluoeswitchobj = {};
	var vProperty = tbluoeswitchrow.find("[name=Property]").text();
			tbluoeswitchobj['Property'] = vProperty;
			tbluoeswitchobj['index'] = index;
var vType = tbluoeswitchrow.find("[name=Type]").text();
			tbluoeswitchobj['Type'] = vType;
			tbluoeswitchobj['index'] = index;
var vDefaultValue = tbluoeswitchrow.find("[name=DefaultValue]").text();
			tbluoeswitchobj['DefaultValue'] = vDefaultValue;
			tbluoeswitchobj['index'] = index;
var vDescription = tbluoeswitchrow.find("[name=Description]").text();
			tbluoeswitchobj['Description'] = vDescription;
			tbluoeswitchobj['index'] = index;

	tbluoeswitchdata.push(tbluoeswitchobj);
});
return tbluoeswitchdata;
	}
function getRowsmethoduoeswitch(){
	var methoduoeswitchdata = [];
	methoduoeswitchrows = $("#methoduoeswitch tbody tr");
methoduoeswitchrows.each(function (index) {
    var methoduoeswitchrow = $(this);
 	var methoduoeswitchobj = {};
	var vMethod = methoduoeswitchrow.find("[name=Method]").text();
			methoduoeswitchobj['Method'] = vMethod;
			methoduoeswitchobj['index'] = index;
var vParameters = methoduoeswitchrow.find("[name=Parameters]").text();
			methoduoeswitchobj['Parameters'] = vParameters;
			methoduoeswitchobj['index'] = index;
var vReturnType = methoduoeswitchrow.find("[name=ReturnType]").text();
			methoduoeswitchobj['ReturnType'] = vReturnType;
			methoduoeswitchobj['index'] = index;
var vDescription = methoduoeswitchrow.find("[name=Description]").text();
			methoduoeswitchobj['Description'] = vDescription;
			methoduoeswitchobj['index'] = index;

	methoduoeswitchdata.push(methoduoeswitchobj);
});
return methoduoeswitchdata;
	}
function getRowstbluoetable(){
	var tbluoetabledata = [];
	tbluoetablerows = $("#tbluoetable tbody tr");
tbluoetablerows.each(function (index) {
    var tbluoetablerow = $(this);
 	var tbluoetableobj = {};
	var vProperty = tbluoetablerow.find("[name=Property]").text();
			tbluoetableobj['Property'] = vProperty;
			tbluoetableobj['index'] = index;
var vType = tbluoetablerow.find("[name=Type]").text();
			tbluoetableobj['Type'] = vType;
			tbluoetableobj['index'] = index;
var vDefaultValue = tbluoetablerow.find("[name=DefaultValue]").text();
			tbluoetableobj['DefaultValue'] = vDefaultValue;
			tbluoetableobj['index'] = index;
var vDescription = tbluoetablerow.find("[name=Description]").text();
			tbluoetableobj['Description'] = vDescription;
			tbluoetableobj['index'] = index;

	tbluoetabledata.push(tbluoetableobj);
});
return tbluoetabledata;
	}
function getRowsmethoduoetable(){
	var methoduoetabledata = [];
	methoduoetablerows = $("#methoduoetable tbody tr");
methoduoetablerows.each(function (index) {
    var methoduoetablerow = $(this);
 	var methoduoetableobj = {};
	var vMethod = methoduoetablerow.find("[name=Method]").text();
			methoduoetableobj['Method'] = vMethod;
			methoduoetableobj['index'] = index;
var vParameters = methoduoetablerow.find("[name=Parameters]").text();
			methoduoetableobj['Parameters'] = vParameters;
			methoduoetableobj['index'] = index;
var vReturnType = methoduoetablerow.find("[name=ReturnType]").text();
			methoduoetableobj['ReturnType'] = vReturnType;
			methoduoetableobj['index'] = index;
var vDescription = methoduoetablerow.find("[name=Description]").text();
			methoduoetableobj['Description'] = vDescription;
			methoduoetableobj['index'] = index;

	methoduoetabledata.push(methoduoetableobj);
});
return methoduoetabledata;
	}
function getRowstbluoetableexport(){
	var tbluoetableexportdata = [];
	tbluoetableexportrows = $("#tbluoetableexport tbody tr");
tbluoetableexportrows.each(function (index) {
    var tbluoetableexportrow = $(this);
 	var tbluoetableexportobj = {};
	var vProperty = tbluoetableexportrow.find("[name=Property]").text();
			tbluoetableexportobj['Property'] = vProperty;
			tbluoetableexportobj['index'] = index;
var vType = tbluoetableexportrow.find("[name=Type]").text();
			tbluoetableexportobj['Type'] = vType;
			tbluoetableexportobj['index'] = index;
var vDefaultValue = tbluoetableexportrow.find("[name=DefaultValue]").text();
			tbluoetableexportobj['DefaultValue'] = vDefaultValue;
			tbluoetableexportobj['index'] = index;
var vDescription = tbluoetableexportrow.find("[name=Description]").text();
			tbluoetableexportobj['Description'] = vDescription;
			tbluoetableexportobj['index'] = index;

	tbluoetableexportdata.push(tbluoetableexportobj);
});
return tbluoetableexportdata;
	}
function getRowsmethoduoetableexport(){
	var methoduoetableexportdata = [];
	methoduoetableexportrows = $("#methoduoetableexport tbody tr");
methoduoetableexportrows.each(function (index) {
    var methoduoetableexportrow = $(this);
 	var methoduoetableexportobj = {};
	var vMethod = methoduoetableexportrow.find("[name=Method]").text();
			methoduoetableexportobj['Method'] = vMethod;
			methoduoetableexportobj['index'] = index;
var vParameters = methoduoetableexportrow.find("[name=Parameters]").text();
			methoduoetableexportobj['Parameters'] = vParameters;
			methoduoetableexportobj['index'] = index;
var vReturnType = methoduoetableexportrow.find("[name=ReturnType]").text();
			methoduoetableexportobj['ReturnType'] = vReturnType;
			methoduoetableexportobj['index'] = index;
var vDescription = methoduoetableexportrow.find("[name=Description]").text();
			methoduoetableexportobj['Description'] = vDescription;
			methoduoetableexportobj['index'] = index;

	methoduoetableexportdata.push(methoduoetableexportobj);
});
return methoduoetableexportdata;
	}
function getRowstbluoetabs(){
	var tbluoetabsdata = [];
	tbluoetabsrows = $("#tbluoetabs tbody tr");
tbluoetabsrows.each(function (index) {
    var tbluoetabsrow = $(this);
 	var tbluoetabsobj = {};
	var vProperty = tbluoetabsrow.find("[name=Property]").text();
			tbluoetabsobj['Property'] = vProperty;
			tbluoetabsobj['index'] = index;
var vType = tbluoetabsrow.find("[name=Type]").text();
			tbluoetabsobj['Type'] = vType;
			tbluoetabsobj['index'] = index;
var vDefaultValue = tbluoetabsrow.find("[name=DefaultValue]").text();
			tbluoetabsobj['DefaultValue'] = vDefaultValue;
			tbluoetabsobj['index'] = index;
var vDescription = tbluoetabsrow.find("[name=Description]").text();
			tbluoetabsobj['Description'] = vDescription;
			tbluoetabsobj['index'] = index;

	tbluoetabsdata.push(tbluoetabsobj);
});
return tbluoetabsdata;
	}
function getRowsmethoduoetabs(){
	var methoduoetabsdata = [];
	methoduoetabsrows = $("#methoduoetabs tbody tr");
methoduoetabsrows.each(function (index) {
    var methoduoetabsrow = $(this);
 	var methoduoetabsobj = {};
	var vMethod = methoduoetabsrow.find("[name=Method]").text();
			methoduoetabsobj['Method'] = vMethod;
			methoduoetabsobj['index'] = index;
var vParameters = methoduoetabsrow.find("[name=Parameters]").text();
			methoduoetabsobj['Parameters'] = vParameters;
			methoduoetabsobj['index'] = index;
var vReturnType = methoduoetabsrow.find("[name=ReturnType]").text();
			methoduoetabsobj['ReturnType'] = vReturnType;
			methoduoetabsobj['index'] = index;
var vDescription = methoduoetabsrow.find("[name=Description]").text();
			methoduoetabsobj['Description'] = vDescription;
			methoduoetabsobj['index'] = index;

	methoduoetabsdata.push(methoduoetabsobj);
});
return methoduoetabsdata;
	}
function getRowstbluoethemes(){
	var tbluoethemesdata = [];
	tbluoethemesrows = $("#tbluoethemes tbody tr");
tbluoethemesrows.each(function (index) {
    var tbluoethemesrow = $(this);
 	var tbluoethemesobj = {};
	var vProperty = tbluoethemesrow.find("[name=Property]").text();
			tbluoethemesobj['Property'] = vProperty;
			tbluoethemesobj['index'] = index;
var vType = tbluoethemesrow.find("[name=Type]").text();
			tbluoethemesobj['Type'] = vType;
			tbluoethemesobj['index'] = index;
var vDefaultValue = tbluoethemesrow.find("[name=DefaultValue]").text();
			tbluoethemesobj['DefaultValue'] = vDefaultValue;
			tbluoethemesobj['index'] = index;
var vDescription = tbluoethemesrow.find("[name=Description]").text();
			tbluoethemesobj['Description'] = vDescription;
			tbluoethemesobj['index'] = index;

	tbluoethemesdata.push(tbluoethemesobj);
});
return tbluoethemesdata;
	}
function getRowsmethoduoethemes(){
	var methoduoethemesdata = [];
	methoduoethemesrows = $("#methoduoethemes tbody tr");
methoduoethemesrows.each(function (index) {
    var methoduoethemesrow = $(this);
 	var methoduoethemesobj = {};
	var vMethod = methoduoethemesrow.find("[name=Method]").text();
			methoduoethemesobj['Method'] = vMethod;
			methoduoethemesobj['index'] = index;
var vParameters = methoduoethemesrow.find("[name=Parameters]").text();
			methoduoethemesobj['Parameters'] = vParameters;
			methoduoethemesobj['index'] = index;
var vReturnType = methoduoethemesrow.find("[name=ReturnType]").text();
			methoduoethemesobj['ReturnType'] = vReturnType;
			methoduoethemesobj['index'] = index;
var vDescription = methoduoethemesrow.find("[name=Description]").text();
			methoduoethemesobj['Description'] = vDescription;
			methoduoethemesobj['index'] = index;

	methoduoethemesdata.push(methoduoethemesobj);
});
return methoduoethemesdata;
	}
function getRowstbluoetoast(){
	var tbluoetoastdata = [];
	tbluoetoastrows = $("#tbluoetoast tbody tr");
tbluoetoastrows.each(function (index) {
    var tbluoetoastrow = $(this);
 	var tbluoetoastobj = {};
	var vProperty = tbluoetoastrow.find("[name=Property]").text();
			tbluoetoastobj['Property'] = vProperty;
			tbluoetoastobj['index'] = index;
var vType = tbluoetoastrow.find("[name=Type]").text();
			tbluoetoastobj['Type'] = vType;
			tbluoetoastobj['index'] = index;
var vDefaultValue = tbluoetoastrow.find("[name=DefaultValue]").text();
			tbluoetoastobj['DefaultValue'] = vDefaultValue;
			tbluoetoastobj['index'] = index;
var vDescription = tbluoetoastrow.find("[name=Description]").text();
			tbluoetoastobj['Description'] = vDescription;
			tbluoetoastobj['index'] = index;

	tbluoetoastdata.push(tbluoetoastobj);
});
return tbluoetoastdata;
	}
function getRowsmethoduoetoast(){
	var methoduoetoastdata = [];
	methoduoetoastrows = $("#methoduoetoast tbody tr");
methoduoetoastrows.each(function (index) {
    var methoduoetoastrow = $(this);
 	var methoduoetoastobj = {};
	var vMethod = methoduoetoastrow.find("[name=Method]").text();
			methoduoetoastobj['Method'] = vMethod;
			methoduoetoastobj['index'] = index;
var vParameters = methoduoetoastrow.find("[name=Parameters]").text();
			methoduoetoastobj['Parameters'] = vParameters;
			methoduoetoastobj['index'] = index;
var vReturnType = methoduoetoastrow.find("[name=ReturnType]").text();
			methoduoetoastobj['ReturnType'] = vReturnType;
			methoduoetoastobj['index'] = index;
var vDescription = methoduoetoastrow.find("[name=Description]").text();
			methoduoetoastobj['Description'] = vDescription;
			methoduoetoastobj['index'] = index;

	methoduoetoastdata.push(methoduoetoastobj);
});
return methoduoetoastdata;
	}
function getRowstbluoetoc(){
	var tbluoetocdata = [];
	tbluoetocrows = $("#tbluoetoc tbody tr");
tbluoetocrows.each(function (index) {
    var tbluoetocrow = $(this);
 	var tbluoetocobj = {};
	var vProperty = tbluoetocrow.find("[name=Property]").text();
			tbluoetocobj['Property'] = vProperty;
			tbluoetocobj['index'] = index;
var vType = tbluoetocrow.find("[name=Type]").text();
			tbluoetocobj['Type'] = vType;
			tbluoetocobj['index'] = index;
var vDefaultValue = tbluoetocrow.find("[name=DefaultValue]").text();
			tbluoetocobj['DefaultValue'] = vDefaultValue;
			tbluoetocobj['index'] = index;
var vDescription = tbluoetocrow.find("[name=Description]").text();
			tbluoetocobj['Description'] = vDescription;
			tbluoetocobj['index'] = index;

	tbluoetocdata.push(tbluoetocobj);
});
return tbluoetocdata;
	}
function getRowsmethoduoetoc(){
	var methoduoetocdata = [];
	methoduoetocrows = $("#methoduoetoc tbody tr");
methoduoetocrows.each(function (index) {
    var methoduoetocrow = $(this);
 	var methoduoetocobj = {};
	var vMethod = methoduoetocrow.find("[name=Method]").text();
			methoduoetocobj['Method'] = vMethod;
			methoduoetocobj['index'] = index;
var vParameters = methoduoetocrow.find("[name=Parameters]").text();
			methoduoetocobj['Parameters'] = vParameters;
			methoduoetocobj['index'] = index;
var vReturnType = methoduoetocrow.find("[name=ReturnType]").text();
			methoduoetocobj['ReturnType'] = vReturnType;
			methoduoetocobj['index'] = index;
var vDescription = methoduoetocrow.find("[name=Description]").text();
			methoduoetocobj['Description'] = vDescription;
			methoduoetocobj['index'] = index;

	methoduoetocdata.push(methoduoetocobj);
});
return methoduoetocdata;
	}
function getRowstbluoetoolbar(){
	var tbluoetoolbardata = [];
	tbluoetoolbarrows = $("#tbluoetoolbar tbody tr");
tbluoetoolbarrows.each(function (index) {
    var tbluoetoolbarrow = $(this);
 	var tbluoetoolbarobj = {};
	var vProperty = tbluoetoolbarrow.find("[name=Property]").text();
			tbluoetoolbarobj['Property'] = vProperty;
			tbluoetoolbarobj['index'] = index;
var vType = tbluoetoolbarrow.find("[name=Type]").text();
			tbluoetoolbarobj['Type'] = vType;
			tbluoetoolbarobj['index'] = index;
var vDefaultValue = tbluoetoolbarrow.find("[name=DefaultValue]").text();
			tbluoetoolbarobj['DefaultValue'] = vDefaultValue;
			tbluoetoolbarobj['index'] = index;
var vDescription = tbluoetoolbarrow.find("[name=Description]").text();
			tbluoetoolbarobj['Description'] = vDescription;
			tbluoetoolbarobj['index'] = index;

	tbluoetoolbardata.push(tbluoetoolbarobj);
});
return tbluoetoolbardata;
	}
function getRowsmethoduoetoolbar(){
	var methoduoetoolbardata = [];
	methoduoetoolbarrows = $("#methoduoetoolbar tbody tr");
methoduoetoolbarrows.each(function (index) {
    var methoduoetoolbarrow = $(this);
 	var methoduoetoolbarobj = {};
	var vMethod = methoduoetoolbarrow.find("[name=Method]").text();
			methoduoetoolbarobj['Method'] = vMethod;
			methoduoetoolbarobj['index'] = index;
var vParameters = methoduoetoolbarrow.find("[name=Parameters]").text();
			methoduoetoolbarobj['Parameters'] = vParameters;
			methoduoetoolbarobj['index'] = index;
var vReturnType = methoduoetoolbarrow.find("[name=ReturnType]").text();
			methoduoetoolbarobj['ReturnType'] = vReturnType;
			methoduoetoolbarobj['index'] = index;
var vDescription = methoduoetoolbarrow.find("[name=Description]").text();
			methoduoetoolbarobj['Description'] = vDescription;
			methoduoetoolbarobj['index'] = index;

	methoduoetoolbardata.push(methoduoetoolbarobj);
});
return methoduoetoolbardata;
	}
function getRowstbluoetoolbaranimation(){
	var tbluoetoolbaranimationdata = [];
	tbluoetoolbaranimationrows = $("#tbluoetoolbaranimation tbody tr");
tbluoetoolbaranimationrows.each(function (index) {
    var tbluoetoolbaranimationrow = $(this);
 	var tbluoetoolbaranimationobj = {};
	var vProperty = tbluoetoolbaranimationrow.find("[name=Property]").text();
			tbluoetoolbaranimationobj['Property'] = vProperty;
			tbluoetoolbaranimationobj['index'] = index;
var vType = tbluoetoolbaranimationrow.find("[name=Type]").text();
			tbluoetoolbaranimationobj['Type'] = vType;
			tbluoetoolbaranimationobj['index'] = index;
var vDefaultValue = tbluoetoolbaranimationrow.find("[name=DefaultValue]").text();
			tbluoetoolbaranimationobj['DefaultValue'] = vDefaultValue;
			tbluoetoolbaranimationobj['index'] = index;
var vDescription = tbluoetoolbaranimationrow.find("[name=Description]").text();
			tbluoetoolbaranimationobj['Description'] = vDescription;
			tbluoetoolbaranimationobj['index'] = index;

	tbluoetoolbaranimationdata.push(tbluoetoolbaranimationobj);
});
return tbluoetoolbaranimationdata;
	}
function getRowsmethoduoetoolbaranimation(){
	var methoduoetoolbaranimationdata = [];
	methoduoetoolbaranimationrows = $("#methoduoetoolbaranimation tbody tr");
methoduoetoolbaranimationrows.each(function (index) {
    var methoduoetoolbaranimationrow = $(this);
 	var methoduoetoolbaranimationobj = {};
	var vMethod = methoduoetoolbaranimationrow.find("[name=Method]").text();
			methoduoetoolbaranimationobj['Method'] = vMethod;
			methoduoetoolbaranimationobj['index'] = index;
var vParameters = methoduoetoolbaranimationrow.find("[name=Parameters]").text();
			methoduoetoolbaranimationobj['Parameters'] = vParameters;
			methoduoetoolbaranimationobj['index'] = index;
var vReturnType = methoduoetoolbaranimationrow.find("[name=ReturnType]").text();
			methoduoetoolbaranimationobj['ReturnType'] = vReturnType;
			methoduoetoolbaranimationobj['index'] = index;
var vDescription = methoduoetoolbaranimationrow.find("[name=Description]").text();
			methoduoetoolbaranimationobj['Description'] = vDescription;
			methoduoetoolbaranimationobj['index'] = index;

	methoduoetoolbaranimationdata.push(methoduoetoolbaranimationobj);
});
return methoduoetoolbaranimationdata;
	}
function getRowstbluoetoolbarposition(){
	var tbluoetoolbarpositiondata = [];
	tbluoetoolbarpositionrows = $("#tbluoetoolbarposition tbody tr");
tbluoetoolbarpositionrows.each(function (index) {
    var tbluoetoolbarpositionrow = $(this);
 	var tbluoetoolbarpositionobj = {};
	var vProperty = tbluoetoolbarpositionrow.find("[name=Property]").text();
			tbluoetoolbarpositionobj['Property'] = vProperty;
			tbluoetoolbarpositionobj['index'] = index;
var vType = tbluoetoolbarpositionrow.find("[name=Type]").text();
			tbluoetoolbarpositionobj['Type'] = vType;
			tbluoetoolbarpositionobj['index'] = index;
var vDefaultValue = tbluoetoolbarpositionrow.find("[name=DefaultValue]").text();
			tbluoetoolbarpositionobj['DefaultValue'] = vDefaultValue;
			tbluoetoolbarpositionobj['index'] = index;
var vDescription = tbluoetoolbarpositionrow.find("[name=Description]").text();
			tbluoetoolbarpositionobj['Description'] = vDescription;
			tbluoetoolbarpositionobj['index'] = index;

	tbluoetoolbarpositiondata.push(tbluoetoolbarpositionobj);
});
return tbluoetoolbarpositiondata;
	}
function getRowsmethoduoetoolbarposition(){
	var methoduoetoolbarpositiondata = [];
	methoduoetoolbarpositionrows = $("#methoduoetoolbarposition tbody tr");
methoduoetoolbarpositionrows.each(function (index) {
    var methoduoetoolbarpositionrow = $(this);
 	var methoduoetoolbarpositionobj = {};
	var vMethod = methoduoetoolbarpositionrow.find("[name=Method]").text();
			methoduoetoolbarpositionobj['Method'] = vMethod;
			methoduoetoolbarpositionobj['index'] = index;
var vParameters = methoduoetoolbarpositionrow.find("[name=Parameters]").text();
			methoduoetoolbarpositionobj['Parameters'] = vParameters;
			methoduoetoolbarpositionobj['index'] = index;
var vReturnType = methoduoetoolbarpositionrow.find("[name=ReturnType]").text();
			methoduoetoolbarpositionobj['ReturnType'] = vReturnType;
			methoduoetoolbarpositionobj['index'] = index;
var vDescription = methoduoetoolbarpositionrow.find("[name=Description]").text();
			methoduoetoolbarpositionobj['Description'] = vDescription;
			methoduoetoolbarpositionobj['index'] = index;

	methoduoetoolbarpositiondata.push(methoduoetoolbarpositionobj);
});
return methoduoetoolbarpositiondata;
	}
function getRowstbluoetoolbartheme(){
	var tbluoetoolbarthemedata = [];
	tbluoetoolbarthemerows = $("#tbluoetoolbartheme tbody tr");
tbluoetoolbarthemerows.each(function (index) {
    var tbluoetoolbarthemerow = $(this);
 	var tbluoetoolbarthemeobj = {};
	var vProperty = tbluoetoolbarthemerow.find("[name=Property]").text();
			tbluoetoolbarthemeobj['Property'] = vProperty;
			tbluoetoolbarthemeobj['index'] = index;
var vType = tbluoetoolbarthemerow.find("[name=Type]").text();
			tbluoetoolbarthemeobj['Type'] = vType;
			tbluoetoolbarthemeobj['index'] = index;
var vDefaultValue = tbluoetoolbarthemerow.find("[name=DefaultValue]").text();
			tbluoetoolbarthemeobj['DefaultValue'] = vDefaultValue;
			tbluoetoolbarthemeobj['index'] = index;
var vDescription = tbluoetoolbarthemerow.find("[name=Description]").text();
			tbluoetoolbarthemeobj['Description'] = vDescription;
			tbluoetoolbarthemeobj['index'] = index;

	tbluoetoolbarthemedata.push(tbluoetoolbarthemeobj);
});
return tbluoetoolbarthemedata;
	}
function getRowsmethoduoetoolbartheme(){
	var methoduoetoolbarthemedata = [];
	methoduoetoolbarthemerows = $("#methoduoetoolbartheme tbody tr");
methoduoetoolbarthemerows.each(function (index) {
    var methoduoetoolbarthemerow = $(this);
 	var methoduoetoolbarthemeobj = {};
	var vMethod = methoduoetoolbarthemerow.find("[name=Method]").text();
			methoduoetoolbarthemeobj['Method'] = vMethod;
			methoduoetoolbarthemeobj['index'] = index;
var vParameters = methoduoetoolbarthemerow.find("[name=Parameters]").text();
			methoduoetoolbarthemeobj['Parameters'] = vParameters;
			methoduoetoolbarthemeobj['index'] = index;
var vReturnType = methoduoetoolbarthemerow.find("[name=ReturnType]").text();
			methoduoetoolbarthemeobj['ReturnType'] = vReturnType;
			methoduoetoolbarthemeobj['index'] = index;
var vDescription = methoduoetoolbarthemerow.find("[name=Description]").text();
			methoduoetoolbarthemeobj['Description'] = vDescription;
			methoduoetoolbarthemeobj['index'] = index;

	methoduoetoolbarthemedata.push(methoduoetoolbarthemeobj);
});
return methoduoetoolbarthemedata;
	}
function getRowstbluoetooltip(){
	var tbluoetooltipdata = [];
	tbluoetooltiprows = $("#tbluoetooltip tbody tr");
tbluoetooltiprows.each(function (index) {
    var tbluoetooltiprow = $(this);
 	var tbluoetooltipobj = {};
	var vProperty = tbluoetooltiprow.find("[name=Property]").text();
			tbluoetooltipobj['Property'] = vProperty;
			tbluoetooltipobj['index'] = index;
var vType = tbluoetooltiprow.find("[name=Type]").text();
			tbluoetooltipobj['Type'] = vType;
			tbluoetooltipobj['index'] = index;
var vDefaultValue = tbluoetooltiprow.find("[name=DefaultValue]").text();
			tbluoetooltipobj['DefaultValue'] = vDefaultValue;
			tbluoetooltipobj['index'] = index;
var vDescription = tbluoetooltiprow.find("[name=Description]").text();
			tbluoetooltipobj['Description'] = vDescription;
			tbluoetooltipobj['index'] = index;

	tbluoetooltipdata.push(tbluoetooltipobj);
});
return tbluoetooltipdata;
	}
function getRowsmethoduoetooltip(){
	var methoduoetooltipdata = [];
	methoduoetooltiprows = $("#methoduoetooltip tbody tr");
methoduoetooltiprows.each(function (index) {
    var methoduoetooltiprow = $(this);
 	var methoduoetooltipobj = {};
	var vMethod = methoduoetooltiprow.find("[name=Method]").text();
			methoduoetooltipobj['Method'] = vMethod;
			methoduoetooltipobj['index'] = index;
var vParameters = methoduoetooltiprow.find("[name=Parameters]").text();
			methoduoetooltipobj['Parameters'] = vParameters;
			methoduoetooltipobj['index'] = index;
var vReturnType = methoduoetooltiprow.find("[name=ReturnType]").text();
			methoduoetooltipobj['ReturnType'] = vReturnType;
			methoduoetooltipobj['index'] = index;
var vDescription = methoduoetooltiprow.find("[name=Description]").text();
			methoduoetooltipobj['Description'] = vDescription;
			methoduoetooltipobj['index'] = index;

	methoduoetooltipdata.push(methoduoetooltipobj);
});
return methoduoetooltipdata;
	}
function getRowstbluoevideo(){
	var tbluoevideodata = [];
	tbluoevideorows = $("#tbluoevideo tbody tr");
tbluoevideorows.each(function (index) {
    var tbluoevideorow = $(this);
 	var tbluoevideoobj = {};
	var vProperty = tbluoevideorow.find("[name=Property]").text();
			tbluoevideoobj['Property'] = vProperty;
			tbluoevideoobj['index'] = index;
var vType = tbluoevideorow.find("[name=Type]").text();
			tbluoevideoobj['Type'] = vType;
			tbluoevideoobj['index'] = index;
var vDefaultValue = tbluoevideorow.find("[name=DefaultValue]").text();
			tbluoevideoobj['DefaultValue'] = vDefaultValue;
			tbluoevideoobj['index'] = index;
var vDescription = tbluoevideorow.find("[name=Description]").text();
			tbluoevideoobj['Description'] = vDescription;
			tbluoevideoobj['index'] = index;

	tbluoevideodata.push(tbluoevideoobj);
});
return tbluoevideodata;
	}
function getRowsmethoduoevideo(){
	var methoduoevideodata = [];
	methoduoevideorows = $("#methoduoevideo tbody tr");
methoduoevideorows.each(function (index) {
    var methoduoevideorow = $(this);
 	var methoduoevideoobj = {};
	var vMethod = methoduoevideorow.find("[name=Method]").text();
			methoduoevideoobj['Method'] = vMethod;
			methoduoevideoobj['index'] = index;
var vParameters = methoduoevideorow.find("[name=Parameters]").text();
			methoduoevideoobj['Parameters'] = vParameters;
			methoduoevideoobj['index'] = index;
var vReturnType = methoduoevideorow.find("[name=ReturnType]").text();
			methoduoevideoobj['ReturnType'] = vReturnType;
			methoduoevideoobj['index'] = index;
var vDescription = methoduoevideorow.find("[name=Description]").text();
			methoduoevideoobj['Description'] = vDescription;
			methoduoevideoobj['index'] = index;

	methoduoevideodata.push(methoduoevideoobj);
});
return methoduoevideodata;
	}
function getRowstbluoewaterball(){
	var tbluoewaterballdata = [];
	tbluoewaterballrows = $("#tbluoewaterball tbody tr");
tbluoewaterballrows.each(function (index) {
    var tbluoewaterballrow = $(this);
 	var tbluoewaterballobj = {};
	var vProperty = tbluoewaterballrow.find("[name=Property]").text();
			tbluoewaterballobj['Property'] = vProperty;
			tbluoewaterballobj['index'] = index;
var vType = tbluoewaterballrow.find("[name=Type]").text();
			tbluoewaterballobj['Type'] = vType;
			tbluoewaterballobj['index'] = index;
var vDefaultValue = tbluoewaterballrow.find("[name=DefaultValue]").text();
			tbluoewaterballobj['DefaultValue'] = vDefaultValue;
			tbluoewaterballobj['index'] = index;
var vDescription = tbluoewaterballrow.find("[name=Description]").text();
			tbluoewaterballobj['Description'] = vDescription;
			tbluoewaterballobj['index'] = index;

	tbluoewaterballdata.push(tbluoewaterballobj);
});
return tbluoewaterballdata;
	}
function getRowsmethoduoewaterball(){
	var methoduoewaterballdata = [];
	methoduoewaterballrows = $("#methoduoewaterball tbody tr");
methoduoewaterballrows.each(function (index) {
    var methoduoewaterballrow = $(this);
 	var methoduoewaterballobj = {};
	var vMethod = methoduoewaterballrow.find("[name=Method]").text();
			methoduoewaterballobj['Method'] = vMethod;
			methoduoewaterballobj['index'] = index;
var vParameters = methoduoewaterballrow.find("[name=Parameters]").text();
			methoduoewaterballobj['Parameters'] = vParameters;
			methoduoewaterballobj['index'] = index;
var vReturnType = methoduoewaterballrow.find("[name=ReturnType]").text();
			methoduoewaterballobj['ReturnType'] = vReturnType;
			methoduoewaterballobj['index'] = index;
var vDescription = methoduoewaterballrow.find("[name=Description]").text();
			methoduoewaterballobj['Description'] = vDescription;
			methoduoewaterballobj['index'] = index;

	methoduoewaterballdata.push(methoduoewaterballobj);
});
return methoduoewaterballdata;
	}
function getRowstbluoewordcloud(){
	var tbluoewordclouddata = [];
	tbluoewordcloudrows = $("#tbluoewordcloud tbody tr");
tbluoewordcloudrows.each(function (index) {
    var tbluoewordcloudrow = $(this);
 	var tbluoewordcloudobj = {};
	var vProperty = tbluoewordcloudrow.find("[name=Property]").text();
			tbluoewordcloudobj['Property'] = vProperty;
			tbluoewordcloudobj['index'] = index;
var vType = tbluoewordcloudrow.find("[name=Type]").text();
			tbluoewordcloudobj['Type'] = vType;
			tbluoewordcloudobj['index'] = index;
var vDefaultValue = tbluoewordcloudrow.find("[name=DefaultValue]").text();
			tbluoewordcloudobj['DefaultValue'] = vDefaultValue;
			tbluoewordcloudobj['index'] = index;
var vDescription = tbluoewordcloudrow.find("[name=Description]").text();
			tbluoewordcloudobj['Description'] = vDescription;
			tbluoewordcloudobj['index'] = index;

	tbluoewordclouddata.push(tbluoewordcloudobj);
});
return tbluoewordclouddata;
	}
function getRowsmethoduoewordcloud(){
	var methoduoewordclouddata = [];
	methoduoewordcloudrows = $("#methoduoewordcloud tbody tr");
methoduoewordcloudrows.each(function (index) {
    var methoduoewordcloudrow = $(this);
 	var methoduoewordcloudobj = {};
	var vMethod = methoduoewordcloudrow.find("[name=Method]").text();
			methoduoewordcloudobj['Method'] = vMethod;
			methoduoewordcloudobj['index'] = index;
var vParameters = methoduoewordcloudrow.find("[name=Parameters]").text();
			methoduoewordcloudobj['Parameters'] = vParameters;
			methoduoewordcloudobj['index'] = index;
var vReturnType = methoduoewordcloudrow.find("[name=ReturnType]").text();
			methoduoewordcloudobj['ReturnType'] = vReturnType;
			methoduoewordcloudobj['index'] = index;
var vDescription = methoduoewordcloudrow.find("[name=Description]").text();
			methoduoewordcloudobj['Description'] = vDescription;
			methoduoewordcloudobj['index'] = index;

	methoduoewordclouddata.push(methoduoewordcloudobj);
});
return methoduoewordclouddata;
	}
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var instfaqthem = document.getElementById('faqthem');
	var faqtheminst = M.Collapsible.getInstance(instfaqthem);
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
