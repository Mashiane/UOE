M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
function handleRangerange(){
	// get value of range
myrange = $('#rangeinp').val();
// show value on a toast
M.toast({html:myrange, displayLength:3000, classes:'rounded white-text green'});
	}
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var sliderslider = document.getElementById('slider');
  noUiSlider.create(sliderslider, {
   start: [10.0, 100.0],
   connect: false,
   Step: 1.0,
   orientation: 'horizontal', // 'horizontal' or 'vertical'
   range: {
     'min': 0.0,
     'max': 200.0
   },
   format: wNumb({
     decimals: 0
   })
  });
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){

});
