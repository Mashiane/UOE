
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var sliderslider = document.getElementById('slider');
  noUiSlider.create(sliderslider, {
   start: [10.0, 100.0],
   connect: false,
   Step: 1.0,
   orientation: 'horizontal', // 'horizontal' or 'vertical'
   range: {
     'min': 0.0,
     'max': 200.0
   },
   format: wNumb({
     decimals: 0
   })
  });
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
