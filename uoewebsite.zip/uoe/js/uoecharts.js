var colors = HTMLColors();
var activerow;
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
var _mbill0;
	var ambill0 = [];
	var mbill0chart = bb.generate({
	data: {x: "x",
  	columns: [["x", "2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "bar",
    types: {
data1:"bar",data2:"bar"},
    
	labels: true,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Horizontal Chart"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  size: {
    height: 400
  },
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: true,
    x: {
	  type: "category",
		categories: ["2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
      label: {
	  	text: "Period",
	  	position: "outer-center"
	  },
	  tick: {
        rotate: 0,
        multiline: false,
        tooltip: true
      },
      height: 0,
    },
    y: {
      label: {
	  	text: "Percentage",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: true
    },
    y: {
      show: true
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#mbill0"
});
$(document).on('click', '#btnimage', function(e){
	e.preventDefault();
domtoimage.toPng(document.getElementById('mbill0'))
    .then(function (dataUrl) {
        var link = document.createElement('a');
        link.download = 'mbill0.png';
        link.href = dataUrl;
		link.target = "_blank";
        link.click();
    });
});
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var _mbill1;
	var ambill1 = [];
	var mbill1chart = bb.generate({
	data: {x: "x",
  	columns: [["x", "2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "bar",
    types: {
data1:"area",data2:"area-spline"},
    
	labels: true,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Area & Area-Spline"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  size: {
    height: 400
  },
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  type: "category",
		categories: ["2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
      label: {
	  	text: "Period",
	  	position: "outer-center"
	  },
	  tick: {
        rotate: 90,
        multiline: false,
        tooltip: true
      },
      height: 100,
    },
    y: {
      label: {
	  	text: "Percentage",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: false,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#mbill1"
});
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
var _mbill2;
	var ambill2 = [];
	var mbill2chart = bb.generate({
	data: {x: "x",
  	columns: [["x", "2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "bar",
    types: {
data1:"bar",data2:"bar"},
    
	labels: true,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Bar Charts"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  size: {
    height: 400
  },
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  type: "category",
		categories: ["2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
      label: {
	  	text: "Period",
	  	position: "outer-center"
	  },
	  tick: {
        rotate: 0,
        multiline: false,
        tooltip: true
      },
      height: 0,
    },
    y: {
      label: {
	  	text: "Percentage",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#mbill2"
});
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
var _mbill3;
	var ambill3 = [];
	var mbill3chart = bb.generate({
	data: {x: "x",
  	columns: [["x", "2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "bar",
    types: {
data1:"bar",data2:"bar"},
    groups: [
      [
        "data1","data2"
      ]
    ],
	labels: true,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Stacked Charts"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  size: {
    height: 400
  },
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  type: "category",
		categories: ["2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
      label: {
	  	text: "Period",
	  	position: "outer-center"
	  },
	  tick: {
        rotate: 0,
        multiline: false,
        tooltip: true
      },
      height: 0,
    },
    y: {
      label: {
	  	text: "Percentage",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#mbill3"
});
var cd5block = document.getElementById('cd5code');
Prism.highlightElement(cd5block);
var _mbill;
	var ambill = [];
	var mbillchart = bb.generate({
	data: {x: "x",
  	columns: [["x", "2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "bar",
    types: {
data1:"bar",data2:"spline"},
    
	labels: true,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Combination Chart"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  size: {
    height: 400
  },
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  type: "category",
		categories: ["2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
      label: {
	  	text: "",
	  	position: "outer-center"
	  },
	  tick: {
        rotate: 0,
        multiline: false,
        tooltip: true
      },
      height: 0,
    },
    y: {
      label: {
	  	text: "",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#mbill"
});
var cd6block = document.getElementById('cd6code');
Prism.highlightElement(cd6block);
var _mbilld;
	var ambilld = [];
	var mbilldchart = bb.generate({
	data: {
  	columns: [
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "donut",
    types: {
data1:"donut",data2:"donut"},
    
	labels: false,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Donut"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  size: {
    height: 400
  },
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  
      label: {
	  	text: "",
	  	position: "outer-center"
	  },
	  
    },
    y: {
      label: {
	  	text: "",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "Donut",
padAngle: 0.1,
label: {
show: true,
}
},
  bindto: "#mbilld"
});
var cd7block = document.getElementById('cd7code');
Prism.highlightElement(cd7block);
var _mbillg;
	var ambillg = [];
	var mbillgchart = bb.generate({
	data: {
  	columns: [
	["data1",60]
	],
	names: {data1:"% Progress"},
    color: {
    pattern: [
      "red","blue","orange","green"
    ],
    threshold: {
      values: [
        30,60,90,100
      ]
    }
  },
	
	type: "gauge",
    types: {
data1:"gauge"},
    
	labels: false,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Gauge"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  size: {
    height: 400
  },
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  
      label: {
	  	text: "",
	  	position: "outer-center"
	  },
	  
    },
    y: {
      label: {
	  	text: "",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#mbillg"
});
var cd8block = document.getElementById('cd8code');
Prism.highlightElement(cd8block);
var _mbillp;
	var ambillp = [];
	var mbillpchart = bb.generate({
	data: {
  	columns: [
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "pie",
    types: {
data1:"pie",data2:"pie"},
    
	labels: false,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Pie"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  size: {
    height: 400
  },
  pie: {
  	innerRadius: 20,
	padAngle: 0.1,
	padding: 3,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  
      label: {
	  	text: "",
	  	position: "outer-center"
	  },
	  
    },
    y: {
      label: {
	  	text: "",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#mbillp"
});
var cd9block = document.getElementById('cd9code');
Prism.highlightElement(cd9block);
var _mbillstep;
	var ambillstep = [];
	var mbillstepchart = bb.generate({
	data: {x: "x",
  	columns: [["x", "2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "step",
    types: {
data1:"step",data2:"area-step"},
    
	labels: true,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Step"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  size: {
    height: 400
  },
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  type: "category",
		categories: ["2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
      label: {
	  	text: "",
	  	position: "outer-center"
	  },
	  tick: {
        rotate: 0,
        multiline: false,
        tooltip: true
      },
      height: 0,
    },
    y: {
      label: {
	  	text: "",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#mbillstep"
});
var cd10block = document.getElementById('cd10code');
Prism.highlightElement(cd10block);
var _mbilll;
	var ambilll = [];
	var mbilllchart = bb.generate({
	data: {x: "x",
  	columns: [["x", "2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "line",
    types: {
data1:"line",data2:"line"},
    
	labels: true,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Line"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  size: {
    height: 400
  },
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  type: "category",
		categories: ["2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
      label: {
	  	text: "",
	  	position: "outer-center"
	  },
	  tick: {
        rotate: 0,
        multiline: false,
        tooltip: true
      },
      height: 0,
    },
    y: {
      label: {
	  	text: "",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#mbilll"
});
var cd11block = document.getElementById('cd11code');
Prism.highlightElement(cd11block);
var _radar1;
	var aradar1 = [];
	var radar1chart = bb.generate({
	data: {x: "x",
  	columns: [["x", "2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "radar",
    types: {
data1:"radar",data2:"radar"},
    
	labels: true,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Radar1"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  size: {
    height: 400
  },
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  type: "category",
		categories: ["2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
      label: {
	  	text: "",
	  	position: "outer-center"
	  },
	  tick: {
        rotate: 0,
        multiline: false,
        tooltip: true
      },
      height: 0,
    },
    y: {
      label: {
	  	text: "",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: false
    },
    y: {
      show: false
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#radar1"
});
var cd12block = document.getElementById('cd12code');
Prism.highlightElement(cd12block);
var _scatter;
	var ascatter = [];
	var scatterchart = bb.generate({
	data: {x: "x",
  	columns: [["x", "2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
	["data1",300,350,300,0,0,0],["data2",130,100,140,200,150,50]
	],
	names: {data1:"% Progress",data2:"% Expected"},
    colors: {
		data1:"red",data2:"green"
		},
	
	type: "scatter",
    types: {
data1:"scatter",data2:"scatter"},
    
	labels: true,
	onclick: function(d, i) {
   },
    onover: function(d, i) {
   },
    onout: function(d, i) {
   }
  },
title: {
text: "Scatter"
},
  gauge: {
   	min: 0,
    max: 100,
    width: 80,
    fullCircle: false,
	startingAngle: -1.5707964
  },
  size: {
    height: 400
  },
  pie: {
  	innerRadius: 0,
	padAngle: 0.0,
	padding: 0,
	label: {
     	"show": true
    }
  },
  axis: {
  	rotated: false,
    x: {
	  type: "category",
		categories: ["2018-01-01","2018-01-02","2018-01-03","2018-01-04","2018-01-05","2018-01-06"],
      label: {
	  	text: "",
	  	position: "outer-center"
	  },
	  tick: {
        rotate: 0,
        multiline: false,
        tooltip: true
      },
      height: 0,
    },
    y: {
      label: {
	  	text: "",
		position: "outer-middle"
	  }
    }
  },
  grid: {
    x: {
      show: true
    },
    y: {
      show: true
    }
  },
  zoom: {
    enabled: false
  },
  legend: {
  	show: true,
	position: "right",
	equally: true,
	padding: true,
	usePoint: false
  },
  radar: {
    axis: {
      line: {
        show: true
      },
      text: {
        show: true
      }
    },
    level: {
      text: {
        show: true
      }
    }
  },
  donut: {
width: 80,
title: "",
padAngle: 0.0,
label: {
show: true,
}
},
  bindto: "#scatter"
});
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
