var colors = HTMLColors();
var activerow;
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
var instcbo = document.getElementById('cbo');
	var cboinst = M.FormSelect.getInstance(instcbo);
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var instimgs = document.getElementById('imgs');
	var imgsinst = M.FormSelect.getInstance(instimgs);
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
var instimgs1 = document.getElementById('imgs1');
	var imgs1inst = M.FormSelect.getInstance(instimgs1);
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
