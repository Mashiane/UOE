var colors = HTMLColors();
var activerow;
function speech_onend(lastReadId, lastReadclassNames, data){
console.log(data);

}
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
$(document).on('click', '#whatspeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#whatbdy').articulate('speak');
});
$(document).on('click', '#donebeforespeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#donebeforebdy').articulate('speak');
});
$(document).on('click', '#toolsspeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#toolsbdy').articulate('speak');
});
$(document).on('click', '#wherespeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#wherebdy').articulate('speak');
});
var c1block = document.getElementById('c1code');
Prism.highlightElement(c1block);
$(document).on('click', '#howtothemespeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#howtothemebdy').articulate('speak');
});
$(document).on('click', '#whattocopyspeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#whattocopybdy').articulate('speak');
});
$(document).on('click', '#runanywherespeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#runanywherebdy').articulate('speak');
});
$(document).on('click', '#securityspeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#securitybdy').articulate('speak');
});
$(document).on('click', '#databasespeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#databasebdy').articulate('speak');
});
$(document).on('click', '#cookiesspeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#cookiesbdy').articulate('speak');
});
$(document).on('click', '#sessionspeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#sessionbdy').articulate('speak');
});
$(document).on('click', '#mycodespeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#mycodebdy').articulate('speak');
});
var c2block = document.getElementById('c2code');
Prism.highlightElement(c2block);
$(document).on('click', '#gridspeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#gridbdy').articulate('speak');
});
$(document).on('click', '#javaspeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#javabdy').articulate('speak');
});
$(document).on('click', '#websocketsspeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#websocketsbdy').articulate('speak');
});
var c3block = document.getElementById('c3code');
Prism.highlightElement(c3block);
$(document).on('click', '#speedspeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#speedbdy').articulate('speak');
});
var c4block = document.getElementById('c4code');
Prism.highlightElement(c4block);
var c5block = document.getElementById('c5code');
Prism.highlightElement(c5block);
var c6block = document.getElementById('c6code');
Prism.highlightElement(c6block);
var c7block = document.getElementById('c7code');
Prism.highlightElement(c7block);
$(document).on('click', '#owncomponentsspeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#owncomponentsbdy').articulate('speak');
});
$(document).on('click', '#formcontrolsspeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#formcontrolsbdy').articulate('speak');
});
$(document).on('click', '#phonegapspeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#phonegapbdy').articulate('speak');
});
$(document).on('click', '#webviewspeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#webviewbdy').articulate('speak');
});
$(document).on('click', '#ownqspeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#ownqbdy').articulate('speak');
});
$(document).on('click', '#whynotspeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#whynotbdy').articulate('speak');
});
$(document).on('click', '#salespeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#salebdy').articulate('speak');
});
$(document).on('click', '#forwardspeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#forwardbdy').articulate('speak');
});
$(document).on('click', '#bsspeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#bsbdy').articulate('speak');
});
$(document).on('click', '#involvespeak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#involvebdy').articulate('speak');
});
var instfaqthem = document.getElementById('faqthem');
	var faqtheminst = M.Collapsible.getInstance(instfaqthem);
faqtheminst.open(0);
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
