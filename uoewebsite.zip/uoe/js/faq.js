M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
$(document).on('click', '#whatspeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#whatbdy').articulate('speak');
$('#whatbdy').addClass('bold');

});
$(document).on('click', '#donebeforespeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#donebeforebdy').articulate('speak');
$('#donebeforebdy').addClass('bold');

});
$(document).on('click', '#toolsspeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#toolsbdy').articulate('speak');
$('#toolsbdy').addClass('bold');

});
$(document).on('click', '#wherespeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#wherebdy').articulate('speak');
$('#wherebdy').addClass('bold');

});
var c1block = document.getElementById('c1code');
Prism.highlightElement(c1block);
$(document).on('click', '#howtothemespeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#howtothemebdy').articulate('speak');
$('#howtothemebdy').addClass('bold');

});
$(document).on('click', '#whattocopyspeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#whattocopybdy').articulate('speak');
$('#whattocopybdy').addClass('bold');

});
$(document).on('click', '#runanywherespeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#runanywherebdy').articulate('speak');
$('#runanywherebdy').addClass('bold');

});
$(document).on('click', '#securityspeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#securitybdy').articulate('speak');
$('#securitybdy').addClass('bold');

});
$(document).on('click', '#databasespeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#databasebdy').articulate('speak');
$('#databasebdy').addClass('bold');

});
$(document).on('click', '#cookiesspeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#cookiesbdy').articulate('speak');
$('#cookiesbdy').addClass('bold');

});
$(document).on('click', '#sessionspeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#sessionbdy').articulate('speak');
$('#sessionbdy').addClass('bold');

});
$(document).on('click', '#mycodespeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#mycodebdy').articulate('speak');
$('#mycodebdy').addClass('bold');

});
var c2block = document.getElementById('c2code');
Prism.highlightElement(c2block);
$(document).on('click', '#gridspeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#gridbdy').articulate('speak');
$('#gridbdy').addClass('bold');

});
$(document).on('click', '#javaspeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#javabdy').articulate('speak');
$('#javabdy').addClass('bold');

});
$(document).on('click', '#websocketsspeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#websocketsbdy').articulate('speak');
$('#websocketsbdy').addClass('bold');

});
var c3block = document.getElementById('c3code');
Prism.highlightElement(c3block);
$(document).on('click', '#speedspeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#speedbdy').articulate('speak');
$('#speedbdy').addClass('bold');

});
var c4block = document.getElementById('c4code');
Prism.highlightElement(c4block);
var c5block = document.getElementById('c5code');
Prism.highlightElement(c5block);
var c6block = document.getElementById('c6code');
Prism.highlightElement(c6block);
var c7block = document.getElementById('c7code');
Prism.highlightElement(c7block);
$(document).on('click', '#owncomponentsspeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#owncomponentsbdy').articulate('speak');
$('#owncomponentsbdy').addClass('bold');

});
$(document).on('click', '#formcontrolsspeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#formcontrolsbdy').articulate('speak');
$('#formcontrolsbdy').addClass('bold');

});
$(document).on('click', '#phonegapspeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#phonegapbdy').articulate('speak');
$('#phonegapbdy').addClass('bold');

});
$(document).on('click', '#webviewspeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#webviewbdy').articulate('speak');
$('#webviewbdy').addClass('bold');

});
$(document).on('click', '#ownqspeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#ownqbdy').articulate('speak');
$('#ownqbdy').addClass('bold');

});
$(document).on('click', '#whynotspeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#whynotbdy').articulate('speak');
$('#whynotbdy').addClass('bold');

});
$(document).on('click', '#salespeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#salebdy').articulate('speak');
$('#salebdy').addClass('bold');

});
$(document).on('click', '#forwardspeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#forwardbdy').articulate('speak');
$('#forwardbdy').addClass('bold');

});
$(document).on('click', '#bsspeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#bsbdy').articulate('speak');
$('#bsbdy').addClass('bold');

});
$(document).on('click', '#involvespeak', function(e){
	e.preventDefault();
// check if articulate is speaking
isSpeaking = $().articulate('isSpeaking');
// check if articulate is paused
isPaused = $().articulate('isPaused');
if (isSpeaking){
  $().articulate('pause');
}
if (isPaused){
  $().articulate('resume');
}
$('#involvebdy').articulate('speak');
$('#involvebdy').addClass('bold');

});
var instfaqthem = document.getElementById('faqthem');
	var faqtheminst = M.Collapsible.getInstance(instfaqthem);
faqtheminst.open(0);
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){

});
