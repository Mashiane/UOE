function speech_onend(lastReadId, lastReadclassNames, data){
console.log(data);
}
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
$('#whatspeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#whatbdy').articulate('speak');});
$('#donebeforespeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#donebeforebdy').articulate('speak');});
$('#toolsspeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#toolsbdy').articulate('speak');});
$('#wherespeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#wherebdy').articulate('speak');});
var c1block = document.getElementById('c1code');
Prism.highlightElement(c1block);
$('#howtothemespeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#howtothemebdy').articulate('speak');});
$('#whattocopyspeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#whattocopybdy').articulate('speak');});
$('#runanywherespeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#runanywherebdy').articulate('speak');});
$('#securityspeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#securitybdy').articulate('speak');});
$('#databasespeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#databasebdy').articulate('speak');});
$('#cookiesspeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#cookiesbdy').articulate('speak');});
$('#sessionspeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#sessionbdy').articulate('speak');});
$('#mycodespeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#mycodebdy').articulate('speak');});
var c2block = document.getElementById('c2code');
Prism.highlightElement(c2block);
$('#gridspeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#gridbdy').articulate('speak');});
$('#javaspeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#javabdy').articulate('speak');});
$('#websocketsspeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#websocketsbdy').articulate('speak');});
var c3block = document.getElementById('c3code');
Prism.highlightElement(c3block);
$('#speedspeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#speedbdy').articulate('speak');});
var c4block = document.getElementById('c4code');
Prism.highlightElement(c4block);
var c5block = document.getElementById('c5code');
Prism.highlightElement(c5block);
var c6block = document.getElementById('c6code');
Prism.highlightElement(c6block);
var c7block = document.getElementById('c7code');
Prism.highlightElement(c7block);
$('#owncomponentsspeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#owncomponentsbdy').articulate('speak');});
$('#formcontrolsspeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#formcontrolsbdy').articulate('speak');});
$('#phonegapspeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#phonegapbdy').articulate('speak');});
$('#webviewspeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#webviewbdy').articulate('speak');});
$('#ownqspeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#ownqbdy').articulate('speak');});
$('#whynotspeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#whynotbdy').articulate('speak');});
$('#salespeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#salebdy').articulate('speak');});
$('#forwardspeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#forwardbdy').articulate('speak');});
$('#bsspeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#bsbdy').articulate('speak');});
$('#involvespeak').on('click', function (e) {
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#involvebdy').articulate('speak');});
var efab = document.getElementById('faqthem');
	var ifb = M.Collapsible.getInstance(efab);
	ifb.open(0);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
