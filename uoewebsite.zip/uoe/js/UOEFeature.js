var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var insttt = document.getElementById('tt');
	var ttinst = M.TapTarget.getInstance(insttt);
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
$('#fabdiv').floatingActionButton({hoverEnabled: true,
	direction:'top',
	toolbarEnabled: false});
var instfab = document.getElementById('fabdiv');
	var fabinst = M.FloatingActionButton.getInstance(instfab);
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawercollapse').collapsible({
	accordion: true,
	onOpenStart: function(el) {
                   
               },
    onOpenEnd: function(el) {
                   
               },
	onCloseStart: function(el) {
                   
               },
	onCloseEnd: function(el) {
                   
               }
	});
$('#navbardrawer').sidenav({
	draggable:true,
	preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
$(document).on('click', '#fab', function(){
$('#tt').tapTarget('open');
});
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
});
