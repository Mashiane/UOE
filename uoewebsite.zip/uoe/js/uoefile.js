M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
function handleFilesfu(files){
	var tmpfu = files[0];
	var readerfu  = new FileReader();
	readerfu.addEventListener("load", function () {
    	$('#imglogo').attr('src', readerfu.result);
	}, false);
	if (tmpfu) {
    readerfu.readAsDataURL(tmpfu);
  }
	}
function handleFilesfu1(files){
	var tmpfu1 = files[0];
	b64 = '';
	var readerfu1  = new FileReader();
	readerfu1.addEventListener("load", function () {
    	b64 = readerfu1.result;
		$('#txtbase64').val(b64);M.textareaAutoResize($('#txtbase64'));

	}, false);
	if (tmpfu1) {
    readerfu1.readAsDataURL(tmpfu1);
  }
	}
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
M.textareaAutoResize($('#txtbase64'));
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){

});
