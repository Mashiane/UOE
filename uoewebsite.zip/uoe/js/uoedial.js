M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
var _knob6;
	var aknob6 = [];
	$(".knob6").knob({
	'change' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'release' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'format': function (v) {
              return v + '';
    },
	draw: function () {
    	if ("tron" == this.$.data("skin")) {
        	this.cursorExt = .3;
            var b, a = this.arc(this.cv),
            c = 1;
            return this.g.lineWidth = this.lineWidth, this.o.displayPrevious && (b = this.arc(this.v), this.g.beginPath(), this.g.strokeStyle = this.pColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, b.s, b.e, b.d), this.g.stroke()), this.g.beginPath(), this.g.strokeStyle = c ? this.o.fgColor : this.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d), this.g.stroke(), this.g.lineWidth = 2, this.g.beginPath(), this.g.strokeStyle = this.o.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth + 1 + 2 * this.lineWidth / 3, 0, 2 * Math.PI, !1), this.g.stroke(), !1
            }
    },
	});
	$('#knob6dial').trigger('change');
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var _knob7;
	var aknob7 = [];
	$(".knob7").knob({
	'change' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'release' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'format': function (v) {
              return v + '%';
    },
	draw: function () {
    	if ("tron" == this.$.data("skin")) {
        	this.cursorExt = .3;
            var b, a = this.arc(this.cv),
            c = 1;
            return this.g.lineWidth = this.lineWidth, this.o.displayPrevious && (b = this.arc(this.v), this.g.beginPath(), this.g.strokeStyle = this.pColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, b.s, b.e, b.d), this.g.stroke()), this.g.beginPath(), this.g.strokeStyle = c ? this.o.fgColor : this.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d), this.g.stroke(), this.g.lineWidth = 2, this.g.beginPath(), this.g.strokeStyle = this.o.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth + 1 + 2 * this.lineWidth / 3, 0, 2 * Math.PI, !1), this.g.stroke(), !1
            }
    },
	});
	$('#knob7dial').trigger('change');
$('.knob7').each(function () {
           var $this = $(this);
           var myVal = $this.attr("rel");
           $({
               value: 0
           }).animate({
               value: myVal
           }, {
               duration: 2000,
               easing: 'swing',
               step: function () {
                   $this.val(Math.ceil(this.value)).trigger('change');
               }
           })
       });
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
var _knob0;
	var aknob0 = [];
	$(".knob0").knob({
	'change' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'release' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'format': function (v) {
              return v + '';
    },
	draw: function () {
    	if ("tron" == this.$.data("skin")) {
        	this.cursorExt = .3;
            var b, a = this.arc(this.cv),
            c = 1;
            return this.g.lineWidth = this.lineWidth, this.o.displayPrevious && (b = this.arc(this.v), this.g.beginPath(), this.g.strokeStyle = this.pColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, b.s, b.e, b.d), this.g.stroke()), this.g.beginPath(), this.g.strokeStyle = c ? this.o.fgColor : this.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d), this.g.stroke(), this.g.lineWidth = 2, this.g.beginPath(), this.g.strokeStyle = this.o.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth + 1 + 2 * this.lineWidth / 3, 0, 2 * Math.PI, !1), this.g.stroke(), !1
            }
    },
	});
	$('#knob0dial').trigger('change');
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
var _knob8;
	var aknob8 = [];
	$(".knob8").knob({
	'change' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'release' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'format': function (v) {
              return v + '';
    },
	draw: function () {
    	if ("tron" == this.$.data("skin")) {
        	this.cursorExt = .3;
            var b, a = this.arc(this.cv),
            c = 1;
            return this.g.lineWidth = this.lineWidth, this.o.displayPrevious && (b = this.arc(this.v), this.g.beginPath(), this.g.strokeStyle = this.pColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, b.s, b.e, b.d), this.g.stroke()), this.g.beginPath(), this.g.strokeStyle = c ? this.o.fgColor : this.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d), this.g.stroke(), this.g.lineWidth = 2, this.g.beginPath(), this.g.strokeStyle = this.o.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth + 1 + 2 * this.lineWidth / 3, 0, 2 * Math.PI, !1), this.g.stroke(), !1
            }
    },
	});
	$('#knob8dial').trigger('change');
var cd5block = document.getElementById('cd5code');
Prism.highlightElement(cd5block);
var _knob9;
	var aknob9 = [];
	$(".knob9").knob({
	'change' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'release' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'format': function (v) {
              return v + '';
    },
	draw: function () {
    	if ("tron" == this.$.data("skin")) {
        	this.cursorExt = .3;
            var b, a = this.arc(this.cv),
            c = 1;
            return this.g.lineWidth = this.lineWidth, this.o.displayPrevious && (b = this.arc(this.v), this.g.beginPath(), this.g.strokeStyle = this.pColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, b.s, b.e, b.d), this.g.stroke()), this.g.beginPath(), this.g.strokeStyle = c ? this.o.fgColor : this.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d), this.g.stroke(), this.g.lineWidth = 2, this.g.beginPath(), this.g.strokeStyle = this.o.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth + 1 + 2 * this.lineWidth / 3, 0, 2 * Math.PI, !1), this.g.stroke(), !1
            }
    },
	});
	$('#knob9dial').trigger('change');
var cd6block = document.getElementById('cd6code');
Prism.highlightElement(cd6block);
var _knob10;
	var aknob10 = [];
	$(".knob10").knob({
	'change' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'release' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'format': function (v) {
              return v + '';
    },
	draw: function () {
    	if ("tron" == this.$.data("skin")) {
        	this.cursorExt = .3;
            var b, a = this.arc(this.cv),
            c = 1;
            return this.g.lineWidth = this.lineWidth, this.o.displayPrevious && (b = this.arc(this.v), this.g.beginPath(), this.g.strokeStyle = this.pColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, b.s, b.e, b.d), this.g.stroke()), this.g.beginPath(), this.g.strokeStyle = c ? this.o.fgColor : this.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d), this.g.stroke(), this.g.lineWidth = 2, this.g.beginPath(), this.g.strokeStyle = this.o.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth + 1 + 2 * this.lineWidth / 3, 0, 2 * Math.PI, !1), this.g.stroke(), !1
            }
    },
	});
	$('#knob10dial').trigger('change');
var cd7block = document.getElementById('cd7code');
Prism.highlightElement(cd7block);
var _knob11;
	var aknob11 = [];
	$(".knob11").knob({
	'change' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'release' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'format': function (v) {
              return v + '';
    },
	draw: function () {
    	if ("tron" == this.$.data("skin")) {
        	this.cursorExt = .3;
            var b, a = this.arc(this.cv),
            c = 1;
            return this.g.lineWidth = this.lineWidth, this.o.displayPrevious && (b = this.arc(this.v), this.g.beginPath(), this.g.strokeStyle = this.pColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, b.s, b.e, b.d), this.g.stroke()), this.g.beginPath(), this.g.strokeStyle = c ? this.o.fgColor : this.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d), this.g.stroke(), this.g.lineWidth = 2, this.g.beginPath(), this.g.strokeStyle = this.o.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth + 1 + 2 * this.lineWidth / 3, 0, 2 * Math.PI, !1), this.g.stroke(), !1
            }
    },
	});
	$('#knob11dial').trigger('change');
var cd8block = document.getElementById('cd8code');
Prism.highlightElement(cd8block);
var _knob12;
	var aknob12 = [];
	$(".knob12").knob({
	'change' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'release' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'format': function (v) {
              return v + '';
    },
	draw: function () {
    	if ("tron" == this.$.data("skin")) {
        	this.cursorExt = .3;
            var b, a = this.arc(this.cv),
            c = 1;
            return this.g.lineWidth = this.lineWidth, this.o.displayPrevious && (b = this.arc(this.v), this.g.beginPath(), this.g.strokeStyle = this.pColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, b.s, b.e, b.d), this.g.stroke()), this.g.beginPath(), this.g.strokeStyle = c ? this.o.fgColor : this.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d), this.g.stroke(), this.g.lineWidth = 2, this.g.beginPath(), this.g.strokeStyle = this.o.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth + 1 + 2 * this.lineWidth / 3, 0, 2 * Math.PI, !1), this.g.stroke(), !1
            }
    },
	});
	$('#knob12dial').trigger('change');
var cd9block = document.getElementById('cd9code');
Prism.highlightElement(cd9block);
var _knob1;
	var aknob1 = [];
	$(".knob1").knob({
	'change' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'release' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'format': function (v) {
              return v + '';
    },
	draw: function () {
    	if ("tron" == this.$.data("skin")) {
        	this.cursorExt = .3;
            var b, a = this.arc(this.cv),
            c = 1;
            return this.g.lineWidth = this.lineWidth, this.o.displayPrevious && (b = this.arc(this.v), this.g.beginPath(), this.g.strokeStyle = this.pColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, b.s, b.e, b.d), this.g.stroke()), this.g.beginPath(), this.g.strokeStyle = c ? this.o.fgColor : this.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d), this.g.stroke(), this.g.lineWidth = 2, this.g.beginPath(), this.g.strokeStyle = this.o.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth + 1 + 2 * this.lineWidth / 3, 0, 2 * Math.PI, !1), this.g.stroke(), !1
            }
    },
	});
	$('#knob1dial').trigger('change');
var cd10block = document.getElementById('cd10code');
Prism.highlightElement(cd10block);
var _knob2;
	var aknob2 = [];
	$(".knob2").knob({
	'change' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'release' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'format': function (v) {
              return v + '';
    },
	draw: function () {
    	if ("tron" == this.$.data("skin")) {
        	this.cursorExt = .3;
            var b, a = this.arc(this.cv),
            c = 1;
            return this.g.lineWidth = this.lineWidth, this.o.displayPrevious && (b = this.arc(this.v), this.g.beginPath(), this.g.strokeStyle = this.pColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, b.s, b.e, b.d), this.g.stroke()), this.g.beginPath(), this.g.strokeStyle = c ? this.o.fgColor : this.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d), this.g.stroke(), this.g.lineWidth = 2, this.g.beginPath(), this.g.strokeStyle = this.o.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth + 1 + 2 * this.lineWidth / 3, 0, 2 * Math.PI, !1), this.g.stroke(), !1
            }
    },
	});
	$('#knob2dial').trigger('change');
var cd11block = document.getElementById('cd11code');
Prism.highlightElement(cd11block);
var _knob3;
	var aknob3 = [];
	$(".knob3").knob({
	'change' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'release' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'format': function (v) {
              return v + '';
    },
	draw: function () {
    	if ("tron" == this.$.data("skin")) {
        	this.cursorExt = .3;
            var b, a = this.arc(this.cv),
            c = 1;
            return this.g.lineWidth = this.lineWidth, this.o.displayPrevious && (b = this.arc(this.v), this.g.beginPath(), this.g.strokeStyle = this.pColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, b.s, b.e, b.d), this.g.stroke()), this.g.beginPath(), this.g.strokeStyle = c ? this.o.fgColor : this.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d), this.g.stroke(), this.g.lineWidth = 2, this.g.beginPath(), this.g.strokeStyle = this.o.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth + 1 + 2 * this.lineWidth / 3, 0, 2 * Math.PI, !1), this.g.stroke(), !1
            }
    },
	});
	$('#knob3dial').trigger('change');
var cd12block = document.getElementById('cd12code');
Prism.highlightElement(cd12block);
var _knob4;
	var aknob4 = [];
	$(".knob4").knob({
	'change' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'release' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'format': function (v) {
              return v + '';
    },
	draw: function () {
    	if ("tron" == this.$.data("skin")) {
        	this.cursorExt = .3;
            var b, a = this.arc(this.cv),
            c = 1;
            return this.g.lineWidth = this.lineWidth, this.o.displayPrevious && (b = this.arc(this.v), this.g.beginPath(), this.g.strokeStyle = this.pColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, b.s, b.e, b.d), this.g.stroke()), this.g.beginPath(), this.g.strokeStyle = c ? this.o.fgColor : this.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d), this.g.stroke(), this.g.lineWidth = 2, this.g.beginPath(), this.g.strokeStyle = this.o.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth + 1 + 2 * this.lineWidth / 3, 0, 2 * Math.PI, !1), this.g.stroke(), !1
            }
    },
	});
	$('#knob4dial').trigger('change');
var cd13block = document.getElementById('cd13code');
Prism.highlightElement(cd13block);
var _knob5;
	var aknob5 = [];
	$(".knob5").knob({
	'change' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'release' : function (v) {
	var thisid = this.$.attr('id') + '~';
	},
	'format': function (v) {
              return v + '';
    },
	draw: function () {
    	if ("tron" == this.$.data("skin")) {
        	this.cursorExt = .3;
            var b, a = this.arc(this.cv),
            c = 1;
            return this.g.lineWidth = this.lineWidth, this.o.displayPrevious && (b = this.arc(this.v), this.g.beginPath(), this.g.strokeStyle = this.pColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, b.s, b.e, b.d), this.g.stroke()), this.g.beginPath(), this.g.strokeStyle = c ? this.o.fgColor : this.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth, a.s, a.e, a.d), this.g.stroke(), this.g.lineWidth = 2, this.g.beginPath(), this.g.strokeStyle = this.o.fgColor, this.g.arc(this.xy, this.xy, this.radius - this.lineWidth + 1 + 2 * this.lineWidth / 3, 0, 2 * Math.PI, !1), this.g.stroke(), !1
            }
    },
	});
	$('#knob5dial').trigger('change');
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){

});
