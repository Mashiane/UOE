
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
$("#alert .close").click(function() { $(this).closest('#alert').fadeOut('slow');});
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
$("#alert1 .close").click(function() { $(this).closest('#alert1').fadeOut('slow');});
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
$("#alert2 .close").click(function() { $(this).closest('#alert2').fadeOut('slow');});
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
$("#alert3 .close").click(function() { $(this).closest('#alert3').fadeOut('slow');});
var cd5block = document.getElementById('cd5code');
Prism.highlightElement(cd5block);
$("#alert4 .close").click(function() { $(this).closest('#alert4').fadeOut('slow');});
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
