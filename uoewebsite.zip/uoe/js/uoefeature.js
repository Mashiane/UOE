var colors = HTMLColors();
var activerow;
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var insttt = document.getElementById('tt');
	var ttinst = M.TapTarget.getInstance(insttt);
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
$('#fabdiv').floatingActionButton({hoverEnabled: true,
	direction:'top',
	toolbarEnabled: false});
$(document).on('click', '#fab', function(e){
	e.preventDefault();
$('#tt').tapTarget('open');
});
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
