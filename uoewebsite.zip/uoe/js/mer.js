mermaid.initialize({startOnLoad:true});
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
mermaid.initialize({startOnLoad:true});
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
mermaid.initialize({startOnLoad:true});
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
mermaid.initialize({startOnLoad:true});
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
mermaid.initialize({startOnLoad:true});
var cd5block = document.getElementById('cd5code');
Prism.highlightElement(cd5block);
mermaid.initialize({startOnLoad:true});
var cd6block = document.getElementById('cd6code');
Prism.highlightElement(cd6block);
mermaid.initialize({startOnLoad:true});
var cd7block = document.getElementById('cd7code');
Prism.highlightElement(cd7block);
mermaid.initialize({startOnLoad:true});
var cd8block = document.getElementById('cd8code');
Prism.highlightElement(cd8block);
mermaid.initialize({startOnLoad:true});
var cd9block = document.getElementById('cd9code');
Prism.highlightElement(cd9block);
mermaid.initialize({startOnLoad:true});
var cd10block = document.getElementById('cd10code');
Prism.highlightElement(cd10block);
mermaid.initialize({startOnLoad:true});
var cd11block = document.getElementById('cd11code');
Prism.highlightElement(cd11block);
mermaid.initialize({startOnLoad:true});
var cd12block = document.getElementById('cd12code');
Prism.highlightElement(cd12block);
mermaid.initialize({startOnLoad:true});
var cd13block = document.getElementById('cd13code');
Prism.highlightElement(cd13block);
mermaid.initialize({startOnLoad:true});
var cd14block = document.getElementById('cd14code');
Prism.highlightElement(cd14block);
mermaid.initialize({startOnLoad:true});
var cd15block = document.getElementById('cd15code');
Prism.highlightElement(cd15block);
mermaid.initialize({startOnLoad:true});
var cd16block = document.getElementById('cd16code');
Prism.highlightElement(cd16block);
mermaid.initialize({startOnLoad:true});
var cd17block = document.getElementById('cd17code');
Prism.highlightElement(cd17block);
mermaid.initialize({startOnLoad:true});
var cd18block = document.getElementById('cd18code');
Prism.highlightElement(cd18block);
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawercollapse').collapsible({
	accordion: true,
	onOpenStart: function(el) {
                   
               },
    onOpenEnd: function(el) {
                   
               },
	onCloseStart: function(el) {
                   
               },
	onCloseEnd: function(el) {
                   
               }
	});
$('#navbardrawer').sidenav({
	draggable:true,
	preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
});
