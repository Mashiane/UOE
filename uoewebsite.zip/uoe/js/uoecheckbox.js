M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
function handleCheckBoxc1(){
	// get value of checkbox
myc1 = $('#c1inp').is(':checked');

// show value on a toast
M.toast({html:myc1, displayLength:3000, classes:'rounded white-text green'});
	}
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
var cd5block = document.getElementById('cd5code');
Prism.highlightElement(cd5block);
// Set checkbox on forms.html to indeterminate
    var chkc5 = document.getElementById('c5inp');
    if (chkc5 !== null) chkc5.indeterminate = true;
var cd6block = document.getElementById('cd6code');
Prism.highlightElement(cd6block);
function handleCheckBoxpoor(){
	// get value of checkgroup
mycheck = [];
$('input[name=c7]:checked').each(function () {
var thisval = $(this).val();
mycheck.push(thisval);
});

var delim = ",";
gender = mycheck.join(delim);
// show value on a toast
M.toast({html:gender, displayLength:3000, classes:'rounded white-text green'});
	}
function handleCheckBoxrich(){
	// get value of checkgroup
mycheck = [];
$('input[name=c7]:checked').each(function () {
var thisval = $(this).val();
mycheck.push(thisval);
});

var delim = ",";
gender = mycheck.join(delim);
// show value on a toast
M.toast({html:gender, displayLength:3000, classes:'rounded white-text green'});
	}
function handleCheckBoxsad(){
	// get value of checkgroup
mycheck = [];
$('input[name=c7]:checked').each(function () {
var thisval = $(this).val();
mycheck.push(thisval);
});

var delim = ",";
gender = mycheck.join(delim);
// show value on a toast
M.toast({html:gender, displayLength:3000, classes:'rounded white-text green'});
	}
var cd7block = document.getElementById('cd7code');
Prism.highlightElement(cd7block);
$(document).on('click', '#btncheckall', function(e){
	e.preventDefault();
var tblChkBoxc7 = $('#c7 input:checkbox');
	console.log(tblChkBoxc7);
	$(tblChkBoxc7).prop('checked', true);
});
$(document).on('click', '#btnuncheckall', function(e){
	e.preventDefault();
var tblChkBoxc7 = $('#c7 input:checkbox');
	console.log(tblChkBoxc7);
	$(tblChkBoxc7).prop('checked', false);
});
var cd8block = document.getElementById('cd8code');
Prism.highlightElement(cd8block);
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){

});
