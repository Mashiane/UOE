var colors = HTMLColors();
var activerow;
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
// Initialize Firebase
var fbconfig = {
apiKey: "AIzaSyDs-3eMbqkFiEFqswXRvK7kffa7wGFP-L0",
authDomain: "uoelibrary-28987.firebaseapp.com",
databaseURL: "https://uoelibrary-28987.firebaseio.com",
projectId: "uoelibrary-28987",
storageBucket: "uoelibrary-28987.appspot.com",
messagingSenderId: "161544937681"
};
firebase.initializeApp(fbconfig);
// Get a reference to the entire database
var fbdatabase = firebase.database().ref();
var provider = new firebase.auth.GoogleAuthProvider();
function googleSignin() {
firebase.auth()   
.signInWithPopup(provider).then(function(result) {
var token = result.credential.accessToken;
var user = result.user;
console.log(token)
console.log(user)
}).catch(function(error) {
M.toast({html:error.message, displayLength:3000, classes:'rounded white-text red'});
});
}
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var profiles = fbdatabase.child("profiles");
function GetLastprofiles(){
	var lastrec = new Object();
	profiles.limitToLast(1).on('child_added', function(childSnapshot) {
  	lastrec = childSnapshot.val();
	});
	return lastrec;
}
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
var cd5block = document.getElementById('cd5code');
Prism.highlightElement(cd5block);
var cd6block = document.getElementById('cd6code');
Prism.highlightElement(cd6block);
var cd7block = document.getElementById('cd7code');
Prism.highlightElement(cd7block);
profiles.on('child_added', function (snapshot) {
var currentData = snapshot.val();
console.log(currentData);
var profilesRec = {};
profilesRec.emailaddress = currentData.emailaddress;
profilesRec.password = currentData.password;
var eProfile = JSON.stringify(profilesRec);
console.log(eProfile);

});
var cd8block = document.getElementById('cd8code');
Prism.highlightElement(cd8block);
var cd9block = document.getElementById('cd9code');
Prism.highlightElement(cd9block);
$(document).on('click', '#btnsignup', function(e){
	e.preventDefault();
var signup = {};
signup[emailaddress] = emailaddressvalue;
signup[password] = passwordvalue;
firebase.auth().createUserWithEmailAndPassword(signup.emailaddress, signup.password).catch(function(error) {
M.toast({html:error.message, displayLength:3000, classes:'rounded white-text red'});
});
});
$(document).on('click', '#btnsignin', function(e){
	e.preventDefault();
var signin = {};
signin[emailaddress] = emailaddressvalue;
signin[password] = passwordvalue;
firebase.auth().signInWithEmailAndPassword(signin.emailaddress, signin.password).catch(function(error) {
M.toast({html:error.message, displayLength:3000, classes:'rounded white-text red'});
});
});
var cd10block = document.getElementById('cd10code');
Prism.highlightElement(cd10block);
var cd11block = document.getElementById('cd11code');
Prism.highlightElement(cd11block);
var cd12block = document.getElementById('cd12code');
Prism.highlightElement(cd12block);
$(document).on('click', '#btnsignout', function(e){
	e.preventDefault();
firebase.auth().signOut().then(function() {
M.toast({html:'Signed Out!', displayLength:3000, classes:'rounded white-text green'})
}, function(error) {
M.toast({html:error.message, displayLength:3000, classes:'rounded white-text red'});
});
});
$(document).on('click', '#btngooglesignin', function(e){
	e.preventDefault();
googleSignin();
});
$(document).on('click', '#btnanonymoussignin', function(e){
	e.preventDefault();
firebase.auth().signInAnonymously()
.then(function() {
M.toast({html:'Signed In!', displayLength:3000, classes:'rounded white-text green'})
}).catch(function(error) {
M.toast({html:error.message, displayLength:3000, classes:'rounded white-text red'});
});
});
var cd13block = document.getElementById('cd13code');
Prism.highlightElement(cd13block);
$(document).on('click', '#btnsaveprofile', function(e){
	e.preventDefault();
var profile = {};
profile[emailaddress] = emailaddressvalue;
profile[password] = passwordvalue;
profile= JSON.stringify(eProfile);
// Get a key for a new profiles record.
    var profilesKey = profiles.push().key;
	var profilesupdates = {};
	profilesupdates['/profiles/' + profilesKey] = eProfile;
	fbdatabase.update(profilesupdates);
	var profileKey = profilesKey;console.log(profileKey);

});
var cd14block = document.getElementById('cd14code');
Prism.highlightElement(cd14block);
var cd15block = document.getElementById('cd15code');
Prism.highlightElement(cd15block);
$(document).on('click', '#btnsaveprofilebyemail', function(e){
	e.preventDefault();
emailaddress = $('#emailaddress').val().trim();
password = $('#password').val().trim();
var profile = {};
profile[password] = password;
profile= JSON.stringify(eProfile);
var profilesKey = emailaddress;
	profilesKey = CleanKey(profilesKey);
	firebase.database().ref('profiles/' + profilesKey).set(eProfile);
});
var cd16block = document.getElementById('cd16code');
Prism.highlightElement(cd16block);
$(document).on('click', '#btnupdateprofilebyemail', function(e){
	e.preventDefault();
emailaddress = $('#emailaddress').val().trim();
password = $('#password').val().trim();
var profile = {};
profile[password] = password;
profile= JSON.stringify(eProfile);
var profilesUpdate = {};
	var profilesKey = emailaddress;
	profilesKey = CleanKey(profilesKey);
	profilesUpdate['/profiles/' + profilesKey] = eProfile;
	fbdatabase.update(profilesUpdate);
});
var cd17block = document.getElementById('cd17code');
Prism.highlightElement(cd17block);
$(document).on('click', '#btnread', function(e){
	e.preventDefault();
emailaddress = $('#email').val().trim();
var profilesKey = email;
	var single;
	profilesKey = CleanKey(profilesKey);
	var profilesRec = firebase.database().ref('profiles/' + profilesKey);
profilesRec.once('value', function(snapshot) {
  single = snapshot.val();
});console.log(single);

});
var cd18block = document.getElementById('cd18code');
Prism.highlightElement(cd18block);
$(document).on('click', '#btndelete', function(e){
	e.preventDefault();
emailaddress = $('#email').val().trim();
var profilesKey = email;
	profilesKey = CleanKey(profilesKey);
	firebase.database().ref('profiles/' + profilesKey).remove();
});
var cd19block = document.getElementById('cd19code');
Prism.highlightElement(cd19block);
var cd20block = document.getElementById('cd20code');
Prism.highlightElement(cd20block);
$(document).on('click', '#btnconnected', function(e){
	e.preventDefault();
var connectedRef = firebase.database().ref(".info/connected");
var isconnected = false;
connectedRef.on("value", function(snap) {
if (snap.val() === true) {
isconnected = true;
} else {
isconnected = false;
}
});console.log(isconnected);

});
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
