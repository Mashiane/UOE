var mkimmo;
var mkimmo1;
var mkimmo2;
var mgeo;
var mgeoc;
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
mkimmo = new GMaps({
div: '#kimmo',
lat: -12.043333,
lng: -77.028336,
enableNewStyle: true,
click: function(e) {},
dragend: function(e) {}
});
mkimmo.addMarker({
		lat: -12.043333,
		lng: -77.028336,
		title: 'Lima',
		infoWindow: {
		  content: 'Home'
		},
		click: function(e) {	M.toast({html:'<div>You clicked me!</div>', displayLength:3000, classes:'rounded  green white-text '});	}
		});
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
mkimmo1 = new GMaps({
div: '#kimmo1',
lat: -12.043333,
lng: -77.028336,
enableNewStyle: true,
click: function(e) {},
dragend: function(e) {}
});
var plp1 = [[-12.044013,-77.024704],[-12.054493,-77.03024],[-12.055122,-77.030396],[-12.075917,-77.02765],[-12.076358,-77.02792],[-12.076819,-77.02893],[-12.088528,-77.02411],[-12.090815,-77.02271]];
mkimmo1.drawPolyline({
path: plp1,
strokeColor: '#131540',
strokeOpacity: 0.6,
strokeWeight: 6
});
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
mkimmo2 = new GMaps({
div: '#kimmo2',
lat: -12.043333,
lng: -77.028336,
enableNewStyle: true,
click: function(e) {},
dragend: function(e) {}
});
var pgpg1 = [[-12.040398,-77.03374],[-12.040249,-77.03994],[-12.050047,-77.02448],[-12.044805,-77.021545]];
mkimmo2.drawPolygon({
paths: pgpg1,
strokeColor: '#BBD8E9',
strokeOpacity: 1,
strokeWeight: 3,
fillColor: '#BBD8E9',
fillOpacity: 0.6  
});
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
mgeo = new GMaps({
div: '#geo',
lat: -28.479263,
lng: 24.672714,
enableNewStyle: true,
click: function(e) {},
dragend: function(e) {}
});
$(document).on('click', '#btnlocate', function(){
GMaps.geolocate({
        success: function(position){
          mgeo.setCenter(position.coords.latitude, position.coords.longitude);
		  var geome = mgeo.addMarker({
		lat: position.coords.latitude,
		lng: position.coords.longitude,
		title: 'I am here!',
		infoWindow: {
		  content: 'I am here!'
		},
		click: function(e) {		}
		});
        },
        error: function(error){
          M.toast({html:error.message, displayLength:3000, classes:'rounded white-text red'});
        },
        not_supported: function(){
          M.toast({html:'<div>Geolocation is not supported!</div>', displayLength:3000, classes:'rounded  red white-text '});
        }
      });
});
var cd5block = document.getElementById('cd5code');
Prism.highlightElement(cd5block);
mgeoc = new GMaps({
div: '#geoc',
lat: -28.479263,
lng: 24.672714,
enableNewStyle: true,
click: function(e) {},
dragend: function(e) {}
});
$(document).on('click', '#btngeocode', function(){
var myaddress = "East London, South Africa";
var lat;
var lng;
GMaps.geocode({
address: myaddress,
callback: function(results, status) {
if (status == 'OK') {
var latlng = results[0].geometry.location;
lat = latlng.lat();
lng = latlng.lng();
mgeoc.setCenter(lat, lng);
var addr = mgeoc.addMarker({
		lat: lat,
		lng: lng,
		title: 'GeoCode'
	});
}
}
});
});
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
