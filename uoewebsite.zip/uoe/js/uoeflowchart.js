var colors = HTMLColors();
var activerow;
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
var anelediagram = flowchart.parse('st=>start: Start\n' +'e=>end: End\n' +'op1=>operation: My Operation|past\n' +'op2=>operation: Stuff|current\n' +'sub1=>subroutine: My Subroutine|invalid\n' +'cond=>condition: Yes \nor No?|approved\n' +'c2=>condition: Good idea|rejected\n' +'io=>inputoutput: catch something...|future\n\n' +'st->op1\n' +'op1(right)->cond\n' +'cond(yes, right)->c2\n' +'cond(no)->sub1\n' +'sub1(left)->op1\n' +'c2(yes)->io\n' +'c2(no)->op2\n' +'io->e\n' +'op2->e');
  	anelediagram.drawSVG('anele', {
	'flowstate' : {
	'past':{'fill':'#CCCCCC','font-size':'12',},'current':{'fill':'yellow','font-color':'red','font-weight':'bold',},'future':{'fill':'#FFFF99',},'request':{'fill':'blue',},'invalid':{'fill':'#444444',},'approved':{'fill':'#58C4A3','font-size':'12','yes-text':'APPROVED','no-text':'n/a'},'rejected':{'fill':'#C45879','font-size':'12','yes-text':'n/a','no-text':'REJECTED'}
    }
    });
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var fc1diagram = flowchart.parse('st=>start: Start\n' +'e=>end: End\n' +'op1=>operation: My Operation\n' +'sub1=>subroutine: My Subroutine\n' +'cond=>condition: Yes \nor No?\n' +'io=>inputoutput: catch something...\n' +'para=>parallel: parallel tasks\n' +'st->op1\n' +'op1->cond\n' +'cond(yes)->io\n' +'io->e\n' +'cond(no)->para\n' +'para(path1, bottom)->sub1\n' +'sub1(right)->op1\n' +'para(path2, top)->op1');
  	fc1diagram.drawSVG('fc1', {
	'flowstate' : {
	
    }
    });
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
var fc2diagram = flowchart.parse('st=>start: Improve your\n l10n process!\n' +'e=>end: Continue to have fun!:>https://youtu.be/YQryHo1iHb8[blank]\n' +'op1=>operation: Go to locize.com:>https://locize.com[blank]\n' +'sub1=>subroutine: Read the awesomeness\n' +'cond(align-next=no)=>condition: Interested to getting started?\n' +'io=>inputoutput: Register:>https://www.locize.io/register[blank]\n' +'sub2=>subroutine: Read about improving\n your localization workflow\n or another source\n add to the app:>https://medium.com/@adrai/8-signs-you-should-improve-your-localization-process-3dc075d53998[blank]\n' +'op2=>operation: Login:>https://www.locize.io/login[blank]\n' +'cond2=>condition: valid password?\n' +'cond3=>condition: reset password?\n' +'op3=>operation: send email\n' +'sub3=>subroutine: Create a demo project\n' +'sub4=>subroutine: Start your real project\n' +'io2=>inputoutput: Subscribe\n' +'st->op1\n' +'op1->sub1\n' +'sub1->cond\n' +'cond(yes)->io\n' +'io->op2\n' +'op2->cond2\n' +'cond2(no)->cond3\n' +'cond3(no, bottom)->op2\n' +'cond3(yes)->op3\n' +'op3(right)->op2\n' +'cond2(yes)->sub3\n' +'sub3->sub4\n' +'sub4->io2\n' +'io2->e\n' +'cond(no)->sub2\n' +'sub2(right)->op1\n' +'st@>op1({"stroke":"red"})\n' +'op1@>sub1({"stroke":"red"})\n' +'sub1@>cond({"stroke":"red"})');
  	fc2diagram.drawSVG('fc2', {
	'flowstate' : {
	
    }
    });
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
