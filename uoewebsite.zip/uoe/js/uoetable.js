var colors = HTMLColors();
var activerow;
function getRowsinvoice(){
	var invoicedata = [];
	invoicerows = $("#invoice tbody tr");
invoicerows.each(function (index) {
    var invoicerow = $(this);
 	var invoiceobj = {};
	
	invoicedata.push(invoiceobj);
});
return invoicedata;
	}
$("#tbl tbody").on("click", "tr", function () {
    activerow = $(this).closest('tr').find('td').map(function () {
        return $(this).text();
    }).get().join();
	M.toast({html:activerow, displayLength:3000, classes:'rounded white-text green'});
});
function getRowstbl(){
	var tbldata = [];
	tblrows = $("#tbl tbody tr");
tblrows.each(function (index) {
    var tblrow = $(this);
 	var tblobj = {};
	var vitemname = tblrow.find("[name=itemname]").text();
			tblobj['itemname'] = vitemname;
			tblobj['index'] = index;
var vitemsurname = tblrow.find("[name=itemsurname]").text();
			tblobj['itemsurname'] = vitemsurname;
			tblobj['index'] = index;
var vitemprice = tblrow.find("[name=itemprice]").text();
			tblobj['itemprice'] = vitemprice;
			tblobj['index'] = index;

	tbldata.push(tblobj);
});
return tbldata;
	}
function getRowstb2(){
	var tb2data = [];
	tb2rows = $("#tb2 tbody tr");
tb2rows.each(function (index) {
    var tb2row = $(this);
 	var tb2obj = {};
	
	tb2data.push(tb2obj);
});
return tb2data;
	}
function getRowstb3(){
	var tb3data = [];
	tb3rows = $("#tb3 tbody tr");
tb3rows.each(function (index) {
    var tb3row = $(this);
 	var tb3obj = {};
	
	tb3data.push(tb3obj);
});
return tb3data;
	}
function getRowstb4(){
	var tb4data = [];
	tb4rows = $("#tb4 tbody tr");
tb4rows.each(function (index) {
    var tb4row = $(this);
 	var tb4obj = {};
	
	tb4data.push(tb4obj);
});
return tb4data;
	}
function getRowstb4(){
	var tb4data = [];
	tb4rows = $("#tb4 tbody tr");
tb4rows.each(function (index) {
    var tb4row = $(this);
 	var tb4obj = {};
	
	tb4data.push(tb4obj);
});
return tb4data;
	}
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var tblinvoice = document.getElementById('invoice');
	// Class applied to each export button element.
	$.fn.tableExport.defaultButton = "button-default white-text black";
	new TableExport(tblinvoice, {
        headers: true,                              // (Boolean), display table headers (th or td elements) in the <thead>, (default: true)
        footers: true,                              // (Boolean), display table footers (th Or td elements) in the <tfoot>, (default: False)
        formats: ['xlsx', 'xls', 'csv', 'txt'],            // (String[]), filetype(s) for the export, (default: ['xlsx', 'csv', 'txt'])
		filename: 'invoice',                             // (id, String), filename for the downloaded file, (default: 'id')
        bootstrap: true,                           // (Boolean), style buttons using bootstrap, (default: False)
        position: 'bottom',                         // (top, bottom), position of the caption element relative to table, (default: 'bottom')
        ignoreRows: null,                           // (Number, Number[]), row indices To exclude from the exported File(s) (default: Null)
        ignoreCols: null,                           // (Number, Number[]), column indices To exclude from the exported File(s) (default: Null)
        ignoreCSS: '.tableexport-ignore',           // (selector, selector[]), selector(s) to exclude cells from the exported file(s) (default: '.tableexport-ignore')
        emptyCSS: '.tableexport-empty',             // (selector, selector[]), selector(s) to replace cells with an empty string in the exported file(s) (default: '.tableexport-empty')
        trimWhitespace: true,                       // (Boolean), remove all leading/trailing newlines, spaces, And tabs from cell text in the exported File(s) (default: True)
        RTL: false,                                 // (Boolean), set direction of the worksheet To right-To-left (default: False)
        sheetname: 'invoice'                             // (id, String), sheet name for the exported spreadsheet, (default: 'id')
    });
var invblock = document.getElementById('invcode');
Prism.highlightElement(invblock);
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
$(document).on('click', '#btn2json', function(e){
	e.preventDefault();
$("#tbl").tableHTMLExport({type:'json',filename:'tbl.json'});
});
$(document).on('click', '#btn2txt', function(e){
	e.preventDefault();
$("#tbl").tableHTMLExport({type:'txt',filename:'tbl.txt'});
});
$(document).on('click', '#btn2csv', function(e){
	e.preventDefault();
$("#tbl").tableHTMLExport({type:'csv',filename:'tbl.csv'});
});
$(document).on('click', '#btn2png', function(e){
	e.preventDefault();
domtoimage.toPng(document.getElementById('tbl'))
    .then(function (dataUrl) {
        var link = document.createElement('a');
        link.download = 'tbl.png';
        link.href = dataUrl;
		link.target = "_blank";
        link.click();
    });
});
$(document).on('click', '#btnget', function(e){
	e.preventDefault();
myData = getRowstbl();tblData= JSON.stringify(myData);
M.toast({html:tblData, displayLength:3000, classes:'rounded white-text green'});
});
$(document).on('click', '#btntoggle', function(e){
	e.preventDefault();
var tbltbl = $("#tbl");
    var tblheadtbl = $("#tbl th");
	var colToHidetbl = tblheadtbl.filter(".itemsurname");
    var indextbl = colToHidetbl.index();
    tbltbl.find('tr :nth-child(' + (indextbl + 1) + ')').toggle();
});
$(document).on('click', '#btnclear', function(e){
	e.preventDefault();
$('#tbl tbody tr').remove();
});
$(document).on('click', '#btnlastrow', function(e){
	e.preventDefault();
var newRow = '<tr id="tbl_r1546369919437"><td id="tbl_r1546369919437_c0" name="itemname" class="itemname" style="text-align:left !important;">Anele</td><td id="tbl_r1546369919437_c1" name="itemsurname" class="itemsurname" style="text-align:center !important;">Mbangas</td><td id="tbl_r1546369919437_c2" name="itemprice" class="itemprice" style="text-align:right !important;">On Last Row</td></tr>';
		var tbl = $('#tbl');
		tbl.append(newRow);
});
$(document).on('click', '#btnfirst', function(e){
	e.preventDefault();
var newRow = '<tr id="tbl_r1546369919437"><td id="tbl_r1546369919437_c0" name="itemname" class="itemname" style="text-align:left !important;">Mashy</td><td id="tbl_r1546369919437_c1" name="itemsurname" class="itemsurname" style="text-align:center !important;">Mabi</td><td id="tbl_r1546369919437_c2" name="itemprice" class="itemprice" style="text-align:right !important;">First Row</td></tr>';
		$('#tbl > tbody > tr').eq(1-1).before(newRow);
});
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
var cd5block = document.getElementById('cd5code');
Prism.highlightElement(cd5block);
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
