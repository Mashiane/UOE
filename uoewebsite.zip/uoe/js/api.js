
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
var lsOptions = {
	storages: ['local'],
	expireDays: 14};
lsBasil = new window.Basil(lsOptions);
$('#btnconnect').on('click', function (e) {
axios({url: 'https://api.elections.org.za/token',
method: 'post',
headers: {'Content-Type':'application/x-www-form-urlencoded'}, 
data: 'grant_type=password&username=IECWebAPIMediaSABC&password=896e2fc721ab43be8dacd5e6427d8ef4'})
.then(function(response){
var tokenreceived = response.data;
var accesstoken = tokenreceived.access_token;
var expires = tokenreceived.expires_in;
lsBasil.set('accesstoken', accesstoken);
lsBasil.set('tokenexpiry', expires);

})
.catch(function(err){

});});
$('#btnfaq').on('click', function (e) {
var accesstoken = lsBasil.get('accesstoken');
var tokenexpiry = lsBasil.get('tokenexpiry');
axios({url: 'https://api.elections.org.za/api/v1/Voters?Id=7304155526089',
method: 'get',
headers: {'Authorization':'bearer ' + accesstoken}, 
data: ''})
.then(function(response){
var profile = response.data;
console.log(profile);
var Id = profile.Id;
var VoterId = profile.VoterId;
var VoterStatus = profile.VoterStatus;
var VoterStatusID = profile.VoterStatusID;
var VotingStation = profile.VotingStation;
var bRegistered = profile.bRegistered;
var Delimitation = VotingStation.Delimitation;
var Location = VotingStation.Location;
var Name = VotingStation.Name;
var Municipality = Delimitation.Municipality;
var MunicipalityID = Delimitation.MunicipalityID;
var Province = Delimitation.Province;
var ProvinceID = Delimitation.ProvinceID;
var VDNumber = Delimitation.VDNumber;
var WardID = Delimitation.WardID;
var Latitude = Location.Latitude;
var Longitude = Location.Longitude;
var Street = Location.Street;
var Suburb = Location.Suburb;
var Town = Location.Town;
var userprofile = {};
userprofile.Id = Id;
userprofile.VoterId = VoterId;
userprofile.VoterStatus = VoterStatus;
userprofile.VoterStatusID = VoterStatusID;
userprofile.bRegistered = bRegistered;
userprofile.Name = Name;
userprofile.Municipality = Municipality;
userprofile.MunicipalityID = MunicipalityID;
userprofile.Province = Province;
userprofile.ProvinceID = ProvinceID;
userprofile.VDNumber = VDNumber;
userprofile.WardID = WardID;
userprofile.Latitude = Latitude;
userprofile.Longitude = Longitude;
userprofile.Street = Street;
userprofile.Suburb = Suburb;
userprofile.Town = Town;
console.log(userprofile);
lsBasil.set('Id', Id);
lsBasil.set('profile', userprofile);
lsBasil.set('MunicipalityID', MunicipalityID);
lsBasil.set('ProvinceID', ProvinceID);
lsBasil.set('VDNumber', VDNumber);
lsBasil.set('VoterId', VoterId);
lsBasil.set('WardID', WardID);
lsBasil.set('Latitude', Latitude);
lsBasil.set('Longitude', Longitude);

})
.catch(function(err){

});});
$('#btnvd').on('click', function (e) {
var accesstoken = lsBasil.get('accesstoken');
var VDNumber = lsBasil.get('VDNumber');
axios({url: 'http://api.elections.org.za/api/v1/VotingStationDetails?VDNumber=' + VDNumber,
method: 'get',
headers: {'Authorization':'bearer ' + accesstoken}, 
data: ''})
.then(function(response){
var vd = response.data;
console.log(vd);
var Delimitation = vd.Delimitation;
var Location = vd.Location;
var Name = vd.Name;
var Municipality = Delimitation.Municipality;
var MunicipalityID = Delimitation.MunicipalityID;
var Province = Delimitation.Province;
var ProvinceID = Delimitation.ProvinceID;
var VDNumber = Delimitation.VDNumber;
var WardID = Delimitation.WardID;
var Latitude = Location.Latitude;
var Longitude = Location.Longitude;
var Street = Location.Street;
var Suburb = Location.Suburb;
var Town = Location.Town;
var votingdistrict = {};
votingdistrict.Name = Name;
votingdistrict.Municipality = Municipality;
votingdistrict.MunicipalityID = MunicipalityID;
votingdistrict.Province = Province;
votingdistrict.ProvinceID = ProvinceID;
votingdistrict.VDNumber = VDNumber;
votingdistrict.WardID = WardID;
votingdistrict.Latitude = Latitude;
votingdistrict.Longitude = Longitude;
votingdistrict.Street = Street;
votingdistrict.Suburb = Suburb;
votingdistrict.Town = Town;
console.log(votingdistrict);

})
.catch(function(err){

});
});
$('#btnallvoterdetails').on('click', function (e) {
var Id = lsBasil.get('Id');
var accesstoken = lsBasil.get('accesstoken');
axios({url: 'https://api.elections.org.za/api/v1/Voters/GetVoterAllDetails?Id='+Id,
method: 'get',
headers: {'Authorization':'bearer ' + accesstoken}, 
data: ''})
.then(function(response){
var voter = response.data;
console.log(voter);
var SpecialVoter = voter.SpecialVoter;
var Voter = voter.Voter;
var WardCouncilor = voter.WardCouncilor;
var ApplicationStatus = SpecialVoter.ApplicationStatus;
var IsOpen = SpecialVoter.IsOpen;
var SpecialVotesStatus = SpecialVoter.SpecialVotesStatus;
var Id = Voter.Id;
var VoterId = Voter.VoterId;
var VoterStatus = Voter.VoterStatus;
var VoterStatusID = Voter.VoterStatusID;
var VotingStation = Voter.VotingStation;
var bRegistered = Voter.bRegistered;
var Delimitation = VotingStation.Delimitation;
var Location = VotingStation.Location;
var Name = VotingStation.Name;
var Municipality = Delimitation.Municipality;
var MunicipalityID = Delimitation.MunicipalityID;
var Province = Delimitation.Province;
var ProvinceID = Delimitation.ProvinceID;
var VDNumber = Delimitation.VDNumber;
var WardID = Delimitation.WardID;
var Latitude = Location.Latitude;
var Longitude = Location.Longitude;
var Street = Location.Street;
var Suburb = Location.Suburb;
var Town = Location.Town;
var Delimitation = WardCouncilor.Delimitation;
var Municipality = WardCouncilor.Municipality;
var Name = WardCouncilor.Name;
var PartyDetail = WardCouncilor.PartyDetail;
var ContactDetails = Municipality.ContactDetails;
var ID = Municipality.ID;
var Name = Municipality.Name;
var Municipality = Delimitation.Municipality;
var MunicipalityID = Delimitation.MunicipalityID;
var Province = Delimitation.Province;
var ProvinceID = Delimitation.ProvinceID;
var VDNumber = Delimitation.VDNumber;
var WardID = Delimitation.WardID;
var ContactPerson = ContactDetails.ContactPerson;
var Fax = ContactDetails.Fax;
var PostalAddress = ContactDetails.PostalAddress;
var Tel = ContactDetails.Tel;
var WebsiteUrl = ContactDetails.WebsiteUrl;
var Abbreviation = PartyDetail.Abbreviation;
var ContactDetails = PartyDetail.ContactDetails;
var ID = PartyDetail.ID;
var LogoUrl = PartyDetail.LogoUrl;
var Name = PartyDetail.Name;
var RegLevel = PartyDetail.RegLevel;
var RegStatus = PartyDetail.RegStatus;
var ContactPerson = ContactDetails.ContactPerson;
var Fax = ContactDetails.Fax;
var PostalAddress = ContactDetails.PostalAddress;
var Tel = ContactDetails.Tel;
var WebsiteUrl = ContactDetails.WebsiteUrl;

})
.catch(function(err){

});
});
$('#btngetfaqcategories').on('click', function (e) {
var accesstoken = lsBasil.get('accesstoken');
axios({url: 'https://api.elections.org.za/api/v1/FAQ/GetFAQCategories',
method: 'get',
headers: {'Authorization':'bearer ' + accesstoken}, 
data: ''})
.then(function(response){
var faqcategories = response.data;
console.log(faqcategories);
var totfaq = faqcategories.length;
console.log(totfaq);
for (var category in faqcategories){
  var faq = faqcategories[category];
var Id = faq.Id;
var Description = faq.Description;
console.log(faq);
axios({url: 'https://api.elections.org.za/api/v1/FAQ?CategoryID=' + Id,
method: 'get',
headers: {'Authorization':'bearer ' + accesstoken}, 
data: ''})
.then(function(response){
var questions = response.data;
console.log(questions);
for (var queskey in questions){
  var question = questions[queskey];
var Answer = question.Answer;
var Question = question.Question;
console.log(question);

}

})
.catch(function(err){

});

}

})
.catch(function(err){

});
});
$('#btngetfaqs').on('click', function (e) {
var accesstoken = lsBasil.get('accesstoken');
axios({url: 'https://api.elections.org.za/api/v1/FAQ',
method: 'get',
headers: {'Authorization':'bearer ' + accesstoken}, 
data: ''})
.then(function(response){
var faqs = response.data;
console.log(faqs);

})
.catch(function(err){

});
});
$('#btngisvd').on('click', function (e) {
var accesstoken = lsBasil.get('accesstoken');
var VDNumber = lsBasil.get('VDNumber');
axios({url: 'https://api.elections.org.za/api/v1/GIS?VDNumber=' + VDNumber,
method: 'get',
headers: {'Authorization':'bearer ' + accesstoken}, 
data: ''})
.then(function(response){
var gisvd = response.data;
console.log(gisvd);

})
.catch(function(err){

});
});
$('#btngisvdbase64').on('click', function (e) {
var accesstoken = lsBasil.get('accesstoken');
var VDNumber = lsBasil.get('VDNumber');
axios({url: 'https://api.elections.org.za/api/v1/GIS/GetBase64?VDNumber=' + VDNumber,
method: 'get',
headers: {'Authorization':'bearer ' + accesstoken}, 
data: ''})
.then(function(response){
var gisvd = response.data;
var Base64Image = gisvd.Base64Image;
console.log(Base64Image);

})
.catch(function(err){

});
});
$('#btnwcvoter').on('click', function (e) {
var accesstoken = lsBasil.get('accesstoken');
var Id = lsBasil.get('Id');
axios({url: 'https://api.elections.org.za/api/v1/LGEWardCouncilor/' + Id,
method: 'get',
headers: {'Authorization':'bearer ' + accesstoken}, 
data: ''})
.then(function(response){
var wc = response.data;
console.log(wc);

})
.catch(function(err){

});
});
$('#btnwcward').on('click', function (e) {
var accesstoken = lsBasil.get('accesstoken');
var WardID = lsBasil.get('WardID');
axios({url: 'https://api.elections.org.za/api/v1/LGEWardCouncilor?WardID=' + WardID,
method: 'get',
headers: {'Authorization':'bearer ' + accesstoken}, 
data: ''})
.then(function(response){
var wcw = response.data;
console.log(wcw);

})
.catch(function(err){

});
});
$('#btndelimitation').on('click', function (e) {
var accesstoken = lsBasil.get('accesstoken');
var Latitude = lsBasil.get('Latitude');
var Longitude = lsBasil.get('Longitude');
axios({url: 'https://api.elections.org.za/api/v1/Delimitation?Latitude='+Latitude+'&Longitude='+Longitude,
method: 'get',
headers: {'Authorization':'bearer ' + accesstoken}, 
data: ''})
.then(function(response){
var delim = response.data;
console.log(delim);

})
.catch(function(err){

});
});
$('#btnelection').on('click', function (e) {
var accesstoken = lsBasil.get('accesstoken');
axios({url: 'https://api.elections.org.za/api/v1/Delimitation?ElectoralEventID=2014',
method: 'get',
headers: {'Authorization':'bearer ' + accesstoken}, 
data: ''})
.then(function(response){
var delim = response.data;
console.log(delim);

})
.catch(function(err){

});
});
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
