var colors = HTMLColors();
var activerow;
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
var _mashwb;
	var amashwb = [];
	var loadingEle = $('.mashwb');
	var loading_width = loadingEle.width(),loading_height = loadingEle.height();
	$('.mashwb').createWaterBall({
		cvs_config:{
			width:loading_width,
			height:loading_height
		},
		wave_config:{
            waveWidth:0,
            waveHeight:5
        },
        data_range:[35,70,90],
        isLoading:false,
        nowRange:0,
        targetRange:80
	});
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var _mashwb1;
	var amashwb1 = [];
	var loadingEle = $('.mashwb1');
	var loading_width = loadingEle.width(),loading_height = loadingEle.height();
	$('.mashwb1').createWaterBall({
		cvs_config:{
			width:loading_width,
			height:loading_height
		},
		wave_config:{
            waveWidth:0,
            waveHeight:5
        },
        data_range:[50,80,100],
        isLoading:false,
        nowRange:100,
        targetRange:20
	});
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
