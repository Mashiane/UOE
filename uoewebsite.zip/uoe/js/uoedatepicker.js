var colors = HTMLColors();
var activerow;
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
var datedp = $('#dp').datepicker({showClearBtn:true,
	showDaysInNextAndPreviousMonths:true,
	showMonthAfterYear:true,
	yearRange:10,
	firstDay:0,
	disableWeekends:false,
	setDefaultDate:true,
	format:'yyyy-mm-dd',
	autoClose: false,
	i18n: {
		cancel: 'Cancel',
        clear: 'Clear',
		done: 'Ok',
		previousMonth: '<',
		nextMonth: '>'
      }
	});
var instdp = document.getElementById('dp');
		var dpinst = M.Datepicker.getInstance(instdp);
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var timedp1 = $('#dp1').timepicker({showClearBtn:true,
	twelveHour:false,
	defaultTime:'now',
	format:'yyyy-mm-dd',
	vibrate: true,
	autoClose: false,
	i18n: {
		cancel: 'Cancel',
        clear: 'Clear',
		done: 'Ok'
	  }
	});
	timedp1.showView('hours');
var instdp1 = document.getElementById('dp1');
		var dp1inst = M.Timepicker.getInstance(instdp1);
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
