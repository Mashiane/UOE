M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
$('.mib1').countTo({
	formatter: function (value, options) {
      return value.toFixed(options.decimals);
    },
	onUpdate: function (value) {
      console.debug(this);
    },
    onComplete: function (value) {
	  $(this).text('125');
    }
	});
$(document).on('click', '#mib1', function(e){
	e.preventDefault();
M.toast({html:'<div>mib1</div>', displayLength:3000, classes:'rounded white-text  green'});
});
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){

});
