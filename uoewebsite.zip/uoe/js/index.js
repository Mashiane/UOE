var colors = HTMLColors();
var activerow;
function speech_onend(lastReadId, lastReadclassNames, data){
switch(lastReadId){
case '#welcome':
	var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#intro').articulate('speak');
	break;
case '#intro':
	var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#intro1').articulate('speak');
	break;
case '#intro1':
	var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#example').articulate('speak');
	break;
case '#example':
	var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#needs').articulate('speak');
	break;
case '#needs':
	var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#intro2').articulate('speak');
	break;
case '#intro2':
	var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#intro3').articulate('speak');
	break;
case '#intro3':
	var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#howisthissite').articulate('speak');
	break;
case '#howisthissite':
	var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#howisthissite1').articulate('speak');
	break;
case '#howisthissite1':
	var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#source').articulate('speak');
	break;
case '#source':
	var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#intro4').articulate('speak');
	break;
case '#intro4':
	var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#getstarted').articulate('speak');
	break;
}

}
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var cdchip2block = document.getElementById('cdchip2code');
Prism.highlightElement(cdchip2block);
$('#speakdiv').floatingActionButton({hoverEnabled: true,
	direction:'top',
	toolbarEnabled: false});
$(document).on('click', '#speak', function(e){
	e.preventDefault();
var isSpeaking = $().articulate('isSpeaking');
	if (isSpeaking){
  $().articulate('pause');
}
	var isPaused = $().articulate('isPaused');
	if (isPaused){
  $().articulate('resume');
}
	$('#welcome').articulate('speak');
});
$('#navbar').attr('data-step', '1');
$('#navbar').attr('data-intro', 'This is the navigation bar of the page, it uses the UOENavBar class and referenced as Page.NavBar');
$('#navbar').attr('data-hint', 'This is the navigation bar of the page, it uses the UOENavBar class and referenced as Page.NavBar');
function startTour() {
			var tour = introJs();
			tour.setOption('tooltipPosition', 'auto');
			tour.setOption('positionPrecedence', ['left', 'right', 'bottom', 'top']);
			tour.start();
		}
$('#navmenu').attr('data-step', '2');
$('#navmenu').attr('data-intro', 'This is the hamburger menu to show the sidebar. You can show / hide it.');
$('#navmenu').attr('data-hint', 'This is the hamburger menu to show the sidebar. You can show / hide it.');
$('#indexcont').attr('data-step', '3');
$('#indexcont').attr('data-intro', 'Each page has a container where each component can be placed on inside a grid. A grid will have rows and columns. This container has been placed on the center of the page.');
$('#indexcont').attr('data-hint', 'Each page has a container where each component can be placed on inside a grid. A grid will have rows and columns. This container has been placed on the center of the page.');
$('#welcome').attr('data-step', '4');
$('#welcome').attr('data-intro', 'We added a BlockQuote component here to emphasize the topic. We did this with the AddBlockQuote call.');
$('#welcome').attr('data-hint', 'We added a BlockQuote component here to emphasize the topic. We did this with the AddBlockQuote call.');
$('#intro').attr('data-step', '5');
$('#intro').attr('data-intro', 'We applied some CSS to this paragraph to make it bold and italic after adding it with the AddParagraph call.');
$('#intro').attr('data-hint', 'We applied some CSS to this paragraph to make it bold and italic after adding it with the AddParagraph call.');
$('#cd2').attr('data-step', '6');
$('#cd2').attr('data-intro', 'This is a code block, it shows sample UOE library source code that you can use.');
$('#cd2').attr('data-hint', 'This is a code block, it shows sample UOE library source code that you can use.');
$('#intro3').attr('data-step', '7');
$('#intro3').attr('data-intro', 'We used an UOELabel component to add this paragraph.');
$('#intro3').attr('data-hint', 'We used an UOELabel component to add this paragraph.');
$('#getstarted').attr('data-step', '8');
$('#getstarted').attr('data-intro', 'Using the AddLink container call, we were able to add this hyperlink.');
$('#getstarted').attr('data-hint', 'Using the AddLink container call, we were able to add this hyperlink.');
$('#speak').attr('data-step', '9');
$('#speak').attr('data-intro', 'We have added a floating action button to activate speech functionality when selected. This we did with the AddFAB page method.');
$('#speak').attr('data-hint', 'We have added a floating action button to activate speech functionality when selected. This we did with the AddFAB page method.');
$('#footer').attr('data-step', '10');
$('#footer').attr('data-intro', 'This is the footer the page, it uses the UOEFooter class and shows copyrights information and other things.');
$('#footer').attr('data-hint', 'This is the footer the page, it uses the UOEFooter class and shows copyrights information and other things.');
$(document).on('click', '#btntour', function(e){
	e.preventDefault();
startTour();
});
startTour();
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
