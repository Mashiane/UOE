M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
L.MakiMarkers.accessToken = "pk.eyJ1IjoibWFzaGlhbmUiLCJhIjoiY2pqM2YwMHR3MHFpbTNwbXFmeGhlM2xzcCJ9.Q7I83tBGhYq9unYse-4_jA";
var mapmll = L.map('mll',{
	fullscreenControl: {pseudoFullscreen: false}
	}).setView([-32.9499962, 27.7666636], 13);
var tilesmll = L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
	id: 'mapbox.satellite',
    accessToken: 'pk.eyJ1IjoibWFzaGlhbmUiLCJhIjoiY2pqM2YwMHR3MHFpbTNwbXFmeGhlM2xzcCJ9.Q7I83tBGhYq9unYse-4_jA'
}).addTo(mapmll);
	var _mll;var amll = [];
var im1 = L.MakiMarkers.icon({icon: null, color: null});
var mm1 = L.marker([-32.9499962, 27.7666636], {icon: im1}).addTo(mapmll);
mm1.bindPopup("Anele Mashy Mbanga");
var im2 = L.MakiMarkers.icon({icon: "zoo",color: "red", size: "l"});
var mm2 = L.marker([-32.95, 27.76], {icon: im2}).addTo(mapmll);
mm2.bindPopup("The Zoo");
var im3 = L.MakiMarkers.icon({icon: null,color: "green", size: null});
var mm3 = L.marker([-32.95, 27.77], {icon: im3}).addTo(mapmll);
mm3.bindPopup("Green Marker");



var poppop1 = L.popup().setLatLng([-32.94, 27.78]).setContent("I am a standalone popup.").openOn(mapmll);



function onMapClickmll(e) {
		$('#').val(e.latlng); 
	}
	mapmll.on('click', onMapClickmll);
L.control.coordinates({
			position:"bottomleft",
			decimals:2,
			decimalSeperator:",",
			labelTemplateLat:"Lat: {y}",
			labelTemplateLng:"Lng: {x}"
		}).addTo(mapmll);
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
L.MakiMarkers.accessToken = "pk.eyJ1IjoibWFzaGlhbmUiLCJhIjoiY2pqM2YwMHR3MHFpbTNwbXFmeGhlM2xzcCJ9.Q7I83tBGhYq9unYse-4_jA";
var mapmllc = L.map('mllc',{
	fullscreenControl: {pseudoFullscreen: false}
	}).setView([-32.9499962, 27.7666636], 6);
var tilesmllc = L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
	id: 'mapbox.comic',
    accessToken: 'pk.eyJ1IjoibWFzaGlhbmUiLCJhIjoiY2pqM2YwMHR3MHFpbTNwbXFmeGhlM2xzcCJ9.Q7I83tBGhYq9unYse-4_jA'
}).addTo(mapmllc);
	var _mllc;var amllc = [];






function onMapClickmllc(e) {
		$('#').val(e.latlng); 
	}
	mapmllc.on('click', onMapClickmllc);
L.control.coordinates({
			position:"bottomleft",
			decimals:2,
			decimalSeperator:",",
			labelTemplateLat:"Lat: {y}",
			labelTemplateLng:"Lng: {x}"
		}).addTo(mapmllc);
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
L.MakiMarkers.accessToken = "pk.eyJ1IjoibWFzaGlhbmUiLCJhIjoiY2pqM2YwMHR3MHFpbTNwbXFmeGhlM2xzcCJ9.Q7I83tBGhYq9unYse-4_jA";
var mapmllp = L.map('mllp',{
	fullscreenControl: {pseudoFullscreen: false}
	}).setView([51.5, -0.09], 13);
var tilesmllp = L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
	id: 'mapbox.streets',
    accessToken: 'pk.eyJ1IjoibWFzaGlhbmUiLCJhIjoiY2pqM2YwMHR3MHFpbTNwbXFmeGhlM2xzcCJ9.Q7I83tBGhYq9unYse-4_jA'
}).addTo(mapmllp);
	var _mllp;var amllp = [];

var cc1 = L.circle([51.508, -0.11],{color:'red',fillColor:'amber',fillOpacity:0.5,radius:300,weight:1}).addTo(mapmllp);
cc1.bindPopup("<b>Hello world!</b><br />I am a popup.");

var pp1 = L.polygon([[51.509,-0.08],[51.503,-0.06],[51.51,-0.047]],{opacity:1.0,color:'red',fillColor:'green',fillOpacity:1.0,weight:1}).addTo(mapmllp);
pp1.bindPopup("A nice polygon");
mapmllp.fitBounds(pp1.getBounds());




function onMapClickmllp(e) {
		$('#').val(e.latlng); 
	}
	mapmllp.on('click', onMapClickmllp);
L.control.coordinates({
			position:"bottomleft",
			decimals:2,
			decimalSeperator:",",
			labelTemplateLat:"Lat: {y}",
			labelTemplateLng:"Lng: {x}"
		}).addTo(mapmllp);
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
L.MakiMarkers.accessToken = "pk.eyJ1IjoibWFzaGlhbmUiLCJhIjoiY2pqM2YwMHR3MHFpbTNwbXFmeGhlM2xzcCJ9.Q7I83tBGhYq9unYse-4_jA";
var mapmllx = L.map('mllx',{
	fullscreenControl: {pseudoFullscreen: false}
	}).setView([45.51, -122.68], 6);
var tilesmllx = L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
	id: 'mapbox.streets',
    accessToken: 'pk.eyJ1IjoibWFzaGlhbmUiLCJhIjoiY2pqM2YwMHR3MHFpbTNwbXFmeGhlM2xzcCJ9.Q7I83tBGhYq9unYse-4_jA'
}).addTo(mapmllx);
	var _mllx;var amllx = [];




var plpl1 = L.polyline([[45.51,-122.68],[37.77,-122.43],[34.04,-118.2]],{opacity:1.0,color:'blue',fillColor:'blue',fillOpacity:1.0,weight:1}).addTo(mapmllx);
plpl1.bindPopup("My poly line");
mapmllx.fitBounds(plpl1.getBounds());


function onMapClickmllx(e) {
		$('#').val(e.latlng); 
	}
	mapmllx.on('click', onMapClickmllx);
L.control.coordinates({
			position:"bottomleft",
			decimals:2,
			decimalSeperator:",",
			labelTemplateLat:"Lat: {y}",
			labelTemplateLng:"Lng: {x}"
		}).addTo(mapmllx);
var cd5block = document.getElementById('cd5code');
Prism.highlightElement(cd5block);
L.MakiMarkers.accessToken = "pk.eyJ1IjoibWFzaGlhbmUiLCJhIjoiY2pqM2YwMHR3MHFpbTNwbXFmeGhlM2xzcCJ9.Q7I83tBGhYq9unYse-4_jA";
var mapmllx1 = L.map('mllx1',{
	fullscreenControl: {pseudoFullscreen: false}
	}).setView([45.51, -122.68], 13);
var tilesmllx1 = L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
	id: 'mapbox.streets',
    accessToken: 'pk.eyJ1IjoibWFzaGlhbmUiLCJhIjoiY2pqM2YwMHR3MHFpbTNwbXFmeGhlM2xzcCJ9.Q7I83tBGhYq9unYse-4_jA'
}).addTo(mapmllx1);
	var _mllx1;var amllx1 = [];






function onLocationFoundmllx1(e) {
		var radius = e.accuracy / 2;
        var location = e.latlng
        L.marker(location).addTo(mapmllx1)
        L.circle(location, radius).addTo(mapmllx1);
		$('#txtlocation').val(e.latlng);  
	}
	function onLocationErrormllx1(e) {
	}
	mapmllx1.on('locationfound', onLocationFoundmllx1);
	mapmllx1.on('locationerror', onLocationErrormllx1);
	mapmllx1.locate({setView: true, maxZoom: 18});
function onMapClickmllx1(e) {
		$('#txtlocation').val(e.latlng); 
	}
	mapmllx1.on('click', onMapClickmllx1);
L.control.coordinates({
			position:"bottomleft",
			decimals:2,
			decimalSeperator:",",
			labelTemplateLat:"Lat: {y}",
			labelTemplateLng:"Lng: {x}"
		}).addTo(mapmllx1);
var cd6block = document.getElementById('cd6code');
Prism.highlightElement(cd6block);
L.MakiMarkers.accessToken = "pk.eyJ1IjoibWFzaGlhbmUiLCJhIjoiY2pqM2YwMHR3MHFpbTNwbXFmeGhlM2xzcCJ9.Q7I83tBGhYq9unYse-4_jA";
var mapshape = L.map('shape',{
	fullscreenControl: {pseudoFullscreen: false}
	}).setView([-28.4792625, 24.6727135], 5);
var tilesshape = L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
	id: 'mapbox.streets',
    accessToken: 'pk.eyJ1IjoibWFzaGlhbmUiLCJhIjoiY2pqM2YwMHR3MHFpbTNwbXFmeGhlM2xzcCJ9.Q7I83tBGhYq9unYse-4_jA'
}).addTo(mapshape);
	var _shape;var ashape = [];





var georsaadmin = L.geoJson({features:[]},{onEachFeature:function popUp(f,l){
    		var out = [];
    		if (f.properties){
        		for(var key in f.properties){
            	out.push(key+": "+f.properties[key]);
        }
        l.bindPopup(out.join("<br />"));
    }
}}).addTo(mapshape);
      var basersaadmin = 'gis/ZAF_adm.zip';
		shp(basersaadmin).then(function(data){
		georsaadmin.addData(data);
		});

function onMapClickshape(e) {
		$('#').val(e.latlng); 
	}
	mapshape.on('click', onMapClickshape);
L.control.coordinates({
			position:"bottomleft",
			decimals:2,
			decimalSeperator:",",
			labelTemplateLat:"Lat: {y}",
			labelTemplateLng:"Lng: {x}"
		}).addTo(mapshape);
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){

});
