var sdl1block = document.getElementById('sdl1code');
Prism.highlightElement(sdl1block);
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawercollapse').collapsible({
	accordion: true,
	onOpenStart: function(el) {
                   
               },
    onOpenEnd: function(el) {
                   
               },
	onCloseStart: function(el) {
                   
               },
	onCloseEnd: function(el) {
                   
               }
	});
$('#navbardrawer').sidenav({
	draggable:true,
	preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
$(document).on('click', '#btnshowtoast', function(){
M.toast({html:'<div>This is my other button</div>', displayLength:3000, classes:'rounded white-text  orange'});
});
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
});
