M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
$('#splitflap').splitFlap({
	image:'images/chars.png',
	imageSize:'',
	charsMap:'ABCDEFGHIJKLMNOPQRSTUVWXYZ 0123456789.,!?#@()+-=',
	charWidth:50,
	charHeight:100,
	charSubstitute:' ',
	speed:5,
	speedVariation:2,
	text:'UOE Material Websites',
	textInit:'',
	autoplay:true,
	onComplete:function(){}
	});
	var _splitflap;
	var asplitflap = [];
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){

});
