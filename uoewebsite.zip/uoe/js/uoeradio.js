M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
function handleRadioc1(){
	// get value of radio
myradio = $("input[name='c1']:checked").val();
// show value on a toast
M.toast({html:myradio, displayLength:3000, classes:'rounded white-text green'});
	}
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
var cd5block = document.getElementById('cd5code');
Prism.highlightElement(cd5block);
function handleRadiomale(){
	// get value of radio
myradio = $("input[name='rg']:checked").val();
// show value on a toast
M.toast({html:myradio, displayLength:3000, classes:'rounded white-text green'});
	}
function handleRadiofemale(){
	// get value of radio
myradio = $("input[name='rg']:checked").val();
// show value on a toast
M.toast({html:myradio, displayLength:3000, classes:'rounded white-text green'});
	}
var cd6block = document.getElementById('cd6code');
Prism.highlightElement(cd6block);
var cd7block = document.getElementById('cd7code');
Prism.highlightElement(cd7block);
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){

});
