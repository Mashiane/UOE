$('#et1').easyTicker({
	direction: 'up',
	easing: 'swing',
	speed: 'slow',
	interval: 4000,
	height: 'auto',
	visible: 1,
	mousePause: 1,
	controls: {
		up: '',
		down: '',
		toggle: '',
		playText: 'Play',
		stopText: 'Stop'
	}
});
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
$('#et').easyTicker({
	direction: 'up',
	easing: 'swing',
	speed: 'slow',
	interval: 2000,
	height: 'auto',
	visible: 3,
	mousePause: 1,
	controls: {
		up: '',
		down: '',
		toggle: '',
		playText: 'Play',
		stopText: 'Stop'
	}
});
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawercollapse').collapsible({
	accordion: true,
	onOpenStart: function(el) {
                   
               },
    onOpenEnd: function(el) {
                   
               },
	onCloseStart: function(el) {
                   
               },
	onCloseEnd: function(el) {
                   
               }
	});
$('#navbardrawer').sidenav({
	draggable:true,
	preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var colors = HTMLColors();
var activerow;
function speech_onend(lastReadId, lastReadclassNames, data){
console.log('');
}
});
