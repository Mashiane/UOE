var colors = HTMLColors();
var activerow;
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var code2block = document.getElementById('code2code');
Prism.highlightElement(code2block);
var code3block = document.getElementById('code3code');
Prism.highlightElement(code3block);
var gridfefblock = document.getElementById('gridfefcode');
Prism.highlightElement(gridfefblock);
var blockitblock = document.getElementById('blockitcode');
Prism.highlightElement(blockitblock);
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
