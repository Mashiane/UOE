var colors = HTMLColors();
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
$(document).on('click', '#btnagree', function(){
modalpinst.close();
});
$(document).on('click', '#btncancel', function(){
modalpinst.close();
});
$('#modalp').modal({startingTop:'4%',endingTop:'10%',dismissible: false,
	preventScrolling: true});
var instmodalp = document.getElementById('modalp');
	var modalpinst = M.Modal.getInstance(instmodalp);
$(document).on('click', '#btnopen', function(){
modalpinst.open();
});
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
$(document).on('click', '#btnagree', function(){
modalp1inst.close();
});
$(document).on('click', '#btncancel', function(){
modalp1inst.close();
});
$('#modalp1').modal({startingTop:'4%',endingTop:'10%',dismissible: false,
	preventScrolling: true});
var instmodalp1 = document.getElementById('modalp1');
	var modalp1inst = M.Modal.getInstance(instmodalp1);
$(document).on('click', '#btnopen1', function(){
modalp1inst.open();
});
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
$(document).on('click', '#btnagree', function(){
modalp2inst.close();
});
$(document).on('click', '#btncancel', function(){
modalp2inst.close();
});
$('#modalp2').modal({startingTop:'4%',endingTop:'10%',dismissible: false,
	preventScrolling: true});
var instmodalp2 = document.getElementById('modalp2');
	var modalp2inst = M.Modal.getInstance(instmodalp2);
$(document).on('click', '#btnopen2', function(){
modalp2inst.open();
});
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
