var colors = HTMLColors();
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
$('#myeditor').trumbowyg({});
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
var quill = new Quill('#quill', {
  modules: {
    toolbar: [
      [{ header: [1, 2, 3, 4, 5, 6, false] }],
      ['bold', 'italic', 'underline', 'strike'],
      ['link', 'image'],
	  ['blockquote', 'code-block'],
	  [{ 'list': 'ordered'}, { 'list': 'bullet' }],
  	  [{ 'script': 'sub'}, { 'script': 'super' }],
      [{ 'indent': '-1'}, { 'indent': '+1' }], 
	  [{ 'color': [] }, { 'background': [] }], 
      [{ 'align': [] }]
    ]
  },
  placeholder: '',
  theme: 'snow'  // or 'bubble'
});
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
