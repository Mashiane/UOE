var colors = HTMLColors();
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var sd1block = document.getElementById('sd1code');
Prism.highlightElement(sd1block);
$('#car1').carousel({fullwidth: true,
	duration:200,
	numVisible:5,
	dist:-100,
	shift:0,
	padding:0,
	indicators:true,
	onCycleTo: function(item, dragged) {},
	nowrap:false});
var instcar1 = document.getElementById('car1');
	var car1inst = M.Carousel.getInstance(instcar1);
$(document).on('click', '#btnprev', function(){
car1inst.prev();
});
$(document).on('click', '#btnnext', function(){
car1inst.next();
});
$(document).on('click', '#btn3', function(){
car1inst.set(3);
});
var sd2block = document.getElementById('sd2code');
Prism.highlightElement(sd2block);
$('#car0').carousel({fullwidth: true,
	duration:200,
	numVisible:5,
	dist:-100,
	shift:0,
	padding:0,
	indicators:true,
	onCycleTo: function(item, dragged) {},
	nowrap:false});
var instcar0 = document.getElementById('car0');
	var car0inst = M.Carousel.getInstance(instcar0);
$('#car1').carousel({fullwidth: true,
	duration:200,
	numVisible:5,
	dist:-100,
	shift:0,
	padding:0,
	indicators:true,
	onCycleTo: function(item, dragged) {},
	nowrap:false});
var instcar1 = document.getElementById('car1');
	var car1inst = M.Carousel.getInstance(instcar1);
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
