var colors = HTMLColors();
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var ccd1block = document.getElementById('ccd1code');
Prism.highlightElement(ccd1block);
$('#mychips').chips({
	secondaryPlaceholder:'',
	placeholder:'',
	onChipDelete: function (e, data) { mychipschipDeleted(e, data) },
	onChipSelect: function (e, data) { mychipschipSelect(e, data) },
    onChipAdd: function (e, data) { mychipschipAdded(e, data) }
	});
function mychipschipDeleted(e, data) {
	M.toast({html:'<div>Chip has been deleted</div>', displayLength:3000, classes:'rounded  red white-text '});
	}
	function mychipschipAdded(e, data) {
	M.toast({html:'<div>Chip has been added</div>', displayLength:3000, classes:'rounded  green white-text '});
	}
	function mychipschipSelect(e, data) {
	
	}
$('#mychips').chips({data: [{tag: 'Apple',},{tag: 'Microsoft',},{tag: 'Google',}],});
var instmychips = document.getElementById('mychips');
	var mychipsinst = M.Chips.getInstance(instmychips);
var ccd2block = document.getElementById('ccd2code');
Prism.highlightElement(ccd2block);
$('#mychips1').chips({
	secondaryPlaceholder:'',
	placeholder:'',
	onChipDelete: function (e, data) { mychips1chipDeleted(e, data) },
	onChipSelect: function (e, data) { mychips1chipSelect(e, data) },
    onChipAdd: function (e, data) { mychips1chipAdded(e, data) }
	});
function mychips1chipDeleted(e, data) {
	M.toast({html:'<div>Chip has been deleted</div>', displayLength:3000, classes:'rounded  red white-text '});
	}
	function mychips1chipAdded(e, data) {
	M.toast({html:'<div>Chip has been added</div>', displayLength:3000, classes:'rounded  green white-text '});
	}
	function mychips1chipSelect(e, data) {
	
	}
$('#mychips1').chips({autocompleteOptions: {data: {'Xolani': null,'Apple': null,'Microsoft': null,'Google': null,'Anele': null,'Mbanga': null},limit: Infinity,minLength: 1}});
var instmychips1 = document.getElementById('mychips1');
	var mychips1inst = M.Chips.getInstance(instmychips1);
var ccd3block = document.getElementById('ccd3code');
Prism.highlightElement(ccd3block);
$('#mychips2').chips({
	secondaryPlaceholder:'+Tag',
	placeholder:'Enter a Tag',
	onChipDelete: function (e, data) { mychips2chipDeleted(e, data) },
	onChipSelect: function (e, data) { mychips2chipSelect(e, data) },
    onChipAdd: function (e, data) { mychips2chipAdded(e, data) }
	});
function mychips2chipDeleted(e, data) {
	M.toast({html:'<div>Chip has been deleted</div>', displayLength:3000, classes:'rounded  red white-text '});
	}
	function mychips2chipAdded(e, data) {
	M.toast({html:'<div>Chip has been added</div>', displayLength:3000, classes:'rounded  green white-text '});
	}
	function mychips2chipSelect(e, data) {
	
	}
var instmychips2 = document.getElementById('mychips2');
	var mychips2inst = M.Chips.getInstance(instmychips2);
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
