var colors = HTMLColors();
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
var cd5block = document.getElementById('cd5code');
Prism.highlightElement(cd5block);
var cd6block = document.getElementById('cd6code');
Prism.highlightElement(cd6block);
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
