var colors = HTMLColors();
var mkimmo;
var mkimmo1;
var mkimmo2;
var mgeo;
var mgeoc;
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
mkimmo = new GMaps({
div: '#kimmo',
lat: -12.043333,
lng: -77.028336,
enableNewStyle: true,
click: function(e) {},
dragend: function(e) {}
});
mkimmo.addMarker({
		lat: -12.043333,
		lng: -77.028336,
		title: 'Lima',
		infoWindow: {
		  content: 'Home'
		},
		click: function(e) {	M.toast({html:'<div>You clicked me!</div>', displayLength:3000, classes:'rounded  green white-text '});	}
		});
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
mkimmo1 = new GMaps({
div: '#kimmo1',
lat: -12.043333,
lng: -77.028336,
enableNewStyle: true,
click: function(e) {},
dragend: function(e) {}
});
var plp1 = [[-12.044013023376465,-77.02470397949219],[-12.054492950439453,-77.03024291992188],[-12.055122375488281,-77.0303955078125],[-12.07591724395752,-77.02764892578125],[-12.0763578414917,-77.02792358398438],[-12.07681941986084,-77.0289306640625],[-12.08852767944336,-77.02410888671875],[-12.090814590454102,-77.02271270751953]];
mkimmo1.drawPolyline({
path: plp1,
strokeColor: '#131540',
strokeOpacity: 0.6,
strokeWeight: 6
});
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
mkimmo2 = new GMaps({
div: '#kimmo2',
lat: -12.043333,
lng: -77.028336,
enableNewStyle: true,
click: function(e) {},
dragend: function(e) {}
});
var pgpg1 = [[-12.040397644042969,-77.03373718261719],[-12.04024887084961,-77.0399398803711],[-12.050046920776367,-77.02448272705078],[-12.044804573059082,-77.02154541015625]];
mkimmo2.drawPolygon({
paths: pgpg1,
strokeColor: '#BBD8E9',
strokeOpacity: 1,
strokeWeight: 3,
fillColor: '#BBD8E9',
fillOpacity: 0.6  
});
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
mgeo = new GMaps({
div: '#geo',
lat: -28.479263,
lng: 24.672714,
enableNewStyle: true,
click: function(e) {},
dragend: function(e) {}
});
$(document).on('click', '#btnlocate', function(){
GMaps.geolocate({
        success: function(position){
          mgeo.setCenter(position.coords.latitude, position.coords.longitude);
		  var geome = mgeo.addMarker({
		lat: position.coords.latitude,
		lng: position.coords.longitude,
		title: 'I am here!',
		infoWindow: {
		  content: 'I am here!'
		},
		click: function(e) {		}
		});
        },
        error: function(error){
          M.toast({html:error.message, displayLength:3000, classes:'rounded white-text red'});
        },
        not_supported: function(){
          M.toast({html:'<div>Geolocation is not supported!</div>', displayLength:3000, classes:'rounded  red white-text '});
        }
      });
});
var cd5block = document.getElementById('cd5code');
Prism.highlightElement(cd5block);
mgeoc = new GMaps({
div: '#geoc',
lat: -28.479263,
lng: 24.672714,
enableNewStyle: true,
click: function(e) {},
dragend: function(e) {}
});
$(document).on('click', '#btngeocode', function(){
var myaddress = "East London, South Africa";
var lat;
var lng;
GMaps.geocode({
address: myaddress,
callback: function(results, status) {
if (status == 'OK') {
var latlng = results[0].geometry.location;
lat = latlng.lat();
lng = latlng.lng();
mgeoc.setCenter(lat, lng);var addr = mgeoc.addMarker({
		lat: lat,
		lng: lng,
		title: 'GeoCode'
	});
}
}
});
});
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
