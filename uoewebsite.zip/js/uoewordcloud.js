var colors = HTMLColors();
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
var words = [
	{text:"Mashy", weight:45.0, link:'http://www.mbangas.com', handlers:{click:function() {
	mcloudwordClick('Mashy');
	}}},{text:"Ozzie", weight:15.0, link:'http://www.mbangas.com/ozzie', handlers:{click:function() {
	mcloudwordClick('Ozzie');
	}}},{text:"Orio", weight:9.0, link:'http://www.mbangas.com/orio', handlers:{click:function() {
	mcloudwordClick('Orio');
	}}},{text:"Ernesto", weight:8.0, link:'http://www.mbangas.com/ernesto', handlers:{click:function() {
	mcloudwordClick('Ernesto');
	}}}
	];
	$('#mcloud').jQCloud(words, {
	delay: 10,
	autoResize: true
	}
	);
function mcloudwordClick(word){
	
	}
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
