var colors = HTMLColors();
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
M.updateTextFields();
$('#tbla').toolbar({
	content: '#tblaoptions',
	position: 'top',
	animation: 'standard',
	style: 'primary',
	event: 'hover',
	hideOnClick: false
});
// Define any icon actions before calling the toolbar
$('.toolbar-icons a').on('click', function( event ) {
	event.preventDefault();
});
$('#tbla').on('toolbarItemClick',
   function( event, triggerButton ) {
      // this: the element the toolbar is attached to
	  var btnid = triggerButton.id;
	  switch (btnid) {
	  default:
break;
case "user":
M.toast({html:'<div>User button clicked!</div>', displayLength:3000, classes:'rounded  green white-text '});
break;
case "star":
M.toast({html:'<div>Star button clicked!</div>', displayLength:3000, classes:'rounded  green white-text '});
break;
case "edit":
M.toast({html:'<div>Edit button clicked!</div>', displayLength:3000, classes:'rounded  green white-text '});
break;
case "circle":
M.toast({html:'<div>Circle button clicked!</div>', displayLength:3000, classes:'rounded  green white-text '});
break;

	  }
   }
);
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
$('#tbl1').toolbar({
	content: '#tbl1options',
	position: 'left',
	animation: 'bounce',
	style: 'light',
	event: 'click',
	hideOnClick: true
});
// Define any icon actions before calling the toolbar
$('.toolbar-icons a').on('click', function( event ) {
	event.preventDefault();
});
$('#tbl1').on('toolbarItemClick',
   function( event, triggerButton ) {
      // this: the element the toolbar is attached to
	  var btnid = triggerButton.id;
	  switch (btnid) {
	  default:
break;

	  }
   }
);
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
$('#tbl2').toolbar({
	content: '#tbl2options',
	position: 'bottom',
	animation: 'flyin',
	style: 'warning',
	event: 'hover',
	hideOnClick: false
});
// Define any icon actions before calling the toolbar
$('.toolbar-icons a').on('click', function( event ) {
	event.preventDefault();
});
$('#tbl2').on('toolbarItemClick',
   function( event, triggerButton ) {
      // this: the element the toolbar is attached to
	  var btnid = triggerButton.id;
	  switch (btnid) {
	  default:
break;

	  }
   }
);
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
$('#tbl3').toolbar({
	content: '#tbl3options',
	position: 'top',
	animation: 'bounce',
	style: 'success',
	event: 'hover',
	hideOnClick: false
});
// Define any icon actions before calling the toolbar
$('.toolbar-icons a').on('click', function( event ) {
	event.preventDefault();
});
$('#tbl3').on('toolbarItemClick',
   function( event, triggerButton ) {
      // this: the element the toolbar is attached to
	  var btnid = triggerButton.id;
	  switch (btnid) {
	  default:
break;

	  }
   }
);
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
$('#tbl4').toolbar({
	content: '#tbl4options',
	position: 'top',
	animation: 'flip',
	style: 'info',
	event: 'hover',
	hideOnClick: false
});
// Define any icon actions before calling the toolbar
$('.toolbar-icons a').on('click', function( event ) {
	event.preventDefault();
});
$('#tbl4').on('toolbarItemClick',
   function( event, triggerButton ) {
      // this: the element the toolbar is attached to
	  var btnid = triggerButton.id;
	  switch (btnid) {
	  default:
break;

	  }
   }
);
var cd5block = document.getElementById('cd5code');
Prism.highlightElement(cd5block);
$('#tbl5').toolbar({
	content: '#tbl5options',
	position: 'right',
	animation: 'grow',
	style: 'danger',
	event: 'hover',
	hideOnClick: false
});
// Define any icon actions before calling the toolbar
$('.toolbar-icons a').on('click', function( event ) {
	event.preventDefault();
});
$('#tbl5').on('toolbarItemClick',
   function( event, triggerButton ) {
      // this: the element the toolbar is attached to
	  var btnid = triggerButton.id;
	  switch (btnid) {
	  default:
break;

	  }
   }
);
var cd6block = document.getElementById('cd6code');
Prism.highlightElement(cd6block);
var instnavbardrawercollapse = document.getElementById('navbardrawercollapse');
	var navbardrawercollapseinst = M.Collapsible.getInstance(instnavbardrawercollapse);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
