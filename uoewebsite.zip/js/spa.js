var colors = HTMLColors();
$(document).ready(function(){
M.AutoInit();$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});$('select').not('.disabled').formSelect();M.updateTextFields();$('#fabdiv').floatingActionButton({hoverEnabled: true,	direction:'top',	toolbarEnabled: false});var instp1 = document.getElementById('p1');	var p1inst = M.Parallax.getInstance(instp1);$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,	edge:'left'});if (is_touch_device()) {      $('#navbardrawer').css({ overflow: 'auto'});    }
});
