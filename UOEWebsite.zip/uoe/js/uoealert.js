
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
$('#alertclose').on('click', function (e) {
});
$("#alert .close").click(function() { $(this).closest('#alert').fadeOut('slow');});
$('#alertok').on('click', function (e) {
});
$('#alertcancel').on('click', function (e) {
});
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
$('#alert1close').on('click', function (e) {
});
$("#alert1 .close").click(function() { $(this).closest('#alert1').fadeOut('slow');});
$('#alert1ok').on('click', function (e) {
});
$('#alert1cancel').on('click', function (e) {
});
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
$('#alert2close').on('click', function (e) {
});
$("#alert2 .close").click(function() { $(this).closest('#alert2').fadeOut('slow');});
$('#alert2ok').on('click', function (e) {
});
$('#alert2cancel').on('click', function (e) {
});
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
$('#alert3close').on('click', function (e) {
});
$("#alert3 .close").click(function() { $(this).closest('#alert3').fadeOut('slow');});
$('#alert3ok').on('click', function (e) {
});
$('#alert3cancel').on('click', function (e) {
});
var cd5block = document.getElementById('cd5code');
Prism.highlightElement(cd5block);
$('#alert4close').on('click', function (e) {
});
$("#alert4 .close").click(function() { $(this).closest('#alert4').fadeOut('slow');});
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
