M.AutoInit();
$(document).ready(function(){
function pause() {
    		$('body').addClass('loaded');
	}
function resume() {
    		document.getElementById("loader-wrapper").style.display="none";
	}
pause();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
var diagram = flowchart.parse('st=>start: Start\n' +'e=>end: End\n' +'st=>start: Start\n' +'e=>end: End\n' +'welcome=>operation: Welcome\n' +'green=>operation: Green\n' +'yellow=>operation: Yellow\n' +'blue=>operation: Blue\n' +'color=>condition: What is your favourate color?\n' +'welcome->color\n' +'color(yes)->green\n' +'color(yes)->yellow');
  	diagram.drawSVG('anele', {
	'flowstate' : {
	
    }
    });
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
