
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
$('#fabdiv').floatingActionButton({hoverEnabled: true,
	direction:'top',
	toolbarEnabled: false});
$('#fab').on('click', function (e) {
$('#tt').tapTarget('open');});
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
