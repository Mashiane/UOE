
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
var bvbv = new Bideo();
  bvbv.init({
    // Video element
    videoEl: document.querySelector('#bvbackground'),
    // Container element
    container: document.querySelector('body'),
    // Resize
    resize: true,
    // autoplay: false,
    isMobile: window.matchMedia('(max-width: 768px)').matches,
    playButton: document.querySelector('#bvplay'),
    pauseButton: document.querySelector('#bvpause'),
    // Array of objects containing the src and type
    // of different video formats to add
    src: [
      {
        src: 'images/night.mp4',
        type: 'video/mp4'
      }
    ],
    // What to do once video loads (initial frame)
    onLoad: function () {
      document.querySelector('#bvcover').style.display = 'none';
    }
	});
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
