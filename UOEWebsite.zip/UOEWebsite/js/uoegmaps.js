var mkimmo;
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
mkimmo = new GMaps({
div: '#kimmo',
lat: -12.043333,
lng: -77.028336,
click: function(e) {},
dragend: function(e) {}
});
mkimmo.addMarker({
		lat: -12.043333,
		lng: -77.028336,
		title: 'Lima',
		infoWindow: {
		  content: 'Home'
		},
		click: function(e) {	M.toast({html:'<div>You clicked me!</div>', displayLength:3000, classes:'rounded  green white-text '});	}
		});
var plp1 = [[-12.044013,-77.024704],[-12.054493,-77.03024],[-12.055122,-77.030396],[-12.075917,-77.02765],[-12.076358,-77.02792],[-12.076819,-77.02893],[-12.088528,-77.02411],[-12.090815,-77.02271]];
mkimmo.drawPolyline({
path: plp1,
strokeColor: '#131540',
strokeOpacity: 0.6,
strokeWeight: 6
});
var pgpg1 = [[-12.040398,-77.03374],[-12.040249,-77.03994],[-12.050047,-77.02448],[-12.044805,-77.021545]];
mkimmo.drawPolygon({
path: pgpg1,
strokeColor: '#BBD8E9',
strokeOpacity: 1,
strokeWeight: 3,
fillColor: '#BBD8E9',
fillOpacity: 0.6  
});
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
