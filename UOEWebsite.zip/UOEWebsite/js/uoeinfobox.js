
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
$('.mib1').countTo({
	formatter: function (value, options) {
      return value.toFixed(options.decimals);
    },
	onUpdate: function (value) {
      console.debug(this);
    },
    onComplete: function (value) {
	  $(this).text('125');
    }
	});
$('#mib1').on('click', function (e) {
M.toast({html:'<div>mib1</div>', displayLength:3000, classes:'rounded  green white-text '});});
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
