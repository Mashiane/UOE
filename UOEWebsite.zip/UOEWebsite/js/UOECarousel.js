
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
var sd1block = document.getElementById('sd1code');
Prism.highlightElement(sd1block);
$('#car1').carousel({fullwidth: true,
	duration:200,
	numVisible:5,
	dist:-100,
	shift:0,
	padding:0,
	indicators:true,
	onCycleTo: function(item, dragged) {},
	nowrap:false});
var sd2block = document.getElementById('sd2code');
Prism.highlightElement(sd2block);
$('#car0').carousel({fullwidth: true,
	duration:200,
	numVisible:5,
	dist:-100,
	shift:0,
	padding:0,
	indicators:true,
	onCycleTo: function(item, dragged) {},
	nowrap:false});
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
