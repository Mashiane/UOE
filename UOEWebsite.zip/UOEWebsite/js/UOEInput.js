
$(document).ready(function(){
M.AutoInit();
$('.fixed-action-btn.horizontal').floatingActionButton({direction: 'left'});
$('.fixed-action-btn.click-to-toggle').floatingActionButton({direction: 'left', hoverEnabled: false});
$('.fixed-action-btn.toolbar').floatingActionButton({toolbarEnabled: true});
$('select').not('.disabled').formSelect();
var cd1block = document.getElementById('cd1code');
Prism.highlightElement(cd1block);
M.updateTextFields();
var cd2block = document.getElementById('cd2code');
Prism.highlightElement(cd2block);
M.updateTextFields();
var cd3block = document.getElementById('cd3code');
Prism.highlightElement(cd3block);
M.updateTextFields();
var cd4block = document.getElementById('cd4code');
Prism.highlightElement(cd4block);
M.updateTextFields();
var cd5block = document.getElementById('cd5code');
Prism.highlightElement(cd5block);
M.textareaAutoResize($('#tarea'));
$('textarea#tarea').characterCounter();
$('input#tarea').characterCounter();
$('#navbardrawer').sidenav({draggable:true,preventScrolling:true,
	edge:'left'});
if (is_touch_device()) {
      $('#navbardrawer').css({ overflow: 'auto'});
    }
});
